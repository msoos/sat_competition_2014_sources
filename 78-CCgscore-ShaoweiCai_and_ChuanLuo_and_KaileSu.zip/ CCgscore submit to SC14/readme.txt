This is CCgscore version 2014.4
Author: Shaowei Cai.
Email: shaoweicai.cs@gmail.com

To build the solver, please run build.sh, and it will generate a new folder /binary and compile the codes to generate the CCgscore binary; 
additionally, the CCgscore binary will be copied to the /binary folder.

For SAT Competition 2014, Please run CCgscore as
./CCgscore <instance file> 
