#include "basis.h"
#include "ccgscore.h"
#include "cw.h"

#include <sys/times.h> //these two h files are for linux
#include <unistd.h>


int beta;
int theta;
int theta2;

struct tms start, stop;

float sigf;

#define sigscore	ave_weight*sigf   //significant score needed for aspiration

int pick_var_large()
{
	int         i,k,c,v;
	int         best_var,best_score,score_gap;
	lit*		clause_c;
	
	int tmp_score;

	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var = goodvar_stack[0];
		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			score_gap = (score[v] - score[best_var]) + (pscore[v] - pscore[best_var])/beta+ (time_stamp[best_var]-time_stamp[v])/theta;          
            if(score_gap>0)	best_var = v;
            else if(score_gap==0 && time_stamp[v]<time_stamp[best_var] ) best_var = v;
		}
		
		return best_var;
	}
    
	/**Diversification Mode**/

	update_clause_weights();
	
	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;

	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
        
        score_gap = (score[v] - score[best_var]) + (pscore[v] - pscore[best_var])/beta+ (time_stamp[best_var]-time_stamp[v])/theta2;          
        if(score_gap>0)	best_var = v;
        else if(score_gap==0 && time_stamp[v]<time_stamp[best_var] ) best_var = v;
	}
	
	return best_var;
}




//pick a var to be flip
float bp;
int pick_var_3SAT_huge()
{
	int         i,k,c,v;
	int         best_var,score_gap;
	lit*		clause_c;
	
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var=0;
		score[0]=0;
		
		for(i=0; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			
			if (cscc[v]==0) continue;
			
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var])
            {
                if (unsat_app_count[v]>unsat_app_count[best_var])  best_var=v;
                else if (unsat_app_count[v]==unsat_app_count[best_var]&& time_stamp[v]<time_stamp[best_var]) best_var=v;
            } 
		}
		
		if(best_var!=0) return best_var;
	}
	
	
	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];

	if( ((rand()%MY_RAND_MAX_INT)*BASIC_SCALE)<bp )
	{
		
		best_var = clause_c[0].var_num;
		for(k=0; k<clause_lit_count[c]; ++k)
		{
			v = clause_lit[c][k].var_num;
			
			if(unsat_app_count[v]-score[v] <  unsat_app_count[best_var]-score[best_var]) best_var = v;
			else if(unsat_app_count[v]-score[v] == unsat_app_count[best_var]-score[best_var])
			{
				score_gap = (score[v]-score[best_var])+ (time_stamp[best_var]-time_stamp[v])/theta2;
				if(score_gap>0)	best_var = v;
				else if(score_gap==0 && time_stamp[v]<time_stamp[best_var] ) best_var = v;
			}
		}
		return best_var;
		
	}
		
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	
	return best_var;
}



int pick_var_3SAT()
{
	int         i,k,c,v;
	int         best_var,best_score;
	lit*		clause_c;
	
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var = goodvar_stack[0];
		
		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
		}
		
		return best_var;
	}
	
		
	/**Diversification Mode**/
	update_clause_weights();
	
	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	//greedy
	best_score = sigscore;
	best_var = 0;
	
	for(k=0; k<clause_lit_count[c]; ++k)
	{
		v = clause_lit[c][k].var_num;
		if(score[v] > best_score)
		{
			best_var = v;
			best_score = score[v];
		}
	}
		
	if(best_var!=0) return best_var;
	
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	
	return best_var;
}



int (* pick_var) ();


//set functions in the algorithm
void set_functions()
{	
	if(probtype==SAT3||probtype==strSAT)
	{
		flip = flip_3SAT;
		pick_var = pick_var_3SAT;
		
		update_clause_weights = update_clause_weights_3sat;
		if (probtype==SAT3) threshold=200+(num_vars+250)/500;
		else threshold=300;
		sigf=0.6;
		
		scale_ave=(threshold+1)*q_scale;//when smoothing, ave_weight=threshold+1.
        
        if (probtype==SAT3 && ratio<4.225) {
        	
        	if ( (ratio<4.202 && num_vars>100000) || (ratio>=4.202 && num_vars>35000))
            {
                pick_var = pick_var_3SAT_huge;
                
                if (ratio<4.202) bp=0.51;
                else if (ratio<4.21) bp=0.5;
                else if (ratio<4.22) bp=0.495;
                else bp=0.492;
                
                theta2=10000;
                //cout<<"c pick minimum break with "<<bp<<endl;
                
            }
            //else cout<<"c call ccmr"<<endl;
        }
        //else cout<<"c call ccmr"<<endl;
	}
	else 
	{
		flip = flip_large;
        pick_var = pick_var_large;
        update_clause_weights = update_clause_weights_large_sat;
        
        if(probtype==SAT4)
		{
			beta=9;
			pscore_threshold=27;
			theta2=1500;
			
			//theta
			if(ratio<=9.21) theta=300000;
			else if (ratio<9.8) theta=200000;
			else if (ratio<9.91) theta=50000;
			else theta=10000;
			
			//smooth probability
			if (ratio<9.8) 
			{
				smooth_probability=0.6+(ratio-9.0)*0.1;
				if (smooth_probability<0.6) smooth_probability=0.6;
			}
			else smooth_probability=0.7;
		}
		
		else if(probtype==SAT5)
		{
			beta=8;
			
			//pscore_threshold
			if(ratio<=20.01) pscore_threshold=5;
			else if (ratio<=21.1) pscore_threshold=8;
			else pscore_threshold=32;
			
			//theta
			if (ratio<=20.01) theta=100000;
			else if(ratio<=20.4) theta=300000;
			else if(ratio<=20.9) theta=40000;
			else theta=10000;
			
			//theta2
			if (ratio<=20.9) theta2=2000;
			else theta2=1500;
			
			//smooth probability
			if (ratio<=20.5)
			{
				smooth_probability=0.62+(ratio-20.0)*0.15;	
				if (smooth_probability<0.62) smooth_probability=0.62;
			}
			else
			{
				smooth_probability=0.74+(ratio-20.6)*0.15;	
				if (smooth_probability>0.8) smooth_probability=0.8;
			}
			
		}
		else if(probtype==SAT6)
		{
			beta=7;
			
			if (ratio<40.5) smooth_probability=0.88;
			else smooth_probability=0.9;
			
			if(ratio<42.5)
			{
				pscore_threshold=7;
				theta=20000;
				theta2=2000;
			}
			else 
			{
				pscore_threshold=10;
				theta=8000;
				theta2=1400;
			} 
		}
		else {
			beta=6;

			if (ratio<85.2) pscore_threshold=20;
			else pscore_threshold=30;
			
			theta=6000;
			theta2=2000;	
			smooth_probability=0.92;		
		}
		
		/*cout<<"c using gscore"<<endl;
		cout<<"c beta = "<<beta<<endl;
		cout<<"c score_2 threshold = "<<pscore_threshold<<endl;
		cout<<"c theta = "<<theta<<endl;
		cout<<"c theta_2 = "<<theta2<<endl;
		cout<<"c smooth prob = "<<smooth_probability<<endl;*/
	}
}

//int cutoff;
void local_search(int max_flips)
{
	int flipvar;
	int k;
     
	for (step = 0; step<max_flips; step++)
	{
		//find a solution
		if(unsat_stack_fill_pointer==0) return;
		
		flipvar = pick_var();

		flip(flipvar);
		
		time_stamp[flipvar] = step;
        
        /*if (step%10000==0) {
            times(&stop);
            double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);
            if (comp_time>cutoff) return;
        }*/
	}
}


int main(int argc, char* argv[])
{
	int     seed,i;
	cout<<"c this is CCgscore version 2014"<<endl;
	cout<<"c copyright belongs to its author: Shaowei Cai"<<endl;
     
	//struct tms start, stop;
	times(&start);

	if (build_instance(argv[1])==0)
	{
		cout<<"Invalid filename: "<< argv[1]<<endl;
		return -1;
	}
     
	seed=time(0)%3;
    if (argc>2) sscanf(argv[2],"%d",&seed);
    
    set_functions();

    srand(seed);

	for (i = 0; i <= max_tries; i++) 
	{
		 init();
		 
		 times(&stop);
	 
		 local_search(max_flips);

		 if (unsat_stack_fill_pointer==0) break;
	}

	times(&stop);
	double comp_time = double(stop.tms_utime - start.tms_utime +stop.tms_stime - start.tms_stime) / sysconf(_SC_CLK_TCK);

     //print out information about the solution.
	if(unsat_stack_fill_pointer==0)
	{
		//if(verify_sol()==1)
		//{
			//printf("%s %d sat %d %lf \n",argv[1],seed,step,comp_time);
			
			cout<<"s SATISFIABLE"<<endl;
			print_solution();
			
			cout<<"c tries = "<<i<<", steps = "<<step<<endl;
			cout<<"c solveTime = "<<comp_time<<endl;
		// }
		//else cout<<"Sorry, something is wrong."<<endl;
	 }
	 else  cout<<"s UNKNOWN"<<endl;
	 
	free_memory();

    return 0;
}
