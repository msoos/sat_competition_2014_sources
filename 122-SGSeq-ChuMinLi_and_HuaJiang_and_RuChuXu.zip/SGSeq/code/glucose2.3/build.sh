#!/bin/bash

mkdir binary

cd code/glucose2.3/simp
make rs
cp glucose_static ../../../binary/glucose

 
