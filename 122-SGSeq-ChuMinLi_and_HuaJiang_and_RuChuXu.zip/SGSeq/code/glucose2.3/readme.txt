Solver name : glucose
Solver version : 2.3
Authors : Gilles Audemard and Laurent Simon


For compiling : 
   ./build.sh

For running 
glucose BENCHNAME
