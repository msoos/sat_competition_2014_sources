#!/bin/bash
rm -r binary
mkdir binary

cp code/start_sattime.sh binary/
cp code/SGSeq.sh binary/
cd code/sattime2013 
gcc sattime2013.c -O3 -static  -o sattime
cp sattime ../../binary
cd ../glucose2.3
./clean.sh
./build.sh
cp ./binary/glucose ../../binary




 
