
SGSeq Copyright (c) 2013, 2014, Chu Min LI ,Hua Jiang and Ru Chu Xu

To build executables: 

./build.sh


For running:
 
Go to the folder /binary then launch SGS by: ./SGSeq.sh InstanceName -s SEED 




