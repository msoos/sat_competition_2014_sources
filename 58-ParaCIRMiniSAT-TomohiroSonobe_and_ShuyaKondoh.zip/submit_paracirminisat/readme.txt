Name: ParaCIRMiniSAT
Author: Tomohiro SONOBE

ParaCIRMiniSAT is based on MiniSAT 2.2 parallelised by OpenMP.


================================================================================
DIRECTORY (code) OVERVIEW:

mtl/            Mini Template Library
utils/          Generic helper code (I/O, Parsing, CPU-time, etc)
core/           A core version of the solver
simp/           An extended solver with simplification capabilities
README
LICENSE

================================================================================
BUILDING: (release version: without assertions, statically linked, etc)

export MROOT=<minisat-dir>              (or setenv in cshell)
cd { simp }
gmake rs
cp paracirminisat <install-dir>/paracirminisat

================================================================================
EXAMPLES:

> <install-dir>/paracirminisat -thread-num=12 <cnf-file>
