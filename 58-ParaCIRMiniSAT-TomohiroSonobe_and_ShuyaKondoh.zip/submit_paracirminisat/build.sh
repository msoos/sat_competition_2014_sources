#! /bin/sh

mkdir binary
cur_dir=`pwd`
export MROOT=$cur_dir/code
cd $cur_dir/code/simp
make rs
cp ./paracirminisat_static $cur_dir/binary/paracirminisat

