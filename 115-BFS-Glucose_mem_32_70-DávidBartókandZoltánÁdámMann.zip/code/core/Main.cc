/*****************************************************************************************[Main.cc]
 BFS-Glucose -- Copyright (c) 2014, David Bartok, Zoltan Adam Mann

BFS-Glucose sources are based on Glucose (see below Glucose copyrights). Permissions and copyrights of
BFS-Glucose are exactly the same as Glucose which it is based on. (see below).

---------------

 Glucose -- Copyright (c) 2009, Gilles Audemard, Laurent Simon
				CRIL - Univ. Artois, France
				LRI  - Univ. Paris Sud, France

Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose are exactly the same as Minisat which it is based on. (see below).

---------------

Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#define INFINITE 2000000 ///* constant for infinite

#include <errno.h>

#include <cstdlib>
#include <ctime>
#include <signal.h>
//#include "zlib/zlib.h"

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "core/Solver.h"

using namespace Glucose;

//=================================================================================================

///* time variables, BFS structure, occurence comparator

extern int assumpCount;

struct BestFirst
{
    Solver* Slv;
    double score;
};

int assump_vars;

int occurcmp(const void* p1, const void* p2) ///* assump_vars=1 -> increasing order \\ -1 -> decreasing order
{
    var_occur* b1=(var_occur*)p1;
    var_occur* b2=(var_occur*)p2;
    if(b1->activity > b2->activity)
    {
        if(assump_vars==1)
            return 1;
        else return -1;
    }

    if(b1->activity == b2->activity)
    {
        return 0;
    }

    if (assump_vars==1)
    {
        return -1;
    }
    else return 1;
}
///*

//=================================================================================================


void printStats(Solver& solver)
{
    double cpu_time = cpuTime();
    double mem_used = 0;//memUsedPeak();
    printf("c restarts              : %"PRIu64" (%"PRIu64" conflicts in avg)\n", solver.starts,(solver.starts>0 ?solver.conflicts/solver.starts : 0));
    printf("c blocked restarts      : %"PRIu64" (multiple: %"PRIu64") \n", solver.nbstopsrestarts,solver.nbstopsrestartssame);
    printf("c last block at restart : %"PRIu64"\n",solver.lastblockatrestart);
    printf("c nb ReduceDB           : %lld\n", solver.nbReduceDB);
    printf("c nb removed Clauses    : %lld\n",solver.nbRemovedClauses);
    printf("c nb learnts DL2        : %lld\n", solver.nbDL2);
    printf("c nb learnts size 2     : %lld\n", solver.nbBin);
    printf("c nb learnts size 1     : %lld\n", solver.nbUn);

    printf("c conflicts             : %-12"PRIu64"   (%.0f /sec)\n", solver.conflicts   , solver.conflicts   /cpu_time);
    printf("c decisions             : %-12"PRIu64"   (%4.2f %% random) (%.0f /sec)\n", solver.decisions, (float)solver.rnd_decisions*100 / (float)solver.decisions, solver.decisions   /cpu_time);
    printf("c propagations          : %-12"PRIu64"   (%.0f /sec)\n", solver.propagations, solver.propagations/cpu_time);
    printf("c conflict literals     : %-12"PRIu64"   (%4.2f %% deleted)\n", solver.tot_literals, (solver.max_literals - solver.tot_literals)*100 / (double)solver.max_literals);
    printf("c nb reduced Clauses    : %lld\n",solver.nbReducedClauses);

    if (mem_used != 0) printf("Memory used           : %.2f MB\n", mem_used);
    printf("c CPU time              : %g s\n", cpu_time);
}


static Solver* solver;
// Terminate by notifying the solver and back out gracefully. This is mainly to have a test-case
// for this feature of the Solver as it may take longer than an immediate call to '_exit()'.
static void SIGINT_interrupt(int signum) { solver->interrupt(); }

// Note that '_exit()' rather than 'exit()' has to be used. The reason is that 'exit()' calls
// destructors and may cause deadlocks if a malloc/free function happens to be running (these
// functions are guarded by locks for multithreaded use).
static void SIGINT_exit(int signum) {
    printf("\n"); printf("*** INTERRUPTED ***\n");
    if (solver->verbosity > 0){
//        printStats(*solver);
        printf("\n"); printf("*** INTERRUPTED ***\n"); }
    _exit(1); }


//=================================================================================================
// Main:


int main(int argc, char** argv)
{
  printf("c\nc This is BFS-Glucose 1.0 --  based on Glucose and MiniSAT (Many thanks to respective teams)\nc\n");
    try {
        setUsageHelp("c USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        // printf("This is MiniSat 2.0 beta\n");

#if defined(__linux__)
        fpu_control_t oldcw, newcw;
        _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
        printf("c WARNING: for repeatability, setting FPU to use double precision\n");
#endif
        // Extra options:
        //
        IntOption    verb   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 1, IntRange(0, 2));
        BoolOption   mod   ("MAIN", "model",   "show model.", false);
        IntOption    vv  ("MAIN", "vv",   "Verbosity every vv conflicts", 10000, IntRange(1,INT32_MAX));
        IntOption    cpu_lim("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
        IntOption    mem_lim("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));


        parseOptions(argc, argv, true);

        ///*hardwired parameters
        int numSolvers=32;
        int heuristic=7;
        int limit_in=100;
        int limit_new=105;
        assump_vars=-1;
        int w1=-100;
        int w2=-100;
        int w3=100;
        int w4=100;
        int w5=100;
        int w6=-100;
        int w7=0;
        int w8=-100;
        int resbfs=1;
        ///*

         ///*   Solver S;
        double initial_time = cpuTime();

        vec<BestFirst*> S; ///*BFS vector
        Solver* toAnalyze=NULL; ///* the solver to be analyzed

        FILE* res; ///*brought out of the for loop
        ///* print some info for test purposes
        printf("c *****************\n");
        printf("c *numSolvers=%4d*\n",numSolvers);
        printf("c *limit=%4d     *\n",limit_in);
        printf("c *increase=%4d  *\n",limit_new);
        printf("c *a_vars=%4d    *\n",assump_vars);
        printf("c *Weight 1=%4d  *\n",w1);
        printf("c *Weight 2=%4d  *\n",w2);
        printf("c *Weight 3=%4d  *\n",w3);
        printf("c *Weight 4=%4d  *\n",w4);
        printf("c *Weight 5=%4d  *\n",w5);
        printf("c *Weight 6=%4d  *\n",w6);
        printf("c *Weight 7=%4d  *\n",w7);
        printf("c *Weight 8=%4d  *\n",w8);
        printf("c *restarts=%4d  *\n",resbfs);
        printf("c *****************\n");
        ///*
        ///*
        FILE* fp;
        fp=fopen(argv[1],"rb");
        fseek(fp, 0L, SEEK_END);
        long int sz = ftell(fp);
        fclose(fp);
//        printf("Size: %d\n",sz);
        double sizeMB=(double)sz/1024/1024;
//        printf("SizeMB: %f\n",sizeMB);
        double memPerSolver=sizeMB*3; ///* experimental formula
        double maxMem = 11000;
        while(memPerSolver*numSolvers>maxMem*0.7)
        {
            numSolvers/=2;
            if(numSolvers==1)
                break;
        }
        printf("c NumSolvers decreased to: %d\n",numSolvers);
        ///*

FILE* in; ///* brought to the outside for visibility
///*Initialization of the solvers

for(int ii=0; ii<=numSolvers; ii++)
    {
        ///*
        BestFirst* tmp=new BestFirst;
        S.push(tmp);
        S[ii]->score=INFINITE;


        S[ii]->Slv=new Solver;

        ///*

        S[ii]->Slv->verbosity = verb;
        S[ii]->Slv->verbEveryConflicts = vv;
        S[ii]->Slv->showModel = mod;
       ///* solver = &S; static variable, not necessary
        // Use signal handlers that forcibly quit until the solver will be able to respond to
        // interrupts:
	//        signal(SIGINT, SIGINT_exit);
        //signal(SIGXCPU,SIGINT_exit);

         //MZ
        // Set limit on CPU-time:
//        if (cpu_lim != INT32_MAX){
//            rlimit rl;
//            getrlimit(RLIMIT_CPU, &rl);
//            if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max){
//                rl.rlim_cur = cpu_lim;
//                if (setrlimit(RLIMIT_CPU, &rl) == -1)
//                    printf("c WARNING! Could not set resource limit: CPU-time.\n");
//            } }
//
//        // Set limit on virtual memory:
//        if (mem_lim != INT32_MAX){
//            rlim_t new_mem_lim = (rlim_t)mem_lim * 1024*1024;
//            rlimit rl;
//            getrlimit(RLIMIT_AS, &rl);
//            if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
//                rl.rlim_cur = new_mem_lim;
//                if (setrlimit(RLIMIT_AS, &rl) == -1)
//                    printf("c WARNING! Could not set resource limit: Virtual memory.\n");
//            } }
         //MZ

        if (argc == 1)
            printf("c Reading from standard input... Use '--help' for help.\n");

        in = (argc == 1) ? fopen(0, "rb") : fopen(argv[1], "rb");
        if (in == NULL)
            printf("c ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);

        if (S[ii]->Slv->verbosity > 0 && ii==0){ ///* print only the first time
            printf("c ========================================[ Problem Statistics ]===========================================\n");
            printf("c |                                                                                                       |\n"); }
    }///*END OF FOR LOOP

            ///* we build the clause database at the same time for every solver, so this part is removed from the for loop
            parse_DIMACS(in, S, numSolvers); ///* the whole solver list is transferred and also numSolvers
            fclose(in);

for(int ii=0; ii<=numSolvers; ii++)
    {
       ///* FILE* res = (argc >= 3) ? fopen(argv[argc-1], "wb") : NULL;
       res = (argc >= 3) ? fopen(argv[argc-1], "wb") : NULL;



        if (S[ii]->Slv->verbosity > 0 && ii==0){ ///*
            printf("c |  Number of variables:  %12d                                                                   |\n", S[ii]->Slv->nVars());
            printf("c |  Number of clauses:    %12d                                                                   |\n", S[ii]->Slv->nClauses()); }

        double parsed_time = cpuTime();
        if (S[ii]->Slv->verbosity > 0 && ii==0){ ///*
            printf("c |  Parse time:           %12.2f s                                                                 |\n", parsed_time - initial_time);
            printf("c |                                                                                                       |\n"); }

        // Change to signal-handlers that will only notify the solver and allow it to terminate
        // voluntarily:
        //signal(SIGINT, SIGINT_interrupt);
        //signal(SIGXCPU,SIGINT_interrupt);

        if (!S[ii]->Slv->simplify()){
            if (S[ii]->Slv->certifiedOutput != NULL) fprintf(S[ii]->Slv->certifiedOutput, "0\n"), fclose(S[ii]->Slv->certifiedOutput);
            if (res != NULL) fprintf(res, "UNSAT\n"), fclose(res);
            if (S[ii]->Slv->verbosity > 0){
	        printf("c =========================================================================================================\n");
                printf("Solved by unit propagation\n");
//                printStats(*(S[ii]->Slv));
                printf("\n"); }
            printf("s UNSATISFIABLE\n");
            exit(20);
        }
    }
///*end of initialization

///*begin of assumptions
     ///*   vec<Lit> dummy;
     ///*   lbool ret = S.solveLimited(dummy);
    if(assump_vars!=0)
    {
            qsort(occurdata, myvars, sizeof(var_occur), occurcmp);
    }
        vec<Lit>* myAssump=new vec<Lit> [numSolvers]; ///* assumption arrays

        int binary;
        Lit L;
        int cntr;
        for(int ii=0; ii<numSolvers; ii++) ///* creating assumption arrays
        {
            cntr=0;
            binary=ii; ///* Assumption in binary form, e.g. 6=110b-> x0, x1!, x2!
            for(int jj=numSolvers; jj>1; jj/=2) ///* number of assumptions = log(2) numSolvers
            {
                L=mkLit(occurdata[cntr++].index, binary%2);
                S[ii]->Slv->assumptions.push(L);
                binary/=2;
            }
        }
///*end of assumptions


///*the BFS
        lbool retDone=l_Undef; ///* result of the "winning" solver
        lbool retCurr=l_Undef; ///* current returned value

        bool satisfied=false; ///* TRUE, if the problem is SAT
        bool active_solver=true; ///* TRUE, if we still have an active solver
        int current=0; ///* index of running solver

        double maxscore=0; ///*maximal score so far
        int limit=limit_in; ///*conflict limit on solver
        int counter=-1; ///* counts the number of runs (total, among all solvers)
        while(!satisfied && active_solver)
        {
            counter++;
            if(counter>numSolvers)
            {
             //   fprintf(diag, "--change of limit-- \n", current);
                limit*=((double)limit_new/100); ///*increasing limit
            }
          //  fprintf(diag, "to be run: No %d \n",current);

            retCurr=S[current]->Slv->solve_(limit); ///*calling the solve function


//            fprintf(diag,"================================================================\n");
//            fprintf(diag, "Current solver is No. %d\n", current);
//            fprintf(diag, "limit %d \n",limit);
//            fprintf(diag, "Score: %f\n", S[current]->score);


//Heuristic elements:

//currentDepth: nAssigns()
//maxDepth: maxDepth
//averageDepth: avgDepth
//averageLearntClauseLength learnts_literals/nLearnts() := avgLearntClauseLength
//decisionLevel: decisionLevel
//maxDecisionLevel: maxDecisionLevel
//steps ~ propagations
//LBD: avgLBD
//


            if(retCurr==l_Undef)
            {
                ///*custom weights
                S[current]->score=  w1*S[current]->Slv->N_nAssigns()+
                                    w2*S[current]->Slv->N_maxDepth()+
                                    w3*S[current]->Slv->N_avgDepth()+
                                    w4*S[current]->Slv->N_avgLearntClauseLength()+
                                    w5*S[current]->Slv->N_decisionLevel()+
                                    w6*S[current]->Slv->N_maxDecisionLevel()+
                                    w7*S[current]->Slv->N_propagations()+
                                    w8*S[current]->Slv->N_avgLBD();
                ///*

///*                debugging
///*                printf("%f %f %f %f %f %f %f %f\n",S[current]->Slv->N_nAssigns(),
///*                                                S[current]->Slv->N_maxDepth(),
///*                                                S[current]->Slv->N_avgDepth(),
///*                                                S[current]->Slv->N_avgLearntClauseLength(),
///*                                                S[current]->Slv->N_decisionLevel(),
///*                                                S[current]->Slv->N_maxDecisionLevel(),
///*                                                S[current]->Slv->N_propagations(),
///*                                                S[current]->Slv->N_avgLBD());
//
//                printf("%d %d \n",S[current]->Slv->decisionLevel(), S[current]->Slv->dbg() );
//               printf("w: %d %d %d %d %d %d %d \n",w1,w2,w3,w4,w5,w6,w7);
///*
                if(resbfs)
                    {
                        int bt = 0;
                        if(S[current]->Slv->incremental)
                            { // DO NOT BACKTRACK UNTIL 0.. USELESS ///* (?)
                                bt = (S[current]->Slv->decisionLevel()<S[current]->Slv->assumptions.size()) ? S[current]->Slv->decisionLevel() : S[current]->Slv->assumptions.size();
                            }
                        S[current]->Slv->cancelUntil(bt);
                    }


               // printf("N1: %f N2: %f\n",S[current]->Slv->N_nAssigns(), S[current]->Slv->N_maxDepth());

                //fprintf(diag, "newScore: %f\n", S[current]->score);
                maxscore=S[current]->score;

                for(int ii=0; ii<numSolvers; ii++)
                {
                    if(S[ii]->Slv!=NULL && S[ii]->score>maxscore)
                    {
                        current=ii;
                        maxscore=S[ii]->score;
                    }
                }
                continue; ///* this is probably the most often occuring case
            }

            else if(retCurr==l_True)
            {
                //fprintf(diag, "This solver returned SAT.\n");
                retDone=retCurr;
                toAnalyze=S[current]->Slv;
                satisfied=true;
                break;
            }

            else if(retCurr==l_False)
            {
              //  fprintf(diag, "This solver returned UNSAT.\n");
                S[current]->Slv->cancelUntil(0);
                delete S[current]->Slv;
                S[current]->Slv=NULL;

                active_solver=false;
                for(int ii=0; ii<numSolvers; ii++)
                {
                    if (S[ii]->Slv!=NULL)
                    {
                        current=ii;
                        active_solver=true;
                    }
                }
                maxscore=0;
                for(int ii=0; ii<numSolvers; ii++)
                {
                    if(S[ii]->Slv != NULL && S[ii]->score>maxscore)
                    {
                        current=ii;
                        maxscore=S[ii]->score;
                    }
                }
            }
        }

//        cntr=0;
//        for(int ii=numSolvers; ii>1; ii/=2)
//        {
//            S[numSolvers]->Slv->assumptions.push(S[current]->Slv->assumptions[cntr++]);
//        }
//        S[numSolvers]->Slv->assumptions.push(S[current]->Slv->assumptions[0]);
//        S[numSolvers]->Slv->assumptions.push(S[current]->Slv->assumptions[1]);
//        S[numSolvers]->Slv->assumptions.push(S[current]->Slv->assumptions[2]);
//        retDone=S[numSolvers]->Slv->solve_(0);
//        toAnalyze=S[numSolvers]->Slv;
///*end of BFS


///*
if(active_solver==false)
        {
            retDone=l_False; ///* unsat
        }
        if(active_solver==true)
        if (toAnalyze->verbosity > 0){
//            printStats(*toAnalyze);
            printf("\n"); }
///*

       //-------------- Result is put in a external file
        if (res != NULL){
	  if (retDone == l_True){
	    fprintf(res, "SAT\n");
	    fprintf(res, "SAT\n");
	    for (int i = 0; i < toAnalyze->nVars(); i++)
	      if (toAnalyze->model[i] != l_Undef)
		fprintf(res, "%s%s%d", (i==0)?"":" ", (toAnalyze->model[i]==l_True)?"":"-", i+1);
	    fprintf(res, " 0\n");
	  }else if (retDone == l_False)
	    fprintf(res, "UNSAT\n");
	  else
	    fprintf(res, "INDET\n");
	  fclose(res);

	//-------------- Want certified output
        } else {
	  printf(retDone == l_True ? "s SATISFIABLE\n" : retDone == l_False ? "s UNSATISFIABLE\n" : "s INDETERMINATE\n");
	 ///* if(toAnalyze->showModel && retDone==l_True) {
        if(retDone==l_True) { ///* toAnalyte is not valid if unsat
	    printf("v ");
	    for (int i = 0; i < toAnalyze->nVars(); i++)
	      if (toAnalyze->model[i] != l_Undef)
		printf("%s%s%d", (i==0)?"":" ", (toAnalyze->model[i]==l_True)?"":"-", i+1);
	    printf(" 0\n");
	  }
	}

///*free memory
    for(int ii=0; ii<=numSolvers; ii++)
    {
        if(S[ii]!=NULL)
        {
            delete S[ii]; ///*free solver instances
        }
    }
    delete[] myAssump;
///*

#ifdef NDEBUG
        exit(ret == l_True ? 10 : ret == l_False ? 20 : 0);     // (faster than "return", which will invoke the destructor for 'Solver')
#else
        return (retDone == l_True ? 10 : retDone == l_False ? 20 : 0);
#endif
    } catch (OutOfMemoryException&){
      printf("c ===================================================================================================\n");
        printf("INDETERMINATE\n");
        exit(25);
    }
}
