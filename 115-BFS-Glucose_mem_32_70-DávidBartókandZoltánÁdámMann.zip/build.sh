mkdir binary
g++ -O3 -c code/core/Main.cc -I code -o binary/Main.o
g++ -O3 -c code/core/Solver.cc -I code -o binary/Solver.o
g++ -O3 -c code/utils/Options.cc -I code -o binary/Options.o
g++ -O3 -c code/utils/System.cc -I code -o binary/System.o
g++ -o binary/BFSglucose binary/Main.o binary/Solver.o binary/Options.o binary/System.o
rm binary/Main.o binary/Solver.o binary/System.o binary/Options.o 