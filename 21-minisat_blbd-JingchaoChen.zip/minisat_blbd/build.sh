#!/bin/bash

mkdir -p binary 
cd code
export MROOT=$PWD

cd simp
make r
cp minisat_release ../../binary/minisat_blbd
 
