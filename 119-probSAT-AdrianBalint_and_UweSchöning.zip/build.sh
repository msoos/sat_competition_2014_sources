#!/bin/sh
cd code
make
cd ..
rm -rf binary
mkdir binary
cp code/probSAT binary/probSAT
echo "build done"