
----------------------------
satUZK
----------------------------
	Version: satUZK 55 Light
	Authors: Alexander van der Grinten, Andreas Wotzlaw and Ewald Speckenmeyer
	University of Cologne

----------------------------
How to build
----------------------------
	./build.sh builds the solver, the bundled version of SatELite and
	a wrapper that invokes both.
	
	GCC 4.7 is required to build the solver.

----------------------------
How to use
----------------------------
	satUZK-seq is the basic sequential solver and accepts a SAT instance
	in DIMACS CNF format. satUZK-par is our parallel version.

----------------------------
Competition versions
----------------------------
	We are using the following configurations for the SAT Competition 2014:
	
	Sequential SAT+UNSAT tracks:
	./satUZK_wrapper TEMPDIR ./satUZK-seq INSTANCE
	
	Sequential certified UNSAT tracks:
	./satUZK-seq -drat-proof INSTANCE
	
	Parallel SAT+UNSAT:
	./satUZK_wrapper TEMPDIR ./satUZK-par INSTANCE

