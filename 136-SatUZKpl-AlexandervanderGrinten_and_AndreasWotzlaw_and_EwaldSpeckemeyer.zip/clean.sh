#!/bin/sh

rm -rf binary

rm -f code/satUZK/satUZK-seq
rm -f code/satUZK/satUZK-par

cd code/satelite
./clean.sh
cd ../..
rm -f code/satelite/SatELite_release

rm -f code/satUZK_wrapper/satUZK_wrapper

