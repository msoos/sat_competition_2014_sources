#!/bin/sh

cd SatELite_from_Glucose2.0
rm -f ForMani/ADTs/depend.mak
rm -f ForMani/Global/depend.mak
export FM=$PWD/ForMani
cd SatELite
make realclean

