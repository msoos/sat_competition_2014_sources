
namespace satuzk {

enum SolveState {
	kStateUnknown,
	kStateBreak,
	kStateSatisfied,
	kStateUnsatisfiable,
	kStateAssumptionFail
};

/* luby sequence:
	t(i) = 2^(k-1)				if i = 2^k - 1
	t(i) = t(i - 2^(k-1) + 1)	if 2^(k-1) <= i < 2^k - 1 */
inline unsigned int lubySequence(unsigned int i) {
	while(i != 0) {
		// calculate k maximal so that i <= 2^k - 1
		unsigned int rem = i;
		unsigned int k = 0;
		unsigned int kpow = 1; // k-th power of 2
		while(rem != 0) {
			k++;
			rem /= 2;
			kpow *= 2;
		}
		
		// first case: t(i) = 2^(k-1)
		if(i == kpow - 1)
			return kpow / 2;
		// second case: t(i) = t(i - 2^(k-1) + 1)
		i = i - kpow / 2 + 1;
	}
	return 1;
}

template<typename Config>
class VarHeapHooks {
public:
	typedef uint32_t index_type;
	typedef typename Config::variable_type heap_item;
	
	static const uint32_t ILLEGAL_INDEX = (index_type)(-1);

	VarHeapHooks(Config &config) : p_config(config) { }

	bool is_less(heap_item left, heap_item right) {
		/* NOTE: we want a maximum heap so we are comparing for ">" */
		return p_config.var_activity(left) > p_config.var_activity(right);
	}

	void on_init(heap_item variable, index_type index) {
//		std::cout << "Inserting " << variable << " into heap" << std::endl;
		SYS_ASSERT(SYS_ASRT_GENERAL, p_config.p_varConfig.get_heap_info(variable).heap_index
				== ILLEGAL_INDEX);
		p_config.p_varConfig.get_heap_info(variable).heap_index = index;
	}
	void on_remove(heap_item variable) {
//		std::cout << "Removing " << variable << " from heap" << std::endl;
		SYS_ASSERT(SYS_ASRT_GENERAL, p_config.p_varConfig.get_heap_info(variable).heap_index
				!= ILLEGAL_INDEX);
		p_config.p_varConfig.get_heap_info(variable).heap_index = ILLEGAL_INDEX;
	}
	void on_update(heap_item variable, index_type index) {
		SYS_ASSERT(SYS_ASRT_GENERAL, p_config.p_varConfig.get_heap_info(variable).heap_index
				!= ILLEGAL_INDEX);
		p_config.p_varConfig.get_heap_info(variable).heap_index = index;
	}

	index_type get_index(heap_item variable) {
		return p_config.p_varConfig.get_heap_info(variable).heap_index;
	}

	uint32_t get_heap_size() {
		return p_config.heap_size;
	}
	void inc_heap_size() {
		p_config.heap_size++;
	}
	void dec_heap_size() {
		p_config.heap_size--;
	}

	heap_item read(index_type index) {
		return p_config.p_heapArray[index];
	}
	void write(index_type index, heap_item variable) {
		p_config.p_heapArray[index] = variable;
	}

private:
	Config &p_config;
};

template<typename BaseDefs, typename Hooks>
class Config {
public:
	typedef typename BaseDefs::LiteralId literal_type;
	typedef typename BaseDefs::LiteralId variable_type;
	typedef typename BaseDefs::ClauseId clause_type;
	typedef typename BaseDefs::ClauseLitIndex litindex_type;
	typedef typename BaseDefs::Order order_type;
	typedef typename BaseDefs::Activity activity_type;
	typedef typename BaseDefs::DecLevel declevel_type;
	
	static const variable_type kIllegalVar = (variable_type)(-1);
	static const literal_type kIllegalLit = (literal_type)(-1);
	static const clause_type kIllegalClause = (clause_type)(-1);

	static const int kClauseAlignment = 8;

	typedef Config<BaseDefs, Hooks> config_type;

	typedef antecedent_struct<BaseDefs> antecedent_type;
	typedef conflict_struct<BaseDefs> conflict_type;
	typedef SolutionDesc<BaseDefs> SolutionType;

public:
	typedef vars::Config<BaseDefs> var_config_type;
	typedef packed_clause::Config<BaseDefs> clause_config_type;

	typedef typename clause_config_type::head_type clause_head_type;

	typedef uint64_t clause_sig_type;

	typedef problem::sat::prop::config_struct
			<literal_type, order_type, declevel_type> prop_config_type;

	typedef problem::sat::first_uip::config_struct
			<variable_type, literal_type> learn_config_type;

	typedef VarHeapHooks<config_type> var_heap_hooks_type;

public:
	typedef typename var_config_type::occur_iterator occur_iterator;

	typedef typename var_config_type::watchlist_iterator watch_iterator;
	typedef typename var_config_type::watchlist_entry watch_entry_type;
	typedef typename var_config_type::watchlist_entry watchlist_entry;
	
	typedef typename clause_config_type::index_iterator clause_iterator;
	typedef packed_clause::iterator_struct
			<clause_config_type> ClauseLitIterator;

	typedef cause_iterator_struct<config_type> AntecedentIterator;
	typedef conflict_iterator_struct<config_type> ConflictIterator;

	typedef problem::sat::extmodel::config_struct extmodel_config_type;
	typedef problem::sat::extmodel::stack_allocator extmodel_alloc_type;

public:
	Config(Hooks hooks, int config_id) : p_hooks(hooks), p_configId(config_id),
			p_conflictDesc(conflict_type::make_none()),
			p_solutionDesc(SolutionType::makeNone()),
			maintainOcclists(false),
			conflictNum(0),
			currentAssignedVars(0),
			currentActiveClauses(0), currentEssentialClauses(0),
			heap_size(0) {
		/* allocate memory for clauses */
		uint32_t clause_memsize = 4 * 1024 * 1024;
//		std::cout << "c [GC    ] Initial clause space: " << (clause_memsize / 1024) << " kb" << std::endl;
		void *memory = operator new(clause_memsize);
		p_clauseConfig.p_allocator.init_memory(memory, clause_memsize);

		p_rndEngine.seed(0x12345678);
		
		perf.preproc_time = 0;
		perf.inproc_time = 0;
		perf.fact_elim_time = 0;

		opts.general.verbose = 0;
		opts.general.budget = 0;
		opts.general.timeout = 0;
		opts.general.permutate_input = false;
		
		opts.preproc.model = kPreprocNone;
		opts.preproc.with_scc = true;
		opts.preproc.with_fle2 = false;
		opts.preproc.with_hle = false;
		opts.preproc.with_selfsub = true;
		opts.preproc.with_vecd = true;
		opts.preproc.with_bce = true;
		opts.preproc.with_dist = false;
		opts.preproc.with_unhiding = true;
		opts.preproc.with_brm = true;
		opts.preproc.iterations = 1;

		opts.inproc.model = kInprocNone;
		opts.inproc.with_dist = true;
		opts.inproc.with_unhiding = true;
		opts.inproc.with_brm = true;
		
		opts.simp.dist_min_length = 8;
		
		opts.clauseRed.model = kClauseRedAgile;
		opts.clauseRed.agileBaseInterval = 500;
		opts.clauseRed.agileSlowdown = 100;
		opts.clauseRed.geomIncFactor = 1.5f;
		opts.clauseRed.geomSizeFactor = 1.1f;

		opts.restart.strategy = kRestartLuby;

		state.general.start_time = util::performance::current();
		state.general.stop_solve = false;
		
		state.search.varActInc = 1.0f;
		state.search.varActFactor = 1.05f;
		state.search.clauseActInc = 1.0f;
		state.search.clauseActFactor = 1.05f;

		state.restart.lubyCounter = 100;
		state.restart.lubyPeriod = opts.restart.lubyScale
			* lubySequence(stat.search.restarts);
		
		state.restart.glucose_short_buffer = new declevel_type[opts.restart.glucose_short_interval];
		for(unsigned int i = 0; i < opts.restart.glucose_short_interval; ++i)
			state.restart.glucose_short_buffer[i] = 0;
		state.restart.glucose_short_pointer = 0;
		state.restart.glucose_counter = 0;
		state.restart.glucose_short_sum = 0;
		state.restart.glucose_long_sum = 0;

		if(kReportEnable)
			p_reporter.open(p_configId);
	}

	~Config() {
		delete[] state.restart.glucose_short_buffer;
		operator delete(p_clauseConfig.p_allocator.get_memory());
	}

	Config(const Config &) = delete;
	Config &operator= (const Config &) = delete;

	int getConfigId() { return p_configId; }

	/* ----------------- variable related functions --------------- */

	lbool_type var_state(variable_type var) {
		if(!varAssigned(var))
			return lundef();
		return (varOne(var) ? ltrue() : lfalse());
	}

	activity_type var_activity(variable_type var) {
		return p_varConfig.get_heap_info(var).activity;
	}

	/* returns true if the model value of the variable is one */
	bool model_get_variable(variable_type var) {
		return p_varConfig.get_varflag_model(var);
	}
	void model_set_variable(variable_type var, bool value) {
		p_varConfig.clear_varflag_model(var);
		if(value)
			p_varConfig.set_varflag_model(var);
	}
	/* returns true if the model value of the literal is true */
	bool model_get_literal(literal_type lit) {
		if(isOneLiteral(lit))
			return model_get_variable(litVariable(lit));
		return !model_get_variable(litVariable(lit));
	}
	void model_set_literal(literal_type lit) {
		if(isOneLiteral(lit))
			return model_set_variable(litVariable(lit), true);
		return model_set_variable(litVariable(lit), false);
	}
	
	lbool_type lit_state(literal_type lit) {
		return var_state(litVariable(lit)) ^ !isOneLiteral(lit);
	}

	
	/* ------------------ clause related functions ----------------- */
	clause_head_type *clause_head(clause_type clause) {
		return p_clauseConfig.get_head(clause);
	}
	typename clause_config_type::tail_type *clause_tail(clause_type clause) {
		return p_clauseConfig.get_tail(clause);
	}

	bool clause_present(clause_type clause) {
		return !clause_head(clause)->getFlagDelete();
	}


	unsigned int clause_space() {
		return p_clauseConfig.p_allocator.get_total_space()
			- p_clauseConfig.p_allocator.get_free_space();
	}

	void clause_set_first(clause_type clause, literal_type literal)
			{ *(clause_head(clause)->literal(0)) = literal; }
	void clause_set_second(clause_type clause, literal_type literal)
			{ *(clause_head(clause)->literal(1)) = literal; }
	void clause_set_third(clause_type clause, literal_type literal)
			{ *(clause_head(clause)->literal(2)) = literal; }

	literal_type clause_get(clause_type clause, litindex_type index) {
		clause_head_type *head = p_clauseConfig.get_head(clause);
		return *head->literal(index);
	}
	literal_type clause_get_first(clause_type clause)
			{ return *clause_head(clause)->literal(0); }
	literal_type clause_get_second(clause_type clause)
			{ return *clause_head(clause)->literal(1); }
	literal_type clause_get_third(clause_type clause)
			{ return *clause_head(clause)->literal(2); }

	activity_type clause_get_activity(clause_type clause) {
		return clause_tail(clause)->normalTail.activity;
	}
	void clause_set_activity(clause_type clause, activity_type activity) {
		clause_tail(clause)->normalTail.activity = activity;
	}

	clause_sig_type clause_get_sig(clause_type clause) {
		return clause_tail(clause)->normalTail.signature;
	}
	void clause_set_sig(clause_type clause, clause_sig_type signature) {
		clause_tail(clause)->normalTail.signature = signature;
	}
	
	bool clause_sat(clause_type clause) {
		for(auto i = clauseBegin(clause); i != clauseEnd(clause); ++i)
			if(litTrue(*i))
				return true;
		return false;
	}

	void seedRandomEngine(unsigned long seed) {
		std::cout << "c random seed: 0x" << std::hex << seed << std::dec << std::endl;
		p_rndEngine.seed(seed);
	}
	
	/* ---------------- VARIABLE MANAGEMENT FUNCTIONS ---------------------- */
	// reserves space for variables; does not allocate them!
	void varReserve(variable_type count);

	// allocates a single variable
	variable_type varAlloc();

	unsigned int numVariables() {
		return p_varConfig.count();
	}
	vars::VarIterator<BaseDefs> varsBegin() {
		return vars::VarIterator<BaseDefs>(0);
	}
	vars::VarIterator<BaseDefs> varsEnd() {
		return vars::VarIterator<BaseDefs>(p_varConfig.count());
	}
	
	// initializes the VSIDS heuristic
	void randomizeVsids();

	// returns the first literal associated with a variable
	literal_type oneLiteral(variable_type var) {
		return vars::get_one<var_config_type>(var);
	}
	// returns the second literal associated with a variable
	literal_type zeroLiteral(variable_type var) {
		return vars::get_zero<var_config_type>(var);
	}

	/* locks a variable. locked variables must not be removed from clauses
	 * and must not be eliminated */
	void lockVariable(variable_type var);
	void unlockVariable(variable_type var);
	bool varIsLocked(variable_type var);
	
	// returns true if literal == oneLiteral(litGetVar(literal))
	bool isOneLiteral(literal_type literal) {
		return (literal & 1) != 0;
	}
	int litPolarity(literal_type literal) {
		variable_type var = litVariable(literal);
		return literal == oneLiteral(var) ? 1 : -1;
	}

	literal_type litInverse(literal_type literal) {
		return vars::get_inverse<var_config_type>(literal);
	}
	variable_type litVariable(literal_type literal) {
		return vars::get_var<var_config_type>(literal);
	}
	
	bool varAssigned(variable_type var) {
		return p_varConfig.get_assign(var).is_assigned();
	}
	bool varOne(variable_type var) {
		return p_varConfig.get_assign(var).is_one();
	}
	bool varZero(variable_type var) {
		return p_varConfig.get_assign(var).is_zero();
	}
	
	// returns true if a literal is currently assigned true
	bool litTrue(literal_type lit);
	// returns true if a literal is currently assigned false
	bool litFalse(literal_type lit);

	antecedent_type varAntecedent(variable_type var) {
		return p_varConfig.get_antecedent(var);
	}
	declevel_type varDeclevel(variable_type var) {
		return p_varConfig.get_declevel(var);
	}
	// returns true if this variable is fixed by a unit clause
	bool varIsFixed(variable_type var);
	
	/* ----------------- CLAUSE MANAGEMENT FUNCTIONS ----------------------- */

	bool clause_contains(clause_type clause, literal_type literal);
	int clause_polarity(clause_type clause, variable_type variable);

	/* make sure there is enough space to store clauses.
	 * move the whole clause space if there is not. */
	void ensureClauseSpace(unsigned int free_required);
	
	clause_iterator clausesBegin() {
		return p_clauseConfig.begin();
	}
	clause_iterator clausesEnd() {
		return p_clauseConfig.end();
	}

	litindex_type clauseLength(clause_type clause);

	ClauseLitIterator clauseBegin(clause_type clause);
	ClauseLitIterator clauseBegin2(clause_type clause);
	ClauseLitIterator clauseBegin3(clause_type clause);
	ClauseLitIterator clauseEnd(clause_type clause);
	
	unsigned int clauseGetLbd(clause_type clause) {
		return clause_tail(clause)->normalTail.lbd;
	}
	void clauseSetLbd(clause_type clause, unsigned int lbd) {
		if(lbd > UINT16_MAX)
			lbd = UINT16_MAX;
		clause_tail(clause)->normalTail.lbd = lbd;
	}


	void clauseSetEssential(clause_type clause);
	void clauseUnsetEssential(clause_type clause);
	bool clauseIsEssential(clause_type clause);
	
	/* returns true if the clause is currently unit or unsatisfied.
	 * only returns a valid result after propagation is done */
	// FIXME: do we need this?
	bool clauseAssigned(clause_type clause);
	// returns true if the clause is currently the antecedent of a variable
	bool clauseIsAntecedent(clause_type clause);

	// use a copying-garbage collection to get rid of deleted clauses
	void collectClauses();

	/* helper function for collectClauses().
	 * Called when a clause is moved. Updates watch lists etc. */
	void onClauseMove(clause_type from_index, clause_type to_index);
	
	// checks whether a garbage collection is necessary
	void checkClauseGarbage();

	// removes all clauses containing the specified literal
	void expellContaining(literal_type lit);

	/* -------------- WATCH LIST / OCCLIST FUNCTIONS ----------------------- */

	// helper functions to manipulate watch lists
	void watchInsertClause(literal_type literal, literal_type blocking,
		clause_type clause);
	void watchInsertBinary(literal_type literal, literal_type implied);
	
	// helper functions to manipulate watch lists
	void watchRemoveClause(literal_type literal, clause_type clause);
	void watchRemoveBinary(literal_type literal, literal_type implied);
	
	void watchReplaceClause(literal_type literal, clause_type clause,
			clause_type replacement);
	bool watchContainsBinary(literal_type literal, literal_type implied);
	
	void occurConstruct();
	void occurDestruct();

	unsigned int occur_size(literal_type literal) {
		return p_varConfig.occur_size(literal);
	}
	occur_iterator occur_begin(literal_type literal) {
		return p_varConfig.occur_begin(literal);
	}
	occur_iterator occur_end(literal_type literal) {
		return p_varConfig.occur_end(literal);
	}
	void occur_clear(literal_type literal) {
		p_varConfig.occur_clear(literal);
	}

	/* ----------------------- PROPAGATION FUNCTIONS ----------------------- */

	void propagate();

	declevel_type curDeclevel() {
		return p_propagateConfig.decision_level();
	}
	order_type curOrder() {
		return p_propagateConfig.current_order();
	}
	literal_type getOrder(order_type order) {
		return p_propagateConfig.get_assign(order);
	}

	AntecedentIterator causesBegin(antecedent_type antecedent) {
		return AntecedentIterator::begin(*this, antecedent);
	}
	AntecedentIterator causesEnd(antecedent_type antecedent) {
		return AntecedentIterator::end(*this, antecedent);
	}
	ConflictIterator conflictBegin() {
		return ConflictIterator::begin(*this, p_conflictDesc);
	}
	ConflictIterator conflictEnd() {
		return ConflictIterator::end(*this, p_conflictDesc);
	}
	
	/* ------------------- ASSIGN / UNASSIGN FUNCTIONS --------------------- */

	void pushAssign(literal_type literal, antecedent_type antecedent);
	void popAssign();
	
	// creates a new decision level
	void pushLevel();
	// undos a single decision
	void popLevel();
	
	// undos all decisions up to (but not including!) the specified level
	void backjump(declevel_type to_declevel);
	
	// restarts the search from scratch
	void restart();
	
	/* resets the solver state so that another search (e.g. with new clauses or
	 * different assumptions) can be started */
	void reset();

	void checkRestart();
	
	/* ------------------------ INPUT FUNCTIONS ---------------------------- */
	template<typename Iterator>
	void inputClause(litindex_type length, Iterator begin, Iterator end);
	
	void inputFinish();

	/* --------------- CLAUSE REDUCTIONS FUNCTIONS ------------------------- */
	
	// sets the frozen flag and uninstalls the clause
	void freezeClause(clause_type clause);
	// sets the frozen flag for clauses that are currently not installed
	void quickFreezeClause(clause_type clause);
	void unfreezeClause(clause_type clause);
	bool clauseIsFrozen(clause_type clause);

	int calculatePsm(clause_type clause);

	// deletes clauses in order to decrease the number of learned clauses
	void reduceClauses();

	// checks if clause reduction should be done
	void checkClauseReduction();

	/* ------------------ DECISION FUNCTIONS ------------------------------- */

	/* assigns all unit clauses and assumptions.
	 * sets the atSolution, isUnsatisfied etc. flags */
	void start();

	// decides which variable should be assigned next and assigns the variable.
	void decide();
	
	// returns true if we are at a satisfiable assignment
	bool atLeaf() { return currentAssignedVars == p_varConfig.count(); }

	/* returns true if we "solved" the instance
		i.e. the instance is unsat or an assumption is violated */
	bool atSolution() { return !p_solutionDesc.isNone(); }
	bool isUnsatisfiable() { return p_solutionDesc.isUnsatisfiable(); }
	bool isFailedAssumption() { return p_solutionDesc.isFailedAssumption(); }

	// helper functions to rescale activity in order to prevent overflows
	void scaleVarActivity(activity_type divisor);
	void scaleClauseActivity(activity_type divisor);
	
	// update activity heuristics
	void onVarActivity(variable_type var);
	void onAntecedentActivity(antecedent_type antecedent);

	void increaseActivity();

	/* ------------------ CONFLICT MANAGEMENT ------------------------------ */

	void raiseConflict(conflict_type conflict);
	bool atConflict() { return !p_conflictDesc.is_none(); }
	
	// resolves the conflict
	void resolveConflict();

	/* --------------------- ASSUMPTION FUNCTIONS -------------------------- */
	void assumptionEnable(literal_type literal);
	void assumptionDisable(literal_type literal);
	bool isAssumed(literal_type literal);
	
	/* --------------------- ALLOCATION FUNCTIONS -------------------------- */

	/* allocates a clause and fills it with the given literals.
		NOTE: does NOT install watched literal etc. */
	template<typename Iterator>
	clause_type allocClause(litindex_type length, Iterator begin, Iterator end);

	void deleteClause(clause_type clause);

	/* -------------- INSTALL / UNINSTALL FUNCTIONS ------------------------ */
	/* invalidates watch list iterators for the *inverses* of
	 *     the first two literals of the clause.
	 * invalidates occlist iterators for all literals of the clause. */
	void installClause(clause_type clause);
	void uninstallClause(clause_type clause);

	/* ---------------- INSTALL QUEUE FUNCTIONS ---------------------------- */
	/* sometimes we want to install clauses while we're iterating through
	 * binary implications graphs, occurrence lists or watch lists.
	 *
	 * that can be problematic because insterting into those lists invalidates iterators.
	 *
	 * the functions here can be used to queue the installation of those clauses
	 * so that they are installed after iteration is finished. */

	void queueInstallClause(clause_type clause);

	void installQueueProcess();
	bool installQueueEmpty();
	
	/* -------------------- RESOLVENT CALCULATION -------------------------- */
	// TODO: should not be part of Config
	
	// returns true if the resolvent is trivial
	bool resolvent_trivial(clause_type clause1, clause_type clause2,
			variable_type variable) {
		for(auto i = clauseBegin(clause1); i != clauseEnd(clause1); ++i) {
			auto var = litVariable(*i);
			if(var == variable)
				continue;
			int polarity1 = lit_polarity(*i);
			int polarity2 = clause_polarity(clause2, var);
			if(polarity1 == -polarity2)
				return true;
		}
		return false;
	}
	
	// returns true if the resolvent is trivial. calculates its size otherwise
	bool resolvent_length(clause_type clause1, clause_type clause2,
			variable_type variable, unsigned int &length) {
		length = clauseLength(clause1) + clauseLength(clause2) - 2;
		for(auto i = clauseBegin(clause1); i != clauseEnd(clause1); ++i) {
			auto var = litVariable(*i);
			if(var == variable)
				continue;
			int polarity1 = lit_polarity(*i);
			int polarity2 = clause_polarity(clause2, var);
			if(polarity1 == -polarity2)
				return true;
			if(polarity1 == polarity2)
				length--;
		}
		return false;
	}

	// builds the resolvent of the two given clauses
	std::vector<literal_type> resolvent_build(clause_type clause1,
			clause_type clause2, variable_type variable) {
		std::vector<literal_type> result;
		for(auto i = clauseBegin(clause1); i != clauseEnd(clause1); ++i) {
			if(litVariable(*i) == variable)
				continue;
			result.push_back(*i);
		}
		for(auto i = clauseBegin(clause2); i != clauseEnd(clause2); ++i) {
			if(litVariable(*i) == variable)
				continue;
			if(clause_contains(clause1, *i))
				continue;
			result.push_back(*i);
		}
		return result;
	}
	
	/* -------- HELPER FUNCTIONS: LBD CALCULATION -------------------------- */
	std::vector<bool> lbd_buffer;
	int lbd_counter;
	
	void lbd_init() {
		if(lbd_buffer.size() < curDeclevel() + 1)
			lbd_buffer.resize(curDeclevel() + 1, false);
		lbd_counter = 0;
	}
	void lbd_insert(declevel_type declevel) {
		if(lbd_buffer[declevel])
			return;
		lbd_buffer[declevel] = true;
		lbd_counter++;
	}
	void lbd_cleanup(declevel_type declevel) {
		lbd_buffer[declevel] = false;
	}
	int lbd_result() {
		return lbd_counter;
	}

public:
	Hooks p_hooks;

	int p_configId;	

	var_config_type p_varConfig;

	clause_config_type p_clauseConfig;
	
	// stores all unit clauses
	std::vector<literal_type> p_unitClauses;

	prop_config_type p_propagateConfig;
	learn_config_type p_learnConfig;

	extmodel_config_type extmodel_config;
	extmodel_alloc_type extmodel_alloc;

	// stores all active assumptions
	std::vector<literal_type> p_assumptionList;

	std::vector<clause_type> p_installClauseQueue;
	
	std::mt19937 p_rndEngine;
	
	conflict_type p_conflictDesc;
	SolutionType p_solutionDesc;

	bool maintainOcclists;

	// number of conflicts resolved so far
	uint64_t conflictNum;
	// number of variables currently assigned. used to determine if the instance is sat
	variable_type currentAssignedVars;
	// number of currently active clauses. used for clause reduction heuristics
	uint32_t currentActiveClauses;
	uint32_t currentEssentialClauses;

	sys::Reporter p_reporter;

	const bool kReportEnable = false;
	const bool kReportAssign = false, kReportSample = false, kReportReducerSample = false;

	enum class ReportTag : uint16_t {
		kNone, kAssign, kConflict, kSample, kReducerSample
	};

	template<typename T>
	void report(const T &data) {
		if(kReportEnable)
			p_reporter.write(data);
	}

	enum PreprocModel {
		/* do not perform preprocessing at all */
		kPreprocNone,
		/* perform the preprocessing operations iteratively
			in a pre-defined order */
		kPreprocIterative,
		kPreprocAdaptive
	};

	enum InprocModel {
		kInprocNone,
		kInprocAdaptive
	};
	
	enum ClauseRedModel {
		kClauseRedAgile,
		kClauseRedGeometric
	};
	
	enum RestartStrategy {
		kRestartLuby,
		kRestartGlucose
	};

	struct {
		struct StatGeneral {
			uint32_t clauseReallocs;
			uint32_t clauseCollects;
			
			uint64_t deletedClauses;
			
			StatGeneral() :
				clauseReallocs(0),
				clauseCollects(0),
				deletedClauses(0) { }
		} general;

		struct StatSearch {
			uint32_t factElimRuns;
			uint64_t factElimClauses;
			uint64_t factElimLiterals;
			
			uint64_t propagations;
			uint64_t learnedLits, learnedUnits, learnedBinary;
			uint64_t minimizedLits;
			uint32_t restarts;
			util::performance::counter prop_time;
			
			StatSearch() :
				factElimRuns(0),
				factElimClauses(0),
				factElimLiterals(0),
					
				propagations(0),
				learnedLits(0), learnedUnits(0), learnedBinary(0),
				minimizedLits(0),
				restarts(0),
				prop_time(0) { }
		} search;

		struct StatClauseRed {
			uint64_t clausesActive, clausesNotActive, clausesConsidered;
			uint64_t clauseDeletions, clauseFreezes, clauseUnfreezes;
			uint32_t reductionRuns;
			
			StatClauseRed() : clausesActive(0), clausesNotActive(0), clausesConsidered(0),
				clauseDeletions(0), clauseFreezes(0), clauseUnfreezes(0),
				reductionRuns(0) { }
		} clauseRed;

		struct StatSimp {
			uint64_t vecdEliminated, vecdFacts;
			uint64_t bceEliminated;
			uint64_t scc_variables;
			uint64_t fle2_literals;
			uint64_t brm_failed;
			uint64_t brm_equivalent;
			uint64_t brm_independent;
			uint64_t hle_literals;
			uint64_t hle_facts;
			uint64_t hte_clauses;
			uint64_t selfsub_shortcuts;
			uint64_t selfsub_subchecks;
			uint64_t selfsub_reschecks;
			uint64_t selfsub_facts;
			uint64_t selfsub_clauses;
			uint64_t subsumed_clauses;
			uint64_t dist_checks;
			uint64_t dist_conflicts;
			uint64_t dist_conflicts_removed;
			uint64_t dist_asserts;
			uint64_t dist_asserts_removed;
			uint64_t dist_ssubs;
			uint64_t dist_ssubs_removed;
			uint64_t unhide_transitive;
			uint64_t unhide_failed;
			uint64_t unhide_hle;
			uint64_t unhide_hte;

			util::performance::counter scc_time;
			util::performance::counter fle2_time;
			util::performance::counter hle_time;
			util::performance::counter selfsub_time;
			util::performance::counter vecd_time;
			util::performance::counter bce_time;
			
			StatSimp() :
				vecdEliminated(0), vecdFacts(0),
				bceEliminated(0),
				scc_variables(0),
				fle2_literals(0),
				brm_failed(0), brm_equivalent(0), brm_independent(0),
				hle_literals(0), hle_facts(0),
				hte_clauses(0),
				selfsub_shortcuts(0), selfsub_subchecks(0), selfsub_reschecks(0),
					selfsub_facts(0), selfsub_clauses(0),
				subsumed_clauses(0),
				dist_checks(0),
				dist_conflicts(0), dist_conflicts_removed(0), dist_asserts(0), dist_asserts_removed(0),
					dist_ssubs(0), dist_ssubs_removed(0),
				unhide_transitive(0), unhide_failed(0), unhide_hle(0), unhide_hte(0),
				scc_time(0), fle2_time(0), hle_time(0), selfsub_time(0), vecd_time(0), bce_time(0) { }
		} simp;
	} stat;

	struct {
		util::performance::counter preproc_time;
		util::performance::counter inproc_time;
		util::performance::counter fact_elim_time;
	} perf;

	struct {
		struct OptsGeneral {
			int verbose;

			util::performance::counter budget;
			util::performance::counter timeout;
			
			bool permutate_input;

			bool outputDratProof;

			OptsGeneral() : outputDratProof(false) {
			}
		} general;

		struct {
			PreprocModel model;
			bool with_scc;
			bool with_fle2;
			bool with_hle;
			bool with_selfsub;
			bool with_vecd;
			bool with_bce;
			bool with_dist;
			bool with_unhiding;
			bool with_brm;
			uint32_t iterations;
		} preproc;

		struct {
			InprocModel model;
			bool with_dist;
			bool with_unhiding;
			bool with_brm;
		} inproc;

		struct {
			unsigned int dist_min_length;
		} simp;

		struct OptsLearn {
			bool bumpGlueTwice;
			bool minimizeGlucose;
			
			OptsLearn() :
				bumpGlueTwice(false),
				minimizeGlucose(false) { }
		} learn;

		struct {
			ClauseRedModel model;

			// initial learned clauses limit
			uint32_t agileBaseInterval;
			// linear slowdown of the clause limit
			uint32_t agileSlowdown;

			// growth factor for geomSizeLimit
			double geomSizeFactor;
			// growth factor for geomIncLimit
			double geomIncFactor;
		} clauseRed;

		struct OptsRestart {
			RestartStrategy strategy;
			uint32_t lubyScale;
			static const unsigned int glucose_short_interval = 100;

			OptsRestart() : lubyScale(100) { }
		} restart;
	} opts;

	struct {
		struct {
			util::performance::counter start_time;
			volatile bool stop_solve;
		} general;

		struct {
			// increment that is added to the score on each activity
			activity_type varActInc;
			// the increment is multiplies by this factor each conflict 
			activity_type varActFactor;

			// see the corresponding varAct... variables
			activity_type clauseActInc;
			activity_type clauseActFactor;
		} search;

		struct StateClauseRed {
			// number of clause reductions so far
			uint32_t numClauseReds;
			
			// number of conflicts since the last reduce
			uint64_t agileCounter;
			// number of conflicts between two reduce runs
			uint64_t agileInterval;
			
			// current learned clauses limit
			uint64_t geomSizeLimit;
			// number of conflicts since last increment
			uint64_t geomIncCounter;
			// number of conflicts before next increment
			uint64_t geomIncLimit;

			StateClauseRed() : numClauseReds(0) { }
		} clauseRed;

		struct {
			// decision level of last conflict
			declevel_type lastConflictDeclevel;
		} conflict;

		struct {
			uint32_t lubyCounter;
			uint32_t lubyPeriod;
			
			declevel_type *glucose_short_buffer;
			unsigned int glucose_short_pointer;
			unsigned int glucose_counter;
			uint64_t glucose_short_sum;
			uint64_t glucose_long_sum;
		} restart;

		struct StateInproc {
			/* number of new clauses since last in-processing phase */
			unsigned int new_facts;
			unsigned int new_binary;
			
			StateInproc() : new_facts(0),
				new_binary(0) { }
		} inproc;
	} state;

	uint32_t heap_size;
	std::vector<variable_type> p_heapArray;
public:
	print_clause_manipulator<config_type> print_clause(clause_type clause) {
		return print_clause_manipulator<config_type>(*this, clause);
	}
};

};

