
namespace satuzk {
namespace packed_clause {

template<typename Defs>
class ClauseRef;

template<typename Defs>
struct ClauseHead {
	typedef typename Defs::LiteralId LiteralId;
	typedef typename Defs::ClauseLitIndex ClauseLitIndex;
	typedef typename Defs::Activity Activity;
	
	// clause is installed i.e. in watch lists
	static const uint32_t kFlagInstalled = 1;
	// marked for deletion
	static const uint32_t kFlagDelete = 2;
	// marked essential i.e. must not be deleted
	static const uint32_t kFlagEssential = 4;
	// clause is frozen, i.e. not installed but will be reinstalled later
	static const uint32_t kFlagFrozen = 8;
	static const uint32_t kFlagQueuedInstall = 16;
	// clause has been moved/dropped during garbage collection
	static const uint32_t kFlagCollectMoved = 32;
	static const uint32_t kFlagCollectDropped = 64;
	static const uint32_t kFlagImproved = 128;
	static const uint32_t kFlagCheckedDist = 256;
	static const uint32_t kFlagCreatedVecd = 512;
	static const uint32_t kFlagCheckedSsub = 1024;
	

	// flags defined above
	uint32_t p_flags;
	// number of literals of the clause
	ClauseLitIndex p_numLiterals;

	/* we need a default constructor so that this structure
		remains standard-layout */
	ClauseHead() = default;
	ClauseHead(ClauseLitIndex num_literals) : p_flags(0),
			p_numLiterals(num_literals) { }

	ClauseLitIndex getLength() { return p_numLiterals; }

	void setFlagDelete() { p_flags |= kFlagDelete; }
	bool getFlagDelete() { return p_flags & kFlagDelete; }
	void unsetFlagDelete() { p_flags &= ~kFlagDelete; }
	
	void setFlagInstalled() { p_flags |= kFlagInstalled; }
	bool getFlagInstalled() { return p_flags & kFlagInstalled; }
	void unsetFlagInstalled() { p_flags &= ~kFlagInstalled; }
	
	void setFlagEssential() { p_flags |= kFlagEssential; }
	bool getFlagEssential() { return p_flags & kFlagEssential; }
	void unsetFlagEssential() { p_flags &= ~kFlagEssential; }
	
	void setFlagQueuedInstall() { p_flags |= kFlagQueuedInstall; }
	bool getFlagQueuedInstall() { return p_flags & kFlagQueuedInstall; }
	void unsetFlagQueuedInstall() { p_flags &= ~kFlagQueuedInstall; }

	bool get_improved() { return (p_flags & kFlagImproved) != 0; }
	void set_improved() { p_flags |= kFlagImproved; }
	void clear_improved() { p_flags &= ~kFlagImproved; }
	
	void setFlagFrozen() { p_flags |= kFlagFrozen; }
	void unsetFlagFrozen() { p_flags &= ~kFlagFrozen; }
	bool getFlagFrozen() { return p_flags & kFlagFrozen; }

	void setFlagCheckedDist() { p_flags |= kFlagCheckedDist; }
	bool getFlagCheckedDist() { return p_flags & kFlagCheckedDist; }

	void setFlagCreatedVecd() { p_flags |= kFlagCreatedVecd; }

	void setFlagCheckedSsub() { p_flags |= kFlagCheckedSsub; }
	bool getFlagCheckedSsub() { return p_flags & kFlagCheckedSsub; }

	/* called to relocate this clause head.
		note the number of literals is already set up. */
	void relocate(ClauseHead<Defs> *target) {
		target->p_flags = p_flags;
	}

	/* allows access to the clause body */
	void *access(int offset) {
		return (void*)((uintptr_t)this + sizeof(ClauseHead<Defs>) + offset);
	}

	/* allows access to literals */
	LiteralId *literal(ClauseLitIndex index) {
		LiteralId *litptr = (LiteralId*)access(index * sizeof(LiteralId));
		return litptr;
	}
};

template<typename Defs>
struct ClauseTail {
	union {
		struct {
			typename Defs::Activity activity;
			uint64_t signature;
			uint16_t lbd;
		} normalTail;
		
		struct {
			typename Defs::ClauseId destination;
		} movedTail;
	};
};

template<typename Defs>
class Config {
friend class ClauseRef<Defs>;
public:
	static const int kClauseAlign = 8;
	
	typedef typename Defs::LiteralId literal_type;
	typedef typename Defs::ClauseId index_type;
	typedef typename Defs::ClauseLitIndex litindex_type;
	typedef typename Defs::Activity activity_type;
	
	typedef ClauseHead<Defs> head_type;
	typedef ClauseHead<Defs> HeadStruct;
	typedef ClauseTail<Defs> tail_type;
	static_assert(std::is_pod<head_type>::value, "head not trivial");
	static_assert(std::is_pod<tail_type>::value, "tail not trivial");

	typedef std::vector<index_type> index_vector;
	typedef typename index_vector::iterator index_iterator;
	typedef typename index_vector::size_type size_type;

	Config() : p_allocator(kClauseAlign),
			clauses_bytes(0), present_clauses(0), deleted_clauses(0),
			p_present_literals(0) { }
	Config(const Config &other) = delete;
	Config &operator= (const Config &other) = delete;

	Config &operator= (Config &&other) {
		p_allocator = std::move(other.p_allocator);
		p_indices = std::move(other.p_indices);
		clauses_bytes = other.clauses_bytes;
		present_clauses = other.present_clauses;
		deleted_clauses = other.deleted_clauses;
		p_present_literals = other.p_present_literals;
		return *this;
	}

	index_iterator begin() {
		return p_indices.begin();
	}
	index_iterator end() {
		return p_indices.end();
	}

	void push_back(index_type index) {
		p_indices.push_back(index);
	}

	size_type num_clauses() {
		return p_indices.size();
	}
	size_type get_clauses_bytes() {
		return clauses_bytes;
	}
	uint64_t present_literals() {
		return p_present_literals;
	}

	litindex_type adjust_len(litindex_type length) {
		if(length % 2 == 1)
			return length + 1;
		return length;
	}
	index_type calc_bytes(litindex_type length) {
		return sizeof(head_type)
				+ adjust_len(length) * sizeof(literal_type)
				+ sizeof(tail_type);
	}
	head_type *get_head(index_type index) {
		return (head_type*)p_allocator[index];
	}
	tail_type *get_tail(index_type index) {
		auto headptr = get_head(index);
		auto adj_length = adjust_len(headptr->getLength());
		return (tail_type*)headptr->access(adj_length * sizeof(literal_type));
	}

	void set_delete(index_type clause) {
		get_head(clause)->setFlagDelete();
		present_clauses--;
		deleted_clauses++;
		p_present_literals += get_head(clause)->getLength();
	}
	bool get_delete(index_type clause) {
		return get_head(clause)->getFlagDelete();
	}

	void prun_deleted() {
		auto j = p_indices.begin();
		for(auto i = p_indices.begin(); i != p_indices.end(); ++i) {
			head_type *headptr = get_head(*i);
			if(headptr->getFlagDelete()) {
				clauses_bytes -= calc_bytes(headptr->getLength());
				continue;
			}
			*j = *i;
			j++;
		}
		p_indices.resize(j - p_indices.begin());
		deleted_clauses = 0;
	}

	index_vector p_indices;
	util::memory::bulk_alloc::allocator<typename Defs::ClauseId> p_allocator;

	unsigned int clauses_bytes;
	unsigned int present_clauses;
	unsigned int deleted_clauses;
	uint64_t p_present_literals;
};

template<typename Defs>
class ClauseRef {
private:
	ClauseRef(Config<Defs> &config, typename Defs::ClauseId clause_id)
			: p_config(config), p_clauseId(clause_id) {
	}
	
	bool wasMoved();
	bool wasDropped();
	typename Defs::ClauseId getMoveDestination();
	
public:
	Config<Defs> &p_config;
	typename Defs::ClauseId p_clauseId;
};

template<typename Defs>
bool ClauseRef<Defs>::wasMoved() {
	return p_config.get_head(p_clauseId)->flags & Config<Defs>::HeadStruct::kFlagCollectMoved;
}
template<typename Defs>
bool ClauseRef<Defs>::wasDropped() {
	return p_config.get_head(p_clauseId)->flags & Config<Defs>::HeadStruct::kFlagCollectDropped;
}
template<typename Defs>
typename Defs::ClauseId ClauseRef<Defs>::getMoveDestination() {
	assert(wasMoved());
	return p_config.get_tail(p_clauseId)->movedTail.destination;
}

template<typename Config>
typename Config::index_type new_clause(Config &config,
		typename Config::litindex_type length) {
	// allocate memory for the clause
	typename Config::index_type bytelen = config.calc_bytes(length);
	typename Config::index_type index = config.p_allocator.alloc(bytelen);

	// we have to setup the head before we can use get_tail()!
	typename Config::head_type *head = config.get_head(index);
	new (head) typename Config::head_type(length);

	auto tail = config.get_tail(index);
	tail->normalTail.lbd = 0;
	tail->normalTail.activity = 0.0f;
	tail->normalTail.signature = 0;

	config.push_back(index);
	config.clauses_bytes += bytelen;
	config.present_clauses++;
	config.p_present_literals += length;
	return index;
}

template<typename Config, typename Callback>
void relocateClauses(Config &from_config, Config &to_config, Callback &callback) {
	typename Config::index_iterator write_ptr = from_config.begin();
	for(typename Config::index_iterator it = from_config.begin();
			it != from_config.end(); ++it) {
		typename Config::index_type from_index = *it;
		typename Config::head_type *from_head = from_config.get_head(from_index);
		if(from_head->getFlagDelete()) {
			callback.onErase(from_index);
			from_head->p_flags |= Config::HeadStruct::kFlagCollectDropped;
		}else{
			// allocate the new clause
			typename Config::index_type to_index = new_clause(to_config, from_head->getLength());
			auto from_tail = from_config.get_tail(from_index);
			typename Config::head_type *to_head = to_config.get_head(to_index);
			auto to_tail = to_config.get_tail(to_index);
			
			// copy all flags, literals, etc.
			for(typename Config::litindex_type i = 0;
					i < from_head->getLength(); i++) {
				typename Config::literal_type literal = *from_head->literal(i);
				*to_head->literal(i) = literal;
			}
			from_head->relocate(to_head);
			to_tail->normalTail.lbd = from_tail->normalTail.lbd;
			to_tail->normalTail.activity = from_tail->normalTail.activity;
			to_tail->normalTail.signature = from_tail->normalTail.signature;

			callback.onMove(from_index, to_index);
			from_head->p_flags |= Config::HeadStruct::kFlagCollectMoved;
			from_tail->movedTail.destination = to_index;
		}
	}
	from_config.deleted_clauses = 0;
}

template<typename Config>
class iterator_struct
	: public std::iterator<std::forward_iterator_tag, typename Config::literal_type> {
public:
	iterator_struct(Config &config, typename Config::index_type clause,
			typename Config::litindex_type index) {
		p_index = config.get_head(clause)->literal(index);
	}

	void operator++ () {
		p_index++;
	}
	bool operator== (const iterator_struct<Config> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const iterator_struct<Config> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type &operator* () {
		return *p_index;
	}
	
private:
	typename Config::literal_type *p_index;
};

}}; /* namespace satuzk::packed_clause */

