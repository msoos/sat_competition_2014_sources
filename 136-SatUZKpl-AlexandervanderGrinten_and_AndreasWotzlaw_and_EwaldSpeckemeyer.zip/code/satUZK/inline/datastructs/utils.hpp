
/* iostream manipulator to print a clause */
template<typename Config>
class print_clause_manipulator {
public:
	typedef Config config_type;
	typedef typename Config::clause_type clause_type;

	print_clause_manipulator(config_type &config,
			clause_type clause) : p_config(config), p_clause(clause) { }
	
	template<typename Char, typename Traits>
	friend std::basic_ostream<Char, Traits> &operator<<
			(std::basic_ostream<Char, Traits> &ostream,
			print_clause_manipulator<Config> manip) {
		ostream << "[" << manip.p_clause << ": ";
		typedef typename Config::clauselit_iterator iterator;
		for(iterator it = manip.p_config.clause_begin(manip.p_clause);
				it != manip.p_config.clause_end(manip.p_clause); ++it) {
			if(it != manip.p_config.clause_begin(manip.p_clause))
				ostream << ", ";
			ostream << *it;
		}
		ostream << "]";
		return ostream;
	}
private:
	config_type &p_config;
	clause_type p_clause;
};

class lbool_type {
public:
	lbool_type(uint8_t value) : value(value) { }
	
	bool operator== (lbool_type other) {
		return ((other.value & 2) & (value & 2))
			| (!(other.value & 2) & (value == other.value));
	}
	bool operator!= (lbool_type other) {
		return !(operator== (other));
	}
	lbool_type operator^ (bool other) {
		return lbool_type(value ^ (uint8_t)other);
	}
	
	uint8_t value;
};
inline lbool_type lfalse() { return lbool_type(0); }
inline lbool_type ltrue() { return lbool_type(1); }
inline lbool_type lundef() { return lbool_type(2); }

