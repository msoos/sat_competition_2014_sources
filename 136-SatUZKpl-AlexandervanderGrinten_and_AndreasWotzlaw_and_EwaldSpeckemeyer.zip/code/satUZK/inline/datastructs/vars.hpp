
namespace satuzk {
namespace vars {

struct AssignInfo {
	typedef uint8_t value_type;
	static const value_type VALUE_NONE = 0;
	static const value_type VALUE_STATE_BIT = 1;
	static const value_type VALUE_ASSIGNED_BIT = 2;

	static const value_type VALUE_TRUE = 3;
	static const value_type VALUE_FALSE = 2;

	value_type value;

	void assign(bool state) {
		value = VALUE_ASSIGNED_BIT | (int)state;
	}
	void unassign() {
		value = VALUE_NONE;
	}

	bool is_one() {
		return value == VALUE_TRUE;
	}
	bool is_zero() {
		return value == VALUE_FALSE;
	}
	bool is_assigned() {
		return (value & VALUE_ASSIGNED_BIT);
	}
};

template<typename Activity>
struct HeapInfo {
	Activity activity; /* usually 64-bit */
	uint32_t heap_index;
};

template<typename BaseDefs>
union WatchlistEntry {
	typedef typename BaseDefs::LiteralId literal_type;
	typedef typename BaseDefs::ClauseId clause_type;

	union {
		struct {
			static const uint32_t kFlagMask = 0x7;
			static const uint32_t kFlagLong = 0;
			static const uint32_t kFlagBinary = 1;

			uint32_t flags;
			uint32_t padding;
		} general;

		struct {
			clause_type p_clause;
			literal_type p_blocking;
			
			void set_clause(clause_type clause) {
				p_clause = clause;
			}
			void set_blocking(literal_type blocking) {
				p_blocking = blocking;
			}
			clause_type get_clause() {
				return p_clause;
			}
			literal_type get_blocking() {
				return p_blocking;
			}
		} longcl;
		
		struct {
			uint32_t flags;
			literal_type p_implied;
			
			void set_implied(literal_type implied) {
				p_implied = implied;
			}
			literal_type get_implied() {
				return p_implied;
			}
		} binary;
	};
	
	void set_longcl() {
		general.flags &= ~general.kFlagMask;
	}
	void set_binary() {
		general.flags &= ~general.kFlagMask;
		general.flags |= general.kFlagBinary;
	}
	bool is_longcl() {
		return (general.flags & general.kFlagMask) == general.kFlagLong;
	}
	bool is_binary() {
		return (general.flags & general.kFlagMask) == general.kFlagBinary;
	}
};

template<typename Literal, typename Clause>
struct BigEdge {
	Literal literal;
	uint32_t flags;
};

template<typename Clause>
class Occlist {
public:
	typedef Clause clause_type;

	typedef util::vectors::simple<Clause> vector_type;
	typedef typename vector_type::iterator iterator;

	Occlist() : p_vector() { }
	Occlist(Occlist &&other)
		: p_vector(std::move(other.p_vector)) { }
	Occlist(const Occlist &) = delete;
	void operator= (const Occlist &) = delete;

	void insert(Clause clause) {
		p_vector.push_back(clause);
	}
	void clear() {
		p_vector.resize(0);
	}
	void shrink() {
		p_vector.shrink_to_fit();
	}
	void erase(iterator iterator) {
		p_vector.erase(iterator);
	}

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.resize(p_vector.index_of(after));
	}

private:
	vector_type p_vector;
};

/*template<typename Entry>
class Watchlist {
public:
	typedef Entry entry_type;

	typedef chunk_list<entry_type, 15> vector_type;
	typedef typename vector_type::iterator iterator;

	Watchlist() : p_vector() { }
	Watchlist(Watchlist &&other)
		: p_vector(std::move(other.p_vector)) { }
	Watchlist(const Watchlist &) = delete;
	void operator= (const Watchlist &) = delete;

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	void insert(entry_type entry) {
		p_vector.push_back(entry);
	}
	void erase(iterator it) {
		p_vector.erase(it);
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.cut_before(after);
	}

private:
	vector_type p_vector;
};*/

template<typename BaseDefs>
class Watchlist {
public:
	typedef WatchlistEntry<BaseDefs> entry_type;

	typedef util::vectors::simple<entry_type> vector_type;
	typedef typename vector_type::iterator iterator;

	Watchlist() : p_vector() { }
	Watchlist(Watchlist &&other)
		: p_vector(std::move(other.p_vector)) { }
	Watchlist(const Watchlist &) = delete;
	void operator= (const Watchlist &) = delete;

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	void insert(entry_type entry) {
		p_vector.push_back(entry);
	}
	void erase(iterator it) {
		iterator end = p_vector.end();
		--end;
		*it = *end;
		p_vector.pop_back();
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.resize(p_vector.index_of(after));
	}
	void clear() {
		p_vector.clear();
	}

private:
	vector_type p_vector;
};

template<typename BaseDefs>
class Config {
public:
	typedef typename BaseDefs::LiteralId Index;
	typedef typename BaseDefs::LiteralId literal_type;
	typedef typename BaseDefs::LiteralId variable_type;
	typedef typename BaseDefs::ClauseId clause_type;
	typedef typename BaseDefs::Activity activity_type;
	typedef typename BaseDefs::DecLevel declevel_type;
	typedef antecedent_struct<BaseDefs> antecedent_type;
	typedef uint8_t flags_type;
	
	static const literal_type ILLEGAL_LIT = (literal_type)(-1);
	
	static const flags_type kVarflagDeleted = 1;
	static const flags_type kVarflagSavedOne = 2;
	static const flags_type kVarflagModelOne = 4;
	/* true if the variable must not be eliminted */
	static const flags_type kVarflagProtected = 8;

	static const flags_type kLitflagHla = 1;
	/* true if the literal is on the stack during the
		strongly-connected component decomposition */
	static const flags_type kLitflagScc = 2;
	static const flags_type kLitflagMarked = 4;
	/* true if the literal is an assumption
		(i.e. must be set to true before all other decisions) */
	static const flags_type kLitflagAssumption = 8;

	static const flags_type kLitflagBigRemoved = 32;
	static const flags_type kLitflagWatchRemoved = 64;
	static const flags_type kLitflagOccurRemoved = 128;

	typedef AssignInfo assign_type;
	
	typedef Occlist<clause_type> occlist_type;
	typedef std::vector<occlist_type> occlist_vector;
	typedef typename occlist_type::iterator occur_iterator;

	typedef HeapInfo<activity_type> heap_info_type;

	typedef WatchlistEntry<BaseDefs> watchlist_entry;
	typedef Watchlist<BaseDefs> watchlist_type;
	typedef std::vector<watchlist_type> watchlist_vector;
	typedef typename watchlist_type::iterator watchlist_iterator;
	typedef typename watchlist_type::iterator watch_iterator;

	static_assert(std::is_trivial<AssignInfo>::value, "assignment info not trivial");
	static_assert(std::is_trivial<antecedent_type>::value, "antecedent not trivial");
	static_assert(std::is_trivial<watchlist_entry>::value, "watchlist entry not trivial");

	Config() : p_presentCount(0), p_watchSize(0) { }

	void reserve_vars(Index count) {
		p_assigns.reserve(count);
		p_varflags.reserve(count);
		p_declevels.reserve(count);
		p_antecedents.reserve(count);
		p_heapInfos.reserve(count);

		p_litflags.reserve(2 * count);
		p_occlists.reserve(2 * count);
		p_watchlists.reserve(2 * count);
		p_equivPointer.reserve(2 * count);
	}

	Index alloc_var() {
		Index index = p_assigns.size();
		SYS_ASSERT(SYS_ASRT_GENERAL, p_occlists.size() == 2 * index);
		SYS_ASSERT(SYS_ASRT_GENERAL, p_watchlists.size() == 2 * index);
		
		assign_type initial_assign;
		flags_type initial_flags = 0;
		declevel_type initial_declevel = 0;
		antecedent_type initial_antecedent;
		heap_info_type initial_heap_info;

		flags_type initial_litflags1 = 0;
		flags_type initial_litflags2 = 0;
		occlist_type initial_occlist1;
		occlist_type initial_occlist2;
		watchlist_type initial_watchlist1;
		watchlist_type initial_watchlist2;
		literal_type initial_unionfind1;
		literal_type initial_unionfind2;

		initial_assign.value = 0;
		initial_heap_info.activity = 0.0f;
		initial_unionfind1 = 2 * index;
		initial_unionfind2 = 2 * index + 1;

		p_assigns.push_back(initial_assign);
		p_varflags.push_back(initial_flags);
		p_declevels.push_back(initial_declevel);
		p_antecedents.push_back(initial_antecedent);
		p_heapInfos.push_back(initial_heap_info);

		p_litflags.push_back(initial_litflags1);
		p_litflags.push_back(initial_litflags2);
		p_occlists.emplace_back(std::move(initial_occlist1));
		p_occlists.emplace_back(std::move(initial_occlist2));
		p_watchlists.emplace_back(std::move(initial_watchlist1));
		p_watchlists.emplace_back(std::move(initial_watchlist2));
		p_equivPointer.push_back(initial_unionfind1);
		p_equivPointer.push_back(initial_unionfind2);

		p_presentCount++;
		return index;
	}

	Index count() {
		return p_assigns.size();
	}
	
	assign_type &get_assign(variable_type index) {
		return p_assigns[index];
	}

	unsigned int present_count() {
		return p_presentCount;
	}
	void var_delete(variable_type var) {
		std::cout << "var_delete(" << var << ")" << std::endl;
		p_varflags[var] |= kVarflagDeleted;
		p_presentCount--;
	}
	bool var_present(variable_type var) {
		return !(p_varflags[var] & kVarflagDeleted);
	}

	bool get_varflag_deleted(variable_type var) { return p_varflags[var] & kVarflagDeleted; }
	
	bool get_varflag_saved(variable_type var) { return p_varflags[var] & kVarflagSavedOne; }
	void set_varflag_saved(variable_type var) { p_varflags[var] |= kVarflagSavedOne; }
	void clear_varflag_saved(variable_type var) { p_varflags[var] &= ~kVarflagSavedOne; }
	
	flags_type get_varflag_model(variable_type var) { return p_varflags[var] & kVarflagModelOne; }
	void set_varflag_model(variable_type var) { p_varflags[var] |= kVarflagModelOne; }
	void clear_varflag_model(variable_type var) { p_varflags[var] &= ~kVarflagModelOne; }
	
	flags_type get_varflag_protected(variable_type var) { return p_varflags[var] & kVarflagProtected; }
	void set_varflag_protected(variable_type var) { p_varflags[var] |= kVarflagProtected; }
	void clear_varflag_protected(variable_type var) { p_varflags[var] &= ~kVarflagProtected; }
	
	/* -------- decision level related functions ----------- */
	declevel_type get_declevel(variable_type var) { return p_declevels[var]; }
	void set_declevel(variable_type var, declevel_type declevel) { p_declevels[var] = declevel; }

	/* -------- antecedent related functions ----------- */
	antecedent_type get_antecedent(variable_type var) { return p_antecedents[var]; }
	void set_antecedent(variable_type var, antecedent_type antecedent) { p_antecedents[var] = antecedent; }
	
	/* --------------- heap related functions ------------- */
	heap_info_type &get_heap_info(variable_type var) {
		return p_heapInfos[var];
	}

	/* -------- literal flag related functions --------- */
	bool get_litflag_hla(literal_type lit) { return p_litflags[lit] & kLitflagHla; }
	void set_litflag_hla(literal_type lit) { p_litflags[lit] |= kLitflagHla; }
	void clear_litflag_hla(literal_type lit) { p_litflags[lit] &= ~kLitflagHla; }
	
	bool get_litflag_ssc(literal_type lit) { return p_litflags[lit] & kLitflagScc; }
	void set_litflag_ssc(literal_type lit) { p_litflags[lit] |= kLitflagScc; }
	void clear_litflag_ssc(literal_type lit) { p_litflags[lit] &= ~kLitflagScc; }
	
	bool get_litflag_marked(literal_type lit) { return p_litflags[lit] & kLitflagMarked; }
	void set_litflag_marked(literal_type lit) { p_litflags[lit] |= kLitflagMarked; }
	void clear_litflag_marked(literal_type lit) { p_litflags[lit] &= ~kLitflagMarked; }
	
	bool get_litflag_assumption(literal_type lit) { return p_litflags[lit] & kLitflagAssumption; }
	void set_litflag_assumption(literal_type lit) { p_litflags[lit] |= kLitflagAssumption; }
	void clear_litflag_assumption(literal_type lit) { p_litflags[lit] &= ~kLitflagAssumption; }

	bool get_litflag_big_removed(literal_type lit) { return p_litflags[lit] & kLitflagBigRemoved; }
	void set_litflag_big_removed(literal_type lit) { p_litflags[lit] |= kLitflagBigRemoved; }
	void clear_litflag_big_removed(literal_type lit) { p_litflags[lit] &= ~kLitflagBigRemoved; }
	
	bool get_litflag_watch_removed(literal_type lit) { return p_litflags[lit] & kLitflagWatchRemoved; }
	void set_litflag_watch_removed(literal_type lit) { p_litflags[lit] |= kLitflagWatchRemoved; }
	void clear_litflag_watch_removed(literal_type lit) { p_litflags[lit] &= ~kLitflagWatchRemoved; }
	
	bool get_litflag_occur_removed(literal_type lit) { return p_litflags[lit] & kLitflagOccurRemoved; }
	void set_litflag_occur_removed(literal_type lit) { p_litflags[lit] |= kLitflagOccurRemoved; }
	void clear_litflag_occur_removed(literal_type lit) { p_litflags[lit] &= ~kLitflagOccurRemoved; }

	/* ------- occurrence list related functions ------- */
	void occur_insert(literal_type literal, clause_type clause) {
		p_occlists[literal].insert(clause);
	}
	void occur_clear(literal_type literal) {
		p_occlists[literal].clear();
	}
	void occur_shrink(literal_type literal) {
		p_occlists[literal].shrink();
	}
	void occur_erase(literal_type literal, occur_iterator iterator) {
		p_occlists[literal].erase(iterator);
	}
	void occur_cutoff(literal_type literal, occur_iterator iterator) {
		p_occlists[literal].cutoff(iterator);
	}
	unsigned int occur_size(literal_type literal) {
		return p_occlists[literal].size();
	}
	occur_iterator occur_begin(literal_type literal) {
		return p_occlists[literal].begin();
	}
	occur_iterator occur_end(literal_type literal) {
		return p_occlists[literal].end();
	}

	/* ---------- watch related functions ----------- */
	unsigned int watch_overall_size() {
		return p_watchSize;
	}
	void watch_insert(literal_type literal, watchlist_entry entry) {
		watchlist_type &watchlist = p_watchlists[literal];
		watchlist.insert(entry);
		p_watchSize++;
	}
	unsigned int watch_size(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		return watch_list.size();
	}
	watch_iterator watch_begin(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		return watch_list.begin();
	}
	watch_iterator watch_end(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		return watch_list.end();
	}
	void watch_cutoff(literal_type literal, watch_iterator it) {
		watchlist_type &watch_list = p_watchlists[literal];
		p_watchSize -= watch_list.end() - it;
		watch_list.cutoff(it);
	}
	void watch_erase(literal_type literal, watch_iterator it) {
		watchlist_type &watch_list = p_watchlists[literal];
		watch_list.erase(it);
		p_watchSize--;
	}
	void watch_clear(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		p_watchSize -= watch_list.size();
		watch_list.clear();
	}

//	template<typename Visitor>
//	void watchlist_visit(literal_type literal, Visitor &visitor) {
//		watchlist_type &watchlist = p_watchlists[literal];
//		std::cout << "Size of watch list (gen): " << watchlist.size() << std::endl;
//
//		typename watchlist_type::iterator j = watchlist.begin();
//		for(typename watchlist_type::iterator it = watchlist.begin();
//				it != watchlist.end(); ++it) {
			/* make a copy of the watch list entry
				as the visitor is allowed to change it */
//			watchlist_entry entry = *it;
//			if(visitor(literal, entry)) {
//				*j = entry;
//				++j;
//			}
//		}
//		watchlist.cutoff(j);
//	}

	// equivalent variable management
	literal_type equiv_root(literal_type literal) {
		literal_type root = literal;
		while(p_equivPointer[root] != root)
			root = p_equivPointer[root];
		/* path compression */
		literal_type current = literal;
		while(p_equivPointer[current] != root) {
			literal_type parent = p_equivPointer[current];
			p_equivPointer[current] = root;
			current = parent;
		}
		return root;
	}
	void equiv_union(literal_type literal1, literal_type literal2) {
		/* NOTE: no union-by-size for now.
			the literal with smaller index becomes root.
			this makes sure the root of l and l_inverse are
			always inverse of each other. */
		literal_type root1 = equiv_root(literal1);
		literal_type root2 = equiv_root(literal2);
		if(root1 < root2) {
			p_equivPointer[root2] = root1;
		}else p_equivPointer[root1] = root2;
	}

private:
	/* per variable configuration */
	std::vector<assign_type> p_assigns;
	std::vector<flags_type> p_varflags;
	std::vector<declevel_type> p_declevels;
	std::vector<antecedent_type> p_antecedents;
	std::vector<heap_info_type> p_heapInfos;
	
	/* per literal configuration */
	std::vector<flags_type> p_litflags;
	occlist_vector p_occlists;
	watchlist_vector p_watchlists;
	std::vector<literal_type> p_equivPointer;
	
	unsigned int p_presentCount;
	unsigned int p_watchSize;
};

template<typename Config>
bool is_one(typename Config::Index literal) {
	return literal & 1;
//	return literal % 2 == 1;
}

template<typename Config>
typename Config::Index get_zero(typename Config::Index var) {
	return 2 * var;
}

template<typename Config>
typename Config::Index get_one(typename Config::Index var) {
	return 2 * var + 1;
}

template<typename Config>
typename Config::Index get_var(typename Config::Index lit) {
	return lit >> 1;
//	if(lit % 2 == 1)
//		return (lit - 1) / 2;
//	return lit / 2;
}

template<typename Config>
typename Config::literal_type get_inverse(typename Config::Index lit) {
	return lit ^ 1;
//	if(lit % 2 == 1)
//		return lit - 1;
//	return lit + 1;
}

template<typename Defs>
class VarIterator
	: std::iterator<std::forward_iterator_tag, typename Defs::LiteralId> {
public:
	VarIterator(typename Defs::LiteralId index) : p_index(index) {
	}

	void operator++ () {
		p_index++;
	}
	bool operator== (const VarIterator<Defs> &other) {
		return p_index == other.p_index;
	}
	bool operator!= (const VarIterator<Defs> &other) {
		return !(*this == other);
	}

	typename Defs::LiteralId operator* () {
		return p_index;
	}

private:
	typename Defs::LiteralId p_index;
};

}}; /* namespace satuzk::vars */

