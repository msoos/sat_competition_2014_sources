
template<typename Hooks>
class adaptive_unhide_heuristics {
public:
	adaptive_unhide_heuristics(Hooks &hooks) : p_hooks(hooks) { }

	bool another_run(unsigned int total_runs,
			unsigned int last_equiv, unsigned int last_elim, uint64_t last_hle_lits,
			util::performance::counter last_elapsed,
			util::performance::counter total_elapsed) {
		/* hard time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.03f)
			return false;

		/* continue if last run was incredibly good */
		float last_quote = (float)last_elapsed / p_hooks.opts.general.budget;
		unsigned int scaled_elim = last_elim / (last_quote * 100);
		unsigned int scaled_equiv = last_equiv / (last_quote * 100);
//		std::cout << "c [UNHIDE]    another run? quote: " << (last_quote * 100) << "%" << std::endl;
//		std::cout << "c [UNHIDE]       scaled equivalent: " << scaled_equiv
//				<< ", eliminated: " << scaled_elim << std::endl;
		
		unsigned int present_vars = p_hooks.p_varConfig.present_count();
		unsigned int hard_goal_equiv = present_vars * 0.01f;
		unsigned int hard_goal_elim = present_vars * 0.005f;
//		std::cout << "c [UNHIDE]       hard goal equivalent: " << hard_goal_equiv
//				<< ", eliminated: " << hard_goal_elim << std::endl;

		if(scaled_elim > hard_goal_elim || scaled_equiv > hard_goal_equiv)
			return true;
		
		/* soft time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.005)
			return false;

		/* break if last run was incredibly bad */
		unsigned int soft_goal_equiv = present_vars * 0.005f;
		unsigned int soft_goal_elim = present_vars * 0.002f;
//		std::cout << "c [UNHIDE]       soft goal equivalent: " << soft_goal_equiv
//				<< ", eliminated: " << soft_goal_elim << std::endl;

		if(!(scaled_elim > soft_goal_elim && scaled_equiv > soft_goal_equiv))
			return false;
		return true;
	}

	void run_stats(unsigned int run_equiv, unsigned int run_elim,
			unsigned int run_hle_lits,
			util::performance::counter run_elapsed) {
//		std::cout << "c [UNHIDE]    run statistics"
//			<< ", time: " << (run_elapsed / (1000 * 1000)) << " msecs" << std::endl;
//		std::cout << "c [UNHIDE]       equivalent: " << run_equiv
//				<< ", eliminated: " << run_elim << std::endl;
//		std::cout << "c [UNHIDE]       hidden lits: " << run_hle_lits << std::endl;
	}

private:
	Hooks &p_hooks;
};

template<typename Hooks>
class adaptive_brm_heuristics {
public:
	adaptive_brm_heuristics(Hooks &hooks) : p_hooks(hooks) { }
	
	bool another_run(unsigned int last_equiv, unsigned int last_elim,
			util::performance::counter last_elapsed,
			util::performance::counter total_elapsed) {
		/* hard time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.03f)
			return false;

		/* continue if last run was incredibly good */
		float last_quote = (float)last_elapsed / p_hooks.opts.general.budget;
		unsigned int scaled_elim = last_elim / (last_quote * 100);
		unsigned int scaled_equiv = last_equiv / (last_quote * 100);
//		std::cout << "c [BRM   ]    another run? quote: " << (last_quote * 100) << "%" << std::endl;
//		std::cout << "c [BRM   ]       scaled equivalent: " << scaled_equiv
//				<< ", eliminated: " << scaled_elim << std::endl;
		
		unsigned int present_vars = p_hooks.p_varConfig.present_count();
		unsigned int hard_goal_equiv = present_vars * 0.01f;
		unsigned int hard_goal_elim = present_vars * 0.005f;
//		std::cout << "c [BRM   ]       hard goal equivalent: " << hard_goal_equiv
//				<< ", eliminated: " << hard_goal_elim << std::endl;

		if(scaled_elim > hard_goal_elim || scaled_equiv > hard_goal_equiv)
			return true;
		
		/* soft time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.005)
			return false;

		/* break if last run was incredibly bad */
		unsigned int soft_goal_equiv = present_vars * 0.005f;
		unsigned int soft_goal_elim = present_vars * 0.002f;
//		std::cout << "c [BRM   ]       soft goal equivalent: " << soft_goal_equiv
//				<< ", eliminated: " << soft_goal_elim << std::endl;

		if(!(scaled_elim > soft_goal_elim && scaled_equiv > soft_goal_equiv))
			return false;
		return true;
	}

	void run_stats(unsigned int run_equiv, unsigned int run_elim,
			util::performance::counter run_elapsed) {
//		std::cout << "c [BRM   ]    run statistics"
//			<< ", time: " << (run_elapsed / (1000 * 1000)) << " msecs" << std::endl;
//		std::cout << "c [BRM   ]       equivalent: " << run_equiv
//				<< ", eliminated: " << run_elim << std::endl;
	}
	
private:
	Hooks &p_hooks;
};

template<typename Hooks>
class adaptive_dist_heuristics {
public:
	adaptive_dist_heuristics(Hooks &hooks) : p_hooks(hooks) { }

	bool another_run(uint64_t last_removed_lits,
			util::performance::counter last_elapsed,
			unsigned int total_runs, uint64_t total_removed_lits,
			util::performance::counter total_elapsed) {
		/* hard time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.03f)
			return false;
		
		float last_quote = (float)last_elapsed / p_hooks.opts.general.budget;
		unsigned int scaled_removed_lits = last_removed_lits / (last_quote * 100);
		std::cout << "c [DIST  ]       scaled removed lits: " << scaled_removed_lits << std::endl;
		
		unsigned int present_lits = p_hooks.p_clause_config.present_literals();
		unsigned int hard_goal_removed_lits = present_lits * 0.004f;
		std::cout << "c [DIST  ]       hard goal removed lits: " << hard_goal_removed_lits << std::endl;
		if(scaled_removed_lits > hard_goal_removed_lits)
			return true;
		
		return false;
	}

	void run_stats(uint64_t run_removed_lits,
			util::performance::counter run_elapsed) {
		std::cout << "c [DIST  ]    time: " << (run_elapsed / (1000 * 1000)) << " msecs"
				<< ", removed lits: " << run_removed_lits << std::endl;
	}
private:
	Hooks &p_hooks;
};

template<typename Hooks>
void preproc_unhide(Hooks &hooks) {
/*	unsigned int unhide_min_fixed = hooks.p_varConfig.count() * 0.01f;
	unsigned int unhide_min_removed_lits = hooks.p_clause_config.present_clauses * 0.01f;

	unsigned int unhide_iterations = 0;
	unsigned int stat_equiv = 0;
	unsigned int stat_failed = 0;
	unsigned int stat_transitive = 0;
	unsigned int stat_hle_lits = 0;
	unsigned int stat_hte_clauses = 0;

	unhiding_bounded(hooks, hooks.opts.general.budget * 0.01f,
			unhide_min_fixed, unhide_min_removed_lits, 0, 0.75f,
			unhide_iterations, unhide_elapsed, stat_equiv, stat_failed,
			stat_transitive, stat_hle_lits, stat_hte_clauses);
	std::cout << "c   [UNHIDE]    runs: " << unhide_iterations
			<< ", equivalent lits: " << stat_equiv
			<< ", failed lits: " << stat_failed
			<< ", transitive edges: " << stat_transitive << std::endl;
	std::cout << "c   [UNHIDE]    hidden lits: " << stat_hle_lits
			<< ", hidden tautologies: " << stat_hte_clauses << std::endl;
*/

	unsigned int stat_runs = 0;
	util::performance::counter elapsed = 0;

	std::cout << "c [UNHIDE] started" << std::endl;
	adaptive_unhide_heuristics<Hooks> heuristics(hooks);
	unhiding_heuristic(hooks, true, heuristics, stat_runs, elapsed);
	std::cout << "c [UNHIDE]    finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void preproc_bce(Hooks &hooks) {
	util::performance::counter start;
	util::performance::counter elapsed;
	
	std::cout << "c [BCE   ] started"; std::cout.flush();
	start = util::performance::current();
	bce_eliminate(hooks);
	elapsed = util::performance::elapsed(start);
	std::cout << ", finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void preproc_ssub(Hooks &hooks) {
	util::performance::counter start;
	util::performance::counter elapsed;
	
	std::cout << "c [SSUB  ] started"; std::cout.flush();
	start = util::performance::current();
	selfsub_backward_all(hooks);
	elapsed = util::performance::elapsed(start);
	std::cout << ", finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void preproc_brm(Hooks &hooks) {
	util::performance::counter elapsed = 0;
	
	std::cout << "c [BRM   ] started" << std::endl;
	adaptive_brm_heuristics<Hooks> heuristics(hooks);	
	brm_eliminate_heuristic(hooks, heuristics, elapsed);
//	std::cout << "c   [BRM   ]    failed lits: " << brm_failed;
//	std::cout << ", equivalent lits: " << brm_equivalent;
//	std::cout << ", independent lits: " << brm_independent << std::endl;
	std::cout << "c [BRM   ]    finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void preproc_dist(Hooks &hooks) {
	util::performance::counter start;
	util::performance::counter elapsed;
	
	std::cout << "c [DIST  ] started" << std::endl;
	start = util::performance::current();
	adaptive_dist_heuristics<Hooks> heuristics(hooks);
	dist_eliminate_all(hooks, heuristics);
	elapsed = util::performance::elapsed(start);
	std::cout << "c [DIST  ]    finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void preproc_vecd(Hooks &hooks,
		unsigned int &run_elim_vars) {
	util::performance::counter start;
	util::performance::counter elapsed;
	
	std::cout << "c [VECD  ] started"; std::cout.flush();
	start = util::performance::current();
	vecd_eliminate_all(hooks, run_elim_vars);
	elapsed = util::performance::elapsed(start);
	std::cout << ", finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void preproc_iterative(Hooks &hooks) {
	SYS_CRITICAL("Do not use this at the moment\n");
}

template<typename Hooks>
void preproc_adaptive_initial(Hooks &hooks) {
	if(hooks.opts.preproc.with_unhiding)
		preproc_unhide(hooks);
	if(hooks.isUnsatisfiable())
		return;
	if(hooks.opts.preproc.with_selfsub)
		preproc_ssub(hooks);
	if(hooks.isUnsatisfiable())
		return;
	if(hooks.opts.preproc.with_brm)
		preproc_brm(hooks);
	if(hooks.isUnsatisfiable())
		return;
}

template<typename Hooks>
bool another_reduce(Hooks &hooks,
		unsigned int present_vars,
		unsigned int last_elim_vars,
		util::performance::counter last_elapsed,
		util::performance::counter total_elapsed) {
	/* hard time-limit */
	if(total_elapsed > hooks.opts.general.budget * 0.1f)
		return false;
		
	float last_quote = (float)last_elapsed / hooks.opts.general.budget;
	unsigned int scaled_elim_vars = last_elim_vars / (last_quote * 100);
//	std::cout << "c [PRE   ]    time: " << (last_elapsed / (1000 * 1000)) << " msecs"
//		<< ", reduction: " << last_elim_vars << " of " << present_vars << std::endl;
//	std::cout << "c [PRE   ]       scaled reduction: " << scaled_elim_vars << std::endl;
		
	unsigned int hard_goal_elim_vars = present_vars * 0.01f;
//	std::cout << "c [PRE   ]       hard goal reduction: " << hard_goal_elim_vars << std::endl;
	if(scaled_elim_vars > hard_goal_elim_vars)
		return true;
	return false;
}

template<typename Hooks>
void preproc_adaptive_reduce(Hooks &hooks) {
	util::performance::counter total_elapsed = 0;

	while(true) {
		unsigned int present_vars = hooks.p_varConfig.present_count();
		
		auto run_start = util::performance::current();
		unsigned int run_elim_vars = 0;

		if(hooks.opts.preproc.with_bce)
			preproc_bce(hooks);
		if(hooks.opts.preproc.with_vecd)
			preproc_vecd(hooks, run_elim_vars);
		if(hooks.isUnsatisfiable())
			return;
		if(hooks.opts.preproc.with_selfsub)
			preproc_ssub(hooks);
		if(hooks.isUnsatisfiable())
			return;
		if(hooks.opts.preproc.with_brm)
			preproc_brm(hooks);
		if(hooks.isUnsatisfiable())
			return;
		if(hooks.opts.preproc.with_unhiding)
			preproc_unhide(hooks);
		if(hooks.isUnsatisfiable())
			return;
		auto run_elapsed = util::performance::elapsed(run_start);
		
		total_elapsed += run_elapsed;
		
		if(!another_reduce(hooks, present_vars, run_elim_vars,
				run_elapsed, total_elapsed))
			break;
	}
}


template<typename Hooks>
void preproc_adaptive(Hooks &hooks) {
	preproc_adaptive_initial(hooks);
	if(hooks.isUnsatisfiable())
		return;
	preproc_adaptive_reduce(hooks);
}

