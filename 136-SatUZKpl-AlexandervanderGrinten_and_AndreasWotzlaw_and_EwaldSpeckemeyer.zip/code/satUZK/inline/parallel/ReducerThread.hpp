
void ReducerThread::checkCommand() {
	while(p_commandConsumer.receive()) {
		p_idleRound = false;
		
		auto tag = p_commandConsumer.read<CommandTag>();
		if(tag == CommandTag::kExit) {
			p_threadExitFlag = true;
		}else if(tag == CommandTag::kProblemDef) {
			auto num_vars = p_commandConsumer.read<long>();
				
			p_config.varReserve(num_vars);
			for(long i = 0; i < num_vars; ++i) {
				p_config.varAlloc();
				p_distConfig.onAllocVariable();
			}
		}else if(tag == CommandTag::kClause) {
			auto length = p_commandConsumer.read<int>();
			std::vector<BaseDefs::LiteralId> literals;
			for(int i = 0; i < length; i++) {
				auto literal = p_commandConsumer.read<BaseDefs::LiteralId>();
				literals.push_back(literal);
			}
			
			p_config.reset();
			p_config.inputClause(length, literals.begin(), literals.end());
			p_config.inputFinish();
		}else SYS_CRITICAL("Illegal reducer command");
	}
}

void ReducerThread::checkLearned() {
	const unsigned int kQueueSize = 1000;
	
	for(auto it = p_solverLinks.begin(); it != p_solverLinks.end(); ++it) {
		while(it->p_learnedConsumer.receive()) {
			p_idleRound = false;
			
			auto length = it->p_learnedConsumer.read<int>();
			auto lbd = it->p_learnedConsumer.read<int>();
			std::vector<BaseDefs::LiteralId> literals;
			for(int i = 0; i < length; i++) {
				auto literal = it->p_learnedConsumer.read<BaseDefs::LiteralId>();
				literals.push_back(literal);
			}

			bool import = true;
			if(p_workQueue.size() >= kQueueSize)
				if(lbd >= p_workQueue.top().lbd)
					import = false;
			
			if(import) {
				BaseDefs::ClauseId new_clause = p_config.allocClause(length,
						literals.begin(), literals.end());
				p_config.clauseSetLbd(new_clause, lbd);
				
				// NOTE: the queue is a max-priority-queue. this guarantees
				// that we always keep the items with lowest lbd value, but we
				// process them in reverse order, i.e. highest lbd first
				p_workQueue.push(WorkQueueItem(new_clause, lbd));
				if(p_workQueue.size() > kQueueSize) {
					BaseDefs::ClauseId top_clause = p_workQueue.top().clause;
					p_config.deleteClause(top_clause);
					p_workQueue.pop();
				}
			}
		}
	}
}

void ReducerThread::doWork() {
	class DistHooks {
	public:
		DistHooks(ReducerThread &reducer) : p_reducer(reducer) {
		}

		typedef ReducerConfig::literal_type Literal;
		typedef ReducerConfig::variable_type Variable;
		typedef ReducerConfig::clause_type Clause;
		typedef ReducerConfig::litindex_type ClauseLitIndex;
		typedef ReducerConfig::antecedent_type Antecedent;
		typedef ReducerConfig::activity_type Activity;
		typedef ReducerConfig::ClauseLitIterator ClauseLitIterator;
		typedef ReducerConfig::AntecedentIterator AntecedentIterator;
		typedef ReducerConfig::ConflictIterator ConflictIterator;

		Activity varGetActivity(Variable var) { return p_reducer.p_config.var_activity(var); }
		Antecedent varAntecedent(Variable var) { return p_reducer.p_config.varAntecedent(var); }
		Variable litVariable(Literal lit) { return p_reducer.p_config.litVariable(lit); }
		Literal litInverse(Literal lit) { return p_reducer.p_config.litInverse(lit); }
		bool varIsLocked(Variable var) { return p_reducer.p_config.varIsLocked(var); }
		bool litTrue(Literal lit) { return p_reducer.p_config.litTrue(lit); }
		bool litFalse(Literal lit) { return p_reducer.p_config.litFalse(lit); }
		bool varIsFixed(Variable var) { return p_reducer.p_config.varIsFixed(var); }
		ClauseLitIndex clauseLength(Clause clause) { return p_reducer.p_config.clauseLength(clause); }
		ClauseLitIterator clauseBegin(Clause clause) { return p_reducer.p_config.clauseBegin(clause); }
		ClauseLitIterator clauseEnd(Clause clause) { return p_reducer.p_config.clauseEnd(clause); }
		AntecedentIterator causesBegin(Antecedent antecedent) { return p_reducer.p_config.causesBegin(antecedent); }
		AntecedentIterator causesEnd(Antecedent antecedent) { return p_reducer.p_config.causesEnd(antecedent); }
		void reset() { p_reducer.p_config.reset(); }
		void start() { p_reducer.p_config.start(); }
		void pushLevel() { p_reducer.p_config.pushLevel(); }
		void pushAssign(Variable var, Antecedent antecedent)
			{ p_reducer.p_config.pushAssign(var, antecedent); }
		void propagate() { p_reducer.p_config.propagate(); }
		bool atConflict() { return p_reducer.p_config.atConflict(); }
		bool atSolution() { return p_reducer.p_config.atSolution(); }
		ConflictIterator conflictBegin() { return p_reducer.p_config.conflictBegin(); }
		ConflictIterator conflictEnd() { return p_reducer.p_config.conflictEnd(); }
		void resolveConflict() { p_reducer.p_config.resolveConflict(); }

		struct {
			struct {
				uint64_t dist_checks;
				uint64_t dist_conflicts;
				uint64_t dist_conflicts_removed;
				uint64_t dist_asserts;
				uint64_t dist_asserts_removed;
				uint64_t dist_ssubs;
				uint64_t dist_ssubs_removed;
			} simp;
		} stat;
	private:
		ReducerThread &p_reducer;
	};

	if(p_config.kReportReducerSample) {
		p_config.report<ReducerConfig::ReportTag>(ReducerConfig::ReportTag::kReducerSample);
		p_config.report<uint64_t>(util::performance::current());
		p_config.report<uint32_t>(p_workQueue.size());
	}
	
	DistHooks dist_hooks(*this);

	int num_runs = 0;
	while(!p_workQueue.empty() && num_runs < 1000) {
		p_idleRound = false;
		num_runs++;

		BaseDefs::ClauseId clause = p_workQueue.top().clause;
		p_workQueue.pop();
		if(p_config.clauseLength(clause) == 1) { // TODO: replace this by lbd == 1
			p_reducedProducer.write<int>(p_config.clauseLength(clause));
			p_reducedProducer.write<int>(1);
			for(auto cp = p_config.clauseBegin(clause); cp != p_config.clauseEnd(clause); ++cp)
				p_reducedProducer.write<BaseDefs::LiteralId>(*cp);
			p_reducedProducer.send();
		}else{
			DistResult result = p_distConfig.distill(dist_hooks, clause, p_config.clause_get_first(clause));
			if(result == DistResult::kDistilled) {
				p_reducedProducer.write<int>(p_distConfig.newLiterals.size());
				p_reducedProducer.write<int>(p_distConfig.newLiterals.size());
				for(auto cp = p_distConfig.newLiterals.begin(); //FIXME: don't use private members directly
						cp != p_distConfig.newLiterals.end(); ++cp)
					p_reducedProducer.write<BaseDefs::LiteralId>(*cp);
				p_reducedProducer.send();
				
				p_config.reset();
				p_config.deleteClause(clause);

				BaseDefs::ClauseId new_clause = p_config.allocClause(p_distConfig.newLiterals.size(),
						p_distConfig.newLiterals.begin(), p_distConfig.newLiterals.end());
				p_config.installClause(new_clause);
				
				p_redundantCount++;
			}else if(result == DistResult::kMinimal) {
				p_reducedProducer.write<int>(p_config.clauseLength(clause));
				p_reducedProducer.write<int>(p_config.clauseGetLbd(clause));
				for(auto cp = p_config.clauseBegin(clause); cp != p_config.clauseEnd(clause); ++cp)
					p_reducedProducer.write<BaseDefs::LiteralId>(*cp);
				p_reducedProducer.send();
				
				p_config.reset();
				p_config.installClause(clause);
			}
			p_distCount++;
			p_distConfig.reset();
		}
	}
}

void ReducerThread::run() {
	while(!p_threadExitFlag) {
		p_idleRound = true;
		checkLearned();
		checkCommand();
		doWork();
		if(p_idleRound)
			sched_yield();
	}
	std::cout << std::setprecision(2);
	std::cout << "c redundant: " << (100.0f * p_redundantCount / p_distCount) << "%" << std::endl;
}

void ReducerHooks::onLearnedClause(BaseDefs::ClauseId clause) {
	int length = p_instance.p_config.clauseLength(clause);
	int lbd = p_instance.p_config.clauseGetLbd(clause);
	p_instance.p_reducedProducer.write<int>(length);
	p_instance.p_reducedProducer.write<int>(lbd);
	for(auto it = p_instance.p_config.clauseBegin(clause);
			it != p_instance.p_config.clauseEnd(clause); ++it)
		p_instance.p_reducedProducer.write(*it);
	p_instance.p_reducedProducer.send();
}

