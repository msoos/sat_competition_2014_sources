
namespace util {
namespace memory {
namespace bulk_alloc {

template<typename Index>
class allocator {
public:
	typedef Index index_type;
public:
	allocator(Index alignment) : p_memory(NULL), p_alignment(alignment),
			p_offset(0), p_length(0) { };
	allocator(const allocator &other) = delete;
	allocator &operator= (const allocator &other) = delete;
	
	allocator &operator= (allocator &&other) {
		p_memory = other.p_memory;
		p_alignment = other.p_alignment;
		p_offset = other.p_offset;
		p_length = other.p_length;
		return *this;
	}
	
	void init_memory(void *pointer, Index length) {
		SYS_ASSERT(SYS_ASRT_GENERAL, p_memory == NULL);
		SYS_ASSERT(SYS_ASRT_GENERAL, pointer != NULL);

		p_memory = pointer;
		p_length = length;
		p_offset = 0;
	}
	void move_to(void *pointer, Index length) {
		std::memcpy(pointer, p_memory, p_offset);
		p_memory = pointer;
		p_length = length;
	}
	void *get_memory() {
		return p_memory;
	}
	Index get_total_space() {
		return p_length;
	}
	Index get_free_space() {
		return p_length - p_offset;
	}
	Index get_used_space() {
		return p_offset;
	}

	Index alloc(Index length) {
		Index index = p_offset;
		if(index % p_alignment != 0)
			index += p_alignment - index % p_alignment;
		SYS_ASSERT(SYS_ASRT_GENERAL, index + length < p_length);
		p_offset = index + length;
		return index;
	}

	void *operator[] (Index index) {
		return (void*)((uintptr_t)p_memory + index);
	}
		
private:
	void *p_memory;
	Index p_alignment;
	Index p_offset;
	Index p_length;
};

}}}; /* namespace util::memory::bulk_alloc */

