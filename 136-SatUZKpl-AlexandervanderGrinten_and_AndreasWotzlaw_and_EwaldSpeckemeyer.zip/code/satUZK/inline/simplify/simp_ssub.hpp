
static const uint64_t m1 = 0x5555555555555555LL;
static const uint64_t m2 = 0x3333333333333333LL;
static const uint64_t m4 = 0x0f0f0f0f0f0f0f0fLL;
static const uint64_t m8 = 0x00ff00ff00ff00ffLL;
static const uint64_t m16 = 0x0000ffff0000ffffLL;
static const uint64_t m32 = 0x00000000ffffffffLL;
static const uint64_t hff = 0xffffffffffffffffLL;
static const uint64_t h01 = 0x0101010101010101LL;

inline uint64_t popcount(uint64_t x) {
    x = (x & m1) + ((x >> 1) & m1);
    x = (x & m2) + ((x >> 2) & m2);
    x = (x & m4) + ((x >> 4) & m4);
    x = (x & m8) + ((x >> 8) & m8);
    x = (x & m16) + ((x >> 16) & m16);
    x = (x & m32) + ((x >> 32) & m32);
    return x;
}

/* checks whether the resolvent of both clauses subsumes the
	second clause. the resolved variable must be in both clauses
	in opposite polarity. */
template<typename Hooks>
bool resolvent_subsumes(Hooks &hooks,
		typename Hooks::clause_type clause,
		typename Hooks::clause_type subsumed,
		typename Hooks::variable_type resolved) {
	if(hooks.clause_length(clause) > hooks.clause_length(subsumed))
		return false;
	
	auto clause_sig = hooks.clause_get_sig(clause);
	auto subsumed_sig = hooks.clause_get_sig(subsumed);
	typename Hooks::clause_sig_type diff = (~clause_sig) & subsumed_sig;
	if(popcount(diff) >= 2) {
		hooks.stat.simp.selfsub_shortcuts++;
		return false;
	}

	hooks.stat.simp.selfsub_subchecks++;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		typename Hooks::variable_type var = hooks.lit_getvar(*i);
		if(var == resolved)	
			continue;
		if(!hooks.clause_contains(subsumed, *i))
			return false;
	}
	return true;
}

/* tests if the first clause self-subsumes the second
	and returns the variable that can be resolved */
template<typename Hooks>
bool clause_selfsubs(Hooks &hooks,
		typename Hooks::clause_type clause,
		typename Hooks::clause_type subsumed,
		typename Hooks::variable_type &resolved) {
	resolved = Hooks::kIllegalLit;
	
	if(hooks.clause_length(clause) > hooks.clause_length(subsumed))
		return false;
	
	auto clause_sig = hooks.clause_get_sig(clause);
	auto subsumed_sig = hooks.clause_get_sig(subsumed);
	typename Hooks::clause_sig_type diff = (~clause_sig) & subsumed_sig;
	if(popcount(diff) >= 2) {
		hooks.stat.simp.selfsub_shortcuts++;
		return false;
	}

	hooks.stat.simp.selfsub_reschecks++;	
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		/* test if the variable is in the subsumed clause */
		typename Hooks::variable_type var = hooks.lit_getvar(*i);
		int subsumed_pol = hooks.clause_polarity(subsumed, var);
		if(subsumed_pol == 0)
			return false;
		
		/* test if both polarities are equal */
		int clause_pol = hooks.lit_polarity(*i);
		if(clause_pol == subsumed_pol)
			continue;
		
		/* test if there are two literals of opposite polarities */
		if(resolved != Hooks::kIllegalLit)
			return false;
		resolved = var;
	}
	return true;
}

/* determine the literal with the shortest occurrence list */
template<typename Hooks>
typename Hooks::literal_type selfsub_min_occlist(Hooks &hooks,
		typename Hooks::clause_type clause) {
	unsigned int sub_length = 0;
	typename Hooks::literal_type sub_literal = Hooks::kIllegalLit;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		typename Hooks::literal_type inverse = hooks.lit_inverse(*i);
		if(sub_literal == Hooks::kIllegalLit || hooks.occur_size(*i)
				+ hooks.occur_size(inverse) < sub_length) {
			sub_length = hooks.occur_size(*i) + hooks.occur_size(inverse);
			sub_literal = *i;
		}
	}
	return Hooks::kIllegalLit;
}

/* checks whether the given clause subsumes any other one */
template<typename Hooks>
void selfsub_backward_single(Hooks &hooks,
		typename Hooks::clause_type clause,
		typename Hooks::literal_type sub_literal) {
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.clause_present(clause));
	typename Hooks::literal_type sub_inverse = hooks.lit_inverse(sub_literal);
	
	/* check the clauses containing the inverse:
		we only have to check if the resolvent subsumes the second clause */
	typename Hooks::variable_type sub_var = hooks.lit_getvar(sub_literal);
	for(auto j = hooks.occur_begin(sub_inverse);
			j != hooks.occur_end(sub_inverse); ++j) {
		if(!hooks.clause_present(*j))
			continue;
		if(!resolvent_subsumes(hooks, clause, *j, sub_var))
			continue;
		
		/* build the resolvent */
		auto res_lits = hooks.resolvent_build(*j, clause, sub_var);
		hooks.clause_delete(*j);
		if(res_lits.size() == 1) {
			hooks.installUnit(res_lits.front());
			hooks.stat.simp.selfsub_facts++;
		}else if(res_lits.size() == 2) {
			hooks.installBinary(res_lits.front(), res_lits.back());
		}else{
			typename Hooks::clause_type res_clause = hooks.clause_alloc
					(res_lits.size(), res_lits.begin(), res_lits.end());
			if(hooks.clause_head(*j)->getFlagEssential())
				hooks.clause_head(res_clause)->setFlagEssential();
			
			/* keep the resolvent and delete the second clause */
			hooks.queueInstallClause(res_clause);
			hooks.stat.simp.selfsub_clauses++;
		}
	}
	
	/* check the clauses containing the same literal as our clause:
		we have to do a full subsumption/self-subsumption check */	
	for(auto j = hooks.occur_begin(sub_literal);
			j != hooks.occur_end(sub_literal); ++j) {
		if(*j == clause)
			continue;
		if(!hooks.clause_present(*j))
			continue;
		typename Hooks::variable_type res_var = Hooks::kIllegalVar;
		if(!clause_selfsubs(hooks, clause, *j, res_var))
			continue;
		
		if(res_var == Hooks::kIllegalVar) {
			/* regular subsumption: delete the second clause */
			if(hooks.clause_head(*j)->getFlagEssential())
				hooks.clause_head(clause)->setFlagEssential();
			hooks.clause_delete(*j);
			hooks.stat.simp.subsumed_clauses++;
		}else{
			/* self-subsumption: build the resolvent */
			auto res_lits = hooks.resolvent_build(*j, clause, res_var);
			hooks.clause_delete(*j);
			if(res_lits.size() == 1) {
				hooks.installUnit(res_lits.front());
				hooks.stat.simp.selfsub_facts++;
			}else if(res_lits.size() == 2) {
				hooks.installBinary(res_lits.front(), res_lits.back());
			}else{
				typename Hooks::clause_type res_clause = hooks.clause_alloc
						(res_lits.size(), res_lits.begin(), res_lits.end());
				if(hooks.clause_head(*j)->getFlagEssential())
					hooks.clause_head(res_clause)->setFlagEssential();
				
				/* keep the resolvent and delete the second clause */
				hooks.queueInstallClause(res_clause);
				hooks.stat.simp.selfsub_clauses++;
			}
		}
	}

	hooks.installQueueProcess();
	hooks.checkClauseGarbage();
}

/* applies forward subsumption to all clauses */
template<typename Hooks>
void selfsub_backward_all(Hooks &hooks) {
	for(typename Hooks::variable_type var = 0; var < hooks.p_varConfig.count(); ++var) {
		/* we need a queue here because the occlists can change during the algorithm */
		std::vector<typename Hooks::clause_type> queue;
		
		typename Hooks::literal_type lit0 = hooks.zero_literal(var);
		for(auto j = hooks.occur_begin(lit0);
				j != hooks.occur_end(lit0); ++j)
			queue.push_back(*j);
		for(auto j = queue.begin(); j != queue.end(); ++j) {
			if(!hooks.clause_present(*j))
				continue;
			if((hooks.clause_head(*j)->getFlagCheckedSsub()) != 0)
				continue;
			selfsub_backward_single(hooks, *j, lit0);
			hooks.clause_head(*j)->setFlagCheckedSsub();
			if(hooks.isUnsatisfiable())
				return;
		}
		queue.clear();

		typename Hooks::literal_type lit1 = hooks.one_literal(var);
		for(auto j = hooks.occur_begin(lit1);
				j != hooks.occur_end(lit1); ++j)
			queue.push_back(*j);
		for(auto j = queue.begin(); j != queue.end(); ++j) {
			if(!hooks.clause_present(*j))
				continue;
			if((hooks.clause_head(*j)->getFlagCheckedSsub()) != 0)
				continue;
			selfsub_backward_single(hooks, *j, lit1);
			hooks.clause_head(*j)->setFlagCheckedSsub();
			if(hooks.isUnsatisfiable())
				return;
		}
	}

	hooks.installQueueProcess();
	hooks.checkClauseGarbage();
}

