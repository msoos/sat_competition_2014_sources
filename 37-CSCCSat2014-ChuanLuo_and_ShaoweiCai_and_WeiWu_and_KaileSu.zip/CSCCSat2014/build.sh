#!/bin/bash

rm -rf binary/
mkdir binary/
cd ./code/CSCCSat2014/
make
cp CSCCSat2014 ../../binary/CSCCSat2014
make cleanup

