#ifndef _FRWCB2014_H
#define _FRWCB2014_H

#include "basic.h"
#include "FrwCB2014_help.h"

int prob = 600*10000;

int pick_var_huge_FrwCB2014()
{
	int             c,v,ci;
	int             best_var,best_score;
	int		v_score;
	int		most_conf_var;
	struct lit 		*p,*q;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	
	p=clause_lit[c];
	for(;(v=p->var_num)!=0; p++)
	{
		bscore[v]=mscore[v]=0;
		for(q = var_lit[v]; (ci=q->clause_num)!=-1; q++)
		{
			if (sat_count[ci]==1 && q->sense==cur_soln[v]) bscore[v]++;
			else if(sat_count[ci]==0) mscore[v]++;
		}
	}

	best_var=0;
	p=clause_lit[c];
	for(;(best_var=p->var_num)!=0; p++)
	{
		if(conf_change[best_var]!=0)
			break;
	}
	best_score = mscore[best_var]-bscore[best_var];
	if(best_var!=0)
	{
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(conf_change[v]==0)
				continue;
			v_score = mscore[v]-bscore[v];
			if(v_score>best_score)
			{
				best_var = v;
				best_score = v_score;
			}
			else if(v_score<best_score)
				continue;
			else if(conf_change[v]>conf_change[best_var])
				best_var = v;
			else if(conf_change[v]<conf_change[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
	}
	if(best_var!=0 && best_score>0)
		return best_var;
		
	if(rand()%MY_RAND_MAX_INT<prob)
	{
		p=clause_lit[c];
		best_var = p->var_num;
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(bscore[v]<bscore[best_var])
				best_var = v;
			else if(bscore[v]>bscore[best_var])
				continue;
			else if(conf_change[v]>conf_change[best_var])
				best_var = v;
			else if(conf_change[v]<conf_change[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
		return best_var;
	}
	
	
	p=clause_lit[c];
	most_conf_var = p->var_num;
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_change[v]>conf_change[most_conf_var])
			most_conf_var = v;
		else if(conf_change[v]<conf_change[most_conf_var])
			continue;
		else if(time_stamp[v]<time_stamp[most_conf_var])
			most_conf_var = v;
		
	}
	
	return most_conf_var;
	
}


//pick a var to be flip
int pick_var_normal_FrwCB2014()
{
	int             c,v;
	int             best_var,best_score;
	int		v_score;
	int		most_conf_var;
	struct lit 		*p;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];

	best_var=0;
	p=clause_lit[c];
	for(;(best_var=p->var_num)!=0; p++)
	{
		if(conf_change[best_var]!=0)
			break;
	}
	best_score = mscore[best_var]-bscore[best_var];
	if(best_var!=0)
	{
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(conf_change[v]==0)
				continue;
			v_score = mscore[v]-bscore[v];
			if(v_score>best_score)
			{
				best_var = v;
				best_score = v_score;
			}
			else if(v_score<best_score)
				continue;
			else if(conf_change[v]>conf_change[best_var])
				best_var = v;
			else if(conf_change[v]<conf_change[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
	}
	if(best_var!=0 && best_score>0)
		return best_var;
		
	if(rand()%MY_RAND_MAX_INT<prob)
	{
		p=clause_lit[c];
		best_var = p->var_num;
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(bscore[v]<bscore[best_var])
				best_var = v;
			else if(bscore[v]>bscore[best_var])
				continue;
			else if(conf_change[v]>conf_change[best_var])
				best_var = v;
			else if(conf_change[v]<conf_change[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
		return best_var;
	}
	
	
	p=clause_lit[c];
	most_conf_var = p->var_num;
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_change[v]>conf_change[most_conf_var])
			most_conf_var = v;
		else if(conf_change[v]<conf_change[most_conf_var])
			continue;
		else if(time_stamp[v]<time_stamp[most_conf_var])
			most_conf_var = v;
		
	}
	
	return most_conf_var;
	
}

const int w1=3;
const int w2=2;

//pick a var to be flip
int pick_var_lm_FrwCB2014()
{
	int             i,c,v;
	int             best_var,best_score;
	int		v_score;
	int		most_conf_var;
	lit 		*p;
	
	c = unsat_stack[rand()%unsat_stack_fill_pointer];

	best_var=0;
	p=clause_lit[c];
	for(;(best_var=p->var_num)!=0; p++)
	{
		if(conf_change[best_var]!=0)
			break;
	}
	best_score = mscore[best_var]-bscore[best_var];
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_change[v]==0)
			continue;
		v_score = mscore[v]-bscore[v];
		if(v_score>best_score)
		{
			best_var = v;
			best_score = v_score;
		}
		else if(v_score<best_score)
			continue;
		else if(conf_change[v]>conf_change[best_var])
			best_var = v;
		else if(conf_change[v]<conf_change[best_var])
			continue;
		else if(time_stamp[v]<time_stamp[best_var])
			best_var = v;
	}
	
	if(best_var!=0 && best_score>0)
		return best_var;
		
	if(rand()%MY_RAND_MAX_INT<prob)
	{
		p=clause_lit[c];
		best_var = p->var_num;
		for(p++; (v=p->var_num)!=0; p++)
		{
			if(bscore[v]<bscore[best_var])
				best_var = v;
			else if(bscore[v]>bscore[best_var])
				continue;
			else if(mscore[v]*w1+mscore_2[v]*w2>mscore[best_var]*w1+mscore_2[best_var]*w2)
				best_var = v;
			else if(mscore[v]*w1+mscore_2[v]*w2<mscore[best_var]*w1+mscore_2[best_var]*w2)
				continue;
			else if(conf_change[v]>conf_change[best_var])
				best_var = v;
			else if(conf_change[v]<conf_change[best_var])
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
		return best_var;
	}
	
	
	p=clause_lit[c];
	most_conf_var = p->var_num;
	for(p++; (v=p->var_num)!=0; p++)
	{
		if(conf_change[v]>conf_change[most_conf_var])
			most_conf_var = v;
		else if(conf_change[v]<conf_change[most_conf_var])
			continue;
		else if(time_stamp[v]<time_stamp[most_conf_var])
			most_conf_var = v;
		
	}
	
	return most_conf_var;
	
}


#endif

