************ Details about the solver ************
Name: CSCCSat2014
Version: SC2014
Authors: Chuan Luo [1], Shaowei Cai [2], Wei Wu [1], Kaile Su [3]
[1] School of EECS, Peking University, Beijing, China.
[2] State Key Laboratory of Computer Science, Institute of Software, Chinese Academy of Sciences, Beijing, China.
[3] IIIS, Griffith University, Brisbane, Australia.
**************************************************

************ Corresponding papers ****************
[1] Chuan Luo, Shaowei Cai, Wei Wu, Kaile Su: Focused Random Walk with Configuration Checking and Break Minimum for Satisfiability. In Proc. of CP 2013, pp. 481-496.
[2] Chuan Luo, Shaowei Cai, Wei Wu, Kaile Su: Double Configuration Checking in Stochastic Local Search for Satisfiability. To appear in Proc. of AAAI 2014.
**************************************************

************ How to build the solver *************
Execute the following command:
./build.sh
**************************************************

************ How to use the solver ***************
First, enter the directory 'binary'.
Then execute the following command:
./CSCCSat2014 <instance> <seed>
**************************************************
