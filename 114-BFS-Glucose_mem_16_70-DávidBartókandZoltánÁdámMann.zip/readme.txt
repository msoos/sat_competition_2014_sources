Solver name: BFS-Glucose_mem


Version: 1.0c (SAT Competition 2014 Edition)



Authors:


David Bartok

Computer Science BSc Student

Budapest University of Technology and Economics



Zoltan Adam Mann

Associate professor

Department of Computer Science and Information Theory

Budapest University of Technology and Economics



HELP:

Building the solver:

Run the build.sh shell script



Usage of the solver:

Run "BFSglucose" in the "/binary" folder



The solver requires following command line:

DIR/BFSglucose INSTANCE