Author:
Mate Soos (soos.mate@gmail.com)

Name:
cryptominisat-v4.1

Description:
CryptoMiniSat v4.1

* Uses M4RI linear algebra library from
    http://m4ri.sagemath.org/downloads/
  with licence GPLv2

Needs:
* boost
* cmake

Build:
Use cmake, with the parameters you find in build.sh. Then type "make".

Usage:
./cryptominisat problem.CNF
