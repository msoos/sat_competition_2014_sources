#!/bin/sh
# Norbert Manthey, 2014
#
# script to clean the SAT solver Riss
#

# remove binary directory
rm -rf binary

# clean Riss
cd code;
make clean

# return to calling directory
cd ..
