#!/bin/sh
# Norbert Manthey, 2014
#
# script to build the SAT solver Pcasso
#

# setup binary directory
rm -rf binary
mkdir -p binary

cd code;
# build Pcasso
make pcassoRS
cp pcasso ../binary/

# build Coprocessor
make clean
make coprocessorRS
cp coprocessor ../binary/

# copy the call scripts
cp scripts/*.sh ../binary/

# return to calling directory
cd ..
