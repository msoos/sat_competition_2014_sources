#!/bin/bash

SHDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
if [ -z "$SHDIR" ]; then SHDIR="."; fi

cd $SHDIR
mkdir -p binary

cd code/simp
make clean

make rs
cp -f SWDiA5BY_static ../../binary
