This software package contains the SAT solver "CPSparrow"
Adrian Balint 2014

The SAT solver "CPSparrow" combines the SLS solver Sparrow with 
the preprocessor Coprocessor.

The CNF simplifier Coprocessor is used to simplify
the input formula. Then the SAT Solver Sparrow is used to solve the problem.

To build the solve, run the script
	./build.sh
	
To run the solver, use the shell script
	./CPSparrow.sh <input.cnf> <seed> <TMPDIR>

