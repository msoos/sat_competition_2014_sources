#!/bin/sh
# Adrian Balint, 2014
#
# script to build the SAT solver CPSparrow
#

# setup binary directory
rm -rf binary
mkdir -p binary

cd code/Coprocessor

# build Coprocessor
make clean
make coprocessorRS
cp coprocessor ../../binary/

# build sparrow
cd ../Sparrow
make sparrow
cp sparrow ../../binary

# copy the call script
cd ..
cp scripts/CPSparrow.sh ../binary

# return to calling directory
cd ..
