#!/usr/bin/env python
import os
import subprocess as sp
import sys

def tree(d, inst, tmp):
	if d['POSNEG.RATIO.CLAUSE.coeff.variation'] <= 0.411701:
		sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
	elif d['POSNEG.RATIO.CLAUSE.coeff.variation'] > 0.411701 :
		if d['HORNY.VAR.max'] <= 0.000079 :
			if d['POSNEG.RATIO.VAR.mean'] <= 0.223424:
				sys.exit(sp.call("./comb.sh %s %s" %(inst, tmp), shell=True))
			elif d['POSNEG.RATIO.VAR.mean'] > 0.223424 :
				if d['VCG.CLAUSE.max'] <= 0.000104 :
					if d['nvarsOrig'] <= 259234:
						sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
					elif d['nvarsOrig'] > 259234:
						sys.exit(sp.call("./comb.sh %s %s" %(inst, tmp), shell=True))
				elif d['VCG.CLAUSE.max'] > 0.000104:
					sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
		elif d['HORNY.VAR.max'] > 0.000079 :
			if d['BINARY.'] <= 0.005073 :
				if d['VCG.VAR.min'] <= 0.000084:
					sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
				elif d['VCG.VAR.min'] > 0.000084:
					sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
			elif d['BINARY.'] > 0.005073 :
				if d['HORNY.VAR.min'] <= 0.00234 :
					if d['HORNY.VAR.max'] <= 0.002257 :
						if d['VCG.VAR.min'] <= 0.0001 :
							if d['HORNY.VAR.min'] <= 0.000021 :
								if d['nvars'] <= 333123 :
									if d['VCG.VAR.min'] <= 0.000015 :
										if d['VCG.VAR.entropy'] <= 1.428231 :
											if d['VCG.VAR.max'] <= 0.000233:
												sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
											elif d['VCG.VAR.max'] > 0.000233 :
												if d['VCG.VAR.entropy'] <= 1.40333 :
													if d['nvars'] <= 105336:
														sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
													elif d['nvars'] > 105336:
														sys.exit(sp.call("./comb.sh %s %s" %(inst, tmp), shell=True))
												elif d['VCG.VAR.entropy'] > 1.40333:
													sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
										elif d['VCG.VAR.entropy'] > 1.428231:
											sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
									elif d['VCG.VAR.min'] > 0.000015 :
										if d['VCG.CLAUSE.mean'] <= 0.000908 :
											if d['nclausesOrig'] <= 273506:
												sys.exit(sp.call("./comb.sh %s %s" %(inst, tmp), shell=True))
											elif d['nclausesOrig'] > 273506 :
												if d['TRINARY.'] <= 0.542769:
													sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
												elif d['TRINARY.'] > 0.542769:
													sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
										elif d['VCG.CLAUSE.mean'] > 0.000908:
											sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
								elif d['nvars'] > 333123 :
									if d['nvarsOrig'] <= 580875:
										sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
									elif d['nvarsOrig'] > 580875:
										sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
							elif d['HORNY.VAR.min'] > 0.000021 :
								if d['POSNEG.RATIO.CLAUSE.entropy'] <= 2.180197:
									sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
								elif d['POSNEG.RATIO.CLAUSE.entropy'] > 2.180197:
									sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
						elif d['VCG.VAR.min'] > 0.0001 :
							if d['POSNEG.RATIO.VAR.mean'] <= 0.182015 :
								if d['VCG.CLAUSE.entropy'] <= 1.550117:
									sys.exit(sp.call("./comb.sh %s %s" %(inst, tmp), shell=True))
								elif d['VCG.CLAUSE.entropy'] > 1.550117:
									sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
							elif d['POSNEG.RATIO.VAR.mean'] > 0.182015 :
								if d['TRINARY.'] <= 0.939446 :
									if d['VCG.CLAUSE.coeff.variation'] <= 1.082328:
										sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
									elif d['VCG.CLAUSE.coeff.variation'] > 1.082328:
										sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
								elif d['TRINARY.'] > 0.939446:
									sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
					elif d['HORNY.VAR.max'] > 0.002257 :
						if d['VG.min'] <= 0.002224 :
							if d['POSNEG.RATIO.CLAUSE.mean'] <= 0.336406:
								sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
							elif d['POSNEG.RATIO.CLAUSE.mean'] > 0.336406 :
								if d['HORNY.VAR.min'] <= 0.000021 :
									if d['VCG.VAR.coeff.variation'] <= 1.121595:
										sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
									elif d['VCG.VAR.coeff.variation'] > 1.121595:
										sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
								elif d['HORNY.VAR.min'] > 0.000021:
									sys.exit(sp.call("./ms.sh %s %s" %(inst, tmp), shell=True))
						elif d['VG.min'] > 0.002224:
							sys.exit(sp.call("./ms.sate.sh %s %s" %(inst, tmp), shell=True))
				elif d['HORNY.VAR.min'] > 0.00234:
					sys.exit(sp.call("./neg.ms.sh %s %s" %(inst, tmp), shell=True))
