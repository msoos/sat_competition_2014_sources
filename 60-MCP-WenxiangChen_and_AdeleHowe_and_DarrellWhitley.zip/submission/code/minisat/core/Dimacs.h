/****************************************************************************************[Dimacs.h]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#ifndef Minisat_Dimacs_h
#define Minisat_Dimacs_h

#include <stdio.h>
/* #include <iostream> */
#include "utils/ParseUtils.h"
#include "core/SolverTypes.h"
#include "mtl/Sort.h"

namespace Minisat {

  //=================================================================================================
  // DIMACS Parser:

  template<class B, class Solver>
    static void readClause(B& in, Solver& S, vec<Lit>& lits) {
    int     parsed_lit, var;
    lits.clear();
    for (;;){
      parsed_lit = parseInt(in);
      /* printf ("%d\t",parsed_lit); */
      if (parsed_lit == 0) break;
      var = abs(parsed_lit)-1;
      while (var >= S.nVars()) S.newVar();
      lits.push( (parsed_lit > 0) ? mkLit(var) : ~mkLit(var) );
    }
    /* printf ("\n"); */
  }
  
  template<class B, class Solver>
    static void parse_DIMACS_main(B& in, Solver& S) {
    vec<Lit> lits;
    int vars    = 0;
    int clauses = 0;
    int cnt     = 0;
    for (;;){
      skipWhitespace(in);
      if (*in == EOF) break;
      else if (*in == 'p'){
        if (eagerMatch(in, "p cnf")){
          vars    = parseInt(in);
          clauses = parseInt(in);
          // SATRACE'06 hack
          // if (clauses > 4000000)
          //     S.eliminate(true);
        }else{
          printf("c PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
        }
      } else if (*in == 'c' || *in == 'p')
        skipLine(in);
      else{
        cnt++;
        readClause(in, S, lits);
        S.addClause_(lits);
        /* printf("c %d\n",  S.nClauses()); */
      }
    }
    if (vars != S.nVars())
      fprintf(stderr, "WARNING! DIMACS header mismatch: wrong number of variables.\n");
    if (cnt  != clauses)
      fprintf(stderr, "WARNING! DIMACS header mismatch: wrong number of clauses.\n");
  }

  template<class Solver>
    static void parse_hyperplane_constraint(const char* path, Solver& S)
    {
      /* parse hyperplane constraint from path */
      gzFile input_stream = gzopen(path, "rb");
      StreamBuffer in(input_stream);
      vec<Lit> lits;
      /* lits.clear(); */

      /* ignore first (S.num_unsat - 1) lines */
      for (int i=0; i< S.hyper_rank-1; i++)
        {
          skipLine(in);
        }
      
      /* printf ("start readClause for hyperplane\n"); */
      /* for (;;) */
      /*   { */
      skipWhitespace(in);
      /* if (*in == EOF)  */
      /*   { */
      /*     break; */
      /*   } */
      readClause(in, S, lits);
      /* } */
      gzclose(input_stream);
      /* printf ("end readClause for hyperplane\n"); */
      
      /* printf("c l_True=%d, l_false=%d, l_undef=%d\n", toInt(l_True), toInt(l_False), toInt(l_Undef)); */
      
      /* for(int i=0; i<lits.size(); i++) */
      /*   { */
      /*     printf ("%d\t",toRealInt(lits[i])); */
      /*   } */
      /* printf ("\n"); */

      /* printf ("\nstart addUnitclause\n"); */
      /* S.addUnitClause(lits); */
      for(int i=0; i<lits.size(); i++)
        {
          vec<Lit> temp_lits;
          /* temp_lits.clear(); */
          temp_lits.push(lits[i]);
          S.addClause(temp_lits);
        }
      /* printf ("end addUnitclause\n\n"); */
    }

  template<class Solver>
    static void parse_unsat_constraint_negation(const char* path, Solver& S)
    {
      /* parse unsat constraint from path
         allows to take mutiple unsat constrants
      */
      
      gzFile input_stream = gzopen(path, "rb");
      StreamBuffer in(input_stream);
      int count=0;
      
      vec<Lit> lits;
      lits.clear();
      
      while (count<S.num_unsat)
        {
          skipWhitespace(in);
          if (*in == EOF) 
            {
              break;
            }
          /* printf("c readClause\n"); */
          readClause(in, S, lits);
          /* printf ("before negation\n"); */
          /* for (int i=0; i<lits.size(); i++) */
          /*   { */
          /*     printf ("%d (%d)\t\n",toInt(lits[i]), toRealInt(lits[i])); */
          /*   } */
          /* printf ("\n"); */

          /* negate all literals in lis vector */
          for (int i=0; i<lits.size(); i++)
            {
              lits[i] = ~lits[i];
            }

          /* printf ("after negation\n"); */
          /* for (int i=0; i<lits.size(); i++) */
          /*   { */
          /*     printf ("%d (%d)\t\n",toInt(lits[i]), toRealInt(lits[i])); */
          /*   } */
          /* printf ("\n"); */

          S.addClause_(lits);
          count++;
        }
      gzclose(input_stream);
    }

  
  // Inserts problem into solver.
  //
  template<class Solver>
    static void parse_DIMACS(gzFile input_stream, Solver& S) {
    StreamBuffer in(input_stream);

    parse_DIMACS_main(in, S); 
    /* printf("c finish parse_DIMACS_main\n"); */
    /* if (S.verbosity > 0){ */
    /*   printf("c |  Number of variables:  %12d                                         |\n", S.nVars()); */
    /*   printf("c |  Number of clauses:    %12d                                         |\n", S.nClauses()); } */

    if (S.hyper_path)
      {                         /* read hyperplane path */
        FILE* fp;
        
        if ((fp = fopen(S.hyper_path, "r")) == NULL) {
          printf("c ERROR: hyper_path %s not found\n", S.hyper_path);
          exit(0);
        }
        parse_hyperplane_constraint((const char*)S.hyper_path, S);
      }
    
    if (S.unsat_path)
      {
        FILE* fp;
        if ((fp = fopen(S.unsat_path, "r")) == NULL) {
          printf("c ERROR: unsat_path %s not found\n", S.unsat_path);
          exit(0);
        }
        parse_unsat_constraint_negation((const char*)S.unsat_path, S);
      }
  }
  
  
  //=================================================================================================
}

#endif

