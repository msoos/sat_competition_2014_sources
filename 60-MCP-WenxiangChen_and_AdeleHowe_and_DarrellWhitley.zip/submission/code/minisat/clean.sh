cd simp
make clean
cd ../core
make clean
cd ../utils
make clean
cd ..

