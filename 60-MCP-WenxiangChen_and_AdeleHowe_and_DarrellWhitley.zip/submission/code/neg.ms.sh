#!/bin/bash

# negating instance first and running the lastest version of minisat 2.2, need the print the negated solution as well

if [ -n "$2" ]; then
	TMPDIR=$2
else
	TMPDIR=/tmp
fi


# To set in a normal envirnement
mypath=.
TMP=$TMPDIR/hpms_$$        # set this to the location of temporary files, $$ is the process ID
RS=$mypath/minisat2.2-hyper       # set this to the executable of minisat
INPUT=$1;                               # 
shift

echo 'c neg.ms.sh'
echo "c Negating instance at $TMP"
./negOneInstance.py $INPUT $TMP.neg
echo "c"
echo "c Starting minisat on original reduction"
echo "c" 
echo -n "7 " >> $TMP.time
start=$(date +%s%N)
$RS $TMP.neg > $TMP.out
X=$?
# recover the right solution
./negSol.py $TMP.out

spent=$(($(date +%s%N)-${start}))
echo "$(echo "scale=9;$spent/(1*10^09)" | bc)" >> $TMP.time

exit $X
