#!/usr/bin/env python

# master script for learned portfolio
import subprocess as sp
import sys
import re
import os
import tree
inst = sys.argv[1]
if len(sys.argv)>2:
    tmp = sys.argv[2]
else:
    tmp = '/tmp'
# inst = 'test.cnf'

# print 'c tmp = {}'.format(tmp)
# print 'c tmp = %s' % (tmp)
print 'c tmp =', tmp

featBin = './features'
backup = './ms.sh'

# compute features
p = sp.Popen([featBin, inst], stdout=sp.PIPE, stderr=sp.PIPE)
out, err = p.communicate()

# print 'c out:', out
print 'c err:', err

# read features
out = filter(lambda i: i[0]!='c', out.strip().split('\n'))
if out:
    names = out[0].split(',')
    names = map( lambda i : re.sub('[-+]','.', i), names)  # convert special symbols to conform R standard (dots)
    values = out[1].split(',')
    values = map(float, values)     # convert string to numeric

    d = dict(zip(names,values))
    exit(tree.tree(d, inst, tmp))
else:                           # feature computation fails, call
    # print 'c use backup {}'.format(backup)
    print 'c use backup', backup
    # exit(sp.call('{} {}'.format(backup, inst), shell=True))
    exit(sp.call('%s %s' %(backup, inst), shell=True))
