#!/bin/bash
module load python/2.7.1
python ./MCP.py $1 $2
