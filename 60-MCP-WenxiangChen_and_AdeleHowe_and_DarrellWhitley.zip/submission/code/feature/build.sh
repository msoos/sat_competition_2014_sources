g++ *.cpp *.cc -O5 -o features
