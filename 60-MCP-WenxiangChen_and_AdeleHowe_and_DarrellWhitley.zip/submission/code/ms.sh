#!/bin/bash
# running the lastest version of minisat 2.2

if [ -n "$2" ]; then
	TMPDIR=$2
else
	TMPDIR=/tmp
fi

echo 'c ms.sh'

# To set in a normal envirnement
mypath=.
TMP=$TMPDIR/hpms_$$        # set this to the location of temporary files, $$ is the process ID
RS=$mypath/minisat2.2-hyper       # set this to the executable of minisat
INPUT=$1;                               # 
shift

#Hyperplane reduction unsat or indet, run minisat on original
#rm -f $TMP.pre.cnf $TMP.pre.vmap $TMP.pre.elim $TMP.pre.result $TMP.cnf.1
echo "c"
echo "c Starting minisat on original reduction"
echo "c" 
echo -n "7 " >> $TMP.time
start=$(date +%s%N)
$RS $INPUT
X=$?
spent=$(($(date +%s%N)-${start}))
echo "$(echo "scale=9;$spent/(1*10^09)" | bc)" >> $TMP.time

exit $X
