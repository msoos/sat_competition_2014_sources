#!/usr/bin/env python
# negate all literals in a instance

import re
import os
import time
import sys


# fpath = '/home/chenwx/workspace/inst/sat13/SATBench/satchal12-submitted/application/SAT2012_AES/Benchmarks/24/aes_24_4_keyfind_2.cnf'
# inst = 'aes-24-2'

fpath = sys.argv[1]

outpath = sys.argv[2]

# with open(fpath, 'r') as inf, open(outpath, 'w') as outf:
inf = open(fpath, 'r')
outf = open(outpath, 'w')
for line in inf:
    if line[0]=='p':
        print >>outf, line,
    elif line[0]!='c':
        terms = line.split()
        # print 't', terms
        negTerms = [ str(-int(i)) for i in terms]
        # print 'n', negTerms
        print >>outf, ' '.join(negTerms)
