#!/bin/bash
# running satelite before minisat

if [ -n "$2" ]; then
	TMPDIR=$2
else
	TMPDIR=/tmp
fi

echo 'c ms.sate.sh'

# To set in a normal envirnement
mypath=.
TMP=$TMPDIR/hpms_$$        # set this to the location of temporary files, $$ is the process ID
SE=$mypath/SatELite_release     # set this to the executable of SatELite
RS=$mypath/minisat2.2-hyper       # set this to the executable of minisat

INPUT=$1;                               # 
shift 
echo "c"
echo "c Starting SatElite Preprocessing $TMP"
echo "c"
echo "c $SE $INPUT $TMP.cnf $TMP.vmap $TMP.elim"

echo -n "1 " >> $TMP.time
start=$(date +%s%N)

$SE $INPUT $TMP.cnf $TMP.vmap $TMP.elim # 1
X=$?                 # find the error code of the last executed command.

spent=$(($(date +%s%N)-${start}))
echo "$(echo "scale=9;$spent/(1*10^09)" | bc)" >> $TMP.time

echo 'c return code' $X
if [ $X == 0 ]; then
    #Hyperplane reduction unsat or indet, run minisat on original
    #rm -f $TMP.pre.cnf $TMP.pre.vmap $TMP.pre.elim $TMP.pre.result $TMP.cnf.1
    echo "c"
    echo "c Starting minisat on original reduction preprocesed by satelite"
    echo "c" 
    echo -n "7 " >> $TMP.time
    start=$(date +%s%N)
    $RS $TMP.cnf $TMP.result "$@" > $TMP.null # 7
    X=$?
    spent=$(($(date +%s%N)-${start}))
    echo "$(echo "scale=9;$spent/(1*10^09)" | bc)" >> $TMP.time
    if [ $X == 20 ]; then
        echo "s UNSATISFIABLE"
        #rm -f $TMP.cnf $TMP.vmap $TMP.elim $TMP.result $TMP.null
        exit 20
        #Don't call SatElite for model extension.
    elif [ $X != 10 ]; then
        #timeout/unknown, nothing to do, just clean up and exit.
        #rm -f $TMP.cnf $TMP.vmap $TMP.elim $TMP.result $TMP.null
        exit $X
    fi 
	echo "c model extension.."
    echo -n "8 " >> $TMP.time
    start=$(date +%s%N)
    #SATISFIABLE, call SatElite for model extension
    $SE +ext $INPUT $TMP.result $TMP.vmap $TMP.elim  "$@" # 8
    #rm -f $TMP.cnf $TMP.vmap $TMP.elim $TMP.result $TMP.null
    X=$?
    spent=$(($(date +%s%N)-${start}))
    echo "$(echo "scale=9;$spent/(1*10^09)" | bc)" >> $TMP.time
    exit 10
elif [ $X == 11 ]; then
    #SatElite died, glucose must take care of the rest
    echo "c"
    echo "c SatElite died, Starting minisat on original problem"
    echo "c"
    echo -n "12 " >>$TMP.time
    start=$(date +%s%N)
    $RS $INPUT
    X=$?
    spent=$(($(date +%s%N)-${start}))
    echo "$(echo "scale=9;$spent/(1*10^09)" | bc)" >> $TMP.time
fi

#rm -f $TMP.cnf $TMP.vmap $TMP.elim $TMP.result $TMP.cnf.1
exit $X
