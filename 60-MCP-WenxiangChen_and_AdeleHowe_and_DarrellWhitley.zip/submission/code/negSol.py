#!/usr/bin/env python
# negating solution and print the solutions original

import sys
import re
fpath = sys.argv[1]
# with open(fpath) as f:
f = open(fpath)
fstring = f.read()
if 's SATISFIABLE' in fstring:   # only check those instances that have been found satisfiable
    print 's SATISFIABLE'
    sol =  re.sub("v", "", "".join(re.findall(r'^v.*', fstring, re.M))).strip()
    sol = " ".join([str(-int(i)) for i in sol.split()])
    print 'v', sol
