#!/bin/bash

mkdir binary 2>/dev/null

echo 'building hyperplane...'
cd code/hyperplane/
make
cd ../../
mv code/hyperplane/best_hyperplane binary

echo 'building minisat...'
cd code/minisat/
./build.sh
cd ../../
mv code/minisat/minisat2.2-hyper binary

echo 'building satelite...'
cd code/satelite/
./build.sh
cd ../../
mv code/satelite/SatELite_release binary

echo "building features..."
cd code/feature/
./build.sh
cd ../../
mv code/feature/features binary

cp code/*.sh code/*.py binary
