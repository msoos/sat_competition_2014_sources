g++ code/CCA2014.cpp -O3 -o binary/CCA2014
