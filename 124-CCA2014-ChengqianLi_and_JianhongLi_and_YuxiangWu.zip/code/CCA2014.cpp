/*********************************************************************************                              
                            CCA2014

                            April 2014

  This code was written by Chengqian Li at Sun Yat-sen University.

               Do not distribute without permission.
           Include this notice in any copy made.

       Copyright (c) 2014 by Sun Yat-sen University,
                   Guangzhou, China

                        All Rights Reserved

  Permission to use, copy, and modify, this software and its documentation for 
  research purpose is hereby granted without fee,  provided that the above 
  copyright notice appears in all copies and  that both the copyright notice 
  and this permission notice appear in  supporting documentation, and that the 
  name of Sun Yat-sen University  not be used in advertising or publicity 
  pertaining to  distribution of the software without specific, written prior 
  permission.  Sun Yat-sen University makes no representations about the 
  suitability of this software for any purpose.  It is provided "as is" without 
  express or implied warranty.


  Sun Yat-sen University DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, 
  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT 
  SHALL Sun Yat-sen University BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
  CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, 
  DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER 
  TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
  OF THIS SOFTWARE.
  
    This code cannot be used in any business purpose.

*********************************************************************************/



/************************************=== CCA2014 ===***************************************         
** CCA2014 is a local search solver for the Boolean Satisfiability (SAT) problem.
** We have referred to CCASat, but we write our codes ourselves, and we
** have fixed some bugs in the original source codes.
** CCA2014 is implemented by Chengqian Li, 
** when he was in Department of Computer Science, Sun Yat-sen University,
** and this solver exploits the strategies of both Chengqian Li and Yi Fan,
** who is from Institute of Integrated and Intelligent Systems, Griffith University.   
** Email: 498727460@qq.com
*****************************************************************************************/


/************************************=== Acknowledgement ===*************************************
** We thank Prof. Yongmei Liu for introducing us into such an
** exciting and competitive domain. We also thank Prof. Kaile Su
** and Dr. Shaowei Cai for sharing their state-of-the-art strategies
** with us.
************************************************************************************************/
///lit vfc
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
//bool *r,r= new bool[100]; is wrong
//float to double increase effitiont

typedef long long LL;


int debug_pause=0;
int debug_write=0;


//#define MAX_VARS    2000010
//#define MAX_CLAUSES 10000000

//int cons_d=13;
//int cons_beta=2000;


int probtype;
int max_clause_len;
int min_clause_len;
float smooth_probability;
int large_clause_count_threshold;
int delta_age;
const int   	  MY_RAND_MAX_INT =   10000000;
const float 	BASIC_SCALE = 0.0000001; //1.0f/MY_RAND_MAX_FLOAT;






int gama=300;
float ro=0.3;
float ro2=0.7;
int weight2;

int oo=0x7fffffff;

int debug=1;

FILE* file;

int restart_time_max=10001000;
LL flip_time_max=200000000000ll;


int* buff_read_clause;//[MAX_VARS];

int restart;
LL flip_time;

int seed;

int var_n;
int clause_n;

int weight_av;
int weight_yu;
/////////////////////////////////////////////////////////

	void Error(const char r[])
	{
		printf("[error] [%s]\n",r);
		exit(0);
	}
	
	void Pause()
	{
		getchar();
	}

///zz
int **clause_lit;//[MAX_CLAUSES];
int **var_lit;//[MAX_VARS];

int *clause_lit_n;//[MAX_CLAUSES];
int *var_lit_n;//[MAX_VARS];

int* CCD;//[MAX_VARS];
int* CCD_in;//[MAX_VARS];
int CCD_n;

int* vc0;//[MAX_VARS];
int* vc0_i;//[MAX_VARS];
int vc0_n;

int* c0;//[MAX_CLAUSES];
int* c0_i;//[MAX_CLAUSES];
int c0_n;

int* SD;//[MAX_VARS];
int* SD_in;//[MAX_VARS];
int SD_n;

int* cw2;//[MAX_CLAUSES];
int cw2_n;

int* score;//[MAX_VARS];
int *score_p_n;
LL* last_flip_time;//[MAX_VARS];
int* conf_change;//[MAX_VARS];
int* pscore;//[MAX_VARS];
int* value;//[MAX_VARS];

int** neighbor;//[MAX_VARS];
int** neighbor_p_n;//[MAX_VARS];

int* var_clause_size;//[MAX_VARS];
int* var_n_cv0;//[MAX_VARS];

int* sat_n;//[MAX_CLAUSES];
int* sat_n_p_n;

int* weight;//[MAX_CLAUSES];

int* sat_var;//[MAX_CLAUSES];
int* sat_var_2;//[MAX_CLAUSES];



//////////////////////////////////////////////////v
int* var_neighbor_flag;//[MAX_VARS];
int* var_neighbor_flag_use;//[MAX_VARS];
int var_neighbor_flag_use_n=0;

int max(int a,int b)
{
	if(a>b)
		return a;
	return b;
}

int min(int a,int b)
{
	if(a<b)
		return a;
	return b;
}

void CCD_write()
{
	int i;
	printf("CCD: ");
	for(i=0;i<CCD_n;i++)
		printf("%d ",CCD[i]);
	printf("\n");
}

void SD_write()
{
	int i;
	printf("SD: ");
	for(i=0;i<SD_n;i++)
		printf("%d ",SD[i]);
	printf("\n");
}

void Var_write_state(int name)
	{
		if(name==1)
		printf("na v scor pscr r c t\n");
		printf("%2.d %d %4.d %4.d %d %d %lld\n"
			,name,value[name],score[name],pscore[name],CCD_in[name],conf_change[name],last_flip_time[name]);
	}

inline int Clause_check(int name)
	{
		register int *ip;
		for(ip=clause_lit[name];*ip;ip+=2)
		if( *(ip+1) == value[*ip])
			return 1;
		
		return 0;
	}

inline void Clause_not_sat(int name)
	{
		register int v;
		register int *ip;
		
		
		c0_i[name]=c0_n;
		c0[c0_n++]=name;
		
		for(ip=clause_lit[name]; v=*ip; ip+=2)		
		{
			var_n_cv0[v]++;
			if(var_n_cv0[v]==1)
			{				
				vc0_i[v]=vc0_n;
				vc0[vc0_n++]=v;
			}
		}		
	}

inline void Clause_sat(int name)
	{		
		register int i,b,v;
		register int *ip;
		b=c0[--c0_n];
		i=c0_i[name];
		c0[i]=b;
		c0_i[b]=i;
		
		for(ip=clause_lit[name]; v=*ip; ip+=2)		
		{
			var_n_cv0[v]--;
			if(!var_n_cv0[v])
			{			
				b=vc0[--vc0_n];
				i=vc0_i[v];
				vc0[i]=b;
				vc0_i[b]=i;
			}
		}
		
	}

inline void Clause_read(int name)
	{
		int z,i;		
		int clause_var_n;
		
		clause_var_n=0;
		while(fscanf(file,"%d",&z)!=EOF && z)
		{			
			buff_read_clause[clause_var_n]=z;
			clause_var_n++;
		}
		
		max_clause_len=max(max_clause_len,clause_var_n);
		min_clause_len=min(min_clause_len,clause_var_n);
		
		for(i=0;i<clause_var_n;i++)
		{
			z=buff_read_clause[i];
			if(z<0)
				var_clause_size[-z]++;
			else
				var_clause_size[z]++;
		}
		
		clause_lit_n[name]=clause_var_n;
		clause_lit[name]=(int*)malloc(sizeof(int)*2*(clause_var_n+2));
		
		for(i=0;i/2<clause_var_n;i+=2)
		if(buff_read_clause[i/2]<0)
		{
			clause_lit[name][i]=-buff_read_clause[i/2];
			clause_lit[name][i+1]=0;
		}
		else
		{
			clause_lit[name][i]=buff_read_clause[i/2];
			clause_lit[name][i+1]=1;	
		}
			
		clause_lit[name][clause_var_n*2]=0;
		clause_lit[name][clause_var_n*2+1]=0;
	}
	
	
inline void Clause_add_clause_to_var(int name)
	{
		int v;
		register int *ip;
		for(ip=clause_lit[name]; v=*ip; ip+=2)
		{
			if(*(ip+1))
			{
				var_lit[v][var_lit_n[v]++]=name;
				var_lit[v][var_lit_n[v]++]=1;
			}
			else
			{
				var_lit[v][var_lit_n[v]++]=name;
				var_lit[v][var_lit_n[v]++]=0;
			}	
			
			var_lit[v][var_lit_n[v]]=0;
			var_lit[v][var_lit_n[v]+1]=0;
		}				
	}

inline void Clause_add_clause_value_0(int name)
	{
		register int v;
		register int *ip;		
		c0_i[name]=c0_n;
		c0[c0_n++]=name;
		
		for(ip=clause_lit[name];v=*ip;ip+=2)
		{
			if(!var_n_cv0[v])
			{				
				vc0_i[v]=vc0_n;
				vc0[vc0_n++]=v;
			}
			var_n_cv0[v]++;
		}
	}

inline void Clause_init(int name)
	{
		register int v;
		register int *ip;
		for(ip=clause_lit[name];v=*ip;ip+=2)
		{
			if(*(ip+1)==value[v])
			{
				sat_n[name]++;
				if(sat_n[name]==1)
					sat_var[name]=v;
				else if(sat_n[name]==2)
					sat_var_2[name]=v;
			}				
		}
			
		if(!sat_n[name])
		{
			Clause_add_clause_value_0(name);
		}
	}


////////////////////////////////////////////////////////

void Sort(int r[],int a,int b)
{
	int i,j,x,z;
	if(a==b)
		return;
		
	i=a;
	j=b;
	x=r[a];
	
	while(i<j)
	{
		while(i<j && r[j]>=x)
			j--;
		while(i<j && r[i]<=x)
			i++;
		if(i<j)
		{
			z=r[i];
			r[i]=r[j];
			r[j]=z;
		}		
	}
	if(a<i-1)
		Sort(r,a,i-1);
	if(i+1<b)
		Sort(r,i+1,b);
}

inline void Var_add_neighbor(int name)
	{
		register int i,v,c;	
		register int *ip;
		register int *jp;	
		var_neighbor_flag[name]=1;
		
		for(ip=var_lit[name];c=*ip;ip+=2)
		{
			for(jp=clause_lit[c];v=*jp;jp+=2)
			{
				if(var_neighbor_flag[v])
					continue;
					
				var_neighbor_flag[v]=1;
				var_neighbor_flag_use[var_neighbor_flag_use_n]=v;
				var_neighbor_flag_use_n++;
			}			
		}
		
		int neighbor_n=var_neighbor_flag_use_n;
		neighbor[name]=(int*)malloc(sizeof(int)*(neighbor_n+1));
		
		for(i=0;i<neighbor_n;i++)
		neighbor[name][i]=var_neighbor_flag_use[i];
		
		Sort(neighbor[name],0,neighbor_n-1);
		//sort(neighbor[name],neighbor[name]+neighbor_n);
		
		var_neighbor_flag[name]=0;
		
		for(i=0;i<var_neighbor_flag_use_n;i++)
		{
		//	cout<<var_neighbor_flag_use[i]<<' '<<neighbor[i]<<endl;
			var_neighbor_flag[var_neighbor_flag_use[i]]=0;
		}
		var_neighbor_flag_use_n=0;
		
		neighbor[name][neighbor_n]=0;
		
		neighbor_p_n[name]=neighbor[name]+neighbor_n-1;
	}
	
inline void Var_init_score(int name)
	{
		register int c;
		register int *ip;
		for(ip=var_lit[name];c=*ip;ip+=2)
		{
			if(*(ip+1))	
			{
				if(!sat_n[c])
					score[name]+=weight[c];
				else
					if(sat_n[c]==1 && value[name])
						score[name]-=weight[c];	
			}
			else	
			{
			
				if(!sat_n[c])
					score[name]+=weight[c];
				else
					if(sat_n[c]==1 && !value[name])
						score[name]-=weight[c];				
			}			
		}
		
		for(ip=var_lit[name];c=*ip;ip+=2)
		{
			if(*(ip+1))
			{
				if(sat_n[c]==1)
				{
					if(!value[name])
						pscore[name]++;
				}
				else if(sat_n[c]==2)
				{
					if(value[name])
						pscore[name]--;
				}	
			}
			else
			{
				if(sat_n[c]==1)
				{
					if(value[name])
						pscore[name]++;
				}
				else if(sat_n[c]==2)
				{
					if(!value[name])
						pscore[name]--;
				}		
			}
		}
	}

///f3

inline void Var_flip_3_SAT(int name)
	{
		int old_score=score[name];
		register int* sp;
		register int* ip;
		register int* jp;
		int c,v;
		
		last_flip_time[name]=flip_time;
		
		if(value[name])
			value[name]=0;
		else
			value[name]=1;
			
		for(ip = var_lit[name]; c=*ip; ip+=2)
		{			
			sp=sat_n+c;
			
//			z=r_abs[i];
			if(*(ip+1)==value[name])
			{
				(*sp)++;
				if(*sp==2)
				{
					score[sat_var[c]]+=weight[c];
				}
				else if(*sp==1)
				{
					sat_var[c]=name;
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
						score[v] -= weight[c];		
						
					Clause_sat(c);
				}	
			}			
			else
			{
				--(*sp);
				if(*sp==1)
				{
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
					if(*(jp+1) == value[v] )
					{						
						score[v] -= weight[c];
						sat_var[c] = v;
						break;
					}					
				}
				else if(!*sp)
				{				
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
						score[v] += weight[c];
						
					Clause_not_sat(c);
				}
			}			
		}
		/*
		for(Lit* il=var_lit[name];(c=il->c); il++)
		{
			if(value[name] == il->f)
			{
				++sat_n[c];
			
				if (sat_n[c] == 2)
					score[sat_var[c]] += weight[c];
				else if (sat_n[c] == 1)
				{
					sat_var[c] = name;
					for(Lit* jl=clause_lit[c]; v=jl->v; jl++) 
						score[v] -= weight[c];		            
					Clause_sat(c);
				}
			}
			else
			{
				--sat_n[c];
				if (sat_n[c] == 1) //sat_count from 2 to 1
				{
					for(Lit* p=clause_lit[c]; v=p->v; p++) 
					if(p->f == value[v] )
					{						
						score[v] -= weight[c];
						sat_var[c] = v;
						break;
					}
				}
				else if (sat_n[c] == 0) //sat_count from 1 to 0
				{
					for(Lit* p=clause_lit[c]; v=p->v; p++) 
						score[v] += weight[c];
					Clause_not_sat(c);
				}//end else if
			
			}//end else
		}*/
		
		
		score[name]=-old_score;
		conf_change[name]=0;
		int i;
		
		/*for(ip=CCD.r;z=*ip;)
		if(var[z].score<=0)
			var[z].Delete_CCD();
		else
			ip++;*/
			
	/*	for(i=0;i<CCD.n;)
		{
			cout<<i<<' '<<CCD.r[i]<<endl;
			if(var[CCD.r[i]].score<=0)
				var[CCD.r[i]].Delete_CCD();
			else
				i++;
		}*/
		
		for(i=0;i<CCD_n;)
		{
			v=CCD[i];
			if(score[v]<=0)
			{
				CCD[i]=CCD[--CCD_n];
				CCD_in[v]=0;
			}
			else
				i++;
		}
		
		
		int* np=neighbor_p_n[name];
		for(ip=neighbor[name];ip<=np;ip++)	
		{
			v=*ip;
			conf_change[v]=1;
			
			if(score[v]>0 && !CCD_in[v])
			{			
				CCD[CCD_n++]=v;
				CCD_in[v]=1;				
			}
		}
				
		///z
		for(i=0;i<SD_n;)
		{
			v=SD[i];
			if(score[v]<=weight_av || conf_change[v])
			{
				SD[i]=SD[--SD_n];
				SD_in[v]=0;
			}
			else
				i++;
		}
		
		
		if(score[name]>weight_av && !SD_in[name])
		{
			SD[SD_n++]=name;
			SD_in[name]=1;
		}	
	}


///fk
inline void Var_flip_K_SAT(int name)
	{
//		cout<<"++++++++++++++"<<endl;
//		Write_state_all();
		
		register int i,j;	
		register int *ip;
		register int *jp;
		
		int old_score=score[name];
		
		int c,v;
		int flag;
		
		last_flip_time[name]=flip_time;
		
		
		if(value[name])
			value[name]=0;
		else
			value[name]=1;
		
		for(ip = var_lit[name]; c=*ip; ip+=2)
		{			
			if(*(ip+1)==value[name])
			{
				sat_n[c]++;
				if(sat_n[c]==3)
				{
					pscore[sat_var[c]]++;
					pscore[sat_var_2[c]]++;
				}
				else if(sat_n[c]==2)
				{
					score[sat_var[c]]+=weight[c];
					sat_var_2[c]=name;
                
					pscore[name]--;
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
						pscore[v]--;
				}
				else if(sat_n[c]==1)
				{
					sat_var[c]=name;
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
					{
						score[v] -= weight[c];		
						pscore[v]++;
					}	
					pscore[name]--;
					Clause_sat(c);
				}	
			}			
			else
			{
				--(sat_n[c]);
				if(sat_n[c]==2)
				{
					flag=0;
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
					if(*(jp+1) == value[v] )
					{	
						pscore[v]--;
						if(!flag)
						{
							sat_var[c]=v;
							flag=1;
						}
						else
						{
							sat_var_2[c]=v;
							break;
						}
					}					
				} else if(sat_n[c]==1)
				{
					pscore[name]++;
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
						pscore[v]++;
						
					if(sat_var[c]==name)
					{						
						sat_var[c] = sat_var_2[c];
					}
					score[sat_var[c]]-=weight[c];
				}
				else if(!sat_n[c])
				{
					for(jp=clause_lit[c]; v=*jp; jp+=2) 
					{
						score[v] += weight[c];
						pscore[v]--;
					}
					pscore[name]++;
					
					Clause_not_sat(c);
				}
			}			
		}
		
		
		score[name]=-old_score;
		conf_change[name]=0;
		
		for(i=0;i<CCD_n;)
		{
			c=CCD[i];
			if(score[c]<=0)
			{
				CCD[i]=CCD[--CCD_n];
				CCD_in[c]=0;
			}
			else
				i++;
		}
		
		int* np=neighbor_p_n[name];
		for(ip=neighbor[name];ip<=np;ip++)
//		for(i=0;i<neighbor_n;i++)
		{
			v=*ip;
			conf_change[v]=1;
			
			if(score[v]>0 && !CCD_in[v])
			{
				CCD[CCD_n++]=v;
				CCD_in[v]=1;
			}
		}
	}
///fk


///////////////////////////////////////////////////
LL sss=0,weight_add=0;
LL total_CCD_mode=0,total_SD_mode=0,total_diversification_mode=0,total_smooth_mode=0;
int CCD_mode=0,SD_mode=0,diversification_mode=0,smooth_mode=0;
int new_mode=0;
LL SD_not_tabu=0,SD_tabu=0;
LL CCD_not_tabu=0;

LL sum_neighbor=0;
LL sum_CCD_n=0;
LL time_CCD_n=0;
LL sum_var_in_clause_value_0_n=0;
LL time_var_in_clause_value_0_n=0;
LL sum_clause_value_0_n=0;
LL time_clause_value_0_n=0;

LL sum_SD_n=0;
LL time_SD_n=0;

///pk
int Pick_flip_var_K_SAT()
{
	register int ret;
	register int i,c,v;
	ret=0;
	
	if(CCD_n)
	{
		ret=CCD[0];
		
		for(i=1;i<CCD_n;i++)
		{
			v=CCD[i];
			if(score[ret]+(pscore[ret]>>3)<score[v]+(pscore[v]>>3))
				ret=v;
			else
			if(score[ret]+(pscore[ret]>>3)==score[v]+(pscore[v]>>3))
			{
				if(last_flip_time[v]<last_flip_time[ret])
					ret=v;
				/*if(last_flip_time[v]+delta_age <= last_flip_time[ret])
					ret=v;
				else
					if(last_flip_time[v] < last_flip_time[ret]+delta_age && pscore[v]>pscore[ret])
						ret = v;*/
			}			
		}
	//	printf("%d %lld C %d\n",restart,flip_time,ret);
		return ret;
	}
		
	/*
	if(CCD_n)
	{
		ret=CCD[0];
		
		for(i=1;i<CCD_n;i++)
		{
			v=CCD[i];
			if(score[ret]<score[v])
				ret=v;
			else
			if(score[v]==score[ret])
			{
				if(last_flip_time[v]+delta_age <= last_flip_time[ret])
					ret=v;
				else
					if(last_flip_time[v] < last_flip_time[ret]+delta_age && pscore[v]>pscore[ret])
						ret = v;
			}			
		}
	//	printf("%d %lld C %d\n",restart,flip_time,ret);
		D.Error("j9t843yu4yha");
		return ret;
	}
	*/
	
	
	
	for(i=0;i<vc0_n;i++)
	if(score[vc0[i]] > weight_av)
	{
		ret=vc0[i];
		break;
	}
			
	for(;i<vc0_n;i++)
	{
		v=vc0[i];
		if(score[ret]< score[v])
			ret=v;
		else if(score[ret]== score[v])
		{
			if(last_flip_time[ret] >= last_flip_time[v]+delta_age)
					ret=v;
			else
				if(last_flip_time[v]<last_flip_time[ret]+delta_age	
					&&pscore[ret]<pscore[v])
					ret=v;
		}		
	}
	if(ret)
	{	
	//	printf("%lld S %d\n",flip_time,ret);
		return ret;
	}
	
	
	
	
	if( 
		((rand()%MY_RAND_MAX_INT)*BASIC_SCALE) < smooth_probability 
		&& cw2_n>large_clause_count_threshold 
	)
	{
		int zv,i;
		for(i=0; i<cw2_n;)
		{
			c=cw2[i];
			if(sat_n[c]>0)
			{
				weight[c]--;
				
				if(weight[c]==1)
					cw2[i] = cw2[--cw2_n];
				else 
					i++;
				if(sat_n[c] == 1)
				{
					v = sat_var[c];
					score[v]++;
					
					if(score[v]>0 &&  conf_change[v]>0  && !CCD_in[v])
					{
						CCD[CCD_n++]=v;
						CCD_in[v]=1;
					}
				}
			}
			else
				i++;
		}		
	}	
	else 
	{
		for(i=0; i < c0_n; ++i)
		{
			c = c0[i];
			weight[c]++;
			
			if(weight[c] == 2)
				cw2[cw2_n++] = c;
		}
		
		for(i=0; i<vc0_n; ++i)
		{
			v = vc0[i];
			score[v] += var_n_cv0[v];
			if(score[v]>0 &&  conf_change[v]>0  && !CCD_in[v])
			{
				CCD[CCD_n++]=v;
				CCD_in[v]=1;
			}
		}
	}
	
	
	register int* ip;
		c = c0[rand()%c0_n];
		ip=clause_lit[c];
		
		ret = *ip;
		LL la,lb;
		
		for(ip+=2; v=*ip; ip+=2)
		{
			la=score[ret] + (pscore[ret]>>3) + ((flip_time-last_flip_time[ret])>>11);
			lb=score[v] + (pscore[v]>>3) + ((flip_time-last_flip_time[v])>>11);
			if( la < lb) 
				ret = v;
			else
			if(la==lb)
			{
				if(last_flip_time[ret] > last_flip_time[v]) 
					ret = v;
			}
		}
	
		return ret;
}
///pk



///p3
int Pick_flip_var_3_SAT()
{
	int ret;
	register int i,v,j;
	ret=0;
	if(CCD_n)
	{
		ret=CCD[0];
		
		for(i=1;i<CCD_n;i++)
		{
			v=CCD[i];
			if(score[ret]<score[v])			
				ret=v;
			else 
				if(score[ret]==score[v])
				{
					if(var_n_cv0[v]>var_n_cv0[ret])
						ret=v;
					else
						if(var_n_cv0[v]==var_n_cv0[ret])
						{
					 		if(last_flip_time[v]< last_flip_time[ret])
					 			ret=v;
					 	}
				}
		}
		
		return ret;
	}
		
	///z
	
	int zret=0;
	
	for(i=0;i<vc0_n;i++)
	if(score[vc0[i]]>weight_av)
	{
		zret=vc0[i];		
	//	b=score[ret];
	//	bl=last_flip_time[ret];
		break;
	}
	
	for(;i<vc0_n;i++)
	{
		v=vc0[i];		
		if(score[v] > score[zret] || score[v] == score[zret] && last_flip_time[zret]> last_flip_time[v])
			zret=v;
	}
	
//	if(zret)
//		return zret;
	
	
	if(SD_n)
	{
		ret=SD[0];
		
		for(i=1;i<SD_n;i++)
		{
			v=SD[i];
			if(score[ret]<score[v] || score[ret]==score[v] && last_flip_time[v]< last_flip_time[ret])
				ret=v;
		}
		//if(flip_time>=11917698)
		//printf("%d %lld S %d %d %d\n",restart,flip_time,ret,weight_av,weight_yu);
		/*if(zret!=ret)
		{
			cout<<zret<<' '<<ret<<endl;
			D.Error("rj903ut89043jy");
		}*/
		return ret;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	{		
	
		for(i=0;i<c0_n;i++)
		{
			weight[c0[i]]++;
			/*
			for(jp=clause[z].r_abs;va=*jp;jp++)
			{				
				vp=var+va;
				vp->score++;
				continue;
				if(vp->score > 0)
				{
					if(vp->conf_change)
					{
						if(!CCDi[va])
						{
							CCD_n++;
							*CCD_n=va;
							CCDi[va]=CCD_n;
						}
					}
					else
					{
						if(vp->score > weight_av && !vp->in_SD)
							vp->Add_SD();
					}
				}
			}*/
		}
		
		weight_yu+=c0_n;
		while(weight_yu>=clause_n)
		{
			weight_av++;
			weight_yu-=clause_n;
			
			for(i=0;i<SD_n;)
			{
				v=SD[i];
				if(score[v]<=weight_av)
				{
					SD[i]=SD[--SD_n];
					SD_in[v]=0;
				}
				else
					i++;
			}
		}
		
		
		
		for(i=0;i<vc0_n;i++)
		{
			v=vc0[i];
			score[v]+=var_n_cv0[v];
			
			if(!conf_change[v] && score[v] > weight_av && !SD_in[v])
			{
				SD[SD_n++]=v;
				SD_in[v]=1;
			}
			
			if(conf_change[v] && score[v] > 0 && !CCD_in[v])
			{
				CCD[CCD_n++]=v;
				CCD_in[v]=1;
			}
		}
		
		
		//Zheng_SD();	
	}
	

	register int *ip;
	
	//////////////////////////
	if(weight_av > gama)
	{	
		register int sn;
		
		for(i=1;i<=var_n;i++)
			score[i]=0;
					
		
		
		weight_yu=0;
		//cout<<weight2<<endl;
		int i;
		for(i=1;i<=clause_n;i++)
		{			
			weight[i]=(int)(weight[i]*ro + weight2);
			weight_yu+=weight[i];
			sn=sat_n[i];
			
			
			if(!sn)
			{
				for(ip=clause_lit[i]; v=*ip; ip+=2)
					score[v]+=weight[i];;
				continue;
			}
			if(sn==1)
			{
			//	if(cp->sat_var<1 || cp->sat_var> var_n)
			//		D.Error("jgt43uyt98quy");
				score[sat_var[i]]-=weight[i];
				
				continue;
			}
		}
		weight_av=weight_yu/clause_n;
		weight_yu%=clause_n;
		
		for(i=0;i<CCD_n;)
		{
			v=CCD[i];
			if(score[v]<=0)
			{
				CCD[i]=CCD[--CCD_n];
				CCD_in[v]=0;
			}
			else
				i++;
		}
		
		for(i=0;i<SD_n;)
		{
			v=SD[i];
			if(score[v]<=weight_av || conf_change[v])
			{
				SD[i]=SD[--SD_n];
				SD_in[v]=0;
			}
			else
				i++;
		}
		
		for(i=1;i<=var_n;i++)
		{
			if(score[i]>0 && conf_change[i] && !CCD_in[i])
			{
				CCD[CCD_n++]=i;
				CCD_in[i]=1;
			}
			
			if(score[i]>weight_av && !conf_change[i] && !SD_in[i])
			{
				SD[SD_n++]=i;
				SD_in[i]=1;
			}
		}
	}
	
	int zz;
	
	
	
	////////////////////////////
	zz=c0[rand()%(c0_n)];
	ip=clause_lit[zz];
	
	ret=*ip;
	for(ip+=2;v=*ip;ip+=2)
	{
		v=*ip;
		if(last_flip_time[ret] > last_flip_time[v])
			ret=v;
	}
	
	///if(flip_time>=11917698)
	//	printf("%d %lld V %d %d %d %d\n",restart,flip_time,ret,zz,v,c0_n);
	return ret;
}

int Check()
{
	int i;
	for(i=1;i<=clause_n;i++)
	if(!Clause_check(i))
		return 0;
	return 1;
}

LL total_flip_time=0,total_restart=0;

int (*Pick_flip_var) ();
void (*Var_flip)(int);



int Instance(char instance_file[],int instance_seed)
{
	int finish=0;
	int i,j;
	int* ip;
	int* jp;
	char rs[100];
	file=fopen(instance_file,"r");
	if(!file)
		Error("g43h894y3qyh");
		
	seed=instance_seed;
	
	///////////////////////////////////////////////	
	while(fscanf(file,"%s",rs)!=EOF)
	{
		if(rs[0]=='p')
			break;
		while(fgetc(file)!='\n');
	}
	if(fscanf(file,"%s",rs)==EOF)
		return 0;
		
	if(strcmp(rs,"cnf"))
	{
		Error("38y94aehahuuu");
	}
		
	if(fscanf(file,"%d%d",&var_n,&clause_n)==EOF)
		return 0;
	
	
	///zz
	buff_read_clause=(int*)malloc(sizeof(int)*(var_n*2+2));
	
	clause_lit=(int**)malloc(sizeof(int*)*(clause_n+2));
	var_lit=(int**)malloc(sizeof(int*)*(var_n+2));
	clause_lit_n=(int*)malloc(sizeof(int)*(clause_n+2));
	var_lit_n=(int*)malloc(sizeof(int)*(var_n+2));
	CCD=(int*)malloc(sizeof(int)*(var_n+2));
	CCD_in=(int*)malloc(sizeof(int)*(var_n+2));
	vc0=(int*)malloc(sizeof(int)*(var_n+2));
	vc0_i=(int*)malloc(sizeof(int)*(var_n+2));
	c0=(int*)malloc(sizeof(int)*(clause_n+2));
	c0_i=(int*)malloc(sizeof(int)*(clause_n+2));
	SD=(int*)malloc(sizeof(int)*(var_n+2));
	SD_in=(int*)malloc(sizeof(int)*(var_n+2));
	cw2=(int*)malloc(sizeof(int)*(clause_n+2));
	score=(int*)malloc(sizeof(int)*(var_n+2));
	last_flip_time=(LL*)malloc(sizeof(LL)*(var_n+2));
	conf_change=(int*)malloc(sizeof(int)*(var_n+2));
	pscore=(int*)malloc(sizeof(int)*(var_n+2));
	value=(int*)malloc(sizeof(int)*(var_n+2));
	neighbor=(int**)malloc(sizeof(int*)*(var_n+2));
	neighbor_p_n=(int**)malloc(sizeof(int*)*(var_n+2));
	var_clause_size=(int*)malloc(sizeof(int)*(var_n+2));
	var_n_cv0=(int*)malloc(sizeof(int)*(var_n+2));
	sat_n=(int*)malloc(sizeof(int)*(clause_n+2));
	weight=(int*)malloc(sizeof(int)*(clause_n+2));
	sat_var=(int*)malloc(sizeof(int)*(clause_n+2));
	sat_var_2=(int*)malloc(sizeof(int)*(clause_n+2));
	
	var_neighbor_flag=(int*)malloc(sizeof(int)*(var_n+2));
	var_neighbor_flag_use=(int*)malloc(sizeof(int)*(var_n+2));
	
	
	
	
	
	
	
	
	//////////////////////////////////////////
	for(i=0;i<=var_n;i++)
	{
		var_neighbor_flag[i]=0;
		var_neighbor_flag_use[i]=0;
	}
	var_neighbor_flag_use_n=0;
		
	for(i=1;i<=var_n;i++)
	{
		var_clause_size[i]=0;
	}
	
	max_clause_len=0;
	min_clause_len=oo;
	for(i=1;i<=clause_n;i++)
		Clause_read(i);
	
	if(max_clause_len == min_clause_len)
	{
		if(max_clause_len<=3) probtype=3;
		else if(max_clause_len<=5) probtype=5;
		else probtype=7;
	}
	else {
		probtype=0;
	}
	
	//cons_d=max(3,13-max_clause_len);
	
	if(probtype==3 || probtype==0)
	{
		Pick_flip_var=Pick_flip_var_3_SAT;
		Var_flip=Var_flip_3_SAT;
	}
	else
	{
		Pick_flip_var=Pick_flip_var_K_SAT;
		Var_flip=Var_flip_K_SAT;
	}



	
	for(i=1;i<=var_n;i++)
	{		
		var_lit[i]=(int*)malloc(sizeof(int)*2*(var_clause_size[i]+2));
		var_lit_n[i]=0;
		var_lit[i][0]=0;
		var_lit[i][1]=0;
	}
	
	///////////////////////////////////////////	
	
	for(i=1;i<=clause_n;i++)
		Clause_add_clause_to_var(i);
		

	for(i=1;i<=var_n;i++)
		Var_add_neighbor(i);
	
	for(i=1;i<=var_n;i++)
		sum_neighbor+=neighbor_p_n[i]-neighbor[i];
	
		
		
	delta_age=oo;
	
		
	if(probtype==3)
	{
		gama=200+(var_n+250)/500;
	}
	else if(probtype==5)
	{
		smooth_probability = 0.75;
		if(var_n>=1500) smooth_probability = 0.725;
		large_clause_count_threshold = 10;
		
		delta_age=min(2*var_n,delta_age);
	}
	else if(probtype==7)
	{
		smooth_probability = 0.92;
		large_clause_count_threshold = 10;
		delta_age=min(20*var_n,2500);
	}
	else //non k-SAT
	{
		gama=300;
	}
		
	weight2=(int)((gama+1)*ro2-1);
	
/*	for(i=1;i<=clause_n;i++)
	{
		int v;
		for(ip=clause_lit[i];v=*ip;ip+=2)
		{
			if(!*(ip+1))
				putchar('-');
			printf("%d ",*ip);			
		}
		printf("\n");
	}*/
	
	//////////////////////////////////////////
	int best_answer=clause_n;
//	for(seed=1;seed<=10;seed++)
		finish=0;
		CCD_mode=0,SD_mode=0,diversification_mode=0,smooth_mode=0;
		
		memset(CCD,0,sizeof(CCD));
		memset(CCD_in,0,sizeof(CCD_in));
		CCD_n=0;
		
		memset(vc0,0,sizeof(vc0));
		memset(vc0_i,0,sizeof(vc0_i));
		vc0_n=0;
		
		memset(c0,0,sizeof(c0));
		memset(c0_i,0,sizeof(c0_i));
		c0_n=0;
		
		memset(SD,0,sizeof(SD));
		memset(SD_in,0,sizeof(SD_in));
		SD_n=0;
	//	memset(SD_r,0,sizeof(SD_r));
	//	memset(SD_ri,0,sizeof(SD_ri));
	//	SD_p_n=SD_r-1;
		
		
		memset(cw2,0,sizeof(cw2));	
		cw2_n=0;
		
		
		srand(seed);
		
		int flip_var;
		///D
	//	flip_time_max=clause_n*var_n*3;
	//	flip_time_max=clause_n*20;
		for(restart=1;restart<=restart_time_max;restart++)
		{
			total_restart++;
			
			for(i=0;i<CCD_n;i++)
			{
				CCD_in[CCD[i]]=0;
				CCD[i]=0;
			}			
			CCD_n=0;
			
			for(i=0;i<SD_n;i++)
			{
				SD_in[SD[i]]=0;
				SD[i]=0;
			}			
			SD_n=0;
			
			for(i=0;i<vc0_n;i++)
			{
				vc0_i[vc0[i]]=0;
				vc0[i]=0;
			}
			vc0_n=0;
			
			for(i=0;i<c0_n;i++)
			{
				c0_i[c0[i]]=0;
				c0[i]=0;
			}
			c0_n=0;
			
			for(i=0;i<cw2_n;i++)
				cw2[i]=0;
			cw2_n=0;
			
			for(i=1;i<=var_n;i++)
			{
				conf_change[i]=1;
				score[i]=0;
				last_flip_time[i]=0;
				var_n_cv0[i]=0;
				
				value[i]=rand()%2;
			}
			
				
			for(i=1;i<=var_n;i++)
				last_flip_time[i]=i-1-var_n;
			
		//	if(restart==1)
			{			
				weight_av=1;
				weight_yu=0;
				
				for(i=1;i<=clause_n;i++)
				{
					sat_n[i]=0;
					weight[i]=1;
				}
					
				for(i=1;i<=clause_n;i++)
					Clause_init(i);
			}
			
			
				
			for(i=1;i<=var_n;i++)
				Var_init_score(i);
				
						
			if(debug_write)
			for(i=1;i<=var_n;i++)
				Var_write_state(i);
			
			for(i=1;i<=var_n;i++)
			if(score[i]>0 && conf_change[i])
			{
				CCD[CCD_n++]=i;
				CCD_in[i]=1;
			}
			
			
			//for(i=1;i<=var_n;i++)
			//	conf_change[i]=0;
			
		//	if(debug_write)
		
			for(i=1;i<=var_n;i++)
			if(score[i]>weight_av && conf_change[i])
			{
				SD[SD_n++]=i;
				SD_in[i]=1;
			}	
				
			if(restart>1)
			{
				if(best_answer>50)
				{
					flip_time_max=flip_time_max*4;
				}
				else if(best_answer>10)
				{
					flip_time_max=flip_time_max*2;
				}
				else
					flip_time_max=(LL)(flip_time_max*2);
			}
		
			int last_best_answer;
			printf("c c %d %lld %d %d %d\n"
				,restart
				,flip_time_max
				,best_answer
				,last_best_answer
				,(int)clock()
				);
		
		 	last_best_answer=clause_n;
		 	
		 	//if(debug_write)
		 	//for(i=1;i<=var_n;i++)				cout<<i<<' '<<value[i]<<endl;
	
		 	
		 	
			for(flip_time=0;flip_time<flip_time_max;flip_time++)
			{
				best_answer=min(best_answer,c0_n);
				last_best_answer=min(last_best_answer,c0_n);
				
				if(!c0_n)
				{
					finish=1;
					break;
				}
			/*	if(!(flip_time%100000))
				{					
					if(clock() > time_limit * 1000000)
					{
						finish=1;
						break;
					}
				}*/
				//if(debug_write)
				//if(flip_time>=11917698)
				/*{
					for(i=1;i<=var_n;i++)						Var_write_state(i);
					CCD_write();
					SD_write();
				}
				*/
				flip_var=Pick_flip_var();
				/*
				if(probtype==3 || probtype==0)
					flip_var=Pick_flip_var_3_SAT();
				else
					flip_var=Pick_flip_var_K_SAT();
				*/
				total_flip_time++;
	
				//if(debug_write)
				
				//if(flip_time >=11917698 || (11917690<=flip_time) && (flip_time<=11917700) && (flip_time%1==0))
				/*{
					printf("     step name v scor CCD weights  c0 smooth wei_av wei_yu\n");
					printf("%9.lld %4.d %d %4.d %3.d %7.d %3.d %6.d %6.d %6.d\n",flip_time
						,flip_var,value[flip_var]
						,score[flip_var],CCD_n,weight_av*clause_n+weight_yu,c0_n
						,smooth_mode
						,weight_av
						,weight_yu
						);					
					//clause_value_0.Write();
				}
				*/
				
				
				Var_flip(flip_var);
				/*if(probtype==3 || probtype==0)
					Var_flip_3_SAT(flip_var);
				else
					Var_flip_K_SAT(flip_var);*/
					
				if(flip_time==flip_time_max-1)
				{
					flip_time++;
					break;
				}
					
				if(!c0_n)
				{
					finish=1;
					flip_time++;
					break;
				}
				
				
				
				//if(flip_time>=11917698)
				//Pause();
			}
			
			if(finish)
				break;
			
			if(restart==restart_time_max)
				break;
		}
		
		if(!c0_n)
		{
			if(!Check())
			{
				printf("s unkown\n");
				exit(0);
			}
			printf("s SATISFIABLE\n");
		//	printf("s SATISFIABLE\n");
			
			printf("v");
		//	printf("v");
			
			for(i=1;i<=var_n;i++)
			{
				if(value[i])
				{
					printf(" %d",i);
				}
				else
				{
					printf(" -%d",i);
				}
			}
			
			printf(" 0\n");
		}
		else
		{
		//	cout<<finish<<endl;
		//	cout<<clause_value_0.n<<endl;
			printf("s unkown\n");
#if debug_all
			D.Error("t9034uuy35h");
#endif
		}
		
		/////////////////////////////////////////
		printf("c seed %d\n",seed);
	//	cout<<"c seed "<<seed<<endl;
		
	//	cout<<"c time_limit "<<time_limit<<endl;
		
		printf("c restart %d\n",restart);
	//	cout<<"c restart "<<restart<<endl;
		
		printf("c last_flip_time %lld\n",flip_time);
		printf("c total_flip_time %lld\n",total_flip_time);
	//	cout<<"c last_flip_time "<<flip_time<<endl;
		
/*		printf("c CCD %d\n",CCD_mode,CCD_mode/double(total_flip_time));
		printf("c SD %d\n",SD_mode,SD_mode/double(total_flip_time));
		printf("c diver %d\n",diversification_mode,diversification_mode/double(total_flip_time));
		printf("c smooth %d\n",smooth_mode,smooth_mode/double(total_flip_time));		
		printf("c total_flip_time %lld\n",total_flip_time);

		printf("c sss %lld\n",sss);
		printf("c weight_add %lld\n",weight_add);
		printf("c new_mode %d\n",new_mode);
		printf("c SD_not_tabu %lld\n",SD_not_tabu);
		printf("c SD_tabu %lld\n",SD_tabu);
		printf("c CCD_not_tabu\n",CCD_not_tabu);
		
		printf("c sum_neighbor %lld\n",sum_neighbor);
		printf("c sum_CCD_n %lld\n",sum_CCD_n);
		printf("c time_CCD_n %lld\n",time_CCD_n);
		printf("c rate_CCD_n %lf\n",sum_CCD_n/double(time_CCD_n));
		
		printf("c sum_var_in_clause_value_0_n %lld\n",sum_var_in_clause_value_0_n);
		printf("c time_var_in_clause_value_0_n %lld\n",time_var_in_clause_value_0_n);
		printf("c rate_var_in_clause_value_0_n %lf\n",sum_var_in_clause_value_0_n/double(time_var_in_clause_value_0_n));
		
		printf("c sum_clause_value_0_n %lld\n",sum_clause_value_0_n);
		printf("c time_clause_value_0_n %lld\n",time_clause_value_0_n);
		printf("c rate_clause_value_0_n %lf\n",sum_clause_value_0_n/double(time_clause_value_0_n));
		
		printf("c sum_SD_n %lld\n",sum_SD_n);
		printf("c time_SD_n %lld\n",time_SD_n);
		printf("c rate_SD_n %lf\n",sum_SD_n/double(time_SD_n));*/
		
		printf("c flip/time %lf\n",total_flip_time / (double)(clock()/1000000.0));
		{	
			int z=(int)clock();
			printf("c time %lf\n",z/1000000.0);
		}
		
	//////////////////////////////


	
	
	
	for(i=1;i<=var_n;i++)
	{		
		free(neighbor[i]);
		free(var_lit[i]);
	}
	
	for(i=1;i<=clause_n;i++)
	{
		free(clause_lit[i]);
	}
	
///zz
	free(clause_lit);
	free(var_lit);
	free(clause_lit_n);
	free(var_lit_n);
	free(CCD);
	free(CCD_in);
	free(vc0);
	free(vc0_i);
	free(c0);
	free(c0_i);
	free(SD);
	free(SD_in);
	free(cw2);
	free(score);
	free(last_flip_time);
	free(conf_change);
	free(pscore);
	free(value);
	free(neighbor);
	free(neighbor_p_n);
	free(var_clause_size);
	free(var_n_cv0);
	free(sat_n);
	free(weight);
	free(sat_var);
	free(sat_var_2);
	free(buff_read_clause);
	
	free(var_neighbor_flag);
	free(var_neighbor_flag_use);
}

int main(int argc,char* argv[])
{
	int a,b;
	sscanf(argv[2],"%d",&a);
	
	Instance(argv[1],a);
	return 0;
}

