It is compiled by g++ with the following command: 
	g++ CCA2014.cpp -O3 -static -o CCA2014.

Its running command is:
	./CCA2014 <instance file name> <random seed>
