MiniSat-ClauseSplit 1.0 -- Balázs Donát Bessenyei, Zoltán Ádám Mann

To build: simply run ./build.sh

Usage is almost the same as of minisat, the additional command line parameters (shortened for minisat hack track) are
-s-e			-	Splitter enabled
-S-MCL=<num>	-	Maximal output clause length for clauses splitted
-S-TMIN=<num>	-	Minimal input clause length (lower threshold) for splitter
-S-TMAX=<num>	-	Maximal input clause length (upper threshold) for splitter
-S-ACF=<0/1>	-	Additional clauses flag

For meanings of the parameters, see the paper attached

Minisat original readme follows:

================================================================================
DIRECTORY OVERVIEW:

mtl/            Mini Template Library
utils/          Generic helper code (I/O, Parsing, CPU-time, etc)
core/           A core version of the solver
simp/           An extended solver with simplification capabilities
README
LICENSE

================================================================================
BUILDING: (release version: without assertions, statically linked, etc)

export MROOT=<minisat-dir>              (or setenv in cshell)
cd { core | simp }
gmake rs
cp minisat_static <install-dir>/minisat

================================================================================
EXAMPLES:

Run minisat with same heuristics as version 2.0:

> minisat <cnf-file> -no-luby -rinc=1.5 -phase-saving=0 -rnd-freq=0.02
