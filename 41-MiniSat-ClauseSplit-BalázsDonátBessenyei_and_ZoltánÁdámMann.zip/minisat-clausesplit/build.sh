#!/usr/bin/env bash
mkdir binary
cd code/core
make
cd ../..
cp code/core/minisat binary/
