#!/bin/bash

cd code/satUZK
make
if [ $? -ne 0 ]; then
	echo "Could not build satUZK"
	exit 1
fi
cd ../..

cd code/satUZK_wrapper
make
if [ $? -ne 0 ]; then
	echo "Could not build satUZK_wrapper"
	exit 1
fi
cd ../..

cd code/satelite
./build.sh
if [ $? -ne 0 ]; then
	echo "Could not build satelite"
	exit 1
fi
cd ../..

mkdir binary
cp code/satUZK/satUZK-seq binary/
cp code/satUZK/satUZK-par binary/
cp code/satUZK_wrapper/satUZK_wrapper binary/
cp code/satelite/SatELite_release binary/

