
namespace satuzk {

/* --------------------- VARIABLE MANAGEMENT FUNCTIONS --------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::varReserve(Config<BaseDefs, Hooks>::variable_type count) {
	p_varConfig.reserve_vars(count);
}
template<typename BaseDefs, typename Hooks>
typename Config<BaseDefs, Hooks>::variable_type Config<BaseDefs, Hooks>::varAlloc() {
	variable_type id = p_varConfig.alloc_var();

	problem::sat::first_uip::onAllocVariable(p_learnConfig, *this);

	var_heap_hooks_type heap_hooks(*this);
	p_varConfig.get_heap_info(id).activity = 0;
	p_varConfig.get_heap_info(id).heap_index = var_heap_hooks_type::ILLEGAL_INDEX;
	p_heapArray.push_back(0);
	util::heaps::binary::insert(heap_hooks, id);

	return id;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::randomizeVsids() {
	var_heap_hooks_type heap_hooks(*this);

	std::uniform_real_distribution<activity_type> activity_dist(0, 5);
	std::bernoulli_distribution phase_dist(0.5);
	for(variable_type var = 0; var < p_varConfig.count(); ++var) {
		p_varConfig.get_heap_info(var).activity = activity_dist(p_rndEngine);
		util::heaps::binary::became_less(heap_hooks, var);

		if(phase_dist(p_rndEngine))
			p_varConfig.set_varflag_saved(var);
	}
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::varIsLocked(Config<BaseDefs, Hooks>::variable_type var) {
	return false; //FIXME
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::litTrue(Config<BaseDefs, Hooks>::literal_type lit) {
	variable_type var = lit >> 1;
	uint8_t assign = p_varConfig.get_assign(var).value;
	if(!(assign & 2))
		return false;
	return !((assign ^ lit) & 1);
//		return p_varConfig.get_assign(lit >> 1).value == (2 | (lit & 1));
//	variable_type var = vars::get_var<var_config_type>(lit);
//	bool is_one = vars::is_one<var_config_type>(lit);
//	return p_varConfig.get_assign(var).litTrue(is_one);
}
template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::litFalse(Config<BaseDefs, Hooks>::literal_type lit) {
	variable_type var = lit >> 1;
	uint8_t assign = p_varConfig.get_assign(var).value;
	if(!(assign & 2))
		return false;
	return ((assign ^ lit) & 1);
//		return p_varConfig.get_assign(lit >> 1).value == (2 | ((~lit) & 1));
//		variable_type var = vars::get_var<var_config_type>(lit);
//		bool is_one = vars::is_one<var_config_type>(lit);
//		return p_varConfig.get_assign(var).litFalse(is_one);
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::varIsFixed(Config<BaseDefs, Hooks>::variable_type var) {
	return varDeclevel(var) == 1;
}

/* ------------------- CLAUSE MANAGEMENT FUNCTIONS ------------------------- */

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::clause_contains(Config<BaseDefs, Hooks>::clause_type clause,
		Config<BaseDefs, Hooks>::literal_type literal) {
/*	unsigned int sig_size = sizeof(typename clause_head_type::signature_type) * 8;
	typename clause_head_type::signature_type litsig = (1 << (literal % sig_size));
	if((clause_head(clause)->signature & litsig) == 0)
		return false;*/

	for(auto i = clauseBegin(clause); i != clauseEnd(clause); ++i)
		if(*i == literal)
			return true;
	return false;
}

template<typename BaseDefs, typename Hooks>
int Config<BaseDefs, Hooks>::clause_polarity(Config<BaseDefs, Hooks>::clause_type clause,
		Config<BaseDefs, Hooks>::variable_type variable) {
	for(auto i = clauseBegin(clause); i != clauseEnd(clause); ++i) {
		variable_type var = litVariable(*i);
		if(var != variable)
			continue;
		return lit_polarity(*i);
	}
	return 0;
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::clauseAssigned(Config<BaseDefs, Hooks>::clause_type clause) {
	if(clauseLength(clause) == 1)
		return true;

	literal_type lit1 = clause_get_first(clause);
	literal_type lit2 = clause_get_second(clause);
	return varAssigned(litVariable(lit1)) && varAssigned(litVariable(lit2));
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::clauseIsAntecedent(Config<BaseDefs, Hooks>::clause_type clause) {
	literal_type unit_lit = clause_get_first(clause);
	variable_type unit_var = litVariable(unit_lit);
	auto antecedent = antecedent_type::make_clause(clause);
	if(varAssigned(unit_var)
			&& antecedent == varAntecedent(unit_var))
		return true;
	return false;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::ensureClauseSpace(unsigned int free_required) {
	if(free_required < p_clauseConfig.p_allocator.get_free_space())
		return;
	
	unsigned int used_estimate = p_clauseConfig.p_allocator.get_used_space();
	unsigned int final_space = 1.5f * used_estimate + free_required;

	if(opts.general.verbose >= 1)
		std::cout << "c [GC    ] Extending clause space to " << (final_space / 1024) << " kb" << std::endl;

	void *old_pointer = p_clauseConfig.p_allocator.get_memory();
	void *new_pointer = operator new(final_space);
	if(new_pointer == NULL)
		SYS_CRITICAL("Out of memory\n");
	p_clauseConfig.p_allocator.move_to(new_pointer, final_space);
	operator delete(old_pointer);

	stat.general.clauseReallocs++;
}

template<typename BaseDefs, typename Hooks>
typename Config<BaseDefs, Hooks>::litindex_type Config<BaseDefs, Hooks>::clauseLength(
		Config<BaseDefs, Hooks>::clause_type clause) {
	clause_head_type *head = p_clauseConfig.get_head(clause);
	return head->getLength();
}

template<typename BaseDefs, typename Hooks>
typename Config<BaseDefs, Hooks>::ClauseLitIterator Config<BaseDefs, Hooks>::clauseBegin(
		Config<BaseDefs, Hooks>::clause_type clause) {
	return ClauseLitIterator(p_clauseConfig, clause, 0);
}
template<typename BaseDefs, typename Hooks>
typename Config<BaseDefs, Hooks>::ClauseLitIterator Config<BaseDefs, Hooks>::clauseBegin2(
		Config<BaseDefs, Hooks>::clause_type clause) {
	if(clauseLength(clause) < 2)
		return clauseEnd(clause);
	return ClauseLitIterator(p_clauseConfig, clause, 1);
}
template<typename BaseDefs, typename Hooks>
typename Config<BaseDefs, Hooks>::ClauseLitIterator Config<BaseDefs, Hooks>::clauseBegin3(
		Config<BaseDefs, Hooks>::clause_type clause) {
	if(clauseLength(clause) < 3)
		return clauseEnd(clause);
	return ClauseLitIterator(p_clauseConfig, clause, 2);
}
template<typename BaseDefs, typename Hooks>
typename Config<BaseDefs, Hooks>::ClauseLitIterator Config<BaseDefs, Hooks>::clauseEnd(
		Config<BaseDefs, Hooks>::clause_type clause) {
	return ClauseLitIterator(p_clauseConfig, clause,
			clauseLength(clause));
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::clauseSetEssential(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagEssential());
	currentEssentialClauses++;
	clause_head(clause)->setFlagEssential();
}
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::clauseUnsetEssential(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, clause_head(clause)->getFlagEssential());
	currentEssentialClauses--;
	clause_head(clause)->unsetFlagEssential();
}
template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::clauseIsEssential(Config<BaseDefs, Hooks>::clause_type clause) {
	return clause_head(clause)->getFlagEssential();
}

// callback functor used during collectClauses()
template<typename Config>
class DelClauseCallback {
public:
	DelClauseCallback(Config &config) : p_config(config) { }

	void onErase(typename Config::clause_type from_index) {
		SYS_ASSERT(SYS_ASRT_GENERAL, !p_config.clause_head(from_index)->getFlagInstalled());
	}

	void onMove(typename Config::clause_type from_index,
			typename Config::clause_type to_index) {
		p_config.onClauseMove(from_index, to_index);
	}

private:
	Config &p_config;
};

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::collectClauses() {
	// allocate new space for the clauses
	unsigned int count_estimate = p_clauseConfig.present_clauses;
	unsigned int used_estimate = p_clauseConfig.get_clauses_bytes();
	unsigned int space_estimate =  used_estimate + kClauseAlignment * count_estimate;
	unsigned int final_space = 1.5f * space_estimate + 4 * 1024 * 1024;
	
	clause_config_type new_config;
	void *memory = operator new(final_space);
	new_config.p_allocator.init_memory(memory, final_space);
	
	// copy them to the new space
	DelClauseCallback<config_type> callback(*this);
	packed_clause::relocateClauses(p_clauseConfig, new_config, callback);

	SYS_ASSERT(SYS_ASRT_GENERAL, new_config.p_allocator.get_total_space()
			- new_config.p_allocator.get_free_space() < space_estimate);

	// free the memory used by the old configuration
	operator delete(p_clauseConfig.p_allocator.get_memory());
	p_clauseConfig = std::move(new_config);

	// rebuild occurrence lists
	if(maintainOcclists) {
		for(variable_type var = 0; var < p_varConfig.count(); ++var) {
			p_varConfig.occur_clear(oneLiteral(var));
			p_varConfig.occur_clear(zeroLiteral(var));
		}
		for(auto i = clausesBegin(); i != clausesEnd(); ++i)
			for(auto j = clauseBegin(*i); j != clauseEnd(*i); ++j)
				p_varConfig.occur_insert(*j, *i);
	}
	
	stat.general.clauseCollects++;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::onClauseMove(Config<BaseDefs, Hooks>::clause_type from_index,
		Config<BaseDefs, Hooks>::clause_type to_index) {
	//std::cout << "Moving " << from_index << " to " << to_index << std::endl;
	/* replace the clause in both watch lists.
		NOTE: we cannot use clause_get_first on to_index! */
	if(!clause_head(from_index)->getFlagInstalled())
		return;
	
	if(clauseLength(from_index) == 1) {
		// there is nothing to fix in this case
	}else if(clauseLength(from_index) == 2) {
		// there is nothing to fix in this case
	}else{
		literal_type lit1 = clause_get_first(from_index);
		literal_type lit2 = clause_get_second(from_index);
		watchReplaceClause(litInverse(lit1), from_index, to_index);
		watchReplaceClause(litInverse(lit2), from_index, to_index);
		
		/* update the antecedent if the clause was unit */
		variable_type unit_var = litVariable(lit1);
		auto from_antecedent = antecedent_type::make_clause(from_index);
		auto to_antecedent = antecedent_type::make_clause(to_index);
		//if(varAssigned(unit_var))
		//	std::cout << "Antecedent: " << varAntecedent(unit_var).type
		//			<< " / " << varAntecedent(unit_var).identifier.padding << std::endl;
		if(from_antecedent == varAntecedent(unit_var))
			p_varConfig.set_antecedent(unit_var, to_antecedent);
	}
}

// checks whether a garbage collection is necessary
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::checkClauseGarbage() {
	if(p_clauseConfig.deleted_clauses
			> 0.5f * p_clauseConfig.present_clauses)
		collectClauses();
	
	unsigned int count_estimate = p_clauseConfig.num_clauses();
	unsigned int used_estimate = p_clauseConfig.get_clauses_bytes();
	unsigned int space_estimate =  used_estimate + kClauseAlignment * count_estimate;
	
	if(p_clauseConfig.p_allocator.get_used_space() > 2 * space_estimate)
		collectClauses();
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::expellContaining(Config<BaseDefs, Hooks>::literal_type lit) {
	SYS_ASSERT(SYS_ASRT_GENERAL, currentAssignedVars == 0);
	
	// remove unit clauses
	auto unit_it = std::find(p_unitClauses.begin(), p_unitClauses.end(), lit);
	if(unit_it != p_unitClauses.end())
		p_unitClauses.erase(unit_it);
	
	// remove long clauses
	for(clause_iterator it = p_clauseConfig.begin();
			it != p_clauseConfig.end(); ++it) {
		if(!clause_contains(*it, lit))
			continue;
		if(clauseIsEssential(*it))
			clauseUnsetEssential(*it);
		if(!clauseIsFrozen(*it))
			uninstallClause(*it);
		deleteClause(*it);
	}
	p_clauseConfig.prun_deleted();
}


/* -------------- WATCH LIST / OCCLIST FUNCTIONS ----------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::watchInsertClause(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::literal_type blocking,
		Config<BaseDefs, Hooks>::clause_type clause) {
	watch_entry_type new_entry;
	new_entry.set_longcl();
	new_entry.longcl.set_clause(clause);
	new_entry.longcl.set_blocking(blocking);
	p_varConfig.watch_insert(literal, new_entry);
}
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::watchInsertBinary(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::literal_type implied) {
	watch_entry_type new_entry;
	new_entry.set_binary();
	new_entry.binary.set_implied(implied);
	p_varConfig.watch_insert(literal, new_entry);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::watchRemoveClause(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::clause_type clause) {
	for(auto i = p_varConfig.watch_begin(literal);
			i != p_varConfig.watch_end(literal); ++i) {
		if(!(*i).is_longcl())
			continue;
		if((*i).longcl.get_clause() != clause)
			continue;
		p_varConfig.watch_erase(literal, i);
		return;
	}
	SYS_CRITICAL("Clause not found\n");
}
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::watchRemoveBinary(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::literal_type implied) {
	for(auto i = p_varConfig.watch_begin(literal);
			i != p_varConfig.watch_end(literal); ++i) {
		if(!(*i).is_binary())
			continue;
		if((*i).binary.get_implied() != implied)
			continue;
		p_varConfig.watch_erase(literal, i);
		return;
	}
	SYS_CRITICAL("watch_remove_binary(): Entry not found\n");
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::watchReplaceClause(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::clause_type clause,
		Config<BaseDefs, Hooks>::clause_type replacement) {
	for(auto i = p_varConfig.watch_begin(literal);
			i != p_varConfig.watch_end(literal); ++i) {
		if(!(*i).is_longcl())
			continue;
		if((*i).longcl.get_clause() != clause)
			continue;
		(*i).longcl.set_clause(replacement);
		return;
	}
	SYS_CRITICAL("Clause not found\n");
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::watchContainsBinary(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::literal_type implied) {
	for(auto i = p_varConfig.watch_begin(literal);
			i != p_varConfig.watch_end(literal); ++i) {
		if(!(*i).is_binary())
			continue;
		if((*i).binary.get_implied() != implied)
			continue;
		return true;
	}
	return false;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::occurConstruct() {
	SYS_ASSERT(SYS_ASRT_GENERAL, !maintainOcclists);
	for(auto i = clausesBegin(); i != clausesEnd(); ++i) {
		for(auto j = clauseBegin(*i); j != clauseEnd(*i); ++j)
			p_varConfig.occur_insert(*j, *i);
	}
	maintainOcclists = true;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::occurDestruct() {
	SYS_ASSERT(SYS_ASRT_GENERAL, maintainOcclists);
	for(variable_type i = 0; i < p_varConfig.count(); ++i) {
		p_varConfig.occur_clear(zeroLiteral(i));
		p_varConfig.occur_shrink(zeroLiteral(i));
		p_varConfig.occur_clear(oneLiteral(i));
		p_varConfig.occur_shrink(oneLiteral(i));
	}
	maintainOcclists = false;
}

/* ------------------- ASSIGN / UNASSIGN FUNCTIONS --------------------- */

template<typename Hooks>
class PropagateCallback {
public:
	void on_unit(typename Hooks::literal_type literal) { }
};

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::propagate() {
	if(atConflict())
		return;
	while(p_propagateConfig.props_left()) {
		literal_type literal = p_propagateConfig.next_prop();
		stat.search.propagations++;
		
		/* visit the binary/ternary watch list of the literal */
		PropagateCallback<config_type> callback;
		//if(propagate_big(*this, callback, literal))
		//	return;
		/* visit the other (non-binary/ternary clauses) */
		if(propagate_watch(*this, callback, literal))
			return;
	}
}

/* ------------------- ASSIGN / UNASSIGN FUNCTIONS --------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::pushAssign(Config<BaseDefs, Hooks>::literal_type literal,
		Config<BaseDefs, Hooks>::antecedent_type antecedent) {
	// variables are never pushed twice!
	variable_type var = litVariable(literal);
	SYS_ASSERT(SYS_ASRT_GENERAL, !varAssigned(var));
	
	p_propagateConfig.push_assign(literal);

	// setup the antecedent and decision level of the variable
	bool is_one = literal == oneLiteral(var);
	p_varConfig.get_assign(var).assign(is_one);
	p_varConfig.set_declevel(var, curDeclevel());
	p_varConfig.set_antecedent(var, antecedent);
	currentAssignedVars++;

	// phase saving
	if(is_one) {
		p_varConfig.set_varflag_saved(var);
	}else p_varConfig.clear_varflag_saved(var);

	if(kReportAssign) {
		report<ReportTag>(ReportTag::kAssign);
		report<uint32_t>(literal);
	}
	
//		std::cout << "[PUSH] Literal " << literal << " at order " << cur_order() 
//			<< " and decision " << curDeclevel() << std::endl;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::popAssign() {
	literal_type literal = p_propagateConfig.pop_assign();

	variable_type var = litVariable(literal);
	p_varConfig.get_assign(var).unassign();
	currentAssignedVars--;

	// reinsert the variable into the heap
	var_heap_hooks_type heap_hooks(*this);
	if(p_varConfig.get_heap_info(var).heap_index
			== var_heap_hooks_type::ILLEGAL_INDEX)
		util::heaps::binary::insert(heap_hooks, var);

//		std::cout << "[POP] Literal " << literal << std::endl;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::pushLevel() {
	p_propagateConfig.new_decision();
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::popLevel() {
	SYS_ASSERT(SYS_ASRT_GENERAL, curDeclevel() > 0);
	typename prop_config_type::decision_info decision
			= p_propagateConfig.peek_decision();
	p_propagateConfig.props_reset();
	while(p_propagateConfig.assign_index() > decision.first_index)
		popAssign();
	p_propagateConfig.pop_decision();
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::backjump(Config<BaseDefs, Hooks>::declevel_type to_declevel) {
//		std::cout << "Backjump to level " << to_declevel << std::endl;
//		std::cout << "   Current level was: " << curDeclevel() << std::endl;
	while(to_declevel < curDeclevel())
		popLevel();
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::restart() {
	backjump(2);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::reset() {
	p_solutionDesc = SolutionType::makeNone();
	p_conflictDesc = conflict_type::make_none();
	backjump(0);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::checkRestart() {
	if(opts.restart.strategy == kRestartLuby) {
		state.restart.lubyCounter++;
		if(state.restart.lubyCounter >= state.restart.lubyPeriod) {
			restart();
			stat.search.restarts++;
			state.restart.lubyPeriod = opts.restart.lubyScale
					* lubySequence(stat.search.restarts);
			state.restart.lubyCounter = 0;
		}
	}else if(opts.restart.strategy == kRestartGlucose) {
		unsigned int glucose_ptr = state.restart.glucose_short_pointer;
		/* update the short average */
		declevel_type lastConflictDeclevel = state.conflict.lastConflictDeclevel;
		if(state.restart.glucose_counter >= 100)
			state.restart.glucose_short_sum
					-= state.restart.glucose_short_buffer[glucose_ptr];
		state.restart.glucose_short_buffer[glucose_ptr] = lastConflictDeclevel;
		state.restart.glucose_short_sum += lastConflictDeclevel;
		/* update the long average */
		state.restart.glucose_long_sum += lastConflictDeclevel;
		state.restart.glucose_short_pointer++;
		state.restart.glucose_short_pointer %= opts.restart.glucose_short_interval;
	
		float short_avg = (float)state.restart.glucose_short_sum
				/ opts.restart.glucose_short_interval;
		float long_avg = (float)state.restart.glucose_long_sum / conflictNum;

		state.restart.glucose_counter++;
		if(state.restart.glucose_counter > 100 && 0.7f * short_avg > long_avg) {
			restart();
			stat.search.restarts++;
			state.restart.glucose_counter = 0;
			state.restart.glucose_short_sum = 0;
		}
	}else SYS_CRITICAL("Illegal restart strategy\n");
}

/* ----------------------------- INPUT FUNCTIONS --------------------------- */

template<typename BaseDefs, typename Hooks>
template<typename Iterator>
void Config<BaseDefs, Hooks>::inputClause(Config<BaseDefs, Hooks>::litindex_type length,
		Iterator begin, Iterator end) {
	clause_type clause = allocClause(length, begin, end);
	clauseSetEssential(clause);
	queueInstallClause(clause);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::inputFinish() {
	installQueueProcess();

	// initialize clause deletion heuristics
	unsigned int num_clauses = p_clauseConfig.num_clauses();
	state.clauseRed.geomIncCounter = 0;
	state.clauseRed.geomIncLimit = 100;
	state.clauseRed.geomSizeLimit = num_clauses / 3 + 10;

	state.clauseRed.agileCounter = 0;
	state.clauseRed.agileInterval = opts.clauseRed.agileBaseInterval;
}

/* ------------------------ CLAUSE REDUCTION FUNCTIONS --------------------- */

template<typename Config>
class WorkClauseLt {
public:
	WorkClauseLt(Config &config) : p_config(config) { }

	bool operator() (typename Config::clause_type left,
			typename Config::clause_type right) {
		if((p_config.clauseGetLbd(left) < 4 || p_config.clauseGetLbd(right) < 4)
				&& (p_config.clauseGetLbd(left) != p_config.clauseGetLbd(right)))
			return p_config.clauseGetLbd(left) < p_config.clauseGetLbd(right);
		
		return p_config.clause_get_activity(left)
				> p_config.clause_get_activity(right);
	}

private:
	Config &p_config;
};

template<typename Config>
class ClauseGlueLt {
public:
	ClauseGlueLt(Config &config) : p_config(config) { }

	bool operator() (typename Config::clause_type left,
			typename Config::clause_type right) {
		if(p_config.clauseGetLbd(left) != p_config.clauseGetLbd(right))
			return p_config.clauseGetLbd(left) < p_config.clauseGetLbd(right);
		
		return p_config.clause_get_activity(left)
				> p_config.clause_get_activity(right);
	}

private:
	Config &p_config;
};

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::freezeClause(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagFrozen());
	uninstallClause(clause);
	clause_head(clause)->setFlagFrozen();
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::quickFreezeClause(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagInstalled());
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagFrozen());
	clause_head(clause)->setFlagFrozen();
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::unfreezeClause(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, clause_head(clause)->getFlagFrozen());
	installClause(clause);
	clause_head(clause)->unsetFlagFrozen();
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::clauseIsFrozen(Config<BaseDefs, Hooks>::clause_type clause) {
	return clause_head(clause)->getFlagFrozen();
}

template<typename BaseDefs, typename Hooks>
int Config<BaseDefs, Hooks>::calculatePsm(Config<BaseDefs, Hooks>::clause_type clause) {
	int psm = 0;
	for(auto it = clauseBegin(clause); it != clauseEnd(clause); ++it) {
		variable_type var = litVariable(*it);
		bool saved_one = p_varConfig.get_varflag_saved(var);
		if((isOneLiteral(*it) && saved_one)
				|| (!isOneLiteral(*it) && !saved_one))
			psm++;
	}
	return psm;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::reduceClauses() {
	SYS_ASSERT(SYS_ASRT_GENERAL, !atConflict());
	
	// build a list of all clauses that are considered for deletion
	std::vector<clause_type> delete_queue;
	for(clause_iterator it = p_clauseConfig.begin();
			it != p_clauseConfig.end(); ++it) {
		// never delete essential clauses
		if(clauseIsEssential(*it) || !clause_present(*it))
			continue;
		// do not delete classes that are currently unit
		if(clauseIsAntecedent(*it))
			continue;

		// TODO: does this make sense?
		// don't delete units and binary clauses
		if(clauseLength(*it) < 3)
			continue;
		// keep clauses with high activity
		if(clause_get_activity(*it) > state.search.clauseActInc) {
			stat.clauseRed.clausesActive++;
		}else{
			stat.clauseRed.clausesNotActive++;
			delete_queue.push_back(*it);
		}
	}

	// TODO: just backjump to a lower level instead of resetting
	reset(); // reset the solver so that unfreeze works correctly
	
	for(unsigned int i = 0; i < delete_queue.size(); i++) {
		auto clause = delete_queue[i];
		
		if(clauseIsFrozen(clause)) {
			// unfreeze clauses if their psm is good
			if(calculatePsm(clause) <= 3) {
				unfreezeClause(clause);
				stat.clauseRed.clauseUnfreezes++;
			}
		}else{
			if(clauseGetLbd(clause) <= 8) {
				// freeze clauses that are good in general but bad under the current assignment
				freezeClause(clause);
				stat.clauseRed.clauseFreezes++;
			}else{
				uninstallClause(clause);
				deleteClause(clause);
				stat.clauseRed.clauseDeletions++;
			}
		}
		stat.clauseRed.clausesConsidered++;
	}
	p_clauseConfig.prun_deleted();
	stat.clauseRed.reductionRuns++;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::checkClauseReduction() {
	if(opts.clauseRed.model == kClauseRedAgile) {
		state.clauseRed.agileCounter++;
		if(state.clauseRed.agileCounter
				>= state.clauseRed.agileInterval) {
			reduceClauses();
			state.clauseRed.numClauseReds++;

			state.clauseRed.agileCounter = 0;
			state.clauseRed.agileInterval += opts.clauseRed.agileSlowdown;
		}
	}else if(opts.clauseRed.model == kClauseRedGeometric) {
		if(currentActiveClauses - currentEssentialClauses
				>= state.clauseRed.geomSizeLimit)
			reduceClauses();
			state.clauseRed.numClauseReds++;

		state.clauseRed.geomIncCounter++;
		if(state.clauseRed.geomIncCounter
				>= state.clauseRed.geomIncLimit) {
			state.clauseRed.geomSizeLimit
					*= opts.clauseRed.geomSizeFactor;
			state.clauseRed.geomIncLimit
					*= opts.clauseRed.geomIncFactor;
			state.clauseRed.geomIncCounter = 0;
		}
	}else SYS_CRITICAL("Illegal clause reduction model\n");
}

/* ---------------------- DECISION FUNCTIONS ------------------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::start() {
	if(!p_solutionDesc.isNone())
		return;
	SYS_ASSERT(SYS_ASRT_GENERAL, p_conflictDesc.is_none());
	
	// units are assigned on decision level 1
	if(curDeclevel() == 0) {
		pushLevel();
		for(auto it = p_unitClauses.begin(); it != p_unitClauses.end(); ++it) {
			if(litTrue(*it))
				continue;
			if(litFalse(*it)) {
				p_solutionDesc = SolutionType::makeUnsatisfiable();
				return;
			}
			
			pushAssign(*it, antecedent_type::make_decision());
			propagate();
			if(atConflict()) {
				SYS_ASSERT(SYS_ASRT_GENERAL, atSolution());
				return;
			}
		}
	}
	
	// assumptions are assigned on decision level 2
	if(curDeclevel() == 1) {
		pushLevel();
		for(auto it = p_assumptionList.begin(); it != p_assumptionList.end(); ++it) {
			SYS_ASSERT(SYS_ASRT_GENERAL, p_varConfig.get_litflag_assumption(*it));
			if(litTrue(*it))
				continue;
			if(litFalse(*it)) {
				p_solutionDesc = SolutionType::makeFailedAssumption();
				return;
			}
			
			pushAssign(*it, antecedent_type::make_decision());
			propagate();
			if(atConflict()) {
				SYS_ASSERT(SYS_ASRT_GENERAL, atSolution());
				return;
			}
		}
	}
	SYS_ASSERT(SYS_ASRT_GENERAL, curDeclevel() >= 2);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::decide() {
	SYS_ASSERT(SYS_ASRT_GENERAL, p_solutionDesc.isNone());
	SYS_ASSERT(SYS_ASRT_GENERAL, p_conflictDesc.is_none());
	
	/* determine the variable with minimal vsids score */
	literal_type decliteral = kIllegalLit;
	if(decliteral == kIllegalLit) {
		var_heap_hooks_type heap_hooks(*this);
		variable_type var = util::heaps::binary::remove_minimum(heap_hooks);
		while(varAssigned(var))
			var = util::heaps::binary::remove_minimum(heap_hooks);
		
		bool saved_one = p_varConfig.get_varflag_saved(var);
		decliteral = saved_one ? oneLiteral(var) : zeroLiteral(var);
	}
	
	/* create a new decision level; assign the variable */
	p_propagateConfig.new_decision();
	pushAssign(decliteral, antecedent_type::make_decision());
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::scaleVarActivity(Config<BaseDefs, Hooks>::activity_type divisor) {
	for(variable_type var = 0; var < p_varConfig.count(); var++)
		p_varConfig.get_heap_info(var).activity /= divisor;
	state.search.varActInc /= divisor;
}
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::scaleClauseActivity(Config<BaseDefs, Hooks>::activity_type divisor) {
	for(auto i = clausesBegin(); i != clausesEnd(); ++i)
		clause_set_activity(*i, clause_get_activity(*i) / divisor);
	state.search.clauseActInc /= divisor;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::onVarActivity(Config<BaseDefs, Hooks>::variable_type var) {
	var_heap_hooks_type heap_hooks(*this);
	
	double activity = p_varConfig.get_heap_info(var).activity;
	p_varConfig.get_heap_info(var).activity += state.search.varActInc;
	
	if(p_varConfig.get_heap_info(var).heap_index
			!= var_heap_hooks_type::ILLEGAL_INDEX)
		util::heaps::binary::became_less(heap_hooks, var);
	
	/* re-scale the activity of all variables if necessary */
	if(activity > 1.0E50)
		scaleVarActivity(activity);
}
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::onAntecedentActivity(Config<BaseDefs, Hooks>::antecedent_type antecedent) {
	if(antecedent.is_clause()) {
		clause_type clause = antecedent.identifier.clause_ident; 
		double activity = clause_get_activity(clause);
		clause_set_activity(clause, activity + state.search.clauseActInc);
		
		/* re-scale the activity of all clauses if necessary */
		if(activity > 1.0E50)
			scaleClauseActivity(activity);
	}
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::increaseActivity() {
	state.search.varActInc *= state.search.varActFactor;
	state.search.clauseActInc *= state.search.clauseActFactor;
}

/* ------------------------- CONFLICT MANAGEMENT --------------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::raiseConflict(conflict_type conflict) {
//		std::cout << "Conflict! Variable: " << variable << std::endl;
	SYS_ASSERT(SYS_ASRT_GENERAL, !atConflict());
	SYS_ASSERT(SYS_ASRT_GENERAL, !atSolution());

	if(curDeclevel() == 1) {
		p_solutionDesc = SolutionType::makeUnsatisfiable();
	}else if(curDeclevel() == 2) {
		p_solutionDesc = SolutionType::makeFailedAssumption();
	}

	p_conflictDesc = conflict;
	conflictNum++;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::resolveConflict() {
	SYS_ASSERT(SYS_ASRT_GENERAL, !atSolution());

	state.conflict.lastConflictDeclevel = curDeclevel();

	// determine the first uip clause
	problem::sat::first_uip::cut(p_learnConfig, *this, conflictBegin(), conflictEnd());
	problem::sat::first_uip::minimize(p_learnConfig, *this);
	problem::sat::first_uip::build(p_learnConfig, *this);
	
	// backjump and reset the conflict state
	SYS_ASSERT(SYS_ASRT_GENERAL, p_learnConfig.min_size() > 0);
	if(p_learnConfig.min_size() > 1) {
		literal_type watch_lit = p_learnConfig.min_get(1);
		variable_type watch_var = litVariable(watch_lit);
		backjump(varDeclevel(watch_var));
	}else backjump(0);
	p_conflictDesc = conflict_type::make_none();

	stat.search.learnedLits += p_learnConfig.cut_size();
	stat.search.minimizedLits += p_learnConfig.min_size();

	literal_type uip_literal = p_learnConfig.min_get(0);
	variable_type uip_var = litVariable(uip_literal);
	
	// generate a clause for the conflict
	clause_type learned = allocClause(p_learnConfig.min_size(),
			p_learnConfig.begin_min(), p_learnConfig.end_min());
	installClause(learned);

	// output the drat proof line for this clause
	// TODO: move this to a "Hooks" function
	if(opts.general.outputDratProof) {
		for(auto it = p_learnConfig.begin_min(); it != p_learnConfig.end_min(); ++it) {
			if(!isOneLiteral(*it))
				std::cout << '-';
			std::cout << (litVariable(*it) + 1);
			std::cout << ' ';
		}
		std::cout << "0" << std::endl;
	}
		
	// calculate the literal-block-distance
	unsigned int lbd = problem::sat::lbd::of_clause
			<config_type, 15>(*this, learned);
	clauseSetLbd(learned, lbd);
	clause_set_activity(learned, state.search.clauseActInc);
	
	p_hooks.onLearnedClause(learned);

	// add the learned clause to the clause database
	if(p_learnConfig.min_size() > 2) {
		pushAssign(uip_literal, antecedent_type::make_clause(learned));

		// bump variables asserted by glue clauses as in glucose
		if(opts.learn.bumpGlueTwice)
			for(auto i = p_learnConfig.begin_curlevel();
					i != p_learnConfig.end_curlevel(); ++i) {
				antecedent_type antecedent = varAntecedent(*i);
				if(antecedent.is_binary() && lbd > 2) {
					/* cannot check if the clause is learned.
						do not bump for now! */
					//onVarActivity(*i);
				}else if(antecedent.is_clause()) {
					clause_type reason = antecedent.identifier.clause_ident;
					if(!clause_head(reason)->getFlagEssential()
							&& clauseGetLbd(reason) < lbd)
						onVarActivity(*i);
				}
			}
	}else if(p_learnConfig.min_size() == 2) {
		literal_type reason_inverse = p_learnConfig.min_get(1);
		literal_type reason_literal = litInverse(reason_inverse);
		pushAssign(uip_literal,
				antecedent_type::make_binary(reason_literal));
		stat.search.learnedBinary++;
		state.inproc.new_binary++;
	}else{
		stat.search.learnedUnits++;
		state.inproc.new_facts++;
	}
	
	if(kReportSample) {
		report<ReportTag>(ReportTag::kSample);
		report<uint64_t>(currentActiveClauses);
	}

	// reset the learning configuration
	problem::sat::first_uip::reset(p_learnConfig, *this);
}

/* --------------------- ASSUMPTION FUNCTIONS -------------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::assumptionEnable(Config<BaseDefs, Hooks>::literal_type literal) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !p_varConfig.get_litflag_assumption(literal));
	SYS_ASSERT(SYS_ASRT_GENERAL, !varAssigned(litVariable(literal)));
	p_varConfig.set_litflag_assumption(literal);

	p_assumptionList.push_back(literal);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::assumptionDisable(Config<BaseDefs, Hooks>::literal_type literal) {
	SYS_ASSERT(SYS_ASRT_GENERAL, p_varConfig.get_litflag_assumption(literal));
	SYS_ASSERT(SYS_ASRT_GENERAL, !varAssigned(litVariable(literal)));
	p_varConfig.clear_litflag_assumption(literal);

	auto it = std::find(p_assumptionList.begin(), p_assumptionList.end(), literal);
	SYS_ASSERT(SYS_ASRT_GENERAL, it != p_assumptionList.end());
	p_assumptionList.erase(it);
}

template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::isAssumed(Config<BaseDefs, Hooks>::literal_type literal) {
	return p_varConfig.get_litflag_assumption(literal);
}

/* --------------------- ALLOCATION FUNCTIONS -------------------------- */

template<typename BaseDefs, typename Hooks>
template<typename Iterator>
typename Config<BaseDefs, Hooks>::clause_type Config<BaseDefs, Hooks>::allocClause(
		Config<BaseDefs, Hooks>::litindex_type length, Iterator begin, Iterator end) {
	SYS_ASSERT(SYS_ASRT_GENERAL, length > 0);
	unsigned int mem_estimate = p_clauseConfig.calc_bytes(length)
			+ kClauseAlignment;
	
	// ensure that there is enough free space for a new clause
	if(p_clauseConfig.p_allocator.get_free_space() < mem_estimate)
		ensureClauseSpace(mem_estimate);
	
	// sanity check
/*		for(auto i = begin; i != end; ++i) {
		SYS_ASSERT(SYS_ASRT_GENERAL, p_varConfig.var_present(litVariable(*i)));
		for(auto j = begin; j != end; ++j) {
			if(i == j)
				continue;
			if(*i == *j || *i == litInverse(*j))
				SYS_CRITICAL("Illegal clause for clause_alloc()");
		}
	}*/
	
	clause_type clause = packed_clause::new_clause(p_clauseConfig, length);
	clause_head_type *head = p_clauseConfig.get_head(clause);

	clause_sig_type signature = 0;
	unsigned int sig_size = sizeof(clause_sig_type) * 8;
	litindex_type k = 0;
	for(Iterator it = begin; it != end && k < length; ++it, ++k) {
		*(head->literal(k)) = *it;
		signature |= (1 << ((*it) % sig_size));
	}
	clause_set_sig(clause, signature);
	SYS_ASSERT(SYS_ASRT_GENERAL, k == length);
	return clause;
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::deleteClause(clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clauseIsEssential(clause));
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagDelete());
	p_clauseConfig.set_delete(clause);
	stat.general.deletedClauses++;
	
	// output the drat proof line for this clause
	// TODO: move this to a "Hooks" function
	if(opts.general.outputDratProof) {
		std::cout << "d ";
		for(auto it = clauseBegin(clause); it != clauseEnd(clause); ++it) {
			if(!isOneLiteral(*it))
				std::cout << '-';
			std::cout << (litVariable(*it) + 1);
			std::cout << ' ';
		}
		std::cout << "0" << std::endl;
	}
}

/* ---------------- INSTALL / UNINSTALL FUNCTIONS --------------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::installClause(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagInstalled());

	if(clauseLength(clause) == 1) {
		literal_type lit = clause_get_first(clause);
		p_unitClauses.push_back(lit);
	}else if(clauseLength(clause) == 2) {
		literal_type lit1 = clause_get_first(clause);
		literal_type lit2 = clause_get_second(clause);
		watchInsertBinary(litInverse(lit1), lit2);
		watchInsertBinary(litInverse(lit2), lit1);
	}else{
		literal_type lit1 = clause_get_first(clause);
		literal_type lit2 = clause_get_second(clause);
		watchInsertClause(litInverse(lit1), lit2, clause);
		watchInsertClause(litInverse(lit2), lit1, clause);
	}
		
	if(maintainOcclists) {
		for(auto i = clauseBegin(clause); i != clauseEnd(clause); ++i)
			p_varConfig.occur_insert(*i, clause);
	}
	
	clause_head(clause)->setFlagInstalled();
	currentActiveClauses++;
}
template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::uninstallClause(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clauseIsAntecedent(clause));
	SYS_ASSERT(SYS_ASRT_GENERAL, clause_head(clause)->getFlagInstalled());

	SYS_ASSERT(SYS_ASRT_GENERAL, clauseLength(clause) > 1);
	literal_type lit1 = clause_get_first(clause);
	literal_type lit2 = clause_get_second(clause);
	if(clauseLength(clause) == 2) {
		watchRemoveBinary(litInverse(lit1), lit2);
		watchRemoveBinary(litInverse(lit2), lit1);
	}else{
		watchRemoveClause(litInverse(lit1), clause);
		watchRemoveClause(litInverse(lit2), clause);
	}

	// TODO: update occurrence lists
	SYS_ASSERT(SYS_ASRT_GENERAL, !maintainOcclists);
	
	clause_head(clause)->unsetFlagInstalled();
	currentActiveClauses--;
}

/* --------------------- INSTALL QUEUE FUNCTIONS --------------------------- */

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::queueInstallClause(Config<BaseDefs, Hooks>::clause_type clause) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->getFlagQueuedInstall());
	clause_head(clause)->setFlagQueuedInstall();
	p_installClauseQueue.push_back(clause);
}

template<typename BaseDefs, typename Hooks>
void Config<BaseDefs, Hooks>::installQueueProcess() {
	// install long clauses
	for(auto i = p_installClauseQueue.begin(); i != p_installClauseQueue.end(); ++i) {
		clause_head(*i)->unsetFlagQueuedInstall();
		installClause(*i);
	}
	p_installClauseQueue.clear();
	p_installClauseQueue.shrink_to_fit();
}
template<typename BaseDefs, typename Hooks>
bool Config<BaseDefs, Hooks>::installQueueEmpty() {
	return p_installClauseQueue.size() == 0;
}


struct TotalSearchStats {
	util::performance::counter elapsed;

	TotalSearchStats() : elapsed(0) { }
};

template<typename Config>
void progressHeader(Config &config) {
	std::stringstream text;
	text << std::right;
	text << "c (" << std::to_string(config.p_configId) <<") [SEARCH]" ;
	text << std::setw(6) << "secs";
	text << std::setw(14) << "conflicts";
	text << std::setw(9) << "restarts";
	text << std::setw(12) << "limit";
	text << std::setw(10) << "space(kb)";
	std::cout << text.str() << std::endl;
	std::cout << "c -----------------------------------------------------------------------" << std::endl;
}

template<typename Config>
void progressMessage(Config &config,
		util::performance::counter current_time) {
	std::stringstream msg;
	msg << "c (" << std::to_string(config.p_configId) << ") [SEARCH]";
	msg << std::right << std::setprecision(2) << std::fixed;
	msg << std::setw(6) << ((current_time - config.state.general.start_time) / (1000 * 1000 * 1000));
	msg << std::setw(14) << config.conflictNum;
	msg << std::setw(9) << config.stat.search.restarts;
	msg << std::setw(12) << (config.opts.clauseRed.model == Config::kClauseRedAgile
			? config.state.clauseRed.agileInterval
			: config.state.clauseRed.geomSizeLimit);
	msg << std::setw(10) << (config.clause_space() / 1024);
//			msg << std::setw(12) << ((float)config.state.restart.glucose_long_sum / config.conflictNum);
//			msg << std::setw(12) << ((float)config.state.restart.glucose_short_sum
//					/ config.opts.restart.glucose_short_interval);
	std::cout << msg.str() << std::endl;
}


template<typename Hooks>
void search(Hooks &hooks, satuzk::SolveState &cur_state,
		TotalSearchStats &total_stats) {
	auto start = util::performance::current();
	for(unsigned int i = 0; true; i++) {
		hooks.propagate();
		// propagation could lead to a conflict at declevels 1 or 2
		if(hooks.atSolution())
			break;
		if(hooks.atConflict()) {
			hooks.resolveConflict();
			hooks.increaseActivity();
			hooks.checkRestart();
			hooks.checkClauseReduction();
			hooks.checkClauseGarbage();
			continue;
		}
		
		// return after a certain conflict limit is reached
		if(i > 1000)
			break;
		
		hooks.start();
		if(hooks.atSolution())
			break;
		if(hooks.atLeaf())
			break;
		hooks.decide();
	}
	
	if(hooks.atSolution()) {
		if(hooks.isUnsatisfiable()) {
			cur_state = satuzk::SolveState::kStateUnsatisfiable;
			total_stats.elapsed += util::performance::elapsed(start);
			return;
		}else if(hooks.isFailedAssumption()) {
			cur_state = satuzk::SolveState::kStateAssumptionFail;
			total_stats.elapsed += util::performance::elapsed(start);
			return;
		}else{
			SYS_CRITICAL("Illegal state");
		}
	}else if(hooks.atLeaf()) {
		SYS_ASSERT(SYS_ASRT_GENERAL, !hooks.atConflict());
		cur_state = satuzk::SolveState::kStateSatisfied;
		total_stats.elapsed += util::performance::elapsed(start);
		return;
	}else{
		cur_state = satuzk::SolveState::kStateBreak;
		total_stats.elapsed += util::performance::elapsed(start);
		return;
	}
}

template<typename Config>
satuzk::SolveState solveStep(Config &config) {
	config.propagate();
	if(config.atConflict()) /*FIXME: replace with isUnsatisfiable() */
		return satuzk::SolveState::kStateUnsatisfiable;

//	config.eliminate_facts();
	config.checkClauseGarbage();

	uint64_t t_start, t_end;

	if(config.opts.general.verbose >= 1) {
		std::cout << "c [      ]  initial:" << std::endl;
		std::cout << "c [      ]     variables: " << config.p_varConfig.present_count()
			<< ", long clauses: " << config.p_clauseConfig.present_clauses
			<< ", watch lists: " << config.p_varConfig.watch_overall_size() << std::endl;	
	}
	
	if(config.opts.general.verbose >= 1)
		std::cout << "c building occurrence lists" << std::endl;
	t_start = sysGetCpuTime();
	config.occurConstruct();
	t_end = sysGetCpuTime();
	if(config.opts.general.verbose >= 1) {
		std::cout << "c finished in " << (t_end - t_start) << " msecs" << std::endl;
		std::cout << "c occlist memory: " << sys_peak_memory() << " kb" << std::endl;
	}
	
	auto preproc_start = util::performance::current();
	/*if(config.opts.preproc.model == Config::kPreprocIterative) {
		preproc_iterative(config);
	}else if(config.opts.preproc.model == Config::kPreprocAdaptive) {
		preproc_adaptive(config);
	}*/
	config.perf.preproc_time = util::performance::elapsed(preproc_start);
	
	if(config.opts.general.verbose >= 1) {
		std::cout << "c [      ]  before search:" << std::endl;
		std::cout << "c [      ]     variables: " << config.p_varConfig.present_count()
			<< ", long clauses: " << config.p_clauseConfig.present_clauses
			<< ", watch lists: " << config.p_varConfig.watch_overall_size() << std::endl;	
	}
	
	config.occurDestruct();
	
	auto last_message = util::performance::current();
	if(config.opts.general.verbose >= 1)
		progressHeader(config);

	TotalSearchStats search_total_stats;

	while(true) {
		if(config.state.general.stop_solve)
			return satuzk::SolveState::kStateBreak;
		
		// check for timeout / print progress message
		auto current = util::performance::current();
		if(config.opts.general.timeout != 0 && config.opts.general.timeout
				< current - config.state.general.start_time)
			return satuzk::SolveState::kStateBreak;
		if(current - last_message > 5LL * 1000 * 1000 * 1000) {
			if(config.opts.general.verbose >= 1)
				progressMessage(config, current);
			last_message = current;
		}

		/* perform search */
		satuzk::SolveState cur_state = satuzk::SolveState::kStateUnknown;
		search(config, cur_state, search_total_stats);
		if(cur_state == satuzk::SolveState::kStateSatisfied
				|| cur_state == satuzk::SolveState::kStateUnsatisfiable
				|| cur_state == satuzk::SolveState::kStateAssumptionFail) 
			return cur_state;
	
		/* perform inprocessing */
/*		SYS_ASSERT(SYS_ASRT_GENERAL, config.curDeclevel() == 1);
		if(config.opts.inproc.model == Config::kInprocAdaptive) {
			if(config.perf.inproc_time < 0.05f * search_total_stats.elapsed) {
				if(config.opts.general.verbose >= 2)
					std::cout << "c [INPROC] started, total inproc time: "
							<< (config.perf.inproc_time / (1000 * 1000)) << " msecs"
							<< ", search time: " << (search_total_stats.elapsed / (1000 * 1000)) << " msescs" << std::endl;
				auto start = util::performance::current();
				inproc_adaptive(config);
				auto elapsed = util::performance::elapsed(start);
				if(config.opts.general.verbose >= 2)
					std::cout << "c [INPROC] finished in: "
							<< (elapsed / (1000 * 1000)) << " msecs" << std::endl;
				
				config.perf.inproc_time += elapsed;
			}
		}*/
	}
}

}; /* namespace satuzk */

