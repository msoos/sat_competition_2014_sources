
template<typename Hooks>
class inproc_adaptive_unhide_heuristics {
public:
	inproc_adaptive_unhide_heuristics(Hooks &hooks) : p_hooks(hooks) { }

	bool another_run(unsigned int total_runs,
			unsigned int last_equiv, unsigned int last_elim, uint64_t last_hle_lits,
			util::performance::counter last_elapsed,
			util::performance::counter total_elapsed) {
		/* hard time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.03f)
			return false;

		/* continue if last run was incredibly good */
		float last_quote = (float)last_elapsed / p_hooks.opts.general.budget;
		unsigned int scaled_elim = last_elim / (last_quote * 100);
		unsigned int scaled_equiv = last_equiv / (last_quote * 100);
		unsigned int scaled_hle_lits = last_hle_lits / (last_quote * 100);
//		std::cout << "c [UNHIDE]    another run? quote: " << (last_quote * 100) << "%" << std::endl;
//		std::cout << "c [UNHIDE]       scaled equivalent: " << scaled_equiv
//				<< ", eliminated: " << scaled_elim << std::endl;
		
		unsigned int present_vars = p_hooks.p_varConfig.present_count();
		uint64_t present_lits = p_hooks.p_clauseConfig.present_literals();
		unsigned int hard_goal_equiv = present_vars * 0.01f;
		unsigned int hard_goal_elim = present_vars * 0.005f;
		uint64_t hard_goal_hle_lits = present_lits * 0.01f;
//		std::cout << "c [UNHIDE]       hard goal equivalent: " << hard_goal_equiv
//				<< ", eliminated: " << hard_goal_elim << std::endl;

		if(scaled_elim > hard_goal_elim || scaled_equiv > hard_goal_equiv
				|| scaled_hle_lits > hard_goal_hle_lits)
			return true;
		
		/* soft time-limit */
		if(total_elapsed > p_hooks.opts.general.budget * 0.005)
			return false;

		/* break if last run was incredibly bad */
		unsigned int soft_goal_equiv = present_vars * 0.005f;
		unsigned int soft_goal_elim = present_vars * 0.002f;
//		std::cout << "c [UNHIDE]       soft goal equivalent: " << soft_goal_equiv
//				<< ", eliminated: " << soft_goal_elim << std::endl;

		if(!(scaled_elim > soft_goal_elim && scaled_equiv > soft_goal_equiv))
			return false;
		return true;
	}

	void run_stats(unsigned int run_equiv, unsigned int run_elim,
			unsigned int run_hle_lits,
			util::performance::counter run_elapsed) {
//		uint64_t present_lits = p_hooks.p_clauseConfig.present_literals();
		
//		std::cout << "c [UNHIDE]    run statistics"
//			<< ", time: " << (run_elapsed / (1000 * 1000)) << " msecs" << std::endl;
//		std::cout << "c [UNHIDE]       equivalent: " << run_equiv
//				<< ", eliminated: " << run_elim << std::endl;
//		std::cout << "c [UNHIDE]       hidden lits: " << run_hle_lits << " of " << present_lits << std::endl;
	}

private:
	Hooks &p_hooks;
};

template<typename Hooks>
void inproc_unhide(Hooks &hooks) {
	unsigned int stat_runs = 0;
	util::performance::counter elapsed = 0;

//	std::cout << "c [UNHIDE] started" << std::endl;
	inproc_adaptive_unhide_heuristics<Hooks> heuristics(hooks);
	/* NOTE: enabled hte (SAT 2013 paper version) */
	unhiding_heuristic(hooks, true, heuristics, stat_runs, elapsed);
//	std::cout << "c [UNHIDE]    runs: " << stat_runs
//			<< ", finished in " << (elapsed / (1000 * 1000)) << " msecs" << std::endl;
}

template<typename Hooks>
void inproc_brm(Hooks &hooks) {
	brm_run_stats_struct run_stats;
	
	if(hooks.opts.general.verbose > 1)
		std::cout << "c [BRM   ] started" << std::endl;
	brm_eliminate_active(hooks, 100, run_stats);
	if(hooks.opts.general.verbose > 1) {
		std::cout << "c [BRM   ]    failed lits: " << run_stats.failed;
		std::cout << ", equivalent lits: " << run_stats.equivalent;
		std::cout << ", independent lits: " << run_stats.independent << std::endl;
		std::cout << "c [BRM   ]    finished in " << (run_stats.elapsed / (1000 * 1000)) << " msecs" << std::endl;
	}
}

template<typename Hooks>
void inproc_dist(Hooks &hooks) {
	dist_eliminate_active(hooks, 100);
}

template<typename Hooks>
void inproc_adaptive(Hooks &hooks) {
	util::performance::counter start;
	util::performance::counter elapsed;

	start = util::performance::current();
	hooks.installQueueProcess();
	elapsed = util::performance::elapsed(start);
	hooks.perf.fact_elim_time += elapsed;

	if(hooks.opts.inproc.with_dist)
		inproc_dist(hooks);
	if(hooks.isUnsatisfiable())
		return;
	if(hooks.opts.inproc.with_unhiding)
		inproc_unhide(hooks);
	if(hooks.isUnsatisfiable())
		return;
	if(hooks.opts.inproc.with_brm)
		inproc_brm(hooks);
	if(hooks.isUnsatisfiable())
		return;
}

