
namespace problem {
namespace sat {
namespace vars {

template<typename DecLevel, typename Antecedent,
	typename Activity>
struct assign_info {
	typedef uint8_t value_type;
	static const value_type VALUE_NONE = 0;
	static const value_type VALUE_STATE_BIT = 1;
	static const value_type VALUE_ASSIGNED_BIT = 2;

	static const value_type VALUE_TRUE = 3;
	static const value_type VALUE_FALSE = 2;

	value_type value;

	void assign(bool state) {
		value = VALUE_ASSIGNED_BIT | (int)state;
	}
	void unassign() {
		value = VALUE_NONE;
	}

	bool is_one() {
		return value == VALUE_TRUE;
	}
	bool is_zero() {
		return value == VALUE_FALSE;
	}
	bool is_assigned() {
		return (value & VALUE_ASSIGNED_BIT);
	}

	bool lit_true(bool one_lit) {
		return value == (VALUE_ASSIGNED_BIT | (int)one_lit);
	}
	bool lit_false(bool one_lit) {
		return value == (VALUE_ASSIGNED_BIT | (int)!one_lit);
	}
};

template<typename Activity>
struct heap_info_struct {
	Activity activity; /* usually 64-bit */
	uint32_t heap_index;
};

template<typename Clause>
class occur_list_struct {
public:
	typedef Clause clause_type;

	typedef util::vectors::simple<Clause> vector_type;
	typedef typename vector_type::iterator iterator;

	occur_list_struct() : p_vector() { }
	occur_list_struct(occur_list_struct &&other)
		: p_vector(std::move(other.p_vector)) { }
	occur_list_struct(const occur_list_struct &) = delete;
	void operator= (const occur_list_struct &) = delete;

	void insert(Clause clause) {
		p_vector.push_back(clause);
	}
	void clear() {
		p_vector.resize(0);
	}
	void shrink() {
		p_vector.shrink_to_fit();
	}
	void erase(iterator iterator) {
		p_vector.erase(iterator);
	}

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.resize(p_vector.index_of(after));
	}

private:
	vector_type p_vector;
};

/*template<typename Clause>
class occur_list_struct {
public:
	typedef Clause clause_type;

	typedef std::vector<Clause> vector_type;
	typedef typename vector_type::iterator iterator;

	occur_list_struct() : p_vector(0) { }
	occur_list_struct(occur_list_struct &&other)
		: p_vector(std::move(other.p_vector)) { }
	occur_list_struct(const occur_list_struct &) = delete;
	void operator= (const occur_list_struct &) = delete;

	void insert(Clause clause) {
		p_vector.push_back(clause);
	}
	void clear() {
		p_vector.clear();
	}
	void shrink() {
		p_vector.shrink_to_fit();
	}
	void erase(iterator iterator) {
		p_vector.erase(iterator);
	}

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.resize(after - p_vector.begin());
	}

private:
	vector_type p_vector;
};*/

template<typename Literal, typename Clause>
union watchlist_entry_struct {
	typedef Literal literal_type;
	typedef Clause clause_type;

	struct {
		static const uint32_t fl_mask = 0x7;
		static const uint32_t fl_longcl = 0;
		static const uint32_t fl_binary = 1;

		uint32_t flags;
		uint32_t padding;
	} general;

	struct {
		clause_type p_clause;
		literal_type p_blocking;
		
		void set_clause(clause_type clause) {
			p_clause = clause;
		}
		void set_blocking(literal_type blocking) {
			p_blocking = blocking;
		}
		clause_type get_clause() {
			return p_clause;
		}
		literal_type get_blocking() {
			return p_blocking;
		}
	} longcl;
	
	struct {
		uint32_t flags;
		literal_type p_implied;
		
		void set_implied(literal_type implied) {
			p_implied = implied;
		}
		literal_type get_implied() {
			return p_implied;
		}
	} binary;
	
	void set_binary() {
		general.flags |= general.fl_binary;
	}
	bool is_longcl() {
		return (general.flags & general.fl_mask) == general.fl_longcl;
	}
	bool is_binary() {
		return (general.flags & general.fl_mask) == general.fl_binary;
	}
};

/*template<typename Entry>
struct watchlist_struct {
	typedef Entry entry_type;

	typedef chunk_list<entry_type, 15> vector_type;
	typedef typename vector_type::iterator iterator;

	watchlist_struct() {
//		p_vector.construct();
	}

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	void insert(entry_type entry) {
		p_vector.push_back(entry);
	}
	void erase(iterator it) {
		p_vector.erase(it);
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.cut_before(after);
	}

	vector_type p_vector;
};*/

/*template<typename Entry>
struct watchlist_struct {
	typedef Entry entry_type;

	typedef util::vectors::simple<Entry> vector_type;
	typedef typename vector_type::iterator iterator;

	watchlist_struct() {
		p_vector.construct();
	}

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	void insert(entry_type entry) {
		p_vector.push_back(entry);
	}
	void erase(iterator it) {
		p_vector.erase(it);
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.unsafe_resize(p_vector.index_of(after));
	}

	vector_type p_vector;
};*/

template<typename Entry>
class watchlist_struct {
public:
	typedef Entry entry_type;

	typedef std::vector<Entry> vector_type;
	typedef typename vector_type::iterator iterator;

	watchlist_struct() : p_vector(0) { }
	watchlist_struct(watchlist_struct &&other)
		: p_vector(std::move(other.p_vector)) { }
	watchlist_struct(const watchlist_struct &) = delete;
	void operator= (const watchlist_struct &) = delete;

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	void insert(entry_type entry) {
		p_vector.push_back(entry);
	}
	void erase(iterator it) {
		p_vector.erase(it);
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.erase(after, p_vector.end());
	}

private:
	vector_type p_vector;
};

template<typename Literal, typename Clause>
struct big_edge_struct {
	Literal literal;
	uint32_t flags;
};

template<typename Literal, typename Clause>
class bt_watch_list_struct {
public:
	typedef big_edge_struct<Literal, Clause> entry_type;

	typedef std::vector<entry_type> vector_type;
	typedef typename vector_type::iterator iterator;

	bt_watch_list_struct() : p_vector(0) { }
	bt_watch_list_struct(bt_watch_list_struct &&other)
		: p_vector(std::move(other.p_vector)) { }
	bt_watch_list_struct(const bt_watch_list_struct &) = delete;
	void operator= (const bt_watch_list_struct &) = delete;

	typename vector_type::size_type size() {
		return p_vector.size();
	}
	void insert(entry_type entry) {
		p_vector.push_back(entry);
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void erase(iterator after) {
		p_vector.erase(after);
	}
	void cutoff(iterator after) {
		p_vector.resize(after - p_vector.begin());
	}
	void clear() {
		p_vector.clear();
	}

private:
	vector_type p_vector;
};

/* union-find data structure for equivalent literals */
template<typename Literal>
struct unionfind_struct {
	Literal parent;
};

template<typename VarIndex, typename DecLevel, typename Clause,
	typename Antecedent, typename Activity>
class config_struct {
public:
	typedef Clause clause_type;
	typedef VarIndex index_type;
	typedef Antecedent antecedent_type;
	typedef Activity activity_type;
	typedef DecLevel declevel_type;
	typedef uint8_t flags_type;

	typedef index_type variable_type;
	typedef index_type literal_type;
	
	static const literal_type ILLEGAL_LIT = (literal_type)(-1);
	
	static const flags_type FLAG_DELETED = 1;
	static const flags_type FLAG_SAVED_ONE = 2;
	static const flags_type FLAG_MODEL_ONE = 4;

	static const flags_type LITFLAG_HLA = 1;
	/* true if the literal is on the stack during the
		strongly-connected component decomposition */
	static const flags_type LITFLAG_SSC = 2;
	static const flags_type LITFLAG_MARKED = 4;

	static const flags_type LITFLAG_BIG_REMOVED = 32;
	static const flags_type LITFLAG_WATCH_REMOVED = 64;
	static const flags_type LITFLAG_OCCUR_REMOVED = 128;

	typedef assign_info<DecLevel, Antecedent, Activity> assign_type;
	typedef std::vector<assign_type> assign_vector;

	typedef std::vector<declevel_type> declevel_vector;

	typedef std::vector<flags_type> flags_vector_type;
	
	typedef occur_list_struct<Clause> occlist_type;
	typedef std::vector<occlist_type> occlist_vector;
	typedef typename occlist_type::iterator occur_iterator;

	typedef std::vector<antecedent_type> antecedent_vector_type;

	typedef heap_info_struct<Activity> heap_info_type;
	typedef std::vector<heap_info_type> heap_vector_type;	

	typedef watchlist_entry_struct<literal_type, Clause> watchlist_entry;
	typedef watchlist_struct<watchlist_entry> watchlist_type;
	typedef std::vector<watchlist_type> watchlist_vector;
	typedef typename watchlist_type::iterator watchlist_iterator;
	typedef typename watchlist_type::iterator watch_iterator;

	typedef big_edge_struct<literal_type, clause_type> bt_watch_entry_type;
	typedef bt_watch_list_struct<literal_type, clause_type> bt_watch_list_type;
	typedef std::vector<bt_watch_list_type> bt_watch_vector_type;
	typedef typename bt_watch_list_type::iterator bt_watch_iterator;

	typedef unionfind_struct<literal_type> unionfind_type;
	typedef std::vector<unionfind_type> unionfind_vector_type;

	config_struct() : p_present_count(0), big_edges(0) { }

	void reserve_vars(index_type count) {
		p_assigns.reserve(count);
		varflags_vector.reserve(count);
		declevels.reserve(count);
		antecedents.reserve(count);
		heap_infos.reserve(count);

		litflags_vector.reserve(2 * count);
		p_occlists.reserve(2 * count);
		p_watchlists.reserve(2 * count);
		bt_watch_vector.reserve(2 * count);
		unionfind_vector.reserve(2 * count);
	}

	index_type alloc_var() {
		index_type index = p_assigns.size();
		SYS_ASSERT(SYS_ASRT_GENERAL, p_occlists.size() == 2 * index);
		SYS_ASSERT(SYS_ASRT_GENERAL, p_watchlists.size() == 2 * index);
		SYS_ASSERT(SYS_ASRT_GENERAL, bt_watch_vector.size() == 2 * index);
		
		assign_type initial_assign;
		flags_type initial_flags = 0;
		declevel_type initial_declevel = 0;
		antecedent_type initial_antecedent;
		heap_info_type initial_heap_info;

		flags_type initial_litflags1 = 0;
		flags_type initial_litflags2 = 0;
		occlist_type initial_occlist1;
		occlist_type initial_occlist2;
		watchlist_type initial_watchlist1;
		watchlist_type initial_watchlist2;
		bt_watch_list_type initial_bt_watch1;
		bt_watch_list_type initial_bt_watch2;
		unionfind_type initial_unionfind1;
		unionfind_type initial_unionfind2;

		initial_assign.value = 0;
		initial_heap_info.activity = 0.0f;
		initial_unionfind1.parent = 2 * index;
		initial_unionfind2.parent = 2 * index + 1;

		p_assigns.push_back(initial_assign);
		varflags_vector.push_back(initial_flags);
		declevels.push_back(initial_declevel);
		antecedents.push_back(initial_antecedent);
		heap_infos.push_back(initial_heap_info);

		litflags_vector.push_back(initial_litflags1);
		litflags_vector.push_back(initial_litflags2);
		p_occlists.emplace_back(std::move(initial_occlist1));
		p_occlists.emplace_back(std::move(initial_occlist2));
		p_watchlists.emplace_back(std::move(initial_watchlist1));
		p_watchlists.emplace_back(std::move(initial_watchlist2));
		bt_watch_vector.emplace_back(std::move(initial_bt_watch1));
		bt_watch_vector.emplace_back(std::move(initial_bt_watch2));
		unionfind_vector.push_back(initial_unionfind1);
		unionfind_vector.push_back(initial_unionfind2);

		p_present_count++;
		return index;
	}

	index_type count() {
		return p_assigns.size();
	}
	
	assign_type &get_assign(VarIndex index) {
		return p_assigns[index];
	}

	unsigned int present_count() {
		return p_present_count;
	}
	void var_delete(variable_type var) {
		varflags_vector[var] |= FLAG_DELETED;
		p_present_count--;
	}
	bool var_present(variable_type var) {
		return !(varflags_vector[var] & FLAG_DELETED);
	}

	bool get_varflag_deleted(variable_type var) { return varflags_vector[var] & FLAG_DELETED; }
	
	bool get_varflag_saved(variable_type var) { return varflags_vector[var] & FLAG_SAVED_ONE; }
	void set_varflag_saved(variable_type var) { varflags_vector[var] |= FLAG_SAVED_ONE; }
	void clear_varflag_saved(variable_type var) { varflags_vector[var] &= ~FLAG_SAVED_ONE; }
	
	flags_type get_varflag_model(variable_type var) { return varflags_vector[var] & FLAG_MODEL_ONE; }
	void set_varflag_model(variable_type var) { varflags_vector[var] |= FLAG_MODEL_ONE; }
	void clear_varflag_model(variable_type var) { varflags_vector[var] &= ~FLAG_MODEL_ONE; }
	
	/* -------- decision level related functions ----------- */
	declevel_type get_declevel(variable_type var) {
		return declevels[var];
	}
	void set_declevel(variable_type var, declevel_type declevel) {
		declevels[var] = declevel;
	}

	/* -------- antecedent related functions ----------- */
	antecedent_type get_antecedent(variable_type var) {
		return antecedents[var];
	}
	void set_antecedent(variable_type var, antecedent_type antecedent) {
		antecedents[var] = antecedent;
	}
	
	/* --------------- heap related functions ------------- */
	heap_info_type &get_heap_info(variable_type var) {
		return heap_infos[var];
	}

	void watchlist_insert(literal_type literal, watchlist_entry entry) {
		watchlist_type &watchlist = p_watchlists[literal];
		watchlist.insert(entry);
	}

	/* -------- literal flag related functions --------- */
	bool get_litflag_hla(literal_type lit) {
		return litflags_vector[lit] & LITFLAG_HLA;
	}
	void set_litflag_hla(literal_type lit) {
		litflags_vector[lit] |= LITFLAG_HLA;
	}
	void clear_litflag_hla(literal_type lit) {
		litflags_vector[lit] &= ~LITFLAG_HLA;
	}
	
	bool get_litflag_ssc(literal_type lit) {
		return litflags_vector[lit] & LITFLAG_SSC;
	}
	void set_litflag_ssc(literal_type lit) {
		litflags_vector[lit] |= LITFLAG_SSC;
	}
	void clear_litflag_ssc(literal_type lit) {
		litflags_vector[lit] &= ~LITFLAG_SSC;
	}
	
	bool get_litflag_marked(literal_type lit) { return litflags_vector[lit] & LITFLAG_MARKED; }
	void set_litflag_marked(literal_type lit) { litflags_vector[lit] |= LITFLAG_MARKED; }
	void clear_litflag_marked(literal_type lit) { litflags_vector[lit] &= ~LITFLAG_MARKED; }

	bool get_litflag_big_removed(literal_type lit) { return litflags_vector[lit] & LITFLAG_BIG_REMOVED; }
	void set_litflag_big_removed(literal_type lit) { litflags_vector[lit] |= LITFLAG_BIG_REMOVED; }
	void clear_litflag_big_removed(literal_type lit) { litflags_vector[lit] &= ~LITFLAG_BIG_REMOVED; }
	
	bool get_litflag_watch_removed(literal_type lit) { return litflags_vector[lit] & LITFLAG_WATCH_REMOVED; }
	void set_litflag_watch_removed(literal_type lit) { litflags_vector[lit] |= LITFLAG_WATCH_REMOVED; }
	void clear_litflag_watch_removed(literal_type lit) { litflags_vector[lit] &= ~LITFLAG_WATCH_REMOVED; }
	
	bool get_litflag_occur_removed(literal_type lit) { return litflags_vector[lit] & LITFLAG_OCCUR_REMOVED; }
	void set_litflag_occur_removed(literal_type lit) { litflags_vector[lit] |= LITFLAG_OCCUR_REMOVED; }
	void clear_litflag_occur_removed(literal_type lit) { litflags_vector[lit] &= ~LITFLAG_OCCUR_REMOVED; }

	/* ------- occurrence list related functions ------- */
	void occur_insert(literal_type literal, clause_type clause) {
		p_occlists[literal].insert(clause);
	}
	void occur_clear(literal_type literal) {
		p_occlists[literal].clear();
	}
	void occur_shrink(literal_type literal) {
		p_occlists[literal].shrink();
	}
	void occur_erase(literal_type literal, occur_iterator iterator) {
		p_occlists[literal].erase(iterator);
	}
	void occur_cutoff(literal_type literal, occur_iterator iterator) {
		p_occlists[literal].cutoff(iterator);
	}
	unsigned int occur_size(literal_type literal) {
		return p_occlists[literal].size();
	}
	occur_iterator occur_begin(literal_type literal) {
		return p_occlists[literal].begin();
	}
	occur_iterator occur_end(literal_type literal) {
		return p_occlists[literal].end();
	}

	/* ---------- watch related functions ----------- */
	unsigned int watch_size(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		return watch_list.size();
	}
	watch_iterator watch_begin(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		return watch_list.begin();
	}
	watch_iterator watch_end(literal_type literal) {
		watchlist_type &watch_list = p_watchlists[literal];
		return watch_list.end();
	}
	void watch_cutoff(literal_type literal, watch_iterator it) {
		watchlist_type &watch_list = p_watchlists[literal];
		watch_list.cutoff(it);
	}
	void watch_erase(literal_type literal, watch_iterator it) {
		watchlist_type &watch_list = p_watchlists[literal];
		watch_list.erase(it);
	}

	template<typename Visitor>
	void watchlist_visit(literal_type literal, Visitor &visitor) {
		watchlist_type &watchlist = p_watchlists[literal];
//		std::cout << "Size of watch list (gen): " << watchlist.size() << std::endl;

		typename watchlist_type::iterator j = watchlist.begin();
		for(typename watchlist_type::iterator it = watchlist.begin();
				it != watchlist.end(); ++it) {
			/* make a copy of the watch list entry
				as the visitor is allowed to change it */
			watchlist_entry entry = *it;
			if(visitor(literal, entry)) {
				*j = entry;
				++j;
			}
		}
		watchlist.cutoff(j);
	}

	/* ------------ binary implication graph related -------------- */	
	unsigned int big_overall_size() {
		return big_edges;
	}
	unsigned int big_size(literal_type literal) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		return watch_list.size();
	}
	void big_insert(literal_type literal, bt_watch_entry_type entry) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		big_edges++;
		watch_list.insert(entry);
	}
	bt_watch_iterator big_begin(literal_type literal) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		return watch_list.begin();
	}
	bt_watch_iterator big_end(literal_type literal) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		return watch_list.end();
	}
	void big_erase(literal_type literal, bt_watch_iterator iterator) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		big_edges--;
		watch_list.erase(iterator);
	}
	void big_cutoff(literal_type literal, bt_watch_iterator iterator) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		big_edges -= watch_list.end() - iterator;
		watch_list.cutoff(iterator);
	}
	void big_clear(literal_type literal) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		watch_list.clear();
	}
	
	unsigned int bt_watch_size(literal_type literal) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		return watch_list.size();
	}
	void bt_watch_insert(literal_type literal, bt_watch_entry_type entry) {
		bt_watch_list_type &watch_list = bt_watch_vector[literal];
		watch_list.insert(entry);
	}

	/* equivalent variable management */
	literal_type equiv_root(literal_type literal) {
		literal_type root = literal;
		while(unionfind_vector[root].parent != root)
			root = unionfind_vector[root].parent;
		/* path compression */
		literal_type current = literal;
		while(unionfind_vector[current].parent != root) {
			literal_type parent = unionfind_vector[current].parent;
			unionfind_vector[current].parent = root;
			current = parent;
		}
		return root;
	}
	void equiv_union(literal_type literal1, literal_type literal2) {
		/* NOTE: no union-by-size for now.
			the literal with smaller index becomes root.
			this makes sure the root of l and l_inverse are
			always inverse of each other. */
		literal_type root1 = equiv_root(literal1);
		literal_type root2 = equiv_root(literal2);
		if(root1 < root2) {
			unionfind_vector[root2].parent = root1;
		}else unionfind_vector[root1].parent = root2;
	}

private:
	unsigned int p_present_count;
	unsigned int big_edges;
	
	/* per variable configuration */
	assign_vector p_assigns;
	flags_vector_type varflags_vector;
	declevel_vector declevels;
	antecedent_vector_type antecedents;
	heap_vector_type heap_infos;
	
	/* per literal configuration */
	flags_vector_type litflags_vector;
	occlist_vector p_occlists; /* per literal */
	watchlist_vector p_watchlists; /* per literal */
	bt_watch_vector_type bt_watch_vector; /* per literal */
	unionfind_vector_type unionfind_vector;
};

template<typename Config>
bool is_one(typename Config::index_type literal) {
	return literal & 1;
//	return literal % 2 == 1;
}

template<typename Config>
typename Config::index_type get_zero(typename Config::index_type var) {
	return 2 * var;
}

template<typename Config>
typename Config::index_type get_one(typename Config::index_type var) {
	return 2 * var + 1;
}

template<typename Config>
typename Config::index_type get_var(typename Config::index_type lit) {
	return lit >> 1;
//	if(lit % 2 == 1)
//		return (lit - 1) / 2;
//	return lit / 2;
}

template<typename Config>
typename Config::literal_type get_inverse(typename Config::index_type lit) {
	return lit ^ 1;
//	if(lit % 2 == 1)
//		return lit - 1;
//	return lit + 1;
}

}}}; /* namespace problem::sat::vars */

