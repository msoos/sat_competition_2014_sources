
template<typename BaseDefs>
struct antecedent_struct {
	static const uint32_t kTypeNone = 0;
	static const uint32_t kTypeDecision = 1;
	static const uint32_t kTypeClause = 2;
	static const uint32_t kTypeBinary = 3;
	uint32_t type;
	union {
		uint32_t padding;
		typename BaseDefs::ClauseId clause_ident;
		typename BaseDefs::LiteralId binary_ident;
	} identifier;

	static antecedent_struct<BaseDefs> make_none() {
		antecedent_struct<BaseDefs> antecedent;
		antecedent.type = kTypeNone;
		antecedent.identifier.padding = 0;
		return antecedent;
	}
	static antecedent_struct<BaseDefs> make_decision() {
		antecedent_struct<BaseDefs> antecedent;
		antecedent.type = kTypeDecision;
		antecedent.identifier.padding = 0;
		return antecedent;
	}
	static antecedent_struct<BaseDefs> make_clause
			(typename BaseDefs::ClauseId clause) {
		antecedent_struct<BaseDefs> antecedent;
		antecedent.type = kTypeClause;
		antecedent.identifier.clause_ident = clause;
		return antecedent;
	}
	static antecedent_struct<BaseDefs> make_binary
			(typename BaseDefs::LiteralId literal) {
		antecedent_struct<BaseDefs> antecedent;
		antecedent.type = kTypeBinary;
		antecedent.identifier.binary_ident = literal;
		return antecedent;
	}

	bool operator== (antecedent_struct<BaseDefs> other) {
		if(type != other.type)
			return false;
		if(identifier.padding != other.identifier.padding)
			return false;
		return true;
	}
	bool operator!= (antecedent_struct<BaseDefs> other) {
		return !(*this == other);
	}

	bool is_decision() {
		return type == kTypeDecision;
	}
	bool is_clause() {
		return type == kTypeClause;
	}
	bool is_binary() {
		return type == kTypeBinary;
	}

	typename BaseDefs::ClauseId get_clause() {
		return identifier.clause_ident;
	}
	typename BaseDefs::LiteralId get_binary() {
		return identifier.binary_ident;
	}
};

template<typename BaseDefs>
struct conflict_struct {
	static const uint32_t kTypeNone = 0;
	static const uint32_t kTypeClause = 1;
	static const uint32_t kTypeBinary = 2;
	static const uint32_t kTypeFact = 3;
	uint32_t type;
	union {
		struct {
			uint32_t p1;
			uint32_t p2;
		} padding;
		typename BaseDefs::ClauseId clause;
		struct {
			typename BaseDefs::LiteralId l1;
			typename BaseDefs::LiteralId l2;
		} literals;
	};

	static conflict_struct<BaseDefs> make_none() {
		conflict_struct<BaseDefs> result;
		result.type = kTypeNone;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		return result;
	}
	static conflict_struct<BaseDefs> make_clause
			(typename BaseDefs::ClauseId clause) {
		conflict_struct<BaseDefs> result;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		result.type = kTypeClause;
		result.clause = clause;
		return result;
	}
	static conflict_struct<BaseDefs> make_binary
			(typename BaseDefs::LiteralId literal1,
			typename BaseDefs::LiteralId literal2) {
		conflict_struct<BaseDefs> result;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		result.type = kTypeBinary;
		result.literals.l1 = literal1;
		result.literals.l2 = literal2;
		return result;
	}
	static conflict_struct<BaseDefs> make_fact
			(typename BaseDefs::LiteralId literal) {
		conflict_struct<BaseDefs> result;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		result.type = kTypeFact;
		result.literals.l1 = literal;
		return result;
	}
	template<typename Hooks>
	static conflict_struct<BaseDefs> from_antecedent(Hooks &hooks,
			typename BaseDefs::LiteralId literal,
			antecedent_struct<BaseDefs> antecedent) {
		if(antecedent.is_binary()) {
			auto implied = antecedent.get_binary();
			return make_binary(literal, hooks.litInverse(implied));
		}else if(antecedent.is_clause()) {
			auto clause = antecedent.get_clause();
			return make_clause(clause);
		}else SYS_CRITICAL("Cannot convert antecedent to conflict\n");
	}

	bool operator== (antecedent_struct<BaseDefs> other) {
		if(type != other.type)
			return false;
		if(padding != other.padding)
			return false;
		return true;
	}
	bool operator!= (antecedent_struct<BaseDefs> other) {
		return !(*this == other);
	}

	bool is_none() {
		return type == kTypeNone;
	}
	bool is_clause() {
		return type == kTypeClause;
	}
	bool is_binary() {
		return type == kTypeBinary;
	}
	bool is_fact() {
		return type == kTypeFact;
	}

	typename BaseDefs::ClauseId get_clause() {
		return clause;
	}
	typename BaseDefs::LiteralId get_literal1() {
		return literals.l1;
	}
	typename BaseDefs::LiteralId get_literal2() {
		return literals.l2;
	}
};

template<typename BaseDefs>
class SolutionDesc {
public:
	enum Type {
		kTypeNone,
		kTypeUnsatisfiable,
		kTypeFailedAssumption,
	};

	static SolutionDesc<BaseDefs> makeNone() {
		SolutionDesc<BaseDefs> res;
		res.p_type = kTypeNone;
		return res;
	}
	static SolutionDesc<BaseDefs> makeUnsatisfiable() {
		SolutionDesc<BaseDefs> res;
		res.p_type = kTypeUnsatisfiable;
		return res;
	}
	static SolutionDesc<BaseDefs> makeFailedAssumption() {
		SolutionDesc<BaseDefs> res;
		res.p_type = kTypeFailedAssumption;
		return res;
	}

	bool isNone() { return p_type == kTypeNone; }
	bool isUnsatisfiable() { return p_type == kTypeUnsatisfiable; }
	bool isFailedAssumption() { return p_type == kTypeFailedAssumption; }

private:
	Type p_type;
};

template<typename Config>
class cause_iterator_struct {
public:
	cause_iterator_struct(Config &config,
			typename Config::antecedent_type antecedent,
			typename Config::litindex_type index)
			: p_config(config), p_antecedent(antecedent), p_index(index) { }

	static cause_iterator_struct begin(Config &config,
			typename Config::antecedent_type antecedent) {
		return cause_iterator_struct(config, antecedent, 0);
	}
	static cause_iterator_struct end(Config &config,
			typename Config::antecedent_type antecedent) {
		if(antecedent.is_binary()) {
			return cause_iterator_struct(config, antecedent, 1);
		}else if(antecedent.is_clause()) {
			typename Config::clause_type clause = antecedent.get_clause();
			return cause_iterator_struct(config, antecedent,
					config.clauseLength(clause) - 1);
		}else if(antecedent.is_decision()) {
			SYS_CRITICAL("Decision antecedent\n");
		}else SYS_CRITICAL("Illegal antecedent\n");
	}

	void operator++ () {
		++p_index;
	}
	bool operator== (const cause_iterator_struct<Config> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const cause_iterator_struct<Config> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type operator* () {
		if(p_antecedent.is_binary()) {
			SYS_ASSERT(SYS_ASRT_GENERAL, p_index == 0);
			return p_antecedent.get_binary();
		}else if(p_antecedent.is_clause()) {
			typename Config::clause_type clause = p_antecedent.get_clause();
			return p_config.litInverse(p_config.clause_get(clause, p_index + 1));
		}else SYS_CRITICAL("Illegal antecedent\n");
	}
	
private:
	Config &p_config;
	typename Config::antecedent_type p_antecedent;
	typename Config::litindex_type p_index;
};

template<typename Config>
class conflict_iterator_struct {
public:
	conflict_iterator_struct(Config &config,
			typename Config::conflict_type conflict,
			typename Config::litindex_type index)
			: p_config(config), p_conflict(conflict), p_index(index) { }

	static conflict_iterator_struct begin(Config &config,
			typename Config::conflict_type conflict) {
		return conflict_iterator_struct(config, conflict, 0);
	}
	static conflict_iterator_struct end(Config &config,
			typename Config::conflict_type conflict) {
		if(conflict.is_fact()) {
			return conflict_iterator_struct(config, conflict, 1);
		}else if(conflict.is_binary()) {
			return conflict_iterator_struct(config, conflict, 2);
		}else if(conflict.is_clause()) {
			typename Config::clause_type clause = conflict.get_clause();
			return conflict_iterator_struct(config, conflict,
					config.clauseLength(clause));
		}else SYS_CRITICAL("Illegal conflict\n");
	}

	void operator++ () {
		++p_index;
	}
	bool operator== (const conflict_iterator_struct<Config> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const conflict_iterator_struct<Config> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type operator* () {
		if(p_conflict.is_fact()) {
			SYS_ASSERT(SYS_ASRT_GENERAL, p_index == 0);
			return p_conflict.get_literal1();
		}else if(p_conflict.is_binary() && p_index == 0) {
			return p_conflict.get_literal1();
		}else if(p_conflict.is_binary() && p_index == 1) {
			return p_conflict.get_literal2();
		}else if(p_conflict.is_clause()) {
			typename Config::clause_type clause = p_conflict.get_clause();
			return p_config.litInverse(p_config.clause_get(clause, p_index));
		}else SYS_CRITICAL("Illegal conflict\n");
	}
	
private:
	Config &p_config;
	typename Config::conflict_type p_conflict;
	typename Config::litindex_type p_index;
};

