
namespace problem {
namespace sat {
namespace lbd {

template<typename Hooks, int Limit>
int of_clause(Hooks &hooks, typename Hooks::clause_type clause) {
	hooks.lbd_init();
	for(auto i = hooks.clauseBegin(clause);
			i != hooks.clauseEnd(clause); ++i) {
		auto var = hooks.litVariable(*i);
		hooks.lbd_insert(hooks.varDeclevel(var));
	}
	for(auto i = hooks.clauseBegin(clause);
			i != hooks.clauseEnd(clause); ++i) {
		auto var = hooks.litVariable(*i);
		hooks.lbd_cleanup(hooks.varDeclevel(var));
	}
	return hooks.lbd_result();
}

}}};

