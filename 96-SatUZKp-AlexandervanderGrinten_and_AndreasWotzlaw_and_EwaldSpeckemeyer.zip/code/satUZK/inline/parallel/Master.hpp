
void *runSolverThread(void *ptr) {
	SolverThread *thread = (SolverThread*)ptr;
	thread->run();
	return nullptr;
}

void *runReducerThread(void *ptr) {
	ReducerThread *thread = (ReducerThread*)ptr;
	thread->run();
	return nullptr;
}

int Master::run() {
	std::ifstream stream(p_instance);
	CnfReadHooks read_hooks(*this);
	cnf_reader_struct<CnfReadHooks, std::ifstream> reader(read_hooks);
	reader.read(stream);

	std::cout << "Finished parsing" << std::endl;

	for(auto bc = p_solvers.begin(); bc != p_solvers.end(); ++bc) {
		(*bc)->writeCommand(SolverThread::CommandTag::kInitialize);
		(*bc)->sendCommand();
		
		(*bc)->writeCommand(SolverThread::CommandTag::kContinue);
		(*bc)->sendCommand();
	}

	int exit_code = 0;

	while(!globalExitFlag) {
		for(auto it = p_solvers.begin(); it != p_solvers.end(); ++it) {
			if((*it)->recvMessage()) {
				auto tag = (*it)->readMessage<SolverThread::MessageTag>();
				if(tag == SolverThread::MessageTag::kSolvedSat) {
					std::cout << "s SATISFIABLE" << std::endl;

					int num_vars = (*it)->readMessage<int>();
					for(int i = 0; i < num_vars; i++) {
						bool is_one = (*it)->readMessage<bool>();
						int literal_num = is_one ? (i + 1) : -(i + 1);
						p_model.push_back(literal_num);
					}

					globalExitFlag = true;
					exit_code = 10;
					break;
				}else if(tag == SolverThread::MessageTag::kSolvedUnsat) {
					std::cout << "s UNSATISFIABLE" << std::endl;
					globalExitFlag = true;
					exit_code = 20;
					break;
				}else SYS_CRITICAL("Illegal solver message");
			}
		}
		if(!globalExitFlag)
			sleep(1);
	}

	for(auto bc = p_solvers.begin(); bc != p_solvers.end(); ++bc) {
		(*bc)->writeCommand(SolverThread::CommandTag::kExit);
		(*bc)->sendCommand();
	}
	for(auto bc = p_reducers.begin(); bc != p_reducers.end(); ++bc) {
		(*bc)->writeCommand(ReducerThread::CommandTag::kExit);
		(*bc)->sendCommand();
	}
	
	for(auto it = p_threads.begin(); it != p_threads.end(); ++it) {
		if(pthread_join(*it, NULL) != 0)
			throw std::runtime_error("pthread_join() failed");
	}
	
	for(auto it = p_solvers.begin(); it != p_solvers.end(); ++it)
		std::cout << "c (" << (*it)->getConfigId() << " ) exported: "
			<< (*it)->stat.exported << ", imported: " << (*it)->stat.imported << std::endl;

	for(auto it = p_solvers.begin(); it != p_solvers.end(); ++it)
		delete *it;
	for(auto it = p_reducers.begin(); it != p_reducers.end(); ++it)
		delete *it;
	return exit_code;
}

std::vector<int>::iterator Master::beginModel() {
	return p_model.begin();
}
std::vector<int>::iterator Master::endModel() {
	return p_model.end();
}

void Master::CnfReadHooks::on_problem(long num_vars, long num_clauses) {
	p_varCount = num_vars;

	if(num_clauses > 20L * 1000L * 1000L) {
		p_master.p_solvers.push_back(new SolverThread(1));
	}else{
		p_master.p_solvers.push_back(new SolverThread(1));
		p_master.p_solvers.push_back(new SolverThread(2));
		p_master.p_solvers.push_back(new SolverThread(3));
		p_master.p_solvers.push_back(new SolverThread(4));
		p_master.p_solvers.push_back(new SolverThread(5));
		p_master.p_solvers.push_back(new SolverThread(6));
		p_master.p_solvers.push_back(new SolverThread(7));
		p_master.p_solvers.push_back(new SolverThread(8));
		p_master.p_solvers.push_back(new SolverThread(9));
		p_master.p_solvers.push_back(new SolverThread(10));
		p_master.p_reducers.push_back(new ReducerThread(11));
		p_master.p_reducers.push_back(new ReducerThread(12));

		p_master.p_solvers[0]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[1]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[2]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[3]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[4]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[5]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[6]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[7]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[8]->linkReducer(*p_master.p_reducers[0]);
		p_master.p_solvers[9]->linkReducer(*p_master.p_reducers[0]);

		p_master.p_solvers[0]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[1]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[2]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[3]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[4]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[5]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[6]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[7]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[8]->linkReducer(*p_master.p_reducers[1]);
		p_master.p_solvers[9]->linkReducer(*p_master.p_reducers[1]);
	
		p_master.p_reducers[0]->linkSolver(*p_master.p_solvers[0]);
		p_master.p_reducers[0]->linkSolver(*p_master.p_solvers[1]);
		p_master.p_reducers[0]->linkSolver(*p_master.p_solvers[2]);
		p_master.p_reducers[0]->linkSolver(*p_master.p_solvers[3]);
		p_master.p_reducers[0]->linkSolver(*p_master.p_solvers[4]);

		p_master.p_reducers[1]->linkSolver(*p_master.p_solvers[5]);
		p_master.p_reducers[1]->linkSolver(*p_master.p_solvers[6]);
		p_master.p_reducers[1]->linkSolver(*p_master.p_solvers[7]);
		p_master.p_reducers[1]->linkSolver(*p_master.p_solvers[8]);
		p_master.p_reducers[1]->linkSolver(*p_master.p_solvers[9]);
	}
	
	for(auto it = p_master.p_solvers.begin(); it != p_master.p_solvers.end(); ++it) {
		pthread_t thread;
		if(pthread_create(&thread, NULL, runSolverThread, *it) != 0)
			throw std::runtime_error("pthread_create() failed");
		p_master.p_threads.push_back(thread);
	}
	for(auto it = p_master.p_reducers.begin(); it != p_master.p_reducers.end(); ++it) {
		pthread_t thread;
		if(pthread_create(&thread, NULL, runReducerThread, *it) != 0)
			throw std::runtime_error("pthread_create() failed");
		p_master.p_threads.push_back(thread);
	}


	for(auto bc = p_master.p_solvers.begin(); bc != p_master.p_solvers.end(); ++bc) {
		(*bc)->writeCommand(SolverThread::CommandTag::kProblemDef);
		(*bc)->writeCommand<long>(num_vars);
		(*bc)->sendCommand();
	}

	for(auto bc = p_master.p_reducers.begin(); bc != p_master.p_reducers.end(); ++bc) {
		(*bc)->writeCommand(ReducerThread::CommandTag::kProblemDef);
		(*bc)->writeCommand<long>(num_vars);
		(*bc)->sendCommand();
	}
}

void Master::CnfReadHooks::on_clause(std::vector<long> &in_clause) {
	// remove duplicates and check for tautologies
	// TODO: move this to the cnf reader
	auto k = in_clause.begin();
	for(auto i = in_clause.begin(); i != in_clause.end(); ++i) {
		bool duplicate = false;
		for(auto j = i + 1; j != in_clause.end(); ++j) {
			if(*j == *i) {
				duplicate = true;
			}else if(*j == -*i) {
				return;
			}
		}
		if(duplicate)
			continue;
		*k = *i;
		k++;
	}
	in_clause.resize(k - in_clause.begin());
	
	// transform input variable ids to internal variable ids
	std::vector<BaseDefs::LiteralId> out_clause;
	for(auto it = in_clause.begin(); it != in_clause.end(); ++it) {
		long input_variable = (*it) < 0 ? -(*it) : (*it);
		SYS_ASSERT(SYS_ASRT_GENERAL, input_variable <= p_varCount);
		
		BaseDefs::LiteralId intern_variable = input_variable - 1;
		BaseDefs::LiteralId intern_literal = (*it) < 0
				? 2 * intern_variable : 2 * intern_variable + 1;
		out_clause.push_back(intern_literal);
	}
	
	for(auto bc = p_master.p_solvers.begin(); bc != p_master.p_solvers.end(); ++bc) {
		(*bc)->writeCommand(SolverThread::CommandTag::kClause);
		(*bc)->writeCommand<int>(out_clause.size());
		for(auto cp = out_clause.begin(); cp != out_clause.end(); ++cp)
			(*bc)->writeCommand<BaseDefs::LiteralId>(*cp);
		(*bc)->sendCommand();
	}
	
	for(auto bc = p_master.p_reducers.begin(); bc != p_master.p_reducers.end(); ++bc) {
		(*bc)->writeCommand(ReducerThread::CommandTag::kClause);
		(*bc)->writeCommand<int>(out_clause.size());
		for(auto cp = out_clause.begin(); cp != out_clause.end(); ++cp)
			(*bc)->writeCommand<BaseDefs::LiteralId>(*cp);
		(*bc)->sendCommand();
	}
}

