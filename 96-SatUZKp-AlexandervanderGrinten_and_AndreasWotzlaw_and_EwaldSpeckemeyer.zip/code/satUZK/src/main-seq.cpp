
#include <unistd.h>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <cstring>
#include <csignal>
#include <cassert>

#include "../inline/sys/debug.hpp"
#include "../inline/sys/Reporter.hpp"
#include "../inline/util/performance.hpp"
#include "../inline/util/shuffle.hpp"
#include "../inline/util/memory/bulk_alloc.hpp"
#include "../inline/util/heaps/binary.hpp"
#include "../inline/util/chunk_list.hpp"
#include "../inline/util/vectors/simple.hpp"
#include "../inline/algorithms/prop.hpp"
#include "../inline/algorithms/lbd.hpp"
#include "../inline/algorithms/first_uip.hpp"
#include "../inline/algorithms/search.hpp"
#include "../inline/algorithms/lookahead.hpp"
#include "../inline/datastructs/misc_structs.hpp"
#include "../inline/datastructs/vars.hpp"
#include "../inline/datastructs/packed_clause.hpp"
#include "../inline/datastructs/ext_model.hpp"
#include "../inline/datastructs/utils.hpp"
//#include "../inline/simplify/simp_equiv.hpp"
//#include "../inline/simplify/simp_vecd.hpp"
//#include "../inline/simplify/simp_bce.hpp"
//#include "../inline/simplify/simp_brm.hpp"
//#include "../inline/simplify/simp_ssub.hpp"
//#include "../inline/simplify/simp_dist.hpp"
//#include "../inline/simplify/simp_unhiding.hpp"
#include "../inline/io/dimacs2.hpp"
//#include "../inline/preproc.hpp"
//#include "../inline/inproc.hpp"
#include "../include/Config.hpp"
#include "../inline/config.hpp"

#ifdef FEATURE_GOOGLE_PROFILE
#include <google/profiler.h>
#endif

struct BaseDefs {
	typedef uint32_t LiteralId;
	typedef uint32_t ClauseId;
	typedef uint32_t ClauseLitIndex;
	typedef uint32_t Order;
	typedef double Activity;
	typedef uint32_t DecLevel;
};

struct OurHooks {
	void onLearnedClause(BaseDefs::ClauseId clause) { }
};

typedef satuzk::Config<BaseDefs, OurHooks> OurConfig;

template<typename Config>
class CnfReadHooks {
public:
	CnfReadHooks(Config &config) : p_config(config) { }
	
	void on_problem(long num_vars, long num_clauses) {
		p_config.varReserve(num_vars);
		for(long i = 0; i < num_vars; ++i)	
			p_config.varAlloc();
		p_varCount = num_vars;
		std::cout << "c var memory: " << sys_peak_memory() << " kb" << std::endl;
	}

	void on_clause(std::vector<long> &in_clause) {
		// transform input variable ids to internal variable ids
		std::vector<typename BaseDefs::LiteralId> out_clause;
		for(auto it = in_clause.begin(); it != in_clause.end(); ++it) {
			long input_variable = (*it) < 0 ? -(*it) : (*it);
			SYS_ASSERT(SYS_ASRT_GENERAL, input_variable <= p_varCount);
			
			BaseDefs::LiteralId intern_variable = internVariable(input_variable);
			BaseDefs::LiteralId intern_literal = (*it) < 0
					? p_config.zeroLiteral(intern_variable)
					: p_config.oneLiteral(intern_variable);
			out_clause.push_back(intern_literal);
		}
		
		// permutate the input clause
		if(p_config.opts.general.permutate_input)
			util::shuffle(out_clause.begin(), out_clause.end(),
					p_config.p_rndEngine);
		
		p_config.inputClause(out_clause.size(),
				out_clause.begin(), out_clause.end());
	}

	int numVariables() { return p_varCount; }
	BaseDefs::LiteralId internVariable(int input_variable) { return input_variable - 1; }

private:
	long p_varCount;
	Config &p_config;
};

OurConfig *the_config = new OurConfig(OurHooks(), 1);

void onInterrupt(int sig) {
	std::cout << "c signal: ";
	switch(sig) {
	case SIGINT: std::cout << "SIGINT"; break;
	case SIGXCPU: std::cout << "SIGXCPU"; break;
	default: std::cout << sig;
	}
	std::cout << std::endl;
	the_config->state.general.stop_solve = true;
}

int main(int argc, char **argv) {
	OurConfig &config = *the_config;
	config.opts.general.verbose = 1;

	if(signal(SIGINT, onInterrupt) == SIG_ERR
			|| signal(SIGXCPU, onInterrupt) == SIG_ERR)
		throw std::runtime_error("Could not install signal handler");

	/* parse the parameters given to the solver */
	std::vector<std::string> args;
	for(int i = 1; i < argc; ++i)
		args.push_back(std::string(argv[i]));

	bool show_model = false;

	std::string instance;
	std::string model_file;
	for(auto i = args.begin(); i != args.end(); /* no increment here */) {
		if(*i == "-v") {
			config.opts.general.verbose = 3;
			++i;
		}else if(*i == "-budget") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -budget" << std::endl;
				return 0;
			}
			config.opts.general.budget = std::atoi((*i).c_str())
					* 1000LL * 1000LL * 1000LL;
			++i;
		}else if(*i == "-timeout") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -timeout" << std::endl;
				return 0;
			}
			config.opts.general.budget = std::atoi((*i).c_str())
					* 1000LL * 1000LL * 1000LL;
			config.opts.general.timeout = std::atoi((*i).c_str())
					* 1000LL * 1000LL * 1000LL;
			++i;
		}else if(*i == "-seed") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -seed" << std::endl;
				return 0;
			}
			config.seedRandomEngine(std::atoi((*i).c_str()));
			++i;
		}else if(*i == "-permutate-input") {
			config.opts.general.permutate_input = true;
			++i;
		}else if(*i == "-preproc-iterative") {
			config.opts.preproc.model = OurConfig::kPreprocIterative;
			++i;
		}else if(*i == "-preproc-adaptive") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			++i;
		}else if(*i == "-preproc-iterations") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -preproc-iterations" << std::endl;
				return 0;
			}
			config.opts.preproc.iterations = std::atoi((*i).c_str());
			++i;
		}else if(*i == "-preproc-model1") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model2") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = false;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model3") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model4") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = false;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model5") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = false;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model6") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = false;
			config.opts.preproc.with_bce = false;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = true;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model7") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = true;
			config.opts.preproc.with_unhiding = true;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-preproc-model8") {
			config.opts.preproc.model = OurConfig::kPreprocAdaptive;
			config.opts.preproc.with_vecd = true;
			config.opts.preproc.with_bce = true;
			config.opts.preproc.with_selfsub = false;
			config.opts.preproc.with_unhiding = true;
			config.opts.preproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-adaptive") {
			config.opts.inproc.model = OurConfig::kInprocAdaptive;
			++i;
		}else if(*i == "-inproc-model1") {
			config.opts.inproc.model = OurConfig::kInprocAdaptive;
			config.opts.inproc.with_dist = false;
			config.opts.inproc.with_unhiding = true;
			config.opts.inproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-model2") {
			config.opts.inproc.model = OurConfig::kInprocAdaptive;
			config.opts.inproc.with_dist = true;
			config.opts.inproc.with_unhiding = false;
			config.opts.inproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-model3") {
			config.opts.inproc.model = OurConfig::kInprocAdaptive;
			config.opts.inproc.with_dist = true;
			config.opts.inproc.with_unhiding = true;
			config.opts.inproc.with_brm = false;
			++i;
		}else if(*i == "-inproc-model4") {
			config.opts.inproc.model = OurConfig::kInprocAdaptive;
			config.opts.inproc.with_dist = false;
			config.opts.inproc.with_unhiding = false;
			config.opts.inproc.with_brm = true;
			++i;
		}else if(*i == "-learn-bump-glue-twice") {
			config.opts.learn.bumpGlueTwice = true;
			++i;
		}else if(*i == "-learn-minimize-glucose") {
			config.opts.learn.minimizeGlucose = true;
			++i;
		}else if(*i == "-clause-red-agile") {
			config.opts.clauseRed.model = OurConfig::kClauseRedAgile;
			++i;
		}else if(*i == "-restart-glucose") {
			config.opts.restart.strategy = OurConfig::kRestartGlucose;
			++i;
		}else if(*i == "-show-model") {
			show_model = true;
			++i;
		}else if(*i == "-save-model") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for -save_model" << std::endl;
				return 0;
			}
			model_file = *i;
			++i;
		}else if(*i == "-drat-proof") {
			config.opts.general.outputDratProof = true;
			++i;
		}else if((*i).at(0) == '-') {
			std::cout << "Illegal command line parameter '" << (*i) << "'" << std::endl;
			return 0;
		}else{
			/* the last parameter is always the instance name */
			instance = *i;
			++i;
			if(i != args.end()) {
				std::cout << "Unexpected parameter '" << *i
						<< "' after instance name" << std::endl;
				return 0;
			}
		}
	}

	std::cout << "c sizeof(assign_type): " << sizeof(OurConfig::var_config_type::assign_type) << std::endl;
//	std::cout << "c sizeof(watchlist_entry): " << sizeof(OurConfig::var_config_type::watchlist_entry) << std::endl;
//	std::cout << "c sizeof(clause_head_type): " << sizeof(OurConfig::clause_head_type) << std::endl;

	SYS_ASSERT(SYS_ASRT_GENERAL, instance.length() > 0);
	std::ifstream stream(instance);

#ifdef FEATURE_GOOGLE_PROFILE
	char profile[256];
	sprintf(profile, "%d.profile", getpid());
	printf("Writing profile %s\n", profile);
	ProfilerStart(profile);
#endif

	CnfReadHooks<OurConfig> read_hooks(config);
	cnf_reader_struct<decltype(read_hooks), std::ifstream> reader(read_hooks);
	reader.read(stream);
	config.inputFinish();

	std::cout << "c parse time: " << sysGetCpuTime() << " ms" << std::endl;
	std::cout << "c parse memory: " << sys_peak_memory() << " kb" << std::endl;

	satuzk::SolveState result = satuzk::solveStep(config);

	if(model_file.length() > 0) {
		std::fstream model_stream(model_file,
				std::fstream::out | std::fstream::trunc);
		if(result == satuzk::kStateSatisfied) {
			model_stream << "SAT\n";
			
			problem::sat::extmodel::build_model(config,
					config.extmodel_config, config.extmodel_alloc);
			
			for(long i = 1; i <= read_hooks.numVariables(); ++i) {
				auto intern_variable = read_hooks.internVariable(i);
				if(i != 1)
					model_stream << " ";
				/* TODO: don't include non-assigned variables? */
				if(config.model_get_literal(config.oneLiteral(intern_variable))) {
					model_stream << i;
				}else model_stream << -i;
			}
			model_stream << " 0\n";
		}else if(result == satuzk::kStateUnsatisfiable) {
			model_stream << "UNSAT\n";
		}else model_stream << "INDET\n";
		model_stream.close();
	}else{
		if(result == satuzk::kStateSatisfied) {
			std::cout << "s SATISFIABLE" << std::endl;

			problem::sat::extmodel::build_model(config,
					config.extmodel_config, config.extmodel_alloc);		
			
			if(show_model) {
				std::cout << "v";
				for(long i = 1; i <= read_hooks.numVariables(); ++i) {
					auto intern_variable = read_hooks.internVariable(i);
					/* TODO: don't include non-assigned variables? */
					if(config.model_get_literal(config.oneLiteral(intern_variable))) {
						std::cout << " " << i;
					}else std::cout << " " << -i;
				}
				std::cout << " 0" << std::endl;
			}
		}else if(result == satuzk::kStateUnsatisfiable) {
			std::cout << "s UNSATISFIABLE" << std::endl;
		}else if(result == satuzk::kStateAssumptionFail) {
			std::cout << "s ASSUMPTIONFAIL" << std::endl;
		}else std::cout << "s UNKNOWN" << std::endl;
	}

#ifdef FEATURE_GOOGLE_PROFILE
	ProfilerStop();	
#endif

	unsigned int secs = sysGetCpuTime() / 1000;

	std::cout << std::setprecision(2);
	std::cout << "c ------ statistics: general ------" << std::endl;
	std::cout << "c cpu time: " << secs << " secs" << std::endl;
	std::cout << "c peak memory: " << sys_peak_memory() << " kb" << std::endl;
	std::cout << "c    [      ] clause reallocations: " << config.stat.general.clauseReallocs
		<< ", collections: " << config.stat.general.clauseCollects << std::endl;

	std::cout << "c ------ search ------" << std::endl;
	std::cout << "c    conflicts: " << config.conflictNum;
	if(secs != 0)
		std::cout << ", conflicts/sec: " << (config.conflictNum / secs);
	std::cout << std::endl;
	std::cout << "c    propagations: " << config.stat.search.propagations;
	if(secs != 0)
		std::cout << ", propagations/sec: " << (config.stat.search.propagations / secs);
	std::cout << std::endl;
	std::cout << "c    deleted clauses: " << config.stat.general.deletedClauses << std::endl;
	std::cout << "c    restarts: " << config.stat.search.restarts << std::endl;
	std::cout << "c    learned units: " << config.stat.search.learnedUnits << ", binary: " << config.stat.search.learnedBinary << std::endl;
	std::cout << "c    minimized literals: " << config.stat.search.minimizedLits
			<< " of " << config.stat.search.learnedLits << ", " << (100.0f - config.stat.search.minimizedLits * 100.0f
			/ config.stat.search.learnedLits) << "% redundant" << std::endl;
	std::cout << "c    facts removed: clauses: " << config.stat.search.factElimClauses
			<< ", literals: " << config.stat.search.factElimLiterals
			<< ", runs: " << config.stat.search.factElimRuns << std::endl;
	std::cout << "c    clause reductions: " << config.stat.clauseRed.reductionRuns
		<< ", deletions: " << (100.0f * config.stat.clauseRed.clauseDeletions
			/ config.stat.clauseRed.clausesConsidered) << "%"
		<< ", freezes: " << (100.0f * config.stat.clauseRed.clauseFreezes
			/ config.stat.clauseRed.clausesConsidered) << "%"
		<< ", unfreezes: " << (100.0f * config.stat.clauseRed.clauseUnfreezes
			/ config.stat.clauseRed.clausesConsidered) << "%"
		<< ", active: " << (100.0f * config.stat.clauseRed.clausesActive
			/ (config.stat.clauseRed.clausesActive + config.stat.clauseRed.clausesNotActive)) << "%"
		<< ", learnts limit: " << config.state.clauseRed.geomSizeLimit << std::endl;
	
	std::cout << "c ------ simplification ------" << std::endl;
	std::cout << "c    [VECD  ]  vars eliminated: " << config.stat.simp.vecdEliminated
			<< ", facts discovered: " << config.stat.simp.vecdFacts << std::endl;
	std::cout << "c    [SCC   ]  vars eliminated: " << config.stat.simp.scc_variables << std::endl;
	std::cout << "c    [BRM   ]  failed literals: " << config.stat.simp.brm_failed
		<< ", equivalent literals: " << config.stat.simp.brm_equivalent
		<< ", independent literals: " << config.stat.simp.brm_independent << std::endl;
	std::cout << "c    [SUB   ]  clauses removed: " << config.stat.simp.subsumed_clauses << std::endl;
	std::cout << "c    [SSUB  ]  shortcut checks: " << config.stat.simp.selfsub_shortcuts
		<< ", subsumption: " << config.stat.simp.selfsub_subchecks
		<< ", resolution: " << config.stat.simp.selfsub_reschecks << std::endl;
	std::cout << "c    [SSUB  ]  clauses shortened: " << config.stat.simp.selfsub_clauses
		<< ", facts discovered: " << config.stat.simp.selfsub_facts << std::endl;
	std::cout << "c    [BCE   ]  blocked clauses: " << config.stat.simp.bceEliminated << std::endl;
	std::cout << "c    [DIST  ]  checks: " << config.stat.simp.dist_checks
		<< ", conflicts: " << config.stat.simp.dist_conflicts
		<< " (removed " << config.stat.simp.dist_conflicts_removed << " lits)"
		<< ", asserts: " << config.stat.simp.dist_asserts
		<< " (removed " << config.stat.simp.dist_asserts_removed << " lits)"
		<< ", ssubs: " << config.stat.simp.dist_ssubs
		<< " (removed " << config.stat.simp.dist_ssubs_removed << " lits)" << std::endl;
	std::cout << "c    [UNHIDE]  transitive edges: " << config.stat.simp.unhide_transitive
		<< ", failed literals: " << config.stat.simp.unhide_failed
		<< ", hidden literals: " << config.stat.simp.unhide_hle
		<< ", hidden tautologies: " << config.stat.simp.unhide_hte << std::endl;
	
	std::cout << "c    [SAVED ]  space used for saved infos: "
			<< (config.extmodel_alloc.get_offset() / 1024) << " kb" << std::endl;

	std::cout << "c ------ time ------" << std::endl;
	std::cout << "c    [      ]  inprocessing: "
			<< (config.perf.inproc_time / (1000 * 1000)) << " ms" << std::endl;
	std::cout << "c    [      ]  preprocessing: "
			<< (config.perf.preproc_time / (1000 * 1000)) << " ms" << std::endl;
	std::cout << "c    [SEARCH]  fact elimination: "
			<< (config.perf.fact_elim_time / (1000 * 1000)) << " ms" << std::endl;

	delete the_config;

	if(result == satuzk::kStateSatisfied) {
		return 10;
	}else if(result == satuzk::kStateUnsatisfiable) {
		return 20;
	}
	return 0;
}

