#!/bin/sh

# remove binary directory
rm -rf binary

#clean probSAT
cd code/probSAT
make clean

# return to calling directory
cd ..
