#!/bin/sh
cd code/probSAT
make
cd ../../
rm -rf binary
mkdir binary

cp code/scripts/pprobSAT.py binary/
cp code/probSAT/probSAT binary/
echo "build done"