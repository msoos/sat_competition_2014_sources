----------------------------------------------------------
pprobSAT v sc14 
Authors: Adrian Balint
Ulm University - Institute of Theoretical Computer Science 
2014
----------------------------------------------------------


Usage of pprobSAT:
python pprobSAT.py <DIMACS CNF instance> <seed> <numCores> <tmpdir>

numCores instances of probSAT are started
the last two instances use restarts after every 10⁷ respectively 10⁸ flips