# -*- coding: utf-8 -*-
# pprobSAT
# Adrian Balint, Uwe Schöning
#
# runs n instances of probSAT in parallel (script code based on code of Norbert Manthey 2014)
# the last two instances are stareted with maxflips=10^7 resp. 10^8
#


# used libraries
import os, signal, subprocess, time
import sys, shutil, random


probsatCallAndParams="./probSAT -a"
#
# usage and current PID
#
print "c pprobSAT SC14"
print "c Adrian Balint, Uwe Schöning"
print "c runs n instances of probSAT in parallel"

if( len(sys.argv) < 4 ):
	print "c usage: ./pprobSAT.py <input.cnf> <seed> <numCores> [<tmpDirectory>]" #n is the number of instances to start
	sys.exit(0)
print "c running with PID " + str( os.getpid() )

#
# Handle parameters
#
# get input file
#
inputFile=sys.argv[1]
seed=int(sys.argv[2])
numCores=int(sys.argv[3])
if (numCores == 1):
	print "c does not make sense, please start probSAT directly"
	sys.exit(0)


#
# setup tmp files
#
tmpDir="/tmp/"
print "c found " + str(len(sys.argv)) + "parameters"
if(len(sys.argv)>4):
	tmpDir = sys.argv[4]
if( tmpDir[-1:] != '/' ):
	tmpDir = tmpDir + "/"

#construction of temporary files for output

# let user know that everything has been read correctly
print "c starting " + str(numCores) + " instances of probSAT with seed " + str(seed) + " on instance "+ str(inputFile) + " \nc writing temp files to  " + tmpDir

#
# start the two solvers, each in its private process group
#
random.seed(seed)
pids=set()
pidsseed=set()
seeds=set()

for i in range(0,max(numCores-2,2)): 
	seed=random.randint(0,2147483647)
	tmpFile=tmpDir + "probsat_"+str(seed)
	print "c starting instance " + str(i) + " of probSAT started with seed " + str(seed )
	print "c writing to files " + tmpFile +".out .err"
	
    # start probSAT
	probsatCallString= probsatCallAndParams + " " + inputFile + " " + str(seed) # add CNF file and tmp directory
	args = probsatCallString.split( )	# split the actual command line
	print "c calling probSAT with " + str(args)
	probsatProcess = subprocess.Popen(args, stdout=open(tmpFile + ".out","w"), stderr=open(tmpFile + ".err","w"), preexec_fn=os.setpgrp )
	pidsseed.add((probsatProcess.pid,seed))
	pids.add(probsatProcess.pid)
	seeds.add(seed)
	print "c started probSAT instance with PID" + str(probsatProcess.pid)

coresleft=numCores-max(numCores-2,2)
maxflips=10000000
for i in range(0,coresleft): 
	seed=random.randint(0,2147483647)
	tmpFile=tmpDir + "probsat_"+str(seed)
	print "c starting instance " + str(i) + " of probSAT started with seed " + str(seed )
	print "c writing to files " + tmpFile +".out .err"
	
    # start probSAT
	probsatCallString= probsatCallAndParams + " --maxflips " +str(maxflips) +" "+ inputFile + " " + str(seed) # add CNF file and tmp directory
	args = probsatCallString.split( )	# split the actual command line
	print "c calling probSAT with " + str(args)
	probsatProcess = subprocess.Popen(args, stdout=open(tmpFile + ".out","w"), stderr=open(tmpFile + ".err","w"), preexec_fn=os.setpgrp )
	pidsseed.add((probsatProcess.pid,seed))
	pids.add(probsatProcess.pid)
	seeds.add(seed)
	print "c started probSAT instance with PID" + str(probsatProcess.pid)
	maxflips=maxflips*10


#
# wait until the first solver returns
#
winner=""
winnerCode=0
while pids:
	pid,retval=os.wait()
	print "c finished " + str(pid) + " with return value " + str(retval)
	pids.remove(pid)
	# extract the exit code
	signal = retval & 255
	exitCode = (retval >> 8) & 255
	print "c signal: " + str(signal) + " exit code: " + str(exitCode)
	# if exit code is nice, select the winner
	winnerseed=-1
	if signal == 0 and (exitCode == 10 or exitCode == 20 ):
		winnerCode = exitCode				# get exit code
		for i in range(numCores): 
			proc=pidsseed.pop()
			if proc[0]==pid:
				winnerseed=proc[1]
				break												# do not wait for the other process as well, if a solution has been found!
	if winnerseed != -1:
		break

#
# output the result
#
if winnerseed != 0:
	print "c winner seed: " + str(winnerseed)
	tmpFile=tmpDir + "probsat_"+str(winnerseed)
	# for more recent python versions:
	#	with open(tmpFile + ".out", "r") as f:

	
	# for the competition 2014 version:
	f = open(tmpFile + ".out", "r")
	if f :
		shutil.copyfileobj(f, sys.stdout)

else:
	print "s UNKNOWN"
	

# kill the other process, and its child processes
for p in pids:
 	os.kill(-p, 15)
	
# clean up the temporary files
for i in range(numCores): 
	seed=seeds.pop()
	tmpFile=tmpDir + "probsat_"+str(seed)
	os.unlink(tmpFile + ".err")
	os.unlink(tmpFile + ".out")

# exit with the correct exit code
sys.exit(winnerCode)
