#!/bin/bash

mkdir binary

cd code/simp
make r
cp glue_lgl_split_release ../../binary/glue_lgl_split

 
