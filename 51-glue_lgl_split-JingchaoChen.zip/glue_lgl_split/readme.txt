Solver name : glue_lgl_split
Solver version : 1.0
Authors : Jingchao Chen


For compiling : 
   ./build.sh

For running 
glue_lgl_split BENCHNAME
