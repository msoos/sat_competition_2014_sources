#!/bin/sh
    
 mkdir binary
 cd code
 gcc sattime2014r-sc14.c -O3 -static -o sattime2014r
 mv sattime2014r ../binary


