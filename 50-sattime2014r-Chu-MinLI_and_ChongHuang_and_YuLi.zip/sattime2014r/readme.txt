This is the SLS SAT solver sattime2014r submitted to the satcompetition
2014, by Chu Min LI and Yu LI.
To build the executable, type build.sh or 
gcc sattime2014r.c -O3 -static -o sattime2014r in the code subdirectory

to call the solver, type

sattime2014r INSTANCE -seed SEED -nbsol 1
