#!/bin/sh
# Norbert Manthey, 2014
#
# script to clean the SAT solver Riss
#

# remove binary directory
rm -rf binary

# clean Pcasso
cd code/Riss427;
make clean

# clean Sparrow
cd ../Sparrow
make clean

# return to calling directory
cd ..
