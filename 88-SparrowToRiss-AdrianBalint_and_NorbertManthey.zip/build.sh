#!/bin/sh
# Norbert Manthey, 2014
#
# script to build the SAT solver CLaS
#

# setup binary directory
rm -rf binary
mkdir -p binary

cd code/Riss427;
# build Pcasso
make rissRS ARGS="-DTOOLVERSION=427 -DDRATPROOF"
cp riss ../../binary/rissDRAT

# build Coprocessor
make clean
make coprocessorRS ARGS="-DTOOLVERSION=427 -DDRATPROOF"
cp coprocessor ../../binary/

# build sparrow
cd ../Sparrow
make sparrow
cp sparrow ../../binary

# copy the call script
cd ..
cp scripts/SparrowToRiss.sh ../binary

# return to calling directory
cd ..
