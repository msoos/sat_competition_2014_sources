============================_
==== MiniSat_HACK_1430ED ====
============================

Chanseok Oh (chanseok@cs.nyu.edu)
New York University
NY, USA


EDIT DISTANCE (http://www.satcompetition.org/2014/description.shtml)
-------------
Difference of 1430 characters from the original (DRUP-patched) MiniSat 2.2.0.

Total distance: 1430



HOW TO BUILD
------------
To build, `cd' into where `build.sh' is located.

   $ ./build.sh

This will generate an executable `minisat_HACK_1430ED_static' and place it
inside `./binary'. A wrapper launch script `wrapper.sh' written solely for
the competition envrionment is also copied into `./binary'.



EXECUTION
---------
For the SAT+UNSAT tracks,

    $ cd binary
    $ ./wrapper.sh <CNF>

For the Certified UNSAT track,

    $ cd binary
    $ ./wrapper.sh <CNF> --DRUP


However, normally, you would run the executable directly.

    $ cd binary
    $ ./minisat_HACK_1430ED_static <CNF>
