#!/bin/bash

SHDIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
if [ -z "$SHDIR" ]; then SHDIR="."; fi

cd $SHDIR
mkdir -p binary
cp wrapper.sh binary

cd code/simp
make clean

make rs
cp -f minisat_HACK_1430ED_static ../../binary
