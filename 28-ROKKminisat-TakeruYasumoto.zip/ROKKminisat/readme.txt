==================================================
                    SINNminisat
==================================================

(1) For building,
./build.sh

(2) For running,
./binary/rokk BENCHNAME



