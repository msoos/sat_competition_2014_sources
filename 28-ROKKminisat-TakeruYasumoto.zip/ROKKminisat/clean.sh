#!/bin/sh

rm -rf binary/rokk

cd code

export MROOT=$PWD

make -C core clean
make -C simp clean

