/*************************************************************************************************
Copyright (C) 2014 Chong HUANG (jason_hch@hotmail.com)
Laboratory of Smart Computing and Optimization
Huazhong University of Science and Technology, China
Advisors: Chumin LI (chu-min.li@u-picardie.fr), Ruchu XU (xrcy0315@sina.com)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/
#define VERSION "BalancedZ <SAT Compettion 2014 64-bit> V2014.05.06"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#if WIN32
#include <time.h>
#else
#include <limits.h>
#include <unistd.h>
#include <sys/times.h>
#include <sys/types.h>
#endif

#define MAX_NB_CLAUSE		17000000
#define MAX_NB_VAR			4000010
#define MAX_NB_TRIES		10000
#define CLAUSE_MAX_LENGTH	5000
#define WORD_LENGTH			200 
#define ACTIVE				1
#define PASSIVE				0
#define TRUE				1
#define FALSE				0
#define NONE				-MAX_NB_CLAUSE

#define add_to(item,stack) {\
stack[stack##_fill_pointer]=item;\
index_##stack[item]=stack##_fill_pointer++;\
}

#define remove_from(item,stack) {\
stack[index_##stack[item]]=stack[--stack##_fill_pointer];\
index_##stack[stack[stack##_fill_pointer]]=index_##stack[item];\
index_##stack[item]=NONE;\
}

#define max_score_min_flip_time(var,best_var) {\
SCORE_DELTA=var_score[var]-var_score[best_var];\
if(SCORE_DELTA>0) {\
	best_var=var;\
}else if((!SCORE_DELTA) && (rand()%100>=BP)) {\
	if(var_flip_time[var]<var_flip_time[best_var]) {\
		best_var=var;\
	}\
}\
}

#define max_score_max_contribute_score_min_tabu_change_time_min_flip_time(var,best_var) {\
SCORE_DELTA=BETA*(var_score[var]-var_score[best_var])+(var_contribute_score[var]-var_contribute_score[best_var])/GAP;\
if(SCORE_DELTA>0) {\
	best_var=var;\
}else if((!SCORE_DELTA) && (rand()%100>=BP)) {\
	if(var_tabu_change_time[var]<var_tabu_change_time[best_var]) {\
		best_var=var;\
	}else if(var_tabu_change_time[var]==var_tabu_change_time[best_var]) {\
		if(var_flip_time[var]<var_flip_time[best_var]) {\
			best_var=var;\
		}\
	}\
}\
}

#define max_score_max_contribute_score_max_tabu_change_time_min_flip_time(var,best_var) {\
SCORE_DELTA=BETA*(var_score[var]-var_score[best_var])+(var_contribute_score[var]-var_contribute_score[best_var])/GAP;\
if(SCORE_DELTA>0) {\
	best_var=var;\
}else if((!SCORE_DELTA) && (rand()%100>=BP)) {\
	if(var_tabu_change_time[var]>var_tabu_change_time[best_var]) {\
		best_var=var;\
	}else if(var_tabu_change_time[var]==var_tabu_change_time[best_var]) {\
		if(var_flip_time[var]<var_flip_time[best_var]) {\
			best_var=var;\
		}\
	}\
}\
}

#if WIN32
#define BIG_INT __int64
#define BIG_FORMAT "I64d"
#define inline __inline
clock_t begintime,endtime;
#else 
#define BIG_INT long long int
#define BIG_FORMAT "lli"
struct	tms *a_tms;
BIG_INT begintime,endtime,mess;
#endif

double SEARCH_TIME;

int solution[MAX_NB_VAR];

int *clauses[MAX_NB_CLAUSE];

int pos_nb[MAX_NB_VAR];
int neg_nb[MAX_NB_VAR];
int *pos_in[MAX_NB_VAR];
int *neg_in[MAX_NB_VAR];

int clause_length[MAX_NB_CLAUSE];
int clause_static_length[MAX_NB_CLAUSE];
int clause_sat_var[MAX_NB_CLAUSE];
int clause_second_sat_var[MAX_NB_CLAUSE];
int clause_sat_var_index[MAX_NB_CLAUSE];
int clause_weight[MAX_NB_CLAUSE];

int var_score[MAX_NB_VAR];
int var_break[MAX_NB_VAR];
int var_contribute_score[MAX_NB_VAR];
int var_nb_in_stack[MAX_NB_VAR];
int var_tabu_status[MAX_NB_VAR];
BIG_INT var_flip_time[MAX_NB_VAR];
BIG_INT var_tabu_change_time[MAX_NB_VAR];

double saved_result_flip[MAX_NB_TRIES];
double saved_result_time[MAX_NB_TRIES];

int CLAUSE_STACK[MAX_NB_CLAUSE];
int CLAUSE_STACK_fill_pointer=0;
int index_CLAUSE_STACK[MAX_NB_CLAUSE];

int VAR_STACK[MAX_NB_VAR];
int VAR_STACK_fill_pointer=0;
int index_VAR_STACK[MAX_NB_VAR];

int CANDIDATE_STACK[MAX_NB_VAR];
int CANDIDATE_STACK_fill_pointer=0;
int index_CANDIDATE_STACK[MAX_NB_VAR];

int BIG_WEIGHT_CLAUSE_STACK[MAX_NB_CLAUSE];
int BIG_WEIGHT_CLAUSE_STACK_fill_pointer=0;
int index_BIG_WEIGHT_CLAUSE_STACK[MAX_NB_CLAUSE];

int CHANGE_STACK[MAX_NB_VAR];
int CHANGE_STACK_fill_pointer=0;
int index_CHANGE_STACK[MAX_NB_VAR];

void init(void);
void search(void);
int local_search(void);
int local_search_3SAT(void);
int local_search_3SAT_simple(void);

int choose_var(void);
int choose_var_3SAT(void);
int choose_var_3SAT_simple(int clause);

void flip(int var);
void flip_3SAT(int var);
void flip_3SAT_simple(int var);

inline void satisfy(int var,int *satisfy_clauses);
inline void satisfy_3SAT(int var,int *satisfy_clauses);
inline void satisfy_3SAT_simple(int var,int *satisfy_clauses);
inline void reduce(int var,int *reduce_clauses);
inline void reduce_3SAT(int var,int *reduce_clauses);
inline void reduce_3SAT_simple(int var,int *reduce_clauses);
inline void get_clause_sat_vars(int clause,int *sat_var,int *second_sat_var);

inline int random_walk_by_min_flip_time(void);

void adapt_wp(void);
void adapt_wp2(void);
void adapt_bp(void);
void add_clause_weight(void);
void sub_clause_weight(void);
void update_clause_weight(void);
void update_clause_weight_3SAT(void);
void smooth_clause_weight_3SAT(void);

void time_start(void);
void time_end(void);

void scanone(int argc,char *argv[],int i,int *varptr);
void init_parameters(void);
void parse_parameters(int argc,char *argv[]);
char *get_file_name(char *input);
int verify_solution(void);
void handle_interrupt(int sigal);
int my_cmp(const void *a,const void *b);
int build_simple_sat_instance(char *input_file);
void free_memory(void);
void print_help(void);
void print_solution(void);

int NB_VAR,NB_CLAUSE,K;
int NB_UNSAT_CLAUSE,MIN_NB_UNSAT_CLAUSE;
BIG_INT NB_FLIP,NB_DECREASING_FLIP,NB_SIG_FLIP,NB_RANDOM_WALK,NB_MIN;
BIG_INT CUTOFF=4294967295u;
double AVER_DEPTH,AVER_BP;

int INIT_WEIGHT=1;
int delta=1;
int WP=0,WP2=0,WP3=1;
BIG_INT WP_PERIOD,WP2_PERIOD;
int RATIO_DF=70,RATIO_SF=10;

int THRESHOLD=300;
double LAMDA=0.9,SQ=0.3;

int SCORE_DELTA,BETA,GAP,BP,NOISE;
int theta,phi;
BIG_INT last_adapt_flip;
int last_best,adapt_length;

int wp3_flag=FALSE,threshold_flag=FALSE,theta_flag=FALSE,phi_flag=FALSE;
int simple_flag=FALSE,beta_flag=FALSE,gap_flag=FALSE;

BIG_INT TOTAL_WEIGHT,UNSAT_TOTAL_WEIGHT;
int AVER_WEIGHT,DELTA_WEIGHT,SCALE_WEIGHT;

int BEST_VAR,LAST_VAR,DECREASING_FLAG;


int SEED=7777777,MAX_TRIES=100000,NB_SOL=1;
int HELP_FLAG=FALSE,SOLUTION_FLAG=TRUE,CRAFTED_FLAG=FALSE;
char *INPUT_FILE;


#if WIN32
#define MY_TEST	TRUE
#endif

#if MY_TEST
void my_parse_parameters(int argc,char *argv[]) {
	SOLUTION_FLAG=FALSE;
	NB_SOL=10000;
//	SEED=5;
	CUTOFF=50000000;
	MAX_TRIES=10;
	BETA=1000;
	GAP=1;
	BP=0;
//	INPUT_FILE="C:\\Users\\Jason\\Documents\\Academic Research\\Benchmarks\\SAT2012\\unif-k3\\unif-k3-r4.267-v2000-c8534-S2317486902547650874.cnf";
	INPUT_FILE="C:\\Users\\Jason\\Documents\\Academic Research\\Benchmarks\\SAT2012\\unif-k3\\unif-k3-r4.267-v2000-c8534-S9087669915556401318.cnf";
//	INPUT_FILE="C:\\Users\\Jason\\Documents\\Academic Research\\Benchmarks\\SAT2012\\unif-k3\\unif-k3-r4.2-v40000-c168000-S38496475053332083.cnf";
//	INPUT_FILE="C:\\Users\\Jason\\Documents\\Academic Research\\Benchmarks\\SAT2012\\unif-k5\\unif-k5-r20.0-v1600-c32000-S5550251816172831665.cnf";
}
#endif

void adapt_wp(void) {
	double ratio;
	ratio=NB_DECREASING_FLIP*100.0/NB_FLIP;	
	if(ratio<RATIO_DF) {
		WP-=WP/2;
	}else {
		WP+=(100-WP)/10;
	}
}

void adapt_wp2(void) {
	double ratio;
	ratio=NB_SIG_FLIP*100.0/NB_FLIP;
	if(ratio>RATIO_SF) {
		WP2-=WP2/2;
	}else {
		WP2+=(100-WP2)/10;
	}
}

void adapt_bp(void) {
	AVER_BP=(AVER_BP*(NB_FLIP-1)+BP)/NB_FLIP;
	if((NB_FLIP-last_adapt_flip)>adapt_length) {
		NOISE+=(100-NOISE)/phi/2;
		last_adapt_flip=NB_FLIP;      
		last_best=NB_UNSAT_CLAUSE;
	}else if(NB_UNSAT_CLAUSE<last_best) {
		NOISE-=NOISE/phi;
		last_adapt_flip=NB_FLIP;
		last_best=NB_UNSAT_CLAUSE;
	}
	BP=NOISE/5;
}	

void init_parameters(void) {	
	double ratio;
	ratio=NB_CLAUSE*1.0/NB_VAR;
	printf("c %s\n",VERSION);
	printf("c %s %s\n",get_file_name(INPUT_FILE),(TRUE==CRAFTED_FLAG) ? ("Crafted") : ("Random"));
	printf("c #Var: %d, #Clause: %d, K= %d, Ratio: %.3f\n",NB_VAR,NB_CLAUSE,K,ratio);

	if(FALSE==theta_flag) {
		theta=10;
	}
	if(FALSE==phi_flag) {
		phi=5;
	}
	adapt_length=NB_CLAUSE/theta;		
	if(TRUE==CRAFTED_FLAG) {
		K=(K==3) ? (3) : (5);
	}
	switch (K) {
		case 3:
			BETA=1;
			GAP=1;
			if(FALSE==threshold_flag) {
				if(ratio>4.26) {
					THRESHOLD=(NB_VAR>3400) ? ((NB_VAR-3400)/1600*10+250) : (250);
				}else {
					THRESHOLD=(NB_VAR>2000) ? ((NB_VAR-2000)/4200*10+230) : (230);
				}
			}
			break;
		case 4:
			if(FALSE==beta_flag) {
				BETA=14;
			}
			if(FALSE==gap_flag) {
				GAP=2;
			}
			WP_PERIOD=NB_CLAUSE;
			WP2_PERIOD=NB_CLAUSE/3;
			break;
		case 5:
			if(FALSE==beta_flag) {
				BETA=38;
			}
			if(FALSE==gap_flag) {
				GAP=1;
			}
			WP_PERIOD=NB_CLAUSE/3;
			WP2_PERIOD=NB_CLAUSE*2;
			break;
		case 6:
			if(FALSE==beta_flag) {
				BETA=5;
			}
			if(FALSE==gap_flag) {
				GAP=1;
			}
			WP_PERIOD=NB_CLAUSE*5;
			WP2_PERIOD=NB_CLAUSE*5;
			break;
		case 7:
			if(FALSE==beta_flag) {
				BETA=6;
			}
			if(FALSE==gap_flag) {
				GAP=1;
			}
			WP_PERIOD=NB_CLAUSE*3;
			WP2_PERIOD=NB_CLAUSE*3;
			break;
		default:
			WP_PERIOD=NB_CLAUSE*3;
			WP2_PERIOD=NB_CLAUSE*3;
			THRESHOLD=300;	
	}
	printf("c Theta: %d, Phi: %d",theta,phi);
	if(K>3) {
		printf(", Beta: %d, Gap: %d\n",BETA,GAP);
	}else {
		printf(", Threshold: %d\n",THRESHOLD);
	}
}

void init(void) {
	int i,j,clause,count,*vars,var,temp[2];
	srand(SEED);
	NB_FLIP=0;
	NB_DECREASING_FLIP=0;
	NB_SIG_FLIP=0;
	NB_RANDOM_WALK=0;
	NB_UNSAT_CLAUSE=0;
	MIN_NB_UNSAT_CLAUSE=NB_CLAUSE;
	NB_MIN=0;	

	TOTAL_WEIGHT=0;
	UNSAT_TOTAL_WEIGHT=0;
	DELTA_WEIGHT=0;
	AVER_DEPTH=0;

	AVER_WEIGHT=INIT_WEIGHT;
	SCALE_WEIGHT=(int)((THRESHOLD+1)*(1-SQ));
	
	BP=0;
	NOISE=0;
	AVER_BP=0;
	last_adapt_flip=0;
	last_best=NB_UNSAT_CLAUSE;
	
	VAR_STACK_fill_pointer=0;
	CLAUSE_STACK_fill_pointer=0;
	BIG_WEIGHT_CLAUSE_STACK_fill_pointer=0;

	CANDIDATE_STACK_fill_pointer=0;
	CHANGE_STACK_fill_pointer=0;

	for(i=1;i<=NB_CLAUSE;i++) {
		clause_length[i]=clause_static_length[i];
		clause_weight[i]=AVER_WEIGHT;
		clause_sat_var[i]=NONE;
		clause_second_sat_var[i]=NONE;
		clause_sat_var_index[i]=0;
		index_CLAUSE_STACK[i]=NONE;
		index_BIG_WEIGHT_CLAUSE_STACK[i]=NONE;
		TOTAL_WEIGHT+=clause_weight[i];
	}
	for(i=1;i<=NB_VAR;i++) {
		solution[i]=(rand()%2) ? TRUE : FALSE;
		if(TRUE==solution[i]) {
			for(j=0;neg_in[i][j]!=NONE;j++) {
				clause=neg_in[i][j];
				if(clause_length[clause]>0) {
					clause_length[clause]--;
				}
			}
		}else {
			for(j=0;pos_in[i][j]!=NONE;j++) {
				clause=pos_in[i][j];
				if(clause_length[clause]>0) {
					clause_length[clause]--;
				}
			}
		}
		var_score[i]=0;
		var_break[i]=0;
		var_contribute_score[i]=0;
		var_flip_time[i]=0;
		var_nb_in_stack[i]=0;
		var_tabu_status[i]=FALSE;
		var_tabu_change_time[i]=0;
		index_VAR_STACK[i]=NONE;
		index_CANDIDATE_STACK[i]=NONE;
		index_CHANGE_STACK[i]=NONE;
	}
	for(i=1;i<=NB_CLAUSE;i++) {
		if(1==clause_length[i]) {
			vars=clauses[i];
			for(var=*vars;var!=NONE;var=*(vars+=2)) {
				if(solution[var]==*(vars+1)) {
					clause_sat_var[i]=var;
					clause_sat_var_index[i]+=var;
					var_score[var]-=clause_weight[i];
					var_break[var]++;
				}else {
					var_contribute_score[var]+=clause_weight[i];
				}
			}
		}else if(!clause_length[i]) {
			NB_UNSAT_CLAUSE++;
			UNSAT_TOTAL_WEIGHT+=clause_weight[i];
			add_to(i,CLAUSE_STACK);
			vars=clauses[i];
			for(var=*vars;var!=NONE;var=*(vars+=2)) {
				if(!var_nb_in_stack[var]) {
					add_to(var,VAR_STACK);
				}
				var_score[var]+=clause_weight[i];
				var_nb_in_stack[var]++;
			}
		}else if(2==clause_length[i]) {
			vars=clauses[i];
			count=0;
			for(var=*vars;var!=NONE;var=*(vars+=2)) {
				if(solution[var]==*(vars+1)) {
					temp[count++]=var;
					clause_sat_var_index[i]+=var;
					var_contribute_score[var]-=clause_weight[i];
				}
			}
			clause_sat_var[i]=temp[0];
			clause_second_sat_var[i]=temp[1];
		}else {
			vars=clauses[i];
			for(var=*vars;var!=NONE;var=*(vars+=2)) {
				if(solution[var]==*(vars+1)) {
					clause_sat_var_index[i]+=var;
				}
			}	
		}
	}
	BEST_VAR=0;
	var_score[0]=-NB_CLAUSE;
	var_contribute_score[0]=-NB_CLAUSE;
	for(i=1;i<=NB_VAR;i++) {
		if(var_score[i]>0) {
			add_to(i,CANDIDATE_STACK);		
			max_score_max_contribute_score_min_tabu_change_time_min_flip_time(i,BEST_VAR);
		}		
	}
}

inline void satisfy(int var,int *satisfy_clauses) {
	int clause,neibor_var,*vars;
	for(clause=*satisfy_clauses;clause!=NONE;clause=*(++satisfy_clauses)) {
		if(!clause_length[clause]) {
			NB_UNSAT_CLAUSE--;
			UNSAT_TOTAL_WEIGHT-=clause_weight[clause];
			remove_from(clause,CLAUSE_STACK);
			if((clause_weight[clause]>INIT_WEIGHT) && (NONE==index_BIG_WEIGHT_CLAUSE_STACK[clause])) {
				add_to(clause,BIG_WEIGHT_CLAUSE_STACK);	
			}
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				var_score[neibor_var]-=clause_weight[clause];
				var_contribute_score[neibor_var]+=clause_weight[clause];
				var_nb_in_stack[neibor_var]--;		
				if(!var_nb_in_stack[neibor_var]) {
					remove_from(neibor_var,VAR_STACK);
				}
				if(NONE==index_CHANGE_STACK[neibor_var]) {
					add_to(neibor_var,CHANGE_STACK);
				}
				if(TRUE==var_tabu_status[neibor_var]) {
					var_tabu_status[neibor_var]=FALSE;
					var_tabu_change_time[neibor_var]=NB_FLIP;
				}
			}	
			clause_sat_var[clause]=var;
			clause_second_sat_var[clause]=NONE;
		}else if(1==clause_length[clause]) {
			neibor_var=clause_sat_var[clause];
			var_score[neibor_var]+=clause_weight[clause];
			if(NONE==index_CHANGE_STACK[neibor_var]) {
				add_to(neibor_var,CHANGE_STACK);
			}
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				var_contribute_score[neibor_var]-=clause_weight[clause];
			}
			clause_second_sat_var[clause]=var;
		}else if(2==clause_length[clause]) {
			var_contribute_score[clause_sat_var[clause]]+=clause_weight[clause];
			var_contribute_score[clause_second_sat_var[clause]]+=clause_weight[clause];
		}
		clause_length[clause]++;
		clause_sat_var_index[clause]+=var;				
	}
}

inline void reduce(int var,int *reduce_clauses) {
	int clause,neibor_var,*vars;
	for(clause=*reduce_clauses;clause!=NONE;clause=*(++reduce_clauses)) {
		clause_length[clause]--;
		clause_sat_var_index[clause]-=var;
		if(1==clause_length[clause]) {
			if(var==clause_sat_var[clause]) {
				clause_sat_var[clause]=clause_second_sat_var[clause];
			}
			neibor_var=clause_sat_var[clause];
			var_score[neibor_var]-=clause_weight[clause];
			if(NONE==index_CHANGE_STACK[neibor_var]) {
				add_to(neibor_var,CHANGE_STACK);
			}
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				var_contribute_score[neibor_var]+=clause_weight[clause];
			}
			clause_second_sat_var[clause]=NONE;
		}else if(!clause_length[clause]) {
			add_to(clause,CLAUSE_STACK);
			NB_UNSAT_CLAUSE++;
			UNSAT_TOTAL_WEIGHT+=clause_weight[clause];
			if(NONE!=index_BIG_WEIGHT_CLAUSE_STACK[clause]) {
				remove_from(clause,BIG_WEIGHT_CLAUSE_STACK);
			}
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				var_score[neibor_var]+=clause_weight[clause];
				var_contribute_score[neibor_var]-=clause_weight[clause];
				if(!var_nb_in_stack[neibor_var]) {
					add_to(neibor_var,VAR_STACK);
				}
				if(NONE==index_CHANGE_STACK[neibor_var]) {
					add_to(neibor_var,CHANGE_STACK);
				}
				var_nb_in_stack[neibor_var]++;
				if(TRUE==var_tabu_status[neibor_var]) {
					var_tabu_status[neibor_var]=FALSE;
					var_tabu_change_time[neibor_var]=NB_FLIP;
				}
			}
		}else if(2==clause_length[clause]) {
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				if(*(vars+1)==solution[neibor_var]) {
					break;
				}
			}
			clause_sat_var[clause]=neibor_var;
			clause_second_sat_var[clause]=clause_sat_var_index[clause]-neibor_var;
			var_contribute_score[clause_sat_var[clause]]-=clause_weight[clause];
			var_contribute_score[clause_second_sat_var[clause]]-=clause_weight[clause];
		}
	}
}

void flip(int var) {
	int i,temp_var,saved_score,saved_contribute_score;
	NB_FLIP++;
	saved_score=var_score[var];
	saved_contribute_score=var_contribute_score[var];
	if(TRUE==solution[var]) {
		solution[var]=FALSE;
		satisfy(var,neg_in[var]);
		reduce(var,pos_in[var]);
	}else {
		solution[var]=TRUE;
		satisfy(var,pos_in[var]);
		reduce(var,neg_in[var]);
	}
	var_flip_time[var]=NB_FLIP;	
	var_score[var]=-saved_score;
	var_contribute_score[var]=-saved_contribute_score;
	var_tabu_status[var]=TRUE;
	var_tabu_change_time[var]=NB_FLIP;
	for(i=CANDIDATE_STACK_fill_pointer-1;i>=0;i--) {
		temp_var=CANDIDATE_STACK[i];
		if((var_score[temp_var]<=0) || (FALSE!=var_tabu_status[temp_var])) {
			remove_from(temp_var,CANDIDATE_STACK);
		}else {
			max_score_max_contribute_score_min_tabu_change_time_min_flip_time(temp_var,BEST_VAR);
		}
	}
	remove_from(var,CHANGE_STACK);
	for(i=0;i<CHANGE_STACK_fill_pointer;i++) {
		temp_var=CHANGE_STACK[i];
		index_CHANGE_STACK[temp_var]=NONE;
		if((var_score[temp_var]>0) && (NONE==index_CANDIDATE_STACK[temp_var]) && (FALSE==var_tabu_status[temp_var])) {
			add_to(temp_var,CANDIDATE_STACK);
			max_score_max_contribute_score_min_tabu_change_time_min_flip_time(temp_var,BEST_VAR);
		}
	}
	CHANGE_STACK_fill_pointer=0;
}

void sub_clause_weight(void) {
	int i,var,*vars,sat_var,clause;
	for(i=0;i<BIG_WEIGHT_CLAUSE_STACK_fill_pointer;i++) {
		clause=BIG_WEIGHT_CLAUSE_STACK[i];
		clause_weight[clause]-=delta;
		if(clause_weight[clause]<=INIT_WEIGHT) {
			remove_from(clause,BIG_WEIGHT_CLAUSE_STACK);
		}
		TOTAL_WEIGHT-=delta;
		DELTA_WEIGHT-=delta;
		if(DELTA_WEIGHT<0) {
			AVER_WEIGHT--;
			DELTA_WEIGHT=NB_CLAUSE;
		}
		if(1==clause_length[clause]) {
			sat_var=clause_sat_var[clause];
			var_score[sat_var]+=delta;
			if(NONE==index_CHANGE_STACK[sat_var]) {
				add_to(sat_var,CHANGE_STACK);
			}
			var_contribute_score[sat_var]+=delta;
			vars=clauses[clause];
			for(var=*vars;var!=NONE;var=*(vars+=2)) {
				var_contribute_score[var]-=delta;
			}
		}else if(2==clause_length[clause]) {
			var_contribute_score[clause_sat_var[clause]]+=delta;
			var_contribute_score[clause_second_sat_var[clause]]+=delta;
		}
	}
	for(i=0;i<CHANGE_STACK_fill_pointer;i++) {
		var=CHANGE_STACK[i];
		index_CHANGE_STACK[var]=NONE;
		if((FALSE==var_tabu_status[var]) && (var_score[var]>0)) {
			add_to(var,CANDIDATE_STACK);
			max_score_max_contribute_score_min_tabu_change_time_min_flip_time(var,BEST_VAR);
		}
	}
	CHANGE_STACK_fill_pointer=0;
}

void add_clause_weight(void) {
	int i,var,clause;
	for(i=0;i<CLAUSE_STACK_fill_pointer;i++) {
		clause=CLAUSE_STACK[i];
		clause_weight[clause]+=delta;
		TOTAL_WEIGHT+=delta;
		UNSAT_TOTAL_WEIGHT+=delta;
	}
	DELTA_WEIGHT+=delta*CLAUSE_STACK_fill_pointer;
	if(DELTA_WEIGHT>NB_CLAUSE) {
		AVER_WEIGHT++;
		DELTA_WEIGHT-=NB_CLAUSE;
	}
	for(i=0;i<VAR_STACK_fill_pointer;i++) {
		var=VAR_STACK[i];
		var_score[var]+=delta*var_nb_in_stack[var];
		if((FALSE==var_tabu_status[var]) && (var_score[var]>0)) {
			add_to(var,CANDIDATE_STACK);
			max_score_max_contribute_score_min_tabu_change_time_min_flip_time(var,BEST_VAR);
		}
	}
}

void update_clause_weight(void) {
	if(((rand()%1000>=WP3) && (TRUE==DECREASING_FLAG)) || (rand()%100<WP)) {
		sub_clause_weight();
	}else {
		add_clause_weight();
	}
}

int choose_var(void) {
	int i,var,best_var=NONE;
	if(BEST_VAR) {
		best_var=BEST_VAR;
		NB_DECREASING_FLIP++;
		DECREASING_FLAG=TRUE;
	}else {
		for(i=0;i<VAR_STACK_fill_pointer;i++) {
			var=VAR_STACK[i];
			max_score_max_contribute_score_max_tabu_change_time_min_flip_time(var,BEST_VAR);
		}
		if(TRUE==DECREASING_FLAG) {
			if(var_score[BEST_VAR]>AVER_WEIGHT) {
				best_var=BEST_VAR;
				NB_SIG_FLIP++;
				DECREASING_FLAG=TRUE;
			}else if((rand()%100<WP2) && (BEST_VAR!=LAST_VAR)) {
				best_var=BEST_VAR;
				NB_SIG_FLIP++;
				DECREASING_FLAG=FALSE;
			}
		}else if((var_score[BEST_VAR]>0) && (BEST_VAR!=LAST_VAR)) {
			best_var=BEST_VAR;
			NB_SIG_FLIP++;
			DECREASING_FLAG=TRUE;
		}else if((rand()%100<WP2) && (var_score[BEST_VAR]==0) && (BEST_VAR!=LAST_VAR)) {
			best_var=BEST_VAR;
			NB_SIG_FLIP++;
			DECREASING_FLAG=FALSE;
		}
	}
	if(NONE==best_var) {
		best_var=random_walk_by_min_flip_time();
		NB_RANDOM_WALK++;
		update_clause_weight();
		DECREASING_FLAG=FALSE;
	}
	BEST_VAR=0;
	return best_var;
}

int local_search(void) {
	int var;
	time_start();
	while((NB_FLIP<CUTOFF) && (NB_UNSAT_CLAUSE)) {
		var=choose_var();
		flip(var);
		adapt_bp();
		LAST_VAR=var;
		AVER_DEPTH=(AVER_DEPTH*(NB_FLIP-1)+NB_UNSAT_CLAUSE)*1.0/NB_FLIP;
		if(NB_UNSAT_CLAUSE<=MIN_NB_UNSAT_CLAUSE) {
			if(NB_UNSAT_CLAUSE==MIN_NB_UNSAT_CLAUSE) {
				NB_MIN++;
			}else {
				MIN_NB_UNSAT_CLAUSE=NB_UNSAT_CLAUSE;
				NB_MIN=1;
			}
		}
		if(!(NB_FLIP%WP_PERIOD)) {
			adapt_wp();
		}
		if(!(NB_FLIP%WP2_PERIOD)) {
			adapt_wp2();
		}
	}
	time_end();
	return (NB_UNSAT_CLAUSE) ? (FALSE) : (TRUE);
}

void search(void) {
	int tries,ls_result=FALSE,nb_success;
	double total_nb_flip=0;
	double total_search_time=0;
	for(tries=1,nb_success=0;(tries<=MAX_TRIES) && (nb_success<NB_SOL);tries++) {	
		init();
		if(3==K) {
			if((NB_VAR>200000) || (NB_CLAUSE<4.2*NB_VAR-1) || (TRUE==simple_flag)) {
				printf("c 3-SAT simple mode.\n");
				ls_result=local_search_3SAT_simple();
			}else {
				ls_result=local_search_3SAT();
			}
		}else {
			ls_result=local_search();
		} 
		if(TRUE==ls_result) {		
			if(TRUE==verify_solution()) {
				printf("s SATISFIABLE\n");
				if((1==NB_SOL) && (TRUE==SOLUTION_FLAG)) {					
					print_solution();
				}
				saved_result_flip[nb_success]+=(double)NB_FLIP;
				saved_result_time[nb_success]+=SEARCH_TIME;
				nb_success++;
			}else {
				printf("c Oops! Something wrong with me...\n");
			}
		}else {
			printf("c Unknown.\n");
			printf("c Best= %d, #Best= %"BIG_FORMAT"\n",MIN_NB_UNSAT_CLAUSE,NB_MIN);
			saved_result_flip[nb_success]+=(double)NB_FLIP;
			saved_result_time[nb_success]+=SEARCH_TIME;
		} 
		printf("c Step= %"BIG_FORMAT", Time= %.2lf, Depth= %.2f, Bp= %.3f, Speed= %.2lf",
			NB_FLIP,SEARCH_TIME,AVER_DEPTH,AVER_BP,NB_FLIP/SEARCH_TIME);
		if(1==NB_SOL) {
			printf("\n");
		}else {
			printf(", #Try= %d\n",tries);
		}
		total_nb_flip+=(double)NB_FLIP;
		total_search_time+=SEARCH_TIME;
		SEED++;
	}
	if(nb_success>1) {
		printf("c\nc Rate    : %-5.2f%%          Time\n",nb_success*100.0/(tries-1));
		printf("c Average : %-10ld %10.2f\n",(long)(total_nb_flip/nb_success),total_search_time/nb_success);
		if((2*nb_success>=tries) && (NB_SOL>2)) {
			qsort(saved_result_flip,nb_success,sizeof(saved_result_flip[0]),my_cmp);
			qsort(saved_result_time,nb_success,sizeof(saved_result_time[0]),my_cmp);	
			printf("c Medium  : %-10ld %10.2f\n",(long)(saved_result_flip[nb_success/2]),saved_result_time[nb_success/2]);
		}else {
			printf("\n");
		}
	}
	free_memory();
}

int main(int argc,char *argv[]) {
#if MY_TEST
	my_parse_parameters(argc,argv);
#else
	parse_parameters(argc,argv);
#endif
	signal(SIGINT,handle_interrupt);
	if(TRUE==build_simple_sat_instance(INPUT_FILE)) {
		init_parameters();
		search();
	}else { 
		printf("c Input file error.\n"); 
	}
	return TRUE;
}

inline void satisfy_3SAT(int var,int *satisfy_clauses) {
	int clause,neibor_var,*vars;
	for(clause=*satisfy_clauses;clause!=NONE;clause=*(++satisfy_clauses)) {
		if(!clause_length[clause]) {
			NB_UNSAT_CLAUSE--;
			UNSAT_TOTAL_WEIGHT-=clause_weight[clause];
			remove_from(clause,CLAUSE_STACK);
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				var_score[neibor_var]-=clause_weight[clause];
				var_nb_in_stack[neibor_var]--;		
				if(!var_nb_in_stack[neibor_var]) {
					remove_from(neibor_var,VAR_STACK);
				}
				if(NONE==index_CHANGE_STACK[neibor_var]) {
					add_to(neibor_var,CHANGE_STACK);
				}
				if(TRUE==var_tabu_status[neibor_var]) {
					var_tabu_status[neibor_var]=FALSE;
					var_tabu_change_time[neibor_var]=NB_FLIP;
				}
			}	
		}else if(1==clause_length[clause]) {
			neibor_var=clause_sat_var_index[clause];
			if((TRUE==var_tabu_status[neibor_var]) && (var_score[neibor_var]<0)) {
				var_tabu_status[neibor_var]=FALSE;
				var_tabu_change_time[neibor_var]=NB_FLIP;
			}
			var_score[neibor_var]+=clause_weight[clause];
			if(NONE==index_CHANGE_STACK[neibor_var]) {
				add_to(neibor_var,CHANGE_STACK);
			}
		}
		clause_sat_var_index[clause]+=var;
		clause_length[clause]++;		
	}
}

inline void reduce_3SAT(int var,int *reduce_clauses) {
	int clause,neibor_var,*vars;
	for(clause=*reduce_clauses;clause!=NONE;clause=*(++reduce_clauses)) {
		clause_length[clause]--;
		clause_sat_var_index[clause]-=var;
		if(1==clause_length[clause]) {
			neibor_var=clause_sat_var_index[clause];
			var_score[neibor_var]-=clause_weight[clause];
			if(NONE==index_CHANGE_STACK[neibor_var]) {
				add_to(neibor_var,CHANGE_STACK);
			}
		}else if(!clause_length[clause]) {
			add_to(clause,CLAUSE_STACK);
			NB_UNSAT_CLAUSE++;
			UNSAT_TOTAL_WEIGHT+=clause_weight[clause];
			vars=clauses[clause];
			for(neibor_var=*vars;neibor_var!=NONE;neibor_var=*(vars+=2)) {
				var_score[neibor_var]+=clause_weight[clause];
				if(!var_nb_in_stack[neibor_var]) {
					add_to(neibor_var,VAR_STACK);
				}
				if(NONE==index_CHANGE_STACK[neibor_var]) {
					add_to(neibor_var,CHANGE_STACK);
				}
				var_nb_in_stack[neibor_var]++;
				if(TRUE==var_tabu_status[neibor_var]) {
					var_tabu_status[neibor_var]=FALSE;
					var_tabu_change_time[neibor_var]=NB_FLIP;
				}
			}
		}
	}
}

void flip_3SAT(int var) {
	int i,temp_var,saved_score;
	NB_FLIP++;
	saved_score=var_score[var];
	if(TRUE==solution[var]) {
		solution[var]=FALSE;
		satisfy_3SAT(var,neg_in[var]);
		reduce_3SAT(var,pos_in[var]);
	}else {
		solution[var]=TRUE;
		satisfy_3SAT(var,pos_in[var]);
		reduce_3SAT(var,neg_in[var]);
	}
	var_flip_time[var]=NB_FLIP;	
	var_score[var]=-saved_score;
	var_tabu_status[var]=TRUE;
	var_tabu_change_time[var]=NB_FLIP;
	for(i=CANDIDATE_STACK_fill_pointer-1;i>=0;i--) {
		temp_var=CANDIDATE_STACK[i];
		if((var_score[temp_var]<=0) || (FALSE!=var_tabu_status[temp_var])) {
			remove_from(temp_var,CANDIDATE_STACK);
		}else {
			max_score_min_flip_time(temp_var,BEST_VAR);
		}
	}
	remove_from(var,CHANGE_STACK);
	for(i=0;i<CHANGE_STACK_fill_pointer;i++) {
		temp_var=CHANGE_STACK[i];
		index_CHANGE_STACK[temp_var]=NONE;
		if((var_score[temp_var]>0) && (NONE==index_CANDIDATE_STACK[temp_var]) && (FALSE==var_tabu_status[temp_var])) {
			add_to(temp_var,CANDIDATE_STACK);
			max_score_min_flip_time(temp_var,BEST_VAR);
		}
	}
	CHANGE_STACK_fill_pointer=0;
}

void smooth_clause_weight_3SAT(void) {
	int i,var,*vars,temp;
	for(i=1;i<=NB_VAR;i++) {
		var_score[i]=0;
	}
	TOTAL_WEIGHT=0;
	UNSAT_TOTAL_WEIGHT=0;
	for(i=1;i<=NB_CLAUSE;i++) {
		temp=(int)(clause_weight[i]*SQ);
#if WIN32
#else
    /* below codes make sure to perform correctly under 64-bit Linux    */
    /* systems, since the parameters are tuned under a 32-bit enviroment*/
    /* in 32-bit Linux: (int) (10*(double)(0.3))=2                      */
    /* while in 64-bit: (int) (10*(double)(0.3))=3                      */
	/**/if(!(clause_weight[i]%10)) {/************************************/
	/******/temp--;/*****************************************************/
	/**/}/***************************************************************/
	/**************************end of these codes************************/
#endif
		clause_weight[i]=temp+SCALE_WEIGHT;
		TOTAL_WEIGHT+=clause_weight[i];
		if(1==clause_length[i]) {
			var_score[clause_sat_var_index[i]]-=clause_weight[i];
		}else if(!clause_length[i]) {
			UNSAT_TOTAL_WEIGHT+=clause_weight[i];
			vars=clauses[i];
			for(var=*vars;var!=NONE;var=*(vars+=2)) {
				var_score[var]+=clause_weight[i];
			}
		}
	}
	AVER_WEIGHT=TOTAL_WEIGHT/NB_CLAUSE;
	BEST_VAR=0;
	CANDIDATE_STACK_fill_pointer=0;
	for(i=0;i<VAR_STACK_fill_pointer;i++) {
		var=VAR_STACK[i];
		index_CANDIDATE_STACK[var]=NONE;
		if((var_score[var]>0) && (FALSE==var_tabu_status[var])) {
			add_to(var,CANDIDATE_STACK);
			max_score_min_flip_time(var,BEST_VAR);
		}
	}
}

void update_clause_weight_3SAT(void) {
	int i,var,clause;
	for(i=0;i<CLAUSE_STACK_fill_pointer;i++) {
		clause=CLAUSE_STACK[i];
		clause_weight[clause]+=delta;
		TOTAL_WEIGHT+=delta;
		UNSAT_TOTAL_WEIGHT+=delta;
	}
	DELTA_WEIGHT+=delta*CLAUSE_STACK_fill_pointer;
	if(DELTA_WEIGHT>NB_CLAUSE) {
		AVER_WEIGHT++;
		DELTA_WEIGHT-=NB_CLAUSE;
		if(AVER_WEIGHT>THRESHOLD) {
			smooth_clause_weight_3SAT();
			return ;
		}
	}
	for(i=0;i<VAR_STACK_fill_pointer;i++) {
		var=VAR_STACK[i];
		var_score[var]+=delta*var_nb_in_stack[var];
		if((FALSE==var_tabu_status[var]) && (var_score[var]>0)) {
			add_to(var,CANDIDATE_STACK);
			max_score_min_flip_time(var,BEST_VAR);
		}
	}
}

int choose_var_3SAT(void) {
	int i,var,best_var=NONE;
	if(BEST_VAR) {
		best_var=BEST_VAR;
		NB_DECREASING_FLIP++;
		DECREASING_FLAG=TRUE;
	}else {
		for(i=0;i<VAR_STACK_fill_pointer;i++) {
			var=VAR_STACK[i]; 
			max_score_min_flip_time(var,BEST_VAR);
		}
		if(var_score[BEST_VAR]>LAMDA*AVER_WEIGHT) {
			best_var=BEST_VAR;
			NB_SIG_FLIP++;
			DECREASING_FLAG=TRUE;
		}
	}
	if(NONE==best_var) {
		best_var=random_walk_by_min_flip_time();
		NB_RANDOM_WALK++;
		update_clause_weight_3SAT();
		DECREASING_FLAG=FALSE;
	}
	BEST_VAR=0;
	return best_var;
}

int local_search_3SAT(void) {
	int var;
	time_start();
	while((NB_FLIP<CUTOFF) && (NB_UNSAT_CLAUSE)) {
		var=choose_var_3SAT();
		flip_3SAT(var);
		adapt_bp();
		AVER_DEPTH=(AVER_DEPTH*(NB_FLIP-1)+NB_UNSAT_CLAUSE)*1.0/NB_FLIP;
		if(NB_UNSAT_CLAUSE<=MIN_NB_UNSAT_CLAUSE) {
			if(NB_UNSAT_CLAUSE==MIN_NB_UNSAT_CLAUSE) {
				NB_MIN++;
			}else {
				MIN_NB_UNSAT_CLAUSE=NB_UNSAT_CLAUSE;
				NB_MIN=1;
			}
		}
	}
	time_end();
	return (NB_UNSAT_CLAUSE) ? (FALSE) : (TRUE);
}

inline int random_walk_by_min_flip_time(void) {
	int var,best_var,*vars;
	vars=clauses[CLAUSE_STACK[rand()%CLAUSE_STACK_fill_pointer]];
	best_var=*(vars++);
	for(var=*(++vars);var!=NONE;var=*(vars+=2)) {
		if(var_flip_time[var]<var_flip_time[best_var]) {
			best_var=var;
		}
	}
	return best_var;
}

inline void satisfy_3SAT_simple(int var,int *satisfy_clauses) {
	int clause;
	for(clause=*satisfy_clauses;clause!=NONE;clause=*(++satisfy_clauses)) {
		if(!clause_length[clause]) {
			NB_UNSAT_CLAUSE--;
			remove_from(clause,CLAUSE_STACK);
			var_break[var]++;	
		}else if(1==clause_length[clause]) {
			var_break[clause_sat_var_index[clause]]--;
		}
		clause_sat_var_index[clause]+=var;
		clause_length[clause]++;		
	}
}

inline void reduce_3SAT_simple(int var,int *reduce_clauses) {
	int clause;
	for(clause=*reduce_clauses;clause!=NONE;clause=*(++reduce_clauses)) {
		clause_length[clause]--;
		clause_sat_var_index[clause]-=var;
		if(1==clause_length[clause]) {
			var_break[clause_sat_var_index[clause]]++;
		}else if(!clause_length[clause]) {
			add_to(clause,CLAUSE_STACK);
			NB_UNSAT_CLAUSE++;
			var_break[var]--;
		}
	}
}

int choose_var_3SAT_simple(int clause) {
	int var,nb_best,nb_break,min_break;
	int best[100];
	register int *vars;
	vars=clauses[clause];
	var=*vars;
	best[0]=var;
	nb_best=1;
	min_break=var_break[var];
	for(var=*(vars+=2);var!=NONE;var=*(vars+=2)) {
		nb_break=var_break[var];
		if(nb_break<=min_break) {
			if(nb_break<min_break) {
				nb_best=0;
			}
			min_break=nb_break;
			best[nb_best++]=var;
		}
	}
	if(!min_break) {
		return best[rand()%nb_best];
	}
	if(rand()*1.0/RAND_MAX<0.567) {
		return clauses[clause][(rand()%clause_static_length[clause])<<1];
	}else {
		return best[rand()%nb_best];
	}
}

void flip_3SAT_simple(int var) {
	NB_FLIP++;
	if(TRUE==solution[var]) {
		solution[var]=FALSE;
		satisfy_3SAT_simple(var,neg_in[var]);
		reduce_3SAT_simple(var,pos_in[var]);
	}else {
		solution[var]=TRUE;
		satisfy_3SAT_simple(var,pos_in[var]);
		reduce_3SAT_simple(var,neg_in[var]);
	}
}

int local_search_3SAT_simple(void) {
	time_start();
	while((NB_FLIP<CUTOFF) && (NB_UNSAT_CLAUSE)) {
		flip_3SAT_simple(choose_var_3SAT_simple(CLAUSE_STACK[rand()%NB_UNSAT_CLAUSE]));
		AVER_DEPTH=(AVER_DEPTH*(NB_FLIP-1)+NB_UNSAT_CLAUSE)*1.0/NB_FLIP;
		if(NB_UNSAT_CLAUSE<=MIN_NB_UNSAT_CLAUSE) {
			if(NB_UNSAT_CLAUSE==MIN_NB_UNSAT_CLAUSE) {
				NB_MIN++;
			}else {
				MIN_NB_UNSAT_CLAUSE=NB_UNSAT_CLAUSE;
				NB_MIN=1;
			}
		}
	}
	time_end();
	return (NB_UNSAT_CLAUSE) ? (FALSE) : (TRUE);
}

void print_help(void) {		
	printf("c using the following parameters (the order does not matter)\n");
	printf("c your input file\n");
	printf("c -cutoff CUTOFF\n");
	printf("c -seed SEED\n");
	printf("c -maxtries MAXTRIES\n");
	printf("c -nbsol NB_SOL\n");
	printf("c -help: The current help message\n");
	exit(NONE);
}

void parse_parameters(int argc,char *argv[]) {	
	int i;
	if(argc<2)		
		print_help();
	else {
		for(i=1;i<argc;i++) {
			if(!strcmp(argv[i],"-cutoff"))
#if WIN32
				sscanf(argv[++i],"%I64d",&CUTOFF);
#else
				sscanf(argv[++i],"%lli",&CUTOFF);
#endif
			else if(!strcmp(argv[i],"-seed"))
				scanone(argc,argv,++i,&SEED);
			else if(!strcmp(argv[i],"-maxtries"))
				scanone(argc,argv,++i,&MAX_TRIES);
			else if(!strcmp(argv[i],"-nosol"))
				SOLUTION_FLAG=FALSE;
			else if(!strcmp(argv[i],"-nbsol"))
				scanone(argc,argv,++i,&NB_SOL);
			else if(!strcmp(argv[i],"-wp"))
				scanone(argc,argv,++i,&WP);
			else if(!strcmp(argv[i],"-wp2"))
				scanone(argc,argv,++i,&WP2);
			else if(!strcmp(argv[i],"-wp3")) {
				scanone(argc,argv,++i,&WP3);
				wp3_flag=TRUE;
			}else if(!strcmp(argv[i],"-threshold")) {
				scanone(argc,argv,++i,&THRESHOLD);
				threshold_flag=TRUE;
			}else if(!strcmp(argv[i],"-phi")) {
				scanone(argc,argv,++i,&phi);
				phi_flag=TRUE;
			}else if(!strcmp(argv[i],"-theta")) {
				scanone(argc,argv,++i,&theta);
				theta_flag=TRUE;
			}else if(!strcmp(argv[i],"-gap")) {
				scanone(argc,argv,++i,&GAP);
				gap_flag=TRUE;
			}else if(!strcmp(argv[i],"-beta")) {
				scanone(argc,argv,++i,&BETA);
				beta_flag=TRUE;
			}else if(!strcmp(argv[i],"-ratio_df"))
				scanone(argc,argv,++i,&RATIO_DF);
			else if(!strcmp(argv[i],"-ratio_sf"))
				scanone(argc,argv,++i,&RATIO_SF);
			else if(!strcmp(argv[i],"-lamda"))
				sscanf(argv[++i],"%lf",&LAMDA);
			else if(!strcmp(argv[i],"-init_weight"))
				scanone(argc,argv,++i,&INIT_WEIGHT);
			else if(!strcmp(argv[i],"-crafted"))
				CRAFTED_FLAG=TRUE;
			else if(!strcmp(argv[i],"-simple"))
				simple_flag=TRUE;	
			else if(!strcmp(argv[i],"-help"))
				print_help();
			else 
				INPUT_FILE=argv[i];
		}
	}
}

void handle_interrupt(int sigal) {
	time_end();
	free_memory();
	printf("\nc Interupt Signal...\n");
	printf("c Unknown.\n");
	printf("c Step= %"BIG_FORMAT", Time= %.2lf, Speed= %.2lf\n",NB_FLIP,SEARCH_TIME,NB_FLIP/SEARCH_TIME);
	printf("c Best= %d, #Best= %"BIG_FORMAT", Depth= %.2f, Bp= %.3f\n",MIN_NB_UNSAT_CLAUSE,NB_MIN,AVER_DEPTH,AVER_BP);
#if WIN32
#else
	exit(NONE);
#endif
}

int my_cmp(const void *a,const void *b) {
	return (*((double *)(a))>*((double *)(b))) ? (1) : (-1);
}

int build_simple_sat_instance(char *input_file) {
	FILE *fp_in;
	char ch,word2[WORD_LENGTH];
	int i,j,k,l,flag,length,temp,lit,lits[CLAUSE_MAX_LENGTH],*lits1,total_length=0;
	fp_in=fopen(input_file,"r");
	if(NULL==fp_in) {
		printf("c Failed to read the file.\n");
		return FALSE;
	}
	if(fscanf(fp_in,"%c",&ch)!=1) {
		printf("c error_fscanf1...\n");
	}
	while(ch!='p') {
		while(ch!='\n') {
			if(fscanf(fp_in,"%c",&ch)!=1) {
				printf("c error_fscanf2...\n");
			}
		}
		if(fscanf(fp_in,"%c",&ch)!=1) {
			printf("c error_fscanf3...\n");
		}
	}
	if(fscanf(fp_in,"%s%d%d",word2,&NB_VAR,&NB_CLAUSE)!=3) {
		printf("c error_fscanf4...\n");
	}
	if((NB_VAR>=MAX_NB_VAR-1) || (NB_CLAUSE>=MAX_NB_CLAUSE-1)) {
		printf("c Too large CNF.\n");
		exit(NONE);
	}
	for(i=1;i<=NB_VAR;i++) {
		pos_nb[i]=0;
		neg_nb[i]=0;
	}
	for(i=1;i<=NB_CLAUSE;i++) {
		length=0;
		if(fscanf(fp_in,"%d",&lits[length])!=1) {
			printf("c error_fscanf5...\n");
		}
		while(lits[length]) {
			if(EOF==(fscanf(fp_in,"%d",&lits[++length]))) {
				printf("c Error in the input file.\n");
				exit(NONE);
			}
		}
		flag=FALSE;
		for(j=0;j<length-1;j++) {
			lit=lits[j];
			for(k=j+1;k<length;k++) {
				if(abs(lit)>abs(lits[k])) {
					temp=lits[k];
					lits[k]=lit;
					lit=temp;
				}else if(lit==lits[k]) {
					lits[k]=lits[length-1];
					k--;
					length--;
					lits[length]=0;
				}else if(abs(lit)==abs(lits[k])) {
					flag=TRUE;
					break;
				}
			}
			if(TRUE==flag) {
				break;
			}else {
				lits[j]=lit;
			}
		}
		if(FALSE==flag) {
			clauses[i]=(int *)malloc((2*length+1)*sizeof(int));
			if(NULL==clauses[i]) {
				printf("c error_malloc3...\n");
			}
			for(l=0;l<length;l++) {
				lit=lits[l];
				if(lit>0) {
					pos_nb[lit]++;
				}else if(lit<0) {
					neg_nb[-lit]++;
				}else {
					printf("c Error in the input file.\n");
					return FALSE;
				}
				clauses[i][2*l]=(lit>0) ? (lit) : (-lit);
				clauses[i][2*l+1]=(lit>0) ? (TRUE) : (FALSE);
			}
			clauses[i][2*length]=NONE;
			clause_length[i]=length;
			clause_static_length[i]=length;
			total_length+=length;
		}else {
			i--;
			NB_CLAUSE--;
		}
	}
	K=total_length/NB_CLAUSE;
	fclose(fp_in);
	for(i=1;i<=NB_VAR;i++) {
		pos_in[i]=(int *)malloc((pos_nb[i]+1)*sizeof(int));
		neg_in[i]=(int *)malloc((neg_nb[i]+1)*sizeof(int));
		if((NULL==pos_in[i]) || (NULL==neg_in[i]))
			printf("c errof_malloc1...\n");
		pos_in[i][pos_nb[i]]=NONE;
		neg_in[i][neg_nb[i]]=NONE;
		pos_nb[i]=0;
		neg_nb[i]=0;
	}
	for(i=1;i<=NB_CLAUSE;i++) {
		lits1=clauses[i];
		for(lit=*lits1;lit!=NONE;lit=*(lits1+=2)) {
			if(TRUE==*(lits1+1)) {
				pos_in[lit][pos_nb[lit]++]=i;
			}else if(FALSE==*(lits1+1)) {
				neg_in[lit][neg_nb[lit]++]=i;
			}else {
				printf("c Error in the input file.\n");
				return FALSE;
			}
		}
		if(clause_length[i]!=K) {
			CRAFTED_FLAG=TRUE;
		}
	}
	return TRUE;
}

void free_memory(void) {
	int i;
	for(i=1;i<=NB_VAR;i++) {
		free(pos_in[i]);
		free(neg_in[i]);
	}
	for(i=1;i<=NB_CLAUSE;i++) {
		free(clauses[i]);
	}
}

void time_start(void) {
#if WIN32
	begintime=clock();
#else 
	a_tms=(struct tms *)malloc(sizeof(struct tms));
	mess=times(a_tms);
	begintime=a_tms->tms_utime+a_tms->tms_stime;
#endif
}

void time_end(void) {
#if WIN32
	endtime=clock();
	SEARCH_TIME=(endtime-begintime)*1.0/CLK_TCK;
#else
	mess=times(a_tms);
	endtime=a_tms->tms_utime+a_tms->tms_stime;
	SEARCH_TIME=(endtime-begintime)*1.0/sysconf(_SC_CLK_TCK);
#endif
}

int verify_solution(void) {
	int i,j,clause,count;
	for(i=1;i<=NB_CLAUSE;i++) {
		clause_length[i]=clause_static_length[i];
	} 
	for(i=1,count=0;i<=NB_VAR;i++) {
		if(TRUE==solution[i]) {
			for(j=0;neg_in[i][j]!=NONE;j++) {
				clause=neg_in[i][j];
				if(clause_length[clause]>0) {
					clause_length[clause]--;
				}
				else if(clause_length[clause]<0) {
					printf("c error_verify_solution1...\n");
				}
				if(!clause_length[clause]) {
					count++;
				}
			}
		}else {
			for(j=0;pos_in[i][j]!=NONE;j++) {
				clause=pos_in[i][j];
				if(clause_length[clause]>0) {
					clause_length[clause]--;
				}
				else if(clause_length[clause]<0) {
					printf("c error_verify_solution2...\n");
				}
				if(!clause_length[clause]) {
					count++;
				}
			}
		}
	}
	if(!count)
		return TRUE;
	else {
		printf("c %d clauses are UNSAT!\n",count);
		for(i=1;i<=NB_CLAUSE;i++) {
			if(!clause_length[i])
				printf("c #%d is UNSAT!\n",i);
		}
		return FALSE;
	}
}

void scanone(int argc,char *argv[],int i,int *varptr) {
	if((i>=argc) || (sscanf(argv[i],"%i",varptr)!=1)) {	
		fprintf(stderr,"c Bad argument %s\n",(i<argc) ? argv[i] : argv[argc-1]);
		exit(NONE);
	}
}

char* get_file_name(char *input) {
	char c,*temp_input;
	int nb,temp_nb;
	temp_input=input; 
	nb=0;
	for(c=*temp_input;c!='\0';c=*(temp_input+=1)) 
		if(c=='/') 
			nb++;
	temp_input=input; 
	temp_nb=0;
	for(c=*temp_input;c!='\0';c=*(temp_input+=1)) {
		if(c=='/') 
			temp_nb++;
		if(nb==temp_nb)
			return temp_input+1;
	}
	return temp_input;
}

void print_solution(void) {
	int i;
	printf("v ");
	for(i=1;i<=NB_VAR;i++) {
		if(FALSE==solution[i]) {
			printf("-");
		}
		printf("%d",i);
		if(!(i%10)) {
			printf("\nv ");
		}else {
			printf(" ");
		}
	}
	printf("0\n");
}
