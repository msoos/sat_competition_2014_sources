#!/bin/sh

mkdir binary

cd code

gcc -O3 -static BalancedZ.c -o BalancedZ

mv BalancedZ ../binary

