/***********************************************************************************[SimpSolver.cc]
Copyright (c) 2006,      Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "mtl/Sort.h"
#include "loceg/provoSATeur_Solver.h"
#include "utils/System.h"

using namespace Minisat;

//=================================================================================================
// Options:


static const char* _cat = "provoSATeur";


//=================================================================================================
// Constructor/Destructor:


provoSATeur_Solver::provoSATeur_Solver(): debugon(true)
{

}


provoSATeur_Solver::~provoSATeur_Solver()
{
}


Var provoSATeur_Solver::newVar(bool sign, bool dvar) {
    Var v = Solver::newVar(sign, dvar);

    //analyseoccurs[v]=0;
    return v;
}




bool provoSATeur_Solver::addClause_(vec<Lit>& ps)
{
	//if(debugon) printf("[%s] Clauses b %i\n",_cat, clauses.size());
	CRef cr = ca.alloc(ps, false);
	clauses.push(cr);
	attachClause(cr);
	//if(debugon) printf("[%s] Clauses b %i\n",_cat, clauses.size());

    return true;
}

bool provoSATeur_Solver::analyse(std::vector<int> dirties)
{
	maxvar = 0;
	maxocc = 0;
	minvar = 0;
	minocc = 10000.0;
	//analyseoccurs.clear(false);

	if(debugon) printf("[%s] Analyse START\n", _cat);
	if(debugon) fflush(stdout);
	for(int i = 0; i < nVars(); i++)
	{
		analyseoccurs[i]=0.0;
	}


	if(dirties.size()>=(size_t)nVars()) return false;

	for(int i = 0; i < Solver::clauses.size(); i++)
	{
		Clause& c = ca[clauses[i]];
		//if(debugon) printf("[%s] pos %i size %i clause %i\n", _cat, i, Solver::clauses.size(), c.size());
		//		if(debugon) fflush(stdout);

		//TEST maxocc in L2
		if(c.size()!=2) continue;
		for (int i = 0; i < c.size(); i++){
			//if(i==0) {
				//if(debugon) printf("[%s]  %i \n", _cat, var(c[i]));
				//			if(debugon) fflush(stdout);
			//}
			if(!vecHas(var(c[i]), dirties))
			{
				//printf("[%s] %i(%i) ", var(c[i]), analyseoccurs[var(c[i])].size());
				analyseoccurs[abs(var(c[i]))] = analyseoccurs[abs(var(c[i]))] + (1.0/c.size());

				if(analyseoccurs[abs(var(c[i]))] > maxocc)
				{
					maxvar = abs(var(c[i]));
					maxocc = analyseoccurs[abs(var(c[i]))];
				}
				if(analyseoccurs[abs(var(c[i]))] < minocc)
				{
					minvar = abs(var(c[i]));
					minocc = analyseoccurs[abs(var(c[i]))];
				}
			}
		}
		//printf("[%s] \n");

	}
//	if(debugon) printf("[%s] Maxvar %i with %i occs\n", _cat, toInt(maxvar), maxocc);
//	if(debugon) fflush(stdout);
	//std::cin.ignore();
	return true;
}

bool provoSATeur_Solver::containsClause(std::vector<CRef>& cl, CRef cr)
{
	//printf("[%s] cl %i\n", _cat,cl.size());
	/* for(int i = 0; i < cl.size(); i++)
	 {

		Clause& c = ca[cl[i]];
		for (int j = 0; j < c.size(); j++)
				printf("[%s] %i ", _cat, var(c[j]));

		printf("[%s] \n");

	 }*/
	//printf("[%s] cr\n");

	for(size_t i = 0; i < cl.size(); i++)
	{
		CRef c = cl[i];
		if(sameClause(cr, c))
		{
		//	printf("[%s] true");
			return true;
		}
	}

	//printf("[%s] false\n");
	return false;
}


bool provoSATeur_Solver::sameClause(CRef& c1, CRef& c2)
{
	Clause& cc1 = ca[c1];
	Clause& cc2 = ca[c2];
	if (cc1.size() != cc2.size())
	{
		//printf("[%s] not same size\n");
		return false;
	}

	//Lit        ret = lit_Undef;
	const Lit* c   = (const Lit*)cc1;
	const Lit* d   = (const Lit*)cc2;

	bool found = false;
	for (int i = 0; i < cc1.size(); i++) {
		// search for c[i] or ~c[i]
		found = false;
		for (int j = 0; j < cc2.size(); j++)
			if (c[i] == d[j])
				found = true;
		if(!found) return false;
	}

	return found;
}


bool provoSATeur_Solver::clauseHasVar(CRef& c1, int maxvar)
{

	Clause& cc1 = ca[c1];

	for (int i = 0; i < cc1.size(); i++) {
		if (var(cc1[i]) == maxvar)
			return true;
	}

	return false;
}

/*int provoSATeur_Solver::getModus()
{
	if(modus==ALL)
		{
			return INT32_MAX;
		} else if(modus==UNIT )
		{
			return 1;
		} else if(modus==SAT2)
		{
			return 2;
		}
		else if(modus == SAT3)
		{
			return 3;
		} else
		{
			return 100;
		}
}
*/
std::vector<CRef> provoSATeur_Solver::getSubinstance(int maxclauses)
{
	std::vector<CRef> subinst;
	//printf("[%s] Maxvar %i", _cat, maxvar);

	for(int i = 0; i < clauses.size(); i++)
	{
		if(clauseHasVar(clauses[i], maxvar) && !containsClause(subinst, clauses[i]))
		{
			subinst.push_back(clauses[i]);
			if(debugon) {
				Clause& cc1 = ca[clauses[i]];

				printf("[%s] Subsinstance Clause ", _cat);
				for(int j = 0; j < cc1.size(); j++)
				{
					printf(" %i", convertLiteral(cc1[j]));
				}
				printf("\n");
			}
		}

		if(subinst.size() > (size_t)maxclauses) break;
	}
	if(debugon)
	{
		printf("Subsinstance done\n");
		fflush(stdout);
	}
	return subinst;
}


std::vector<CRef> provoSATeur_Solver::getSubinstance(int maxclauses, int varib)
{
	std::vector<CRef> subinst;
	//printf("[%s] Maxvar %i", _cat, maxvar);

	for(int i = 0; i < clauses.size(); i++)
	{
		if(clauseHasVar(clauses[i], varib) && !containsClause(subinst, clauses[i]))
		{
			subinst.push_back(clauses[i]);
			if(debugon) {
				Clause& cc1 = ca[clauses[i]];

				printf("[%s] Subsinstance Clause ", _cat);
				for(int j = 0; j < cc1.size(); j++)
				{
					printf(" %s%i", sign(cc1[j])?"-":"", var(cc1[j]));
				}
				printf("\n");
			}
		}

		if(subinst.size() > (size_t)maxclauses) break;
	}
	if(debugon)
	{
		printf("Subsinstance done\n");
		fflush(stdout);
	}
	return subinst;
}

std::vector<CRef> provoSATeur_Solver::getSubinstanceMin(int maxclauses)
{
	std::vector<CRef> subinst;
	//printf("[%s] Maxvar %i", _cat, maxvar);

	for(int i = 0; i < clauses.size(); i++)
	{
		if(clauseHasVar(clauses[i], minvar) && !containsClause(subinst, clauses[i]))
		{
			subinst.push_back(clauses[i]);
			if(debugon) {
				Clause& cc1 = ca[clauses[i]];

				printf("[%s] Subsinstance Clause ", _cat);
				for(int j = 0; j < cc1.size(); j++)
				{
					printf(" %s%i", sign(cc1[j])?"-":"", var(cc1[j]));
				}
				printf("\n");
			}
		}

		if(subinst.size() > (size_t)maxclauses) break;
	}
	if(debugon)
	{
		printf("Subsinstance done\n");
		fflush(stdout);
	}
	return subinst;
}

std::vector<std::vector<Lit> > provoSATeur_Solver::makeNeg(std::vector<CRef> subinst)
{
	std::vector<std::vector<Lit> > Lits;
	for(size_t i = 0; i < subinst.size(); i++)
	{
		std::vector<std::vector<Lit> > nl;
		if(i==0)
		{

			Clause& c = ca[subinst[i]];
			for(int j = 0; j < c.size(); j++)
			{
				Lit l = ~c[j];
				std::vector<Lit> nnl;
				nnl.push_back(l);
				nl.push_back(nnl);
			}
		} else {
			Clause& c = ca[subinst[i]];
			for(int j = 0; j < c.size(); j++)
			{
				Lit l = ~c[j];
				for(size_t k = 0; k < Lits.size(); k++)
				{
					std::vector<Lit> nnl;
					nnl = Lits[k];
					if(!vecHasNeg(l, nnl))
					{
						if(!vecHas(l, nnl))
						{
							nnl.push_back(l);
						}
						nl.push_back(nnl);
					}
				}

			}

		}
		Lits = nl;
	}
	return Lits;
}

std::vector<std::vector<Lit> > provoSATeur_Solver::makeLits(std::vector<CRef> subinst)
{
	std::vector<std::vector<Lit> > Lits;
	for(size_t i = 0; i < subinst.size(); i++)
	{
		std::vector<Lit>  nl;

		Clause& c = ca[subinst[i]];
		for(int j = 0; j < c.size(); j++)
		{
			Lit l = c[j];
			nl.push_back(l);
		}

		Lits.push_back(nl);
	}
	return Lits;
}

std::vector<Lit> provoSATeur_Solver::getSubvariables(std::vector<std::vector< Lit > > Lits)
{
	std::vector<Lit> subvariables;
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	while(it != Lits.end())
	{
// 			vec<Lit> cl;
		//int     varl;
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
// 				cl.push((*it2));
			//varl = var((*it2));
			if(!vecHas(*it2, subvariables))
			{
				subvariables.push_back(*it2);
				subvariables.push_back(~(*it2));
			}
			it2++;

		}
// 			nS.addClause_(cl);
		it++;
	}
	return subvariables;
}



void provoSATeur_Solver::solverInit(Solver &nS, std::vector<std::vector<Lit> > Lits)
{
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	while(it != Lits.end())
	{
		vec<Lit> cl;
		int     varl;
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
			cl.push((*it2));
			varl = var((*it2));
		/*	if(!vecHas(varl, subvariables))
			{
				subvariables.push_back(varl);
			} */
			while (varl >= nS.nVars()) nS.newVar();
			it2++;

		}
		nS.addClause_(cl);
		it++;
	}
}

Lit provoSATeur_Solver::getNextLit(std::vector<std::vector<Lit> >& Lits,
		std::vector<Lit> variabs,
		std::vector<Lit> sets,
		std::vector<Lit> done)
{
	if(debugon){
			printf("[%s] Nextvar start\n", _cat);
			fflush(stdout);
		}
	Lit n = lit_Undef;
	std::vector<Lit> shortest = Lits[0];
	int min = 100;
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	while(it!=Lits.end())
	{
		std::vector<Lit>::iterator it2 = (*it).begin();
		int tmin = 0;
		while(it2 != (*it).end())
		{
			if(vecHas(*it2, sets) || vecHas(*it2, done)|| vecHasNeg(*it2, done))
			{

			} else {
				tmin ++;
			}
			it2++;
		}
		if(tmin > 1 && tmin < min)
		{
			shortest = *it;
		}
		it++;
	}
	std::vector<Lit>::iterator v = shortest.begin();
	while(v!=shortest.end())
	{
		if(vecHas(*v, sets)|| vecHas(*v, done)|| vecHasNeg(*v, done))
		{
			// already set
		} else {
			if(debugon){
				printf("[%s] Nextvar is %i\n", _cat, convertLiteral(*v));
				fflush(stdout);
			}
			return *v; }
		v++;
	}
	if(debugon){
		printf("[%s] No Nextvar is \n", _cat);
		fflush(stdout);
	}
	return n;
}

void provoSATeur_Solver::calcProvSolutions(std::vector<std::vector<Lit> >& Lits, std::vector<std::vector<Lit> >& solutions)
{

	//double starttime = cpuTime();
	std::vector<Lit> done;
	std::vector<Lit> subvariables = getSubvariables(Lits);
	if(debugon){
		printf("[%s] Solutions start\n", _cat);
		fflush(stdout);
	}
	std::vector<Lit> p;
	for(size_t j = 0; j < Lits.size(); j++)
	{

		// Kluge auswahl treffen welche Variable als n��chstes belegt wird
		// CLuster Vivification
		Lit next = getNextLit(Lits, subvariables, p, done);
		if(next == lit_Undef)
		{
			return;
		}
		done.push_back(next);
		//if(vecHas(subvariables[j], p)) continue;
		//p.push_back(subvariables[j]);
		p.push_back(~next);
		if(debugon){
			printf("[%s] Look for Conf: %i\n", _cat, var(subvariables[j]));
			fflush(stdout);
		}
		if(isConf(Lits, p))
		{
			/*if(debugon){
				printf("[%s] Is Conflict: %i\n", _cat, var(subvariables[j]));
				fflush(stdout);
				std::cin.ignore();
			}*/
			if(!vecHas(Lits, p))
				solutions.push_back(p);
		}
		//p.clear();
	}
	if(debugon){
		printf("[%s] Solutions done %i\n", _cat, (int)solutions.size());
		fflush(stdout);
	}
}

bool provoSATeur_Solver::isSat(std::vector<std::vector<Lit > >& Lits, std::vector<int> sets)
{
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	outer: while(it!=Lits.end())
	{
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
			for(size_t i = 0; i < sets.size(); i++)
			{
				if(abs(sets[i])==var(*it2) && sign(*it2)==(sets[i] < 0))
				{
					it++;
					goto outer; // Klausel erfuellt
				}
			}
			it2++;
		}
		return false; // Klausel nicht erfuellt
	}
	return true; // wenn es keine Klausel gibt die nicht erf�llt war, ist alles SAT
}


bool provoSATeur_Solver::isConf(std::vector<std::vector<Lit > >& Lits, std::vector<Lit> sets)
{
	Lit nset = hasUnit(Lits, sets);
	while(nset!=lit_Undef)
	{

		if(debugon)
				printf("[%s] next nset %i\n",_cat, convertLiteral(nset));
		// konflikt
		if(hasConflict(Lits, sets))
		{
			if(debugon)
			{
				printf("Conflict found\n");
				//std::cin.ignore();
			}
			return true;
		}
		// belegen
		sets.push_back(nset);
		nset=hasUnit(Lits, sets);
	}
	if(debugon)
			printf("[%s] last nset %i\n",_cat, convertLiteral(nset));

	if(hasConflict(Lits, sets))
			{
				if(debugon)
				{
					printf("Conflict found\n");
					//std::cin.ignore();
				}
				return true;
			}
		if(debugon)
		printf("No Conflict found");
	return false;
}

int provoSATeur_Solver::convertLiteral(Lit l)
{
	if(sign(l))
	{
		return 0-var(l);
	} else {
		return var(l);
	}
}

Lit provoSATeur_Solver::hasUnit(std::vector<std::vector<Lit > >& Lits, std::vector<Lit> sets)
{
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	outer: while(it!=Lits.end())
	{
		//if(debugon)
		//	printf("[%s]Check Clause \n", _cat);
		std::vector<Lit>::iterator it2 = (*it).begin();
		int counter = 0;
		Lit unit = lit_Undef;
		inner: while(it2!=(*it).end())
		{
			//if(debugon)
			//	printf("[%s] Lit %i \n", _cat, convertLiteral(*it2));

			for(size_t i = 0; i < sets.size(); i++)
			{
				if(sets[i]==(*it2))
				{
					//if(debugon)
					//	printf("[%s] found satlit %i %i\n", _cat, convertLiteral(*it2), convertLiteral(sets[i]));
					it++;
					goto outer;
				}
				if(var(sets[i])==var(*it2))
				{
					it2++;
					goto inner;
				}
			}
			unit = *it2;
			it2++;
			counter ++;
		}
		//if(debugon)printf("[%s] Counter %i Unit: %i\n", _cat,  counter, convertLiteral(unit));
		if(counter == 1)
			return unit;
		it++;
	}
	return lit_Undef;
}

bool provoSATeur_Solver::hasConflict(std::vector<std::vector<Lit > >& Lits, std::vector<Lit> sets)
{
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
//	bool conflict = true;
	if(debugon)
	{
		for(int i = 0; i < (int)sets.size(); i ++)
		{
			printf("[%s] SETS %i",_cat, convertLiteral(sets[i]));
		}
	}
	//if(debugon)
		//printf("[%s] hasConflict\n", _cat);
	outer: while(it!=Lits.end())
	{
		// fuer jede Klausel
		std::vector<Lit>::iterator it2 = (*it).begin();
		int counter = 0;
//		int unit = 0;

		inner: while(it2!=(*it).end())
		{
			// f�r jedes literal
			//if(debugon)
			//		printf("[%s] check %i \n", _cat, convertLiteral(*it2));
			for(size_t i = 0; i < sets.size(); i++)
			{
				if(var(sets[i])==var(*it2))
				{
//if(debugon)
	//printf("[%s] gleiche Variable %i set %i\n", _cat,convertLiteral(*it2), convertLiteral(sets[i]));
					if(sets[i]==(*it2))
					{
		//				if(debugon)
			//				printf("[%s] SAT Variable %i %i \n", _cat, convertLiteral(sets[i]), convertLiteral(*it2));
						// Klausel erf�llt
						it++;
						goto outer;
					} else {
						it2++;
						goto inner;
					}

				}
			}
			// wenn hier, dann offene variable vorhanden

			it2++;
			counter ++;
		}
		if(counter > 0)
		{
			//mind ein unerf�lltes Literal-> kein Konflikt
			// auf zur n�chsten Klausel
		} else {
			// unsat clause
			return true;
		}
		it++;
	}
	return false;
}


void provoSATeur_Solver::startLearn(int maxiters)
{
	// LoCEG LOOP wie im Paper
	double starttime = cpuTime();
	int maxclauses = 10;
//	int maxsub = getModus();

	std::vector<int> dirties;

	analyseoccurs = new double[nVars()];
	for (int iters = 0; iters < maxiters; iters++)
	{
		if(debugon)printf("[%s] started Iteration %i %i\n", _cat,iters, maxiters);
		if(debugon)fflush(stdout);

		std::vector<CRef> subinst;

		if(!analyse(dirties))
		{
			return;
		}

		//subinst = getSubinstanceMin(maxclauses);
		//dirties.push_back(minvar);

		subinst = getSubinstance(maxclauses);
		dirties.push_back(maxvar);

		/*int randvar = 0;
		while(randvar == 0 || vecHas(randvar, dirties) || randvar > nVars())
		{
			randvar = rand();
		}
		subinst = getSubinstance(maxclauses, randvar);
		dirties.push_back(randvar);
		if(debugon)printf("[%s] Using randvar %i", _cat, randvar);
		*/



		//std::vector<std::vector<Lit> > Lits = makeNeg(subinst);
		std::vector<std::vector<Lit> > Lits = makeLits(subinst);


		//std::vector<int> subvariables = getSubvariables(Lits);
		//std::vector<std::vector<int> > solutions;
		std::vector<std::vector<Lit> > solutions;
		calcProvSolutions(Lits, solutions);


		//std::vector<vec<Lit> > added;
		for(size_t j=0; j < solutions.size(); j++)
		{

			vec<Lit> nlits;

			if(solutions[j].size() > 3) continue;
			for (size_t i = 0; i < solutions[j].size(); i++)
			{
				Lit l = ~(solutions[j][i]);// ? ~mkLit(solutions[j][i]) : mkLit(solutions[j][i]);
				if(debugon)
					printf("[%s] Sol %i \n", _cat, convertLiteral(l));// NEGIERT
				nlits.push( l );
			}


			if(nlits.size()>0)
			{
				if(debugon)printf("[%s] adding %i\n", _cat, nlits.size());
							if(debugon)fflush(stdout);
				addClause_(nlits);
			}
			if(debugon)printf("[%s] Number of clauses %i\n", _cat, nClauses());
			if(debugon)fflush(stdout);
		}

		if(debugon)printf("[%s] Out Iteration %i %i\n", _cat,iters, maxiters);
		if(debugon)fflush(stdout);

		if( cpuTime() -starttime  > 5*60)
		{
			printf("[%s] Because of Runtime Out in Iteration %i %i\n", _cat,iters, maxiters);
			break;
		}
	}

	if(debugon)printf("[%s] loceg done\n", _cat);
	if(debugon)fflush(stdout);
}

void provoSATeur_Solver::makeAssumption(std::vector<int> vars, vec<Lit> &ret)
{

	for(unsigned int i = 0; i < vars.size(); i++)
	{
		Lit l = mkLit(vars[i], true);//vars[i]<0);
		ret.push(l);
	}
}

void provoSATeur_Solver::copyVec(std::vector<int> &in, std::vector<int> &out)
{
	for(unsigned int i = 0 ; i < in.size(); i++)
	{
		out.push_back(in[i]);
	}
}

bool provoSATeur_Solver::vecHas(int needle, std::vector<std::vector<Lit> > haystack)
{
	std::vector<std::vector<Lit> >::iterator it = haystack.begin();

	while(it!=haystack.end())
	{
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
			if(var((*it2))==needle)
			{
				return true;
			}
			it2++;
		}
		it++;
	}


	return false;
}

bool provoSATeur_Solver::sameVec(vec<Lit>& l1, vec<Lit>& l2)
{
	if(l1.size()!=l2.size()) return false;
	for(int i = 0; i < l1.size(); i++)
	{
		if(l1[i]!=l2[i]) return false;
	}
	return true;
}


bool provoSATeur_Solver::sameVec(std::vector<Lit>& l1, std::vector<Lit>& l2)
{
	if(l1.size()!=l2.size()) return false;
	for(int i = 0; i < l1.size(); i++)
	{
		if(l1[i]!=l2[i]) return false;
	}
	return true;
}

bool provoSATeur_Solver::vecHas(std::vector<vec<Lit> >& haystack, vec<Lit>& needle)
{
	std::vector<vec<Lit> >::iterator it = haystack.begin();

	while(it!=haystack.end())
	{
		for(int i = 0; i < (*it).size(); i++)
		{
			if(sameVec(it[i], needle))
				return true;
		}
		it++;
	}
	return false;
}
bool provoSATeur_Solver::vecHas(std::vector<std::vector<Lit> >& haystack, std::vector<Lit>& needle)
{
	std::vector<std::vector<Lit> >::iterator it = haystack.begin();

	while(it!=haystack.end())
	{
		for(int i = 0; i < (*it).size(); i++)
		{
			if(sameVec(it[i], needle))
				return true;
		}
		it++;
	}
	return false;
}

bool provoSATeur_Solver::vecHasNeg(Lit needle, std::vector<Lit> haystack)
{
	std::vector<Lit>::iterator it = haystack.begin();
	while(it!=haystack.end())
	{
		if(var((*it))==var(needle) && sign(needle) != sign((*it)))
		{
			return true;
		}
		it++;
	}
	return false;
}
bool provoSATeur_Solver::vecHas(int needle, std::vector<int> haystack)
{

	for(size_t i = 0; i < haystack.size(); i++)
	{
		if(abs(needle) == abs(haystack[i])) return true;
	}
	return false;
}

bool provoSATeur_Solver::vecHas(Lit needle, vec<Lit>& haystack)
{
	for(int i = 0; i < haystack.size(); i++)
	{
		if(var(haystack[i])==var(needle)) return true;
	}
	return false;
}



bool provoSATeur_Solver::vecHas(Lit needle, std::vector<Lit> haystack)
{
	std::vector<Lit>::iterator it = haystack.begin();
	while(it!=haystack.end())
	{
		if(var((*it))==var(needle) && sign(needle) == sign((*it)))
		{
			return true;
		}
		it++;
	}
	return false;
}
