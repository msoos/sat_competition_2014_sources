/************************************************************************************[SimpSolver.h]
Copyright (c) 2006,      Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#ifndef Minisat_LoCEGSolver_h
#define Minisat_LoCEGSolver_h

#include <vector>
#include <cmath>
#include <iostream>
#include <string>
#include <stddef.h>
#include "mtl/Queue.h"
#include "core/Solver.h"
#include "utils/Options.h"

namespace Minisat {

//=================================================================================================



class provoSATeur_Solver : public Solver {
 public:
    // Constructor/Destructor:
    //
    provoSATeur_Solver();
    ~provoSATeur_Solver();

    // Problem specification:
    //
    Var     newVar    (bool polarity = true, bool dvar = true);
    bool    addClause (const vec<Lit>& ps);
    bool    addEmptyClause();                // Add the empty clause to the solver.
    bool    addClause (Lit p);               // Add a unit clause to the solver.
    bool    addClause (Lit p, Lit q);        // Add a binary clause to the solver.
    bool    addClause (Lit p, Lit q, Lit r); // Add a ternary clause to the solver.
    bool    addClause_(      vec<Lit>& ps);
    bool    substitute(Var v, Lit x);  // Replace all occurences of v with x (may cause a contradiction).
    bool 	containsClause(std::vector<CRef>& cl, CRef cr);
    bool 	sameClause(CRef& c1, CRef& c2);
    void 	setModus			(locegmode mode);

    // LoCEG
    void    startLearn   (int maxiters);  // Perform variable elimination based simplification.
    bool 	vecHasNeg(Lit needle, std::vector<Lit> haystack);
    bool 	vecHas(int needle, std::vector<std::vector<Lit> > haystack);
    bool 	vecHas(Lit needle, std::vector<Lit> haystack);
    bool 	vecHas(int needle, std::vector<int> haystack);
    bool 	vecHas(Lit needle, vec<Lit>& haystack);
    bool	vecHas(std::vector<vec<Lit> >& haystack, vec<Lit>& needle);
    bool	vecHas(std::vector<std::vector<Lit> >& haystack, std::vector<Lit>& needle);
    void 	debug(bool debug);
    void 	copyVec(std::vector<int> &in, std::vector<int> &out);
    bool 	sameVec(vec<Lit>& l1, vec<Lit>& l2);
    bool 	sameVec(std::vector<Lit>& l1, std::vector<Lit>& l2);
    void 	makeAssumption(std::vector<int> vars, vec<Lit> &ret);
   // const  char* getMode();

    // Generate a (possibly simplified) DIMACS file:
    //
#if 0
    void    toDimacs  (const char* file, const vec<Lit>& assumps);
    void    toDimacs  (const char* file);
    void    toDimacs  (const char* file, Lit p);
    void    toDimacs  (const char* file, Lit p, Lit q);
    void    toDimacs  (const char* file, Lit p, Lit q, Lit r);
#endif


 protected:

    // Helper structures:
    //
    struct ElimLt {
        const vec<int>& n_occ;
        explicit ElimLt(const vec<int>& no) : n_occ(no) {}

        // TODO: are 64-bit operations here noticably bad on 32-bit platforms? Could use a saturating
        // 32-bit implementation instead then, but this will have to do for now.
        uint64_t cost  (Var x)        const { return (uint64_t)n_occ[toInt(mkLit(x))] * (uint64_t)n_occ[toInt(~mkLit(x))]; }
        bool operator()(Var x, Var y) const { return cost(x) < cost(y); }
        
        // TODO: investigate this order alternative more.
        // bool operator()(Var x, Var y) const { 
        //     int c_x = cost(x);
        //     int c_y = cost(y);
        //     return c_x < c_y || c_x == c_y && x < y; }
    };

    struct ClauseDeleted {
        const ClauseAllocator& ca;
        explicit ClauseDeleted(const ClauseAllocator& _ca) : ca(_ca) {}
        bool operator()(const CRef& cr) const { return ca[cr].mark() == 1; } };


    double* analyseoccurs;

    bool analyse(std::vector<int> dirties);
    bool clauseHasVar(CRef& c1, int maxvar);
    std::vector<CRef> getSubinstance(int maxclauses);
    std::vector<CRef> getSubinstance(int maxclauses, int varib);
    Lit getNextLit(std::vector<std::vector<Lit> >& Lits, std::vector<Lit> variabs, std::vector<Lit> sets, std::vector<Lit> done);
    std::vector<CRef> getSubinstanceMin(int maxclauses);
    std::vector<std::vector<Lit> > makeNeg(std::vector<CRef> subinst);
    std::vector<std::vector<Lit> > makeLits(std::vector<CRef> subinst);
    std::vector<Lit> getSubvariables(std::vector<std::vector< Lit > > Lits);
    void calcProvSolutions(std::vector<std::vector<Lit> > &Lits, std::vector<std::vector<Lit> >& solutions);
    void solverInit(Solver &nS, std::vector<std::vector<Lit> > Lits);
    bool isSat(std::vector<std::vector<Lit > >& Lits, std::vector<int> sets);
    bool isConf(std::vector<std::vector<Lit > >& Lits, std::vector<Lit> sets);
    Lit hasUnit(std::vector<std::vector<Lit > >& Lits, std::vector<Lit> sets);
    bool hasConflict(std::vector<std::vector<Lit > >& Lits, std::vector<Lit> sets);
   // int getModus();
    int convertLiteral(Lit l);
    int maxvar;
    int minvar;
    double maxocc;
    double minocc;
    bool debugon;
   // locegmode modus;
};


//=================================================================================================
// Implementation of inline methods:


inline bool provoSATeur_Solver::addClause    (const vec<Lit>& ps)    { ps.copyTo(add_tmp); return addClause_(add_tmp); }
inline bool provoSATeur_Solver::addEmptyClause()                     { add_tmp.clear(); return addClause_(add_tmp); }
inline bool provoSATeur_Solver::addClause    (Lit p)                 { add_tmp.clear(); add_tmp.push(p); return addClause_(add_tmp); }
inline bool provoSATeur_Solver::addClause    (Lit p, Lit q)          { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); return addClause_(add_tmp); }
inline bool provoSATeur_Solver::addClause    (Lit p, Lit q, Lit r)   { add_tmp.clear(); add_tmp.push(p); add_tmp.push(q); add_tmp.push(r); return addClause_(add_tmp); }
inline void provoSATeur_Solver::debug			(bool debug)			{ debugon = debug; }
//inline void provoSATeur_Solver::setModus			(locegmode mode)			{ modus = mode; }
//inline const  char* provoSATeur_Solver::getMode()	{ switch(modus) { case ALL: return " ALL"; case UNIT: return "UNIT"; case SAT2: return "SAT2"; case SAT3: return "SAT3"; default: return " ALL"; }}
//=================================================================================================
}

#endif
