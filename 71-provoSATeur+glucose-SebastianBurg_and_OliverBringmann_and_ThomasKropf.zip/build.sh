#!/bin/bash
export MROOT=$PWD/code/provoSATeur
#export FM=$PWD/code/glucose_2.1/sources/SatELite/ForMani

mkdir binary


echo "#!/bin/bash" > binary/start.sh
echo "FILENAME=\$1" >> binary/start.sh
echo "TEMPDIR=\$2" >> binary/start.sh
echo "MODE=\$3" >> binary/start.sh
echo "./provoSATeur_static -iterations=200  -dimacs=out.cnf  \$FILENAME ">> binary/start.sh
echo "./glucose_static out.cnf" >> binary/start.sh



#cd code/glucose_2.1/sources/SatELite/SatELite
#make r
#cp SatELite_release ../../../../../binary

cd code/glucose_2.1/sources/glucose/core
make rs
cp glucose_static ../../../../../binary
 
cd $MROOT
cd loceg
make rs
cp provoSATeur_static ../../../binary

