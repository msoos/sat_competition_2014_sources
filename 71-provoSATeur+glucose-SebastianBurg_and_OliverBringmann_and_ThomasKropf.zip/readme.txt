For compiling : 
   sh build.sh


For running 
sh binary/start.sh BENCHNAME 



