#!/bin/bash

mkdir binary

cp code/RSeq2014.sh binary/
cp code/RSeqSattime2014.sh binary/

cd code/sattime2013
gcc sattime2013.c -O3 -static -o sattime
  
mv sattime ../../binary

cd ../relback/core
make clean
make rs
cp relback_static ../../../binary


 
