#!/bin/bash

mkdir -p binary

cd code/pmcsat/simp/
make rs
cp pmcsat_static ../../../binary
 
