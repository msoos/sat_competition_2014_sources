Dimetheus README.

Solver:  Dimetheus
Author:  Oliver Gableske (oliver@gableske.net)
Website: https://www.gableske.net/dimetheus
Version: 2.100
License: See ./license.txt.

In order to compile the solver, simply type
./build.sh
in the root directory of this package (where you found this readme.txt file).

First, the build.sh script will try to compile the solver assuming that the
GCC compiler is available in at least version 4.4. The newer the GCC version,
the better. The binary "dimetheus" can be found in the binary folder.

Second, the build.sh script will attempt to call the binary to output its
version. If you see this version information, then everything should be fine.

The solver was submitted to the RANDOM SAT TRACK of the SAT Competition 2014.
In order to run the solver on formula bla.cnf in the way the solver was used
in the competition, issue the following command:

./dimetheus -formula bla.cnf -seed 101 -classifyInputDomain 10

The formula name obviously depends on the file that contains the formula to
be solved in DIMACS CNF input format. The seed must be a natural number. The
value for the "classifyInputDomain" parameter MUST be set to 10. The parameter
settings will ensure that the solver runs as a sequential core-engine SLS
solver using Message Passing as explained in the solver description.

The reader can find more information regarding the solve on the website
mentioned above. Write the author an email in case problems occur.