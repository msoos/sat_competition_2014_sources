/* DIMETHEUS SAT SOLVER
 * Author: Oliver Gableske (oliver@gableske.net)
 * Website: http://www.gableske.net/dimetheus
 * License: See ./doc/license.txt
 */

#ifndef LICENSE_H_
#define LICENSE_H_

#define DIMETHEUS_LICENSE_HASH "j710Kq94Hcj2x38eE+HKmkxFVBndZZt1lUj1mykxp8NmoYg95YBTFziFttIEP3Wha9E0zC9fJHkz3dV6GIhhmqj5SU8eJgorfjRbGyucz636ciiLSF352AcFr/8wrrZrbX+4NHell4VY/XKf8ECa+orj0N1QPJyebDFGyknKu9g="

#endif /* LICENSE_H_ */
