
/*      DIMETHEUS SAT SOLVER
 *      Author:         Oliver Gableske (oliver@gableske.net), Borislav Junk (borislav.junk@uni-ulm.de)
 *      Website:        http://www.gableske.net/dimetheus
 *      License:        See ./doc/license.txt
 *      THIS FILE IS UNDER CONSTRUCTION AND THEREFORE NOT COMPLETE IN THIS LATEST STABLE RELEASE
 */

#include "satelite.h"

void satelite_resetModule(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_satelite_component_totalCalls;
	#endif
	#ifdef VERBOSE_SATELITE
	printf("c     SATELITE: Component reset...\n");
	#endif
	satelite_returnCode = SATELITE_UNKNOWN;

	#ifdef COLLECTSTATS
	stats_satelite_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void satelite_initModule(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_satelite_component_totalCalls;
	#endif
	#ifdef VERBOSE_SATELITE
	printf("c     SATELITE: Component init...\n");
	#endif
	satelite_returnCode = SATELITE_UNKNOWN;

	#ifdef COLLECTSTATS
	stats_satelite_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void satelite_disposeModule(){
	#ifdef COLLECTSTATS
	float_ty time_start = STATS_GET_CURRENT_TIME_IN_SEC();
	++stats_satelite_component_totalCalls;
	#endif
	#ifdef VERBOSE_SATELITE
	printf("c     SATELITE: Component dispose...\n");
	#endif

	satelite_returnCode = SATELITE_UNKNOWN;
	#ifdef COLLECTSTATS
	stats_satelite_time_total += STATS_GET_CURRENT_TIME_IN_SEC() - time_start;
	#endif
}

void satelite_extern_printVersion(){
	printf("[Preprocessing   ] [Preprocessor                   ] :: %3d.%-4d :: %s",
			SATELITE_VERSION_MA, SATELITE_VERSION_MI, SATELITE_VERSION_NAME);
}


