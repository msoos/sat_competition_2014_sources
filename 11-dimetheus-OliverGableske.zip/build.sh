#!/bin/bash

echo "Starting build operations for Dimetheus..."
echo "Changing directory to ./code/src"
cd ./code/src
echo "Starting compile operations with make"
make
echo "Changing directory to package root"
cd ../../
echo "Creating the binary directory"
mkdir -p binary
rm -rf ./binary/*
echo "Moving the binary to the binary directory"
mv ./code/bin/dimetheus ./binary/dimetheus
echo "Changing directory to ./code/src"
cd ./code/src
echo "Cleaning up."
make clean
echo "Changing directory to package root"
cd ../../
echo " "
echo " "
echo "Calling the Dimetheus binary. If you see the version information then everything worked out fine."
./binary/dimetheus -v
