#!/bin/sh
# Norbert Manthey, 2014
#
# script to build the SAT solver CLaS
#

# setup binary directory
rm -rf binary
mkdir -p binary

cd code/Pcasso;
# build Pcasso
make pcassoRS
cp pcasso ../../binary/

# build Coprocessor
make clean
make coprocessorRS
cp coprocessor ../../binary/

# copy the call scripts
cp scripts/*.sh ../../binary/

# build sparrow
cd ../Sparrow
make sparrow
cp sparrow ../../binary

# copy the call script
cp CPsparrow.sh ../../binary

# copy the portfolio script
cd ..
cp scripts/CLaS.py ../binary

# return to calling directory
cd ..
