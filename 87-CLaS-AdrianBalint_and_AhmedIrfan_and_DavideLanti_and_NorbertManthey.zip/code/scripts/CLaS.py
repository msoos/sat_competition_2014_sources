#!/usr/bin/python
#
# CLaS
# Adrian Balint, Ahmed Irfan, Davide Lanti, Norbert Manthey, 2014
#
# This script runs Pcasso and Sparrow simultaneously to solve the given CNF instance
#

#
# set up the call strings for the two solvers pcasso and sparrow
#
pcassoCallString="./pcasso.sh"
sparrowCallString="./CPsparrow.sh"

#
#
# main program
#
#

# used libraries
import os, signal, subprocess, time
import sys, shutil

#
# usage and current PID
#
print "c CLaS 2014"
print "c Adrian Balint, Ahmed Irfan, Davide Lanti, Norbert Manthey"
print "c an CDCL, Look-Ahead and SLS solver portfolio solver"
print "c based on: Pcasso and Riss (used inside Pcasso) and Sparrow"
print "c used python version: " + str(sys.version)
if( len(sys.argv) < 3 ):
	print "c usage: ./CLaS.py input.cnf seed tmpDirectory"
	sys.exit(0)
print "c run with PID " + str( os.getpid() )


#
# Handle parameters
#
# get input file
#
inputFile=sys.argv[1]
#
# random seed for sparrow
#
randomSeed=sys.argv[2]
#
# setup tmp files
#
tmpDir="/tmp"
if( len(sys.argv) > 3 ):
	tmpDir = sys.argv[3]
#if( tmpDir[-1:] != '/' ):
#	tmpDir = tmpDir + "/"
tmpFile= tmpDir + "/combSolv" + str( os.getpid() )
# let user know that everything has been read correctly
print "c solve " + str(inputFile) + " with tmp files " + tmpFile

#
# start the two solvers, each in its private process group
#
pids=set()
# start pcasso
pcassoCallString=pcassoCallString + " " + inputFile + " " + tmpDir # add CNF file and tmp directory
args = pcassoCallString.split( )	# split the actual command line
print "c call pcasso with " + str(args)
pcassoProcess = subprocess.Popen(args, stdout=open(tmpFile + ".pcasso.out","w"), stderr=open(tmpFile + ".pcasso.err","w"), preexec_fn=os.setpgrp )
pids.add(pcassoProcess.pid)
print "c start pcasso with " + str(pcassoProcess.pid)

# start sparrow
sparrowCallString=sparrowCallString + " " + inputFile + " " + randomSeed + " " + tmpDir # add CNF file and tmp directory
args = sparrowCallString.split( ) # split the actual command line
print "c call sparrow with " + str(args)
sparrowProcess = subprocess.Popen(args, stdout=open(tmpFile + ".sparrow.out","w"), stderr=open(tmpFile + ".sparrow.err","w"), preexec_fn=os.setpgrp )
pids.add(sparrowProcess.pid)
print "c start CPsparrow with " + str(sparrowProcess.pid)

#
# wait until the first solver returns
#
winner=""
winnerCode=0
while pids:
	pid,retval=os.wait()
	print "c finished " + str(pid) + " with return value " + str(retval)
	pids.remove(pid)
	# extract the exit code
	signal = retval & 255
	exitCode = (retval >> 8) & 255
	print "c signal: " + str(signal) + " exit code: " + str(exitCode)
	# if exit code is nice, select the winner
	if signal == 0 and (exitCode == 10 or exitCode == 20 ):
		winnerCode = exitCode				# get exit code
		if pid == pcassoProcess.pid:		# check out the winner
			winner = "pcasso"
		else:
			winner = "sparrow"
		break												# do not wait for the other process as well, if a solution has been found!

#
# output the result
#
if winnerCode != 0:
	print "c winner: " + winner
	
	# for more recent python versions:
	#with open(tmpFile + "." + winner + ".out", "r") as f:
	
	# for the competition 2014 version:
	f = open(tmpFile + "." + winner + ".out", "r")
	if f :
		shutil.copyfileobj(f, sys.stdout)
	
else:
	print "s UNKNOWN"
	

# kill the other process, and its child processes
for p in pids:
 	os.kill(-p, 15)
	
# clean up the temporary files
os.unlink(tmpFile + ".pcasso.err")
os.unlink(tmpFile + ".pcasso.out")
os.unlink(tmpFile + ".sparrow.err")
os.unlink(tmpFile + ".sparrow.out")

# exit with the correct exit code
sys.exit(winnerCode)
