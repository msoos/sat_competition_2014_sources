This software package contains the SAT solver "CLaS"
Adrian Balint, Ahmed Irfan, Davide Lanti, Norbert Manthey, 2014

The SAT solver "CLaS 2014" combines the SLS solver Sparrow with a 
parallel search space partitioning solver Pcasso. Hence, the solver
combines the three dominant CNF solving approaches CDCL, Look-Ahead
and SLS. The first letters of these techniques lead to the name of 
the solver. 

For both solvers, the CNF simplifier Coprocessor is used to simplify
the input formula best for the kind of solver that is attached. 

To build the solve, run the script
	./build.sh
	
To run the solver, use the python script
	./CLaS.py <input.cnf> TMPDIR
	
Note: the current setup uses on core to run Sparrow, and uses 11 cores
to run Pcasso. The number of cores for pcasso can be changed in the
script "pcasso.sh", which is located in code/Pcasso/scripts. There, the
parameter "-threads" is specified on the command line for the SAT solver.
