#!/bin/bash

mkdir binary/

cd ./code/DCCASat+march_rw/
make
cp ./DCCASat+march_rw ../../binary/
make cleanup

cd ../DCCASat_with_cutoff_and_for_random_instances/
make
cp ./DCCASat ../../binary/
make cleanup

cd ../march_rw/
make
cp ./march_rw ../../binary/
make clean

