************ Details about the solver ************
Name: DCCASat+march_rw
Version: SC2014
Authors: Chuan Luo [1], Shaowei Cai [2], Wei Wu [1], Kaile Su [3]
[1] School of EECS, Peking University, Beijing, China.
[2] State Key Laboratory of Computer Science, Institute of Software, Chinese Academy of Sciences, Beijing, China.
[3] IIIS, Griffith University, Brisbane, Australia.
**************************************************

************ How to build the solver *************
Execute the following command:
./build.sh
**************************************************

************ How to use the solver ***************
First, enter the directory 'binary'.
Then execute the following command:
./DCCASat+march_rw <instance> <seed> <cutoff_time>

In SAT Competition 2014, as the cutoff time is 5000 CPU seconds, so the cutoff_time is 5000. The command for SAT Competition 2014 is described as follows.
./DCCASat+march_rw <instance> <seed> 5000
**************************************************
