#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
using namespace std;


int main(int argc, char **argv)
{
	printf("c this is DCCASat+march_rw [Version: SC2014]\n");
	printf("c for random instances\n");
	printf("c many thanks to the march_rw team!\n");
	
	if(argc!=4)
	{
		printf("c Usage: %s <instance> <seed> <cutoff_time>\n", argv[0]);
		return -1;
	}
	
	
	string command = "";
	string inst_str = argv[1];
	string seed_str = argv[2];
	string cutoff_time_str = argv[3];
	
	command = "./DCCASat " + inst_str + " " + seed_str + " " + cutoff_time_str;
	printf("c start DCCASat\n");
	int status = system(command.c_str());
	
	int dccasat_ret = WEXITSTATUS(status);
	
	if(dccasat_ret!=0)
	{
		command = "./march_rw " + inst_str;
		printf("c start march_rw\n");
		status = system(command.c_str());
	}
	
	
	return 0;
}

