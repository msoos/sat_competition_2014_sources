#!/bin/bash
#
# Build script for the predictor jar file
#
javac -cp *:. -source 5 -target 5 Predictor.java
jar cvf predictor.jar Predictor.class
