package predictor;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.Instances;
import weka.core.SerializationHelper;

public class Predictor {

	private String modelPath;
	private String configPath;
	private String datasetPath;	
	private boolean nonZero;
	
	private String[] configNames;
	
	private Instances unlabeled;

	public static void main(String[] args) {
		Predictor mine = new Predictor();
		int pos=0;
		mine.setDatasetPath(args[pos++]);
		mine.setModelPath(args[pos++]);
		mine.setConfigPath(args[pos++]);
		mine.setNonZero(new Boolean(args[pos++]));
		try {
			mine.predict();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	private void predict() throws Exception {
		readDataset();
		readConfigs();
		double mprob = -1;
		String pred="";
		int predIndex = -1;
		for (int i = 0; i < configNames.length; i++) {
			Classifier c = getClassifier(configNames[i]);
			double prob = getGoodProb(c,configNames[i]);
			if (prob>mprob){
				mprob = prob;
				pred = configNames[i];
				predIndex = i;
			}
			System.err.println("c prob for "+configNames[i]+" = "+prob);
		}
		if (!nonZero || mprob > 0){
			System.out.println("@class "+pred);
			System.out.println("@classIndex "+predIndex);
		}
	}

	private void readDataset() throws FileNotFoundException, IOException {
		unlabeled = new Instances(new BufferedReader(new FileReader(datasetPath)));
	}
	
	private double getGoodProb(Classifier classifier, String config)
			throws Exception {
		// label instances
		int i = 0;
		double[] probs = classifier.distributionForInstance(unlabeled
				.instance(i));
		int index = getMax(probs);
		// unlabeled.classAttribute().value(index)
		Attribute att = unlabeled.attribute(config + "_class");
		String value = att.value(index);
		if (value.equals("bad"))
			return 1 - probs[index];
		else
			return probs[index];

	}

	private int getMax(double[] probs) {
		int pos = 0;
		for (int i = 1; i < probs.length; i++) {
			if (probs[i]>probs[pos]){
				pos=i;
			}
		}
		return pos;
	}

	private Classifier getClassifier(String config) throws FileNotFoundException, Exception{
		return (Classifier) SerializationHelper.read(new FileInputStream(modelPath+config+".model"));
	}
	
	private void readConfigs() throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(configPath));
		configNames = in.readLine().split(" ");
	}

	public String getModelPath() {
		return modelPath;
	}

	public void setModelPath(String modelPath) {
		this.modelPath = modelPath;
	}

	public String getConfigPath() {
		return configPath;
	}

	public void setConfigPath(String configPath) {
		this.configPath = configPath;
	}

	public String getDatasetPath() {
		return datasetPath;
	}

	public void setDatasetPath(String datasetPath) {
		this.datasetPath = datasetPath;
	}

	public boolean isNonZero() {
		return nonZero;
	}

	public void setNonZero(boolean nonZero) {
		this.nonZero = nonZero;
	}

	public String[] getConfigNames() {
		return configNames;
	}

	public void setConfigNames(String[] configNames) {
		this.configNames = configNames;
	}

	public Instances getUnlabeled() {
		return unlabeled;
	}

	public void setUnlabeled(Instances unlabeled) {
		this.unlabeled = unlabeled;
	}
	
	

}
