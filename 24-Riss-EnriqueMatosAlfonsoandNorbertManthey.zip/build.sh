#!/bin/sh
# Norbert Manthey, 2014
#
# script to build the Riss BlackBox SAT Solver 
#

#
# build all tools for the solver
#

# setup binary directory
rm -rf binary
mkdir -p binary

# build Riss, and copy it to the binary location
cd code/Riss427;
make rissRS ARGS="-DDRATPROOF -DTOOLVERSION=427"
strip riss
cp riss ../../binary/

# build the classifier tool
make cls
strip classifier
cp classifier ../../binary/

# back to the calling directory
cd ../..

#
# copy the required jar files
#
cp code/predictor/Weka/weka-3.6.6.jar binary/
cp code/predictor/java6/predictor.jar binary/

# cpoy all the scripts and the model data required for BlackBox
cp code/BlackBox/scripts/blackbox.sh binary/
cp -r code/BlackBox/model binary/

# done
exit 0
