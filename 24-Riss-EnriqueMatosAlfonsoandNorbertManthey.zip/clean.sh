#!/bin/sh
# Norbert Manthey, 2014
#
# script to clean the SAT solver Riss BlackBox
#

# remove binary directory
rm -rf binary

# clean Riss
cd code/Riss427;
make clean

# return to calling directory
cd ../..
