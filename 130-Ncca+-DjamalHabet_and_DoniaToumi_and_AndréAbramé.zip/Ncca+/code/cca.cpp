#include "basis.h"
#include "cca.h"
#include "cw.h"

#include <sys/times.h> //these two h files are for linux
#include <unistd.h>
#include <limits.h>

int delta_age;

//---------------------------------------------

#define invPhi  5
#define invTheta  2

int lastAdaptFlip, lastBest, AdaptLength;
int NOISE, LNOISE;

int initNoise() {
	
	lastAdaptFlip = 0;
	lastBest = unsat_stack_fill_pointer;
	NOISE=0; 
	LNOISE=0; 
	AdaptLength= num_clauses/ invTheta;
}

void adaptNoveltyNoise(int flip) {
	
	if ((flip - lastAdaptFlip) > AdaptLength) {
		NOISE += (int) ((100 - NOISE) / invPhi);
		LNOISE= (int) NOISE/10;
		lastAdaptFlip = flip;      
		lastBest = unsat_stack_fill_pointer;
	} 
	else 
		if (unsat_stack_fill_pointer < lastBest) {
			NOISE -= (int) (NOISE / invPhi / 2);
			LNOISE= (int) NOISE/10;
			lastAdaptFlip = flip;
			lastBest = unsat_stack_fill_pointer;
		}
}

int get_var_noveltyp(int random_clause_unsat) {
	
	int k, max_nb, nb, var, second_max;
	int best_var, second_best_var;
	int last_flip;
	
	best_var = 0;
	score[best_var]=INT_MIN;
	max_nb = INT_MIN;
	last_flip =-1; 
	
	for (k=0; k<clause_lit_count[random_clause_unsat];k++){
		var = clause_lit[random_clause_unsat][k].var_num;
		nb = score[var];
		if ((nb>max_nb) || ((nb==max_nb) && (time_stamp[var]<time_stamp[best_var]))) {
			second_best_var=best_var; 
			second_max=max_nb; 
			best_var=var; 
			max_nb=nb;
		}
		else 
			if ((nb>second_max) || ((nb==second_max) && (time_stamp[var]<time_stamp[second_best_var]))) {
				second_max=nb; 
				second_best_var=var;
			}
		if (time_stamp[var] > last_flip) 
			last_flip=time_stamp[var];
	}
	if (time_stamp[best_var] == last_flip){
		if (rand()%100 < NOISE)
			return second_best_var;
        
		else return best_var;
		
	}
	return best_var;
}

//---------------------------------------------

int pick_var_large()
{
	int         i,k,c,v;
	int         best_var;
	lit*		clause_c;
	
	/**Greedy Mode**/
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
		best_var = goodvar_stack[0];
		
		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var])
			{
				if(abs(time_stamp[v]-time_stamp[best_var])<delta_age)
				{
					if(pscore[v]>pscore[best_var])best_var = v;
					else 
						if((pscore[v]==pscore[best_var]) && (unsat_app_count[v] > unsat_app_count[best_var]))
							best_var = v;
				}
				else
					if(time_stamp[v]<time_stamp[best_var]) best_var = v;
			}
		}
		return best_var;
	}
	
	update_clause_weights();
	c = unsat_stack[rand()%unsat_stack_fill_pointer]; 
	
    if (random()%100 >= LNOISE)  return get_var_noveltyp(c);
	
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(abs(time_stamp[v]-time_stamp[best_var])<delta_age)
		{
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var] && pscore[v]>pscore[best_var]) best_var = v;
		}
		else
            if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	return best_var;
}


//pick a var to be flip
int pick_var_3SAT()
{
	int         i,k,c,v;
	int         best_var;
	lit*		clause_c;
	
	/**Greedy Mode**/
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	
	best_var = 0;
	score[best_var] = INT_MIN;
	unsat_app_count[best_var] = INT_MIN;
	
	
	if(goodvar_stack_fill_pointer>0)
	{
		for(i=0; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			
			if(score[v]>score[best_var]) best_var = v;
			else {
				if(score[v]==score[best_var]){
					if(unsat_app_count[v] > unsat_app_count[best_var])
						best_var = v;
				}
			}
		}
		
		if (best_var!=0) 
			return best_var;
	}
	
	best_var = 0;
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		if(score[unsatvar_stack[i]]>sigscore) 
		{
			best_var = unsatvar_stack[i];
			break;
		}
	}
	
	for(++i; i<unsatvar_stack_fill_pointer; ++i)
	{
		v=unsatvar_stack[i];
		if(score[v]>score[best_var]) best_var = v;
		else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	
	if(best_var!=0) return best_var;
		
	/**Diversification Mode**/

	update_clause_weights();
	
	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	
	return best_var;
}


int (* pick_var) ();


//set functions in the algorithm
void set_functions()
{
	set_clause_weighting();
	
	if(probtype==SAT3||probtype==strSAT)
	{
		flip = flip_3SAT;
		pick_var = pick_var_3SAT;
	}
	else //large ksat
	{
		flip = flip_large;
		pick_var = pick_var_large;
		
		if(probtype==SAT5)
		{
			delta_age=2*num_vars;
			if(delta_age>2000)delta_age=2000;
		}
		else {
			delta_age=20*num_vars;
			if(delta_age>2500)delta_age=2500;
		}
	}
}


void local_search(int max_flips)
{
	int flipvar;
     
	for (step = 0; step<max_flips; step++)
	{
		if(unsat_stack_fill_pointer==0) return;
        
		flipvar = pick_var();
		flip(flipvar);
		time_stamp[flipvar] = step;
		
        if(probtype!=SAT3)
            adaptNoveltyNoise(step);
	}
}


int main(int argc, char* argv[])
{
	int     seed,i;
	cout<<"c This is Ncca+ = CCASat + (Adapt-Novelty+) like heuristic + refinement variable selection "<<endl;
	cout<<"c Many thanks to CCASat team "<<endl;
	cout<<"c Ncca+ v1.05"<<endl;
     
	struct tms start, stop;
	times(&start);

	if (build_instance(argv[1])==0)
	{
		cout<<"c Invalid filename: "<< argv[1]<<endl;
		cout<<"s UNKNOWN "<<endl;
		return -1;
	}
     
    sscanf(argv[3],"%d",&seed);
    srand(seed);
	set_functions();

	for (i = 0; i <= max_tries; i++) 
	{
		init();
		initNoise();
		times(&stop);
		local_search(max_flips);
		if (unsat_stack_fill_pointer==0) break;
    }

	if(unsat_stack_fill_pointer==0)
	{
		cout<<"s SATISFIABLE"<<endl;
		print_solution();
    }
    else cout<<"s UNKNOWN "<<endl;
 	 
    free_memory();

    return 0;
}
