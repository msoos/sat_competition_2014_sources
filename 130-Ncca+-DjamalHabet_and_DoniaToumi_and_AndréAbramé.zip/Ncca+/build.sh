#!/bin/bash

mkdir binary

cd code/
make
cp Ncca+ ../binary


 
