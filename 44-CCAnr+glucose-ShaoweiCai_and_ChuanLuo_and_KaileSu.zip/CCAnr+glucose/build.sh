#!/bin/bash

mkdir binary/

cd code/CCAnr/
make
cp CCAnr ../../binary/

cd ../glucose2.3/simp/
make rs
cp glucose_static ../../../binary/glucose

cd ../../
cp CCAnr+glucose.sh ../binary/
