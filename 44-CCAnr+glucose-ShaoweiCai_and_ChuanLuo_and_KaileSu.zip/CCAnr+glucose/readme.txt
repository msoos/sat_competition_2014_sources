For compiling :
./build.sh

For running :
./CCAnr+glucose.sh <instance> <seed> <sls_cutoff_time>

Especially, for SAT Competition 2014, the value of parameter <sls_cutoff_time> is set to be 1000. So the running command in this context is 

./CCAnr+glucose.sh <instance> <seed> 1000