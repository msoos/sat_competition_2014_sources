./minisat_loceg_static ../../instances/sat13_industrial/b_unsat.cnf -dimacs=bunsat.cnf -debug -verb=2
