#! /bin/sh

mkdir binary
cur_dir=`pwd`
cd $cur_dir/code/
make
cp ./dist/Release/cb_penelope $cur_dir/binary/
cp ./configuration.ini $cur_dir/binary/

