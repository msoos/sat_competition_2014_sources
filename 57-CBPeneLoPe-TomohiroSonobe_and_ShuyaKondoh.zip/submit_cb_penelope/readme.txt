Name: cb_penelope
Author: Tomohiro SONOBE, Shuya KONDOH

PeneLoPe + Community Branching





======== original PeneLoPe description ========

For more information about this SAT solver, you may consult the following paper:
Gilles Audemard, Benoît Hoessen, Said Jabbour, Jean-Marie Lagniez, Cédric Piette, « Revisiting Clause Exchange in Parallel SAT Solving », in Fifteenth International Conference on Theory and Applications of Satisfiability Testing (SAT'12), june 2012.


Content
-------
 - configuration.ini the file containing the different parameters for cb_penelope
 - Doxyfile          file used to generate the documentation of cb_penelope
 - Makefile          makefile used to build cb_penelope (make help to see more information about it)
 - src/              the sources of cb_penelope
 - include/          the public headers of cb_penelope if you plan to use cb_penelope as a library

History
-------
cb_penelope (Tomohiro SONOBE, Shuya KONDOH)

    ^
    |

PeneLoPe (Gilles Audemard, Benoît Hoessen, Said Jabbour, Jean-Marie Lagniez, Cédric Piette)

    ^
    |

ManySat2.0 (Youssef Hamadi, Saïd Jabbour, Lakhdar Sais)

    ^
    |

Minisat2 (Niklas Eén, Niklas Sörensson)


Build
-----

To build the solver, you may use:
make cb_penelope

the corresponding binary will be produced in the directory dist/Release

Usage
-----

You can use cb_penelope directly using the binary, (for more information: use the --help option)
You must specify the configuration file ("configuration.ini").

./dist/Release/cb_penelope -config=./configuration.ini FILE.CNF




