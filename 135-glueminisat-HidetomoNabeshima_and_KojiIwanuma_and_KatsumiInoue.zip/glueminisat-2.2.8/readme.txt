======================================================================

                      GlueMiniSat 2.2.8 (dev120)

      Hidetomo NABESHIMA *1,  Koji IWANUMA *1,  Katsumi INOUE *2

                *1 University of Yamanashi, JAPAN
               {nabesima,iwanuma}@yamanashi.ac.jp

           *2 National Institute of Informatics, JAPAN
                          inoue@nii.ac.jp

======================================================================

(1) BUILDING

   ./build.sh

(2) RUNNING

   ./binary/glueminisat-simp BENCHNAME
