Lingeling SAT Solver Version ayv-86bf266-140429

./configure && make

This software is copyright 2010-2013, Armin Biere, JKU, Linz.  

This is only a restricted release of this software.

See 'COPYING' for more details on the permission to use this software.

All rights are reserved.  No warranty is implied.

Armin Biere
