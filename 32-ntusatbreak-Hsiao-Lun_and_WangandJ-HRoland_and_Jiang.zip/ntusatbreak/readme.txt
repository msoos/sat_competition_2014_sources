name:   ntusat
version: 1.1
author: Hsiao-Lun, Wang and Jie Hong, Roland Jiang

compile:

sh build.sh


execute:

./runBreakIDntusat.sh  <instance>   <tempdir>