#ifndef GLUE_CONSTANTS_DEFINED 
#define GLUE_CONSTANTS_DEFINED 

// Constants for clauses reductions
#define RATIOREMOVECLAUSES 2
#define NBCLAUSESBEFOREREDUCE 20000
#define DYNAMICNBLEVEL
#define CONSTANTREMOVECLAUSE
#define UPDATEVARACTIVITY

#define var_Undef (-1)

// Constants for restarts
#define LOWER_BOUND_FOR_BLOCKING_RESTART 10000

#endif
