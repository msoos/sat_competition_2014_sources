/*
  LoadSimpSolver.cpp for glueSplit_clasp -- Copyright (c) 2014, Jingchao Chen
*/
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "D_Constants.h"
#include "glue_Constants.h"
#include "Stack_PPS.h"
#include "glue_Solver.h"
#include "SimpSolver.h"

using namespace Glucose;

void dumpToSimSolver(SimpSolver * newsolver, Solver * FromSolver, vec<CRef>& cs, int sizelimit) 
{    int i,j;
     vec<Lit> lits;
     for (i =0; i < cs.size(); i++){
                Clause & c = FromSolver->ca[cs[i]];
 		int sz=c.size();
           	if(sz > 6 && sizelimit==2) continue;
	 	lits.clear();
		for (j = 0; j < sz; j++) {
                        Lit lit=c[j];
			if (newsolver->value(lit) == l_True) break;
   			if (newsolver->value(lit) == l_False) continue;
                        lits.push(lit);	
		}
                if(j<sz) continue;
            	if(sizelimit==2 && lits.size() > 2) continue;
                newsolver->addClause_(lits);
      }
}

lbool Load_gSimpSolver(Solver * CurSolver)
{ 
     printf("c Load glue SimpSolver \n");
     int nV=CurSolver->nVars();
     SimpSolver * newsolver=new SimpSolver();
     while (nV > newsolver->nVars()) newsolver->newVar();
     newsolver->recursiveDepth=0;
      
      vec<Lit> lits;
      for(int i=0; i<nV; i++){
	      if(CurSolver->assigns[i] != l_Undef){
		       Lit lt = (CurSolver->assigns[i] == l_True) ? mkLit(i) : ~mkLit(i);
         	       lits.clear();
                       lits.push(lt);
                       newsolver->addClause_(lits);
 	      }
       }
 
      dumpToSimSolver(newsolver,CurSolver,CurSolver->clauses,10000000); 
      dumpToSimSolver(newsolver,CurSolver,CurSolver->learnts,2); 
      newsolver->conflict_limit=-1;
      newsolver->isSimpSolver=true;
      newsolver->eliminate(true);
      if (!newsolver->okay()) return l_False;
      vec<Lit> dummy;
      lbool ret=newsolver->solveLimited(dummy);
      if(ret==l_True) {
          for (int i = 0; i < newsolver->nVars(); i++){
	      if(CurSolver->assigns[i] != l_Undef) continue;
              CurSolver->assigns[i]=newsolver->model[i];
          }
      }
      return ret;
}      

