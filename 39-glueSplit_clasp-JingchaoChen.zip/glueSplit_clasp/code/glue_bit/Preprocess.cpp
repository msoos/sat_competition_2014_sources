/*
 Preprocessing for CircleSAT
*/
#include <cassert>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "D_Constants.h"
#include "Stack_PPS.h"

#define Swap(a,b) { int t; t=a; a=b; b=t;}

/************************************/
/* Constant parameters              */
/************************************/
extern int originClauses; // original number of clauses
extern char *Deletedclause;
extern int delclauses;
//int	deletedVnum;

void Adp_SymPSort(void *a, int n, int es, int (*cmp)(const void *,const void *));
void copyXORclause(Stack<int> * & xorClause, int numXOR);
void getclausePos(PPS *pps);
int BinarySimplify(PPS *pps,char * tabuVar);
void forwardsubsume(PPS *pps);
int XOR_varElimination(PPS *pps, char * tabuVar);
int subsumeDelete(PPS *pps, char * tabuVar);
int subsumptionResolution(PPS *pps, int vi, int & deletedVnum,bool & NewUnit, int delta);
void save_eqv(PPS *pps);

int *Leq_base;  // the set of literals for active XOR clauses
int **Leq;    //  literals for each active XOR clause
int *Eq_base; //  the set of active XOR clauses for each variables

int *BigEq_set;  // the set of big active XOR clauses
int **BigEq;     // indexs which point to each big active XOR clause

int *TimeAss;        // time assignment;
int cTimeA;           // current time assignment                

int equivalence_reasoning(PPS *pps);
void shorten_equivalence(PPS *pps);

void Split_XOR_CNF(PPS *pps);

int *vBoolookup;
int *DependentVar;
int *CeqLen;

void check(int sol[],Stack<int> *clause);

void sortColumn(Stack<int> * & clause, int j_th, int numvar);
void sortClause(Stack<int> * & clause, int numcolumn,int & numClauses, int numvar, int delrepeat);

void release_occCls(PPS *pps) 
{
	if(pps->occCls){
		for(int i = 1; i <= pps->numVar; i++) {
	       pps->occCls[i].release();
	       pps->occCls[-i].release();
		}
	    pps->occCls-=pps->numVar;
	    free(pps->occCls);
        pps->occCls = 0;
	}
	if(pps->occBoth){
        for(int i = 1; i <= pps->numVar; i++) pps->occBoth[i].release();
	    free(pps->occBoth); //bug 2011/9/23
        pps->occBoth=0;
	}
}

void clear_occCls(PPS *pps)
{ 
    if(pps->occCls){
		for(int i = 1; i <= pps->numVar; i++) {
	       pps->occCls[i].shrink(0);
	       pps->occCls[-i].shrink(0);
		}
	}
    else{
		int Itemsize = 2*(pps->numVar + 1); 
       pps->occCls = (Stack<int> *) calloc (Itemsize, sizeof (*(pps->occCls)));
	   pps->occCls+=pps->numVar;
	}
}

/*void init_pps (PPS *pps)
{
   //pps = (struct PPS *)malloc (sizeof PPS);
   //CLRPTR (pps);
  // pps->clause=clause;
  // pps->numClause=numcls;
   //pps->numVar=numatom;
}
*/
void free_mem(int * & ptr)
{
	if(ptr) free(ptr);
	ptr=0;
}
void release_pps (PPS * pps)
{
	if(pps==0) return;
	if(pps->clause) {
		delete pps->clause;
		pps->clause=0;
	}
    release_occCls(pps);
	if(pps->clausePos){
		delete pps->clausePos;
		pps->clausePos=0;
	}
	free_mem(pps->unit);
	free_mem(pps->seen);
    free_mem(pps->outEquAtom);
    if(pps->n_inative) {
		free(pps->inaLit[0]);
		free(pps->inaLit);
		pps->n_inative=0;
    }
	if(pps->numXOR){
		pps->numVar=0;
		free(pps->Leq[0]);
		free(pps->Leq);
	}
    if(pps->inactiveVar){
		delete pps->inactiveVar;
		pps->inactiveVar=0;
	}
}

void release_free_pps (PPS * & pps)
{
	if(pps==0) return;
    release_pps (pps);
    free(pps);
	pps=0;
}

void SetClausePtr(int **clauseP,int *newPointer,int cntClauses);

// Find the solution of inactive variables by XOR equation
void inactiveSolution(int *Fsolution, PPS *pps)
{   int i,trues,var,*px;

    for(i=pps->n_inative-1; i>=0; i--){
		 trues=0;
       	 for(px=pps->inaLit[i]+1; px<pps->inaLit[i+1]; px++){
			 if(Fsolution[ABS(*px)]==0) { trues=-1; break;}
        		if(Fsolution[ABS(*px)]==*px) trues++;
         }
		 if(trues==-1) continue;
         var=pps->inaLit[i][0];
		 if(var<0) {var=-var; trues++;}
		 if(trues%2==0) Fsolution[var]=var;
		 else Fsolution[var]=-var;
    }
    if(pps->n_inative) {
		free(pps->inaLit[0]);
		free(pps->inaLit);
		pps->n_inative=0;
	}
}

inline int equ_lit(int var, PPS *pps)
{   
	if(pps->outEquAtom==0) return pps->unit[var];
	int eqv=ABS(pps->outEquAtom[var]);
	if(eqv==0 || eqv==var) return pps->unit[var];
	if(pps->unit[eqv]==0) return pps->unit[var];
	if(pps->outEquAtom[var]<0) eqv=-pps->unit[eqv];
	else eqv=pps->unit[eqv];
	if(eqv<0) return -var;
	return var;
}

void extend_solution(PPS *pps) 
{
  int *start = pps->extend.begin();
  int *p=pps->extend.end();
  int satisfied,lit,next;

  p=pps->extend.end();
  while (p > start) {
          p--;
	  lit=*p;
	  if(lit!=0){ // bug x=y   x=0, y=0 2011/12/16
		  int vv=ABS(lit); 
		  if(pps->unit[vv]==0) pps->unit[vv]=-lit;
	  }
  }
  p=pps->extend.end();
  while (p > start) {
    satisfied = 0;
    next = 0;
    do {
      lit = next;
      next = *--p;
      if (!lit || satisfied) continue;
      int var=ABS(lit);
      pps->unit[var]=equ_lit(var, pps);
	  if (pps->unit[var]==lit) satisfied = 1;
    } while (next);
    if (satisfied) continue;
	pps->unit[ABS(lit)]=lit;
  }
}

void setDoubleDataIndex(PPS *pps,bool add_delcls)
{
	 clear_occCls(pps);
     //static int callm=0;
	 int *pcls=pps->clause->begin();
	 int *pend=pps->clause->end();
  	 int clsNum=0;
	 pps->numXOR=0;
	 while(pcls < pend){
         int len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
         pcls+=len;
	     if(!add_delcls && (mark==DELETED || mark==FROZE)) continue; //remove;
		 if(mark==XOR_CLS) pps->numXOR++;
		 else clsNum++;
		 int pos=(pcls-pps->clause->begin())-len;
		 for (; lits<pcls; lits++) {
			 pps->occCls[*lits].push(pos);
			 if(mark==XOR_CLS) pps->occCls[-(*lits)].push(pos);
		 }
	 }
	 pps->numClause=clsNum;
}

void setSingleDataIndex(PPS *pps)
{
	release_occCls(pps); 
    pps->occBoth = (Stack<int> *) calloc (pps->numVar + 1, sizeof (*(pps->occBoth)));
    int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
  	int clsNum=0;
	while(pcls < pend){
         int len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
         pcls+=len;
	     if(mark==DELETED) continue; //remove;
		 clsNum++;
		 int pos=(pcls-pps->clause->begin())-len;
		 for (; lits<pcls; lits++) pps->occBoth[ABS(*lits)].push(pos);
	}
	pps->numClause=clsNum;
}

int getBinClsNum(PPS *pps,int * & binNum)
{
	int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
	binNum=(int *)calloc(2*pps->numVar+2,sizeof(int));
  	binNum+=pps->numVar;
        int binNo=0;
	while(pcls < pend){
            int len=*pcls;
	    len=len>>FLAGBIT;
	    int *lits=pcls+1;
            pcls+=len;
            if(len!=3) continue;
	    binNum[lits[0]]++;
	    binNum[lits[1]]++;
	    binNo++;
	}
        return binNo;
}

int checkUnitClause(PPS *pps,int cpos,int & change)
{
    int lit,size,var,k,rc;
    int aCNF[20];
    Stack<int> *clsSAT=pps->clause;
    int *seen=pps->seen;
    int *unit=pps->unit;

   	size=0; change=0;
    int len=(*clsSAT)[cpos];
	len=len>>FLAGBIT;
	int *lits=&(*clsSAT)[cpos];
    int *nextcls=lits+len;
    for(lits++; lits<nextcls; lits++){
	   lit=*lits; var=ABS(lit);
       if(unit[var]!=0) {
	        if(unit[var]!=lit) continue;
  			rc=SAT; goto ret;
	   }
   	   if(seen[ABS(lit)]==0) {
        	if(size>=10) continue;
	     	aCNF[size++]=lit;
		    seen[ABS(lit)]=lit;
	   	}
	    else{
			 if(pps->seen[ABS(lit)]==-lit){
  			   rc=SAT; goto ret;
			 }
		}
	}
	rc=_UNKNOWN;
ret:	
	for(k=0; k<size; k++) seen[ABS(aCNF[k])]=0;
	if(rc==SAT) return SAT;
//unit cluase found
    if(size==1){
        unit[ABS(aCNF[0])]=aCNF[0];
		change=1;
	}
	if(size==0) return UNSAT;
	return SAT;
}


int breakEquivalentLoop(PPS *pps)
{    int i,cur,sign,next1;
     int numatom=pps->numVar;
     int *outEquAtom=pps->outEquAtom;
     int *unit=pps->unit;

     for(i=1; i<=numatom; i++) {
		if(ABS(outEquAtom[i])<=i) continue;
		cur=i;
		sign=1;
		do{ 
			next1=outEquAtom[cur];
			outEquAtom[cur]=sign*i;
			if(unit[cur]!=0){
				int lit=unit[i];
				unit[i]=(outEquAtom[cur]<0 && unit[cur]<0) || (outEquAtom[cur]>0 && unit[cur]>0)? i:-i;
				if(lit==-unit[i]) return UNSAT;
			}
			if(next1<0) {cur=-next1; sign=-sign;}
			else cur=next1;
		} while(cur!=outEquAtom[cur]);
	}

	for(i=1; i<=numatom; i++) {
		next1=ABS(outEquAtom[i]);
		if(outEquAtom[next1]==next1 || next1==0) continue;
		sign=outEquAtom[i]<0 ? -1: 1;
		outEquAtom[i]=sign*outEquAtom[next1];
	}
	return SAT;
}

//delete some cluases
/*
int deletegarbage(PPS *pps, Stack<int>* & clauseOut, int & numOut,int limLen);
int deletegarbage(PPS *pps, int & change)
{
  int rc=deletegarbage(pps, newNum,0x7fffffff);
  if(rc==UNSAT) return rc;
  change=(newNum!=pps->numClause);
  return rc;
}
*/
//outEquAtom=EquLink
int deletegarbage(PPS *pps)//bug 2011/9/25
{
	int lit,var,newsz;
	int j,k,True;
    int *EquLink=pps->outEquAtom;

	if(pps->seen==0) pps->seen=(int *)calloc(pps->numVar+1,sizeof(int));
    int *seen=pps->seen;
    int *unit=pps->unit;

loop:		
 	int numOut=0;
	Stack<int> *clauseOut=new Stack<int>; 
    Stack<int> *clauseIn=pps->clause;
	int *pcls=clauseIn->begin();
	int *pend=clauseIn->end();
	bool unitchange=false; //bug 2011/9/25
	while(pcls < pend){ //map ext var to internal var
         int len=*pcls;
		 int mark= len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls;
         pcls+=len;
         if(mark==DELETED) continue;
		 True=0;
		 int initp=clauseOut->nowpos();
		 clauseOut->push(0);
 		 for(k=1; k<len; k++){
			lit=lits[k];
    		if(EquLink!=0){
		    	int lit1=EquLink[ABS(lit)];
			    if(lit1!=0)	lit=(lit<0)?-lit1:lit1;
			}
			var=ABS(lit);
			if(unit[var]){
				 if(unit[var]!=lit) continue;
				 True++;
				 if(mark!=XOR_CLS) break;
			}

			if(seen[var]==0) {
				seen[var]=lit; 
				clauseOut->push(lit);
			}
			else {
				if(seen[var]==-lit) {True++; if(mark!=XOR_CLS) break;}
				if(mark==XOR_CLS) {
					seen[var]=0;
					int newp=clauseOut->nowpos();
					int m=initp+1;
			    	for(j=initp+1; j<newp; j++) {
						int lit2=(*clauseOut)[j]; 
						if(ABS(lit2)==var) continue;
						(*clauseOut)[m++]=lit2;
					}
				    clauseOut->shrink(m);
				}
			}
			
		 }
		
		 int newp=clauseOut->nowpos();
		 for(j=initp+1; j<newp; j++) {lit=(*clauseOut)[j]; seen[ABS(lit)]=0;}
		 newsz=newp-initp;
       	 if(mark==XOR_CLS) {
			 True=True%2;
			 if(newsz>1 && True){
				 lit=(*clauseOut)[initp+1];
				 (*clauseOut)[initp+1]=-lit;
				 True=0;
			 }
		 }
//		 if(True || newsz>limLen) {
		 if(True) {
		 	 clauseOut->shrink(initp);
		     continue;
		 }
		 if(newsz==1){
			printf("c proprocessing binary clause conflict \n");
			delete clauseOut;
			return UNSAT;
		}
		
		if(newsz==2){
			lit=(*clauseOut)[initp+1];
			unit[ABS(lit)]=lit;
			clauseOut->shrink(initp);
			unitchange=true;
			continue;
		}
		(*clauseOut)[initp]= (newsz << FLAGBIT) | mark;
		numOut++;
	 }
     delete pps->clause;
     pps->clause=clauseOut;
     pps->numClause=numOut;
	 if(unitchange) goto loop;
	 return _UNKNOWN;
}
//delete some cluases
void deleteClause(PPS *pps)
{
	int newNum;
	int k;
 
	Stack<int> *NewClause=new Stack<int>; 
 	newNum=0;

	int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
	while(pcls < pend){ //map ext var to internal var
         int len=*pcls;
		 int mark= len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls;
         pcls+=len;
		 if(mark==DELETED) {
	      	 continue;
		 }
//		 if(mark==XOR_CLS) pps->numXOR++;
      	 for(k=0; k<len; k++) NewClause->push(lits[k]);
		 newNum++;
	 }
     delete pps->clause;
	 pps->clause=NewClause;
 	 pps->numClause=newNum;
}

void mergeTwoEqu(PPS *pps, int lit1, int lit2)
{
    int v1,v2;
	v1=ABS(lit1); v2=ABS(lit2);
	if(v1>v2){
		Swap(v1,v2);
        Swap(lit1,lit2);
  	}
   	if(lit2<0) lit1=-lit1;
   	pps->outEquAtom[v1]=0;
	pps->outEquAtom[v2]=lit1;
}

inline int find(PPS *pps,int vv, int lit)
{
	int lit1=pps->outEquAtom[vv];
    while(lit1){
    	lit=(lit<0)?-lit1:lit1;
	    vv=ABS(lit);
		lit1=pps->outEquAtom[vv];
		if(ABS(lit1)==vv){
			pps->outEquAtom[vv]=0;
			break;
		}
	}
	return lit;
}

inline int find_lit(PPS *pps,int lit)
{
     return find(pps,lit/2,  posLit2lit(lit));
}

void mergeAllEqu(PPS *pps)
{
	for(int i=pps->numVar; i>=2; i--){
         if(pps->outEquAtom[i]==0) continue;
		 int other=find(pps, i,i);
    	 mergeTwoEqu(pps, other, i);
    }
}

int mergeTwoEunit(PPS *pps,int lit1, int lit2)
{
    int v1,v2;
	v1=ABS(lit1); v2=ABS(lit2);
	if(v1>v2){
		Swap(v1,v2);
        Swap(lit1,lit2);
  	}
   	if(lit2<0) lit1=-lit1;
	int *unit=pps->unit;
    if(unit[v2]){// bug 2010.9.19
         if(unit[v2]<0) lit1=-lit1;
		 if(unit[v1]==-lit1) return UNSAT;
         unit[v1]=lit1;
		 return SAT;
	}
	pps->outEquAtom[v1]=0;
	pps->outEquAtom[v2]=lit1;
	return SAT;
}

inline int find1(PPS *pps,int lit)
{   int vv=ABS(lit);
    int *outEquAtom=pps->outEquAtom;
	int lit1=outEquAtom[vv];
    while(lit1){
    	lit=(lit<0)?-lit1:lit1;
	    int vv=ABS(lit);
	    lit1=outEquAtom[vv];
		if(ABS(lit1)==vv){
			outEquAtom[vv]=0;
			break;
		}
	}
	return lit;
}

//binary equivalent resoning
int BinaryEquReason(PPS *pps,char * tabuVar)
{   
    sortClause(pps->clause,4,pps->numClause,pps->numVar,0); //??no duplicate
  	int *unit=pps->unit;
	int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
	while(pcls < pend){
            int len1=*pcls;
		    len1=len1>>FLAGBIT;
		    int *lits1=pcls+1;
            pcls+=len1;
            if(pcls >= pend) break;
			int len2=*pcls;
		    len2=len2>>FLAGBIT;
		    int *lits2=pcls+1;
            if(len1!=3 || len2!=3) continue; //bug 5/23/2011
			int lit1=*lits1; 
			int lit2=lits1[1];
			if(tabuVar){
				if(tabuVar[ABS(lit1)] || tabuVar[ABS(lit2)]) continue;//2012/1/12
			}
		   	if(-lit1==*lits2){
			    if(-lit2==lits2[1]){    //lit1==-lit2;
			// printf("<CNF %d = %d> ", lit1,-lit2);
			   	    int a=find1(pps,lit1);
				    int b=find1(pps,(-lit2));
			        if(a == b) continue;
	                if(a == -b) return UNSAT;
				     int rc=mergeTwoEunit(pps,a,b);
				     if(rc==UNSAT) return UNSAT;
				}
			    if(lit2==lits2[1]){    //A v B  AND -A V B ==> B
			  // printf("\n +-A=%d B=%d ==> B ",lit1,lit2);
			    	int vv=ABS(lit2);
			    	if(unit[vv]==-lit2)	return UNSAT;
				    unit[vv]=lit2;
				}
			}
            else{
			   if(lit1==*lits2){
			      if(-lit2==lits2[1]){    //A v B  AND A V -B ==> A
			    //  printf("\n A=%d +-B=%d ==> A ",lit1,lit2); printf("\n A v B  & -A V B ==> B ");
				     int vv=ABS(lit1);
				     if(unit[vv]==-lit1) return UNSAT;
				     unit[ABS(lit1)]=lit1;
				  }
			   }
			}
    }
    mergeAllEqu(pps);
//delete some cluases
    int rc=deletegarbage(pps);
	return rc;
}

int BinarySimplify(PPS *pps,char * tabuVar)
{
	 int i,sum;
     int loop,change,rc;
    
	 if(pps->seen==0) pps->seen=(int *)calloc(pps->numVar+1,sizeof(int));
  	 if(pps->outEquAtom==0) pps->outEquAtom=(int *)calloc(pps->numVar+1,sizeof(int));
	
	 sum=0;
	 do{
		 loop=0;
         int *pcls=pps->clause->begin();
	     int *pend=pps->clause->end();
  	     while(pcls < pend){
            int len=*pcls;
		    int mark=len & MARKBIT;
		    len=len>>FLAGBIT;
		    pcls+=len;
	        if(mark==DELETED) continue; //remove;
		    int pos=(pcls-pps->clause->begin())-len;
	        rc=checkUnitClause(pps,pos,change);
			if(rc==UNSAT) return UNSAT;
			if(change) loop=1;
		 }
		 sum++;
     } while (loop==1);
  
	sum=0;
	 int oldnum;
	 do{
		 sum++;
		 oldnum=pps->numClause;
		 if(BinaryEquReason(pps,tabuVar)==UNSAT) return UNSAT;
        // printf("c BinaryEquReason loop #=%d numClauses=%d \n", sum,pps->numClause);
		 if((pps->numClause>500000 && sum>10) || sum>30) break;
	 } while(oldnum!=pps->numClause);

	 for(i=1; i<=pps->numVar; i++) { //SAT_dat.k50
		 if(pps->unit[i]==0) continue;
		 if(pps->outEquAtom[i]==0) continue;
		 int other=find1(pps,i);
		 if(other==i) continue;	
		 if(pps->unit[i]<0) other=-other;
		 int vv=ABS(other);
         if(pps->unit[vv]==-other) {
			 printf("c bin equ i=%d pps->unit[%d]=%d UNSAT\n",i,vv,pps->unit[vv]);
			 return UNSAT;
		 }
		 pps->unit[vv]=other;
	 }

	 save_eqv(pps); //2011/12/20

	 return _UNKNOWN;     	 
}

int Load_glueSolver(PPS *pps,int * & fixedVar);

int SimplifySAT(PPS *pps,char *tabuVar)
{
    int rc;
    rc=BinarySimplify(pps, tabuVar);
    if(rc==UNSAT) return UNSAT;

    if(pps->numClause<10000000) {
	  forwardsubsume(pps);
     }
     setDoubleDataIndex(pps,false);
  
//	check((int *)0, pps->clause);
      if(pps->numClause<3000000 || pps->numVar<120000){//12pipe_bug8
            rc=XOR_varElimination(pps,tabuVar);
            if(rc==UNSAT) return UNSAT;
     
            rc=subsumeDelete(pps, tabuVar);
            if(rc==UNSAT) return UNSAT;
       }

	if(originClauses<5000000){
	      int delrepeat=1;
              sortClause(pps->clause,4,pps->numClause,pps->numVar,delrepeat);
        }
        return rc;
}

extern int CNF_space;
//extend space for subsumption Resolution by clause distribution
int subsumeDelete(PPS *pps, char *tabuVar)
{    
     int *unit=pps->unit;
     //int k=0;
	 bool NewUnit;
	 int deletedVnum=0;
	 for(int i=0; i<10 || NewUnit; i++){
		  NewUnit=false;
		  int preNum=deletedVnum;
	      Stack<int> *occCls=pps->occCls; 
		  for(int vi=1; vi<=pps->numVar; vi++){
			   if(unit[vi]) continue;//unit[vi]!=vi+1
			   if(tabuVar){
				   if(tabuVar[vi]) continue; //2012/1/12
			   }
			   int numOccur=occCls[vi]+occCls[-vi]; 
		       if(numOccur<=0) continue;
			   else{//12
		             if(numOccur<12 && occCls[vi]>0 && occCls[-vi]>0) {
	                   bool NewUnit1;
					   int rc=subsumptionResolution(pps, vi, deletedVnum,NewUnit1,0);
			           if(rc==UNSAT) return rc;
					   if(NewUnit1) NewUnit=NewUnit1; 
				   }
			   }
		  }
		  if(preNum!=deletedVnum || NewUnit) {
		   	  int rc=deletegarbage(pps);
			  if(rc==UNSAT) return rc;
		 }
		 setDoubleDataIndex(pps,false);
		 if(preNum==deletedVnum) break;
	 }
	 return _UNKNOWN;
}

void SortLiteral(Stack<int> * clause)
{    
	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 while(pcls < pend){
            int len=*pcls;
		    len=len>>FLAGBIT;
		    int *lit0=pcls+1;
			int *lits=pcls+2;
            pcls+=len;
            for(; lits<pcls; lits++) {
				int *pw;
				for(pw=lits; pw>lit0 && ABS(*(pw-1)) > ABS(*pw); pw--){
				    Swap(*(pw-1),*pw);
				}
			}
     }
}

void sortClause(Stack<int> * & clause, int numcolumn,int & numClauses, int numvar, int delrepeat)
{  
	// -x -> 2(-x)+1, x -> 2x
	if(delrepeat){
		 int *pcls=clause->begin();
	     int *pend=clause->end();
	     while(pcls < pend){
            int len=*pcls;
		    len=len>>FLAGBIT;
		    int *lits=pcls+1;
            pcls+=len;
            for (; lits<pcls; lits++) *lits=lit2posLit(*lits);
		 }
	}
//sort literals in each row    
   	SortLiteral(clause);
//Sort 4 columns
    if(numcolumn>2){
		sortColumn(clause,3,numvar);
		sortColumn(clause,2,numvar);
  	}
	sortColumn(clause,1,numvar);
	sortColumn(clause,0,numvar);
//remove repeated clauses
	if(delrepeat){
		 int *pcls1=clause->begin();
	     int *pend=clause->end();
	     int *pcls2;
		 for(; pcls1 < pend; pcls1=pcls2){
            int len1=*pcls1;
		    int mark=len1 & MARKBIT;
			len1=len1>>FLAGBIT;
		    //int *lit1=pcls1+1;
            pcls2=pcls1+len1;
            if(mark!=CNF_CLS) continue;
			if(pcls2>= pend) break;
			int len2=*pcls2;
		    mark=len2 & MARKBIT;
            if(mark!=CNF_CLS) continue;
		    len2=len2>>FLAGBIT;
		    if(len1!=len2) continue;
            int j;
			for (j=1; j<len1; j++){
				if(pcls1[j]!=pcls2[j]) break;
			}
			if(j>=len1){
				*pcls1=(len1<<FLAGBIT) | DELETED; ////repeated clauses
			}
		 }
// 2x -> x,   2x+1 ->-x
         Stack<int> * newclause=new Stack<int>;
   	     int *pcls=clause->begin();
	     numClauses=0;
		 while(pcls < pend){
            int len=*pcls;
		    int mark=len & MARKBIT;
            len=len>>FLAGBIT;
		    int *lits=pcls;
            pcls+=len;
            if(mark==DELETED) continue;
			numClauses++;
			newclause->push(*lits);
			for (lits++; lits<pcls; lits++) {
				int lit=posLit2lit(*lits);
	         	newclause->push(lit);
			}
		 }
		 delete clause;
		 clause=newclause;
	}
}


void sortClause2(Stack<int> * & clause, int numvar)
{  
	sortColumn(clause,3,numvar);
    sortColumn(clause,2,numvar);
	sortColumn(clause,1,numvar);
	sortColumn(clause,0,numvar);
}

void SortLiteral2(Stack<int> * & clause, int changeNo)
{  
	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 while(pcls < pend){
            int len=*pcls;
		    len=len>>FLAGBIT;
		    int *lits=pcls+1;
            pcls+=len;
        	if(len<3) continue; //size=1
			if(len>3){
			    if(changeNo==1) {Swap(lits[1],lits[2]);}
        	    if(changeNo==2) {Swap(lits[0],lits[2]);}
			}
	        if(lits[0]>lits[1]) Swap(lits[0],lits[1]);
	 }
}

void clslit2poslit(Stack<int> * clauseCNF)
{
	int *pcls=clauseCNF->begin();
	int *pend=clauseCNF->end();
	while(pcls < pend){
         int len=*pcls;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
         pcls+=len;
         for (; lits<pcls; lits++) *lits=lit2posLit(*lits);
	}
}

void poslit2clslit(Stack<int> * clauseCNF)
{
	int *pcls=clauseCNF->begin();
	int *pend=clauseCNF->end();
	while(pcls < pend){
        int len=*pcls;
		len=len>>FLAGBIT;
		int *lits=pcls+1;
        pcls+=len;
        for (; lits<pcls; lits++) *lits=posLit2lit(*lits);
	}
}
/*
void printclause(Stack<int> *clsSAT, int pos)
{
  int len=(*clsSAT)[pos];
	  len=len>>FLAGBIT;
	  printf("\n");
      for(int i=1; i<len; i++) printf("%d ",(*clsSAT)[pos+i]);
}
*/

void forwardsubsume(PPS *pps)
{
	int i,j,k;
	bool deleteCli;
    if(pps->numClause<10) return;
	// -x -> 2(-x)+1, x -> 2x
   
    Stack<int> * clauseCNF=pps->clause;
    clslit2poslit(clauseCNF);
	
	int *Seen =(int *) calloc (2*pps->numVar+2, sizeof (int));
	for(i=0; i<3; i++){
       deleteCli=false;
//sort literals in each row    
	   SortLiteral2(clauseCNF,i);
	   sortClause2(clauseCNF,pps->numVar);
       pps->clause=clauseCNF;
	   getclausePos(pps);
       Stack<int> * clausePos=pps->clausePos;
      
	   for(j =1; j < pps->numClause; j++) {
		   int h=j-1;
		   int hPos= (*clausePos)[h];
           int hLen=(*clauseCNF)[hPos];
           if((hLen & MARKBIT)==DELETED) continue;
		   hLen=hLen>>FLAGBIT;
		   int size=hLen-1;
		   if(size!=2) {//backward subsume
			   if(size>=8) continue;
			   int lit=(*clauseCNF)[hPos+1];
			   int m;
		       for(m=1; m<size; m++) Seen[(*clauseCNF)[hPos+1+m]]=1;
			   for(int k=h-1; k>=0 && k>j-30; k--){
			        int kPos= (*clausePos)[k];
                    int lenK=(*clauseCNF)[kPos];
                    if((lenK & MARKBIT)==DELETED) continue;
		            lenK=lenK>>FLAGBIT;
		  	        int size2=lenK-1;
				    if(size2>=size) continue;
			    	if(lit!=(*clauseCNF)[kPos+1]) break;
			   		for(m=1; m<size2; m++){
						 int lit2=(*clauseCNF)[kPos+1+m];
						 if(Seen[lit2]==0) break;
					}
		            if(m>=size2){
						 (*clauseCNF)[hPos]=(hLen<<FLAGBIT) | DELETED; // //delete
						// Clit1[h][0]=0; // //delete
						 deleteCli=true;
						 break;
					 }
			   }
		       for(m=1; m<size; m++) Seen[(*clauseCNF)[hPos+1+m]]=0;
        	   continue;
		   }
		  
		   int jPos= (*clausePos)[j];
           int jLen=(*clauseCNF)[jPos];
           if((jLen & MARKBIT)==DELETED) continue;
		   jLen=jLen>>FLAGBIT;
		   if(jLen<3) continue;
		  
		   if((*clauseCNF)[jPos+1]==(*clauseCNF)[hPos+1] && (*clauseCNF)[jPos+2]==(*clauseCNF)[hPos+2]) {
               (*clauseCNF)[jPos]=(jLen<<FLAGBIT) | DELETED; // //delete
			   deleteCli=true;
			   for(k=j+1; k<pps->numClause && k<j+5; k++){
		             int kPos= (*clausePos)[k];
                     int kLen=(*clauseCNF)[kPos];
                     if((kLen & MARKBIT)==DELETED) continue;
		             kLen=kLen>>FLAGBIT;
		             if(kLen<3) continue;
		             if((*clauseCNF)[kPos+1]==(*clauseCNF)[hPos+1] && (*clauseCNF)[kPos+2]==(*clauseCNF)[hPos+2]) {
			              (*clauseCNF)[kPos]=(kLen<<FLAGBIT) | DELETED; // //delete
				   }
			   }
		   }
	   }
	   if(deleteCli) {
		   deleteClause(pps);
		   clauseCNF=pps->clause;
	   }
	}
    free(Seen);
	poslit2clslit(clauseCNF);
	pps->clause=clauseCNF;
}

// x=a^b <=> {x, -a,-b}{-x, a}{-x,b}
void ANDgate(int vi, int andclsPos[4],Stack<int> *occCls,Stack<int> *clsSAT)
{   int ab;
    int i,j,k;
	int occ=occCls[vi];
   	ab=0;
    for(i=0; i<occ; i++){ // x==a^b
   	    int posA=occCls[vi][i];
    	andclsPos[0]=posA;
	    int len=(*clsSAT)[posA];
		len=len>>FLAGBIT;
		if(len!=4) continue; //3
		k=1;
        int *clsp=&(*clsSAT)[posA];
		int *lits=clsp+1;
        clsp+=len;
		for (; lits<clsp; lits++){
			  if(*lits==vi) continue;
			  int vb=-(*lits);
	          int occb=occCls[-vi];
	          for(j=0; j<occb; j++){
		          int posB=occCls[-vi][j];
                  int lenB=(*clsSAT)[posB];
		          if( (lenB & MARKBIT)==DELETED) continue;// bug 2011/9/24
			      lenB=lenB>>FLAGBIT;
		          if(lenB!=3) continue; //2
		   	      if((*clsSAT)[posB+1]==vb || (*clsSAT)[posB+2]==vb) {
					   if(ab!=vb) {
						   ab=vb; andclsPos[k++]=posB; //bug 2011/9/24
						   if(k==3) {
							  // printf("c Acls=%d   Bcls=%d Bcls=%d \n",andclsPos[0],andclsPos[1],andclsPos[2]);// Niklas E.en and Armin Biere
			                  // for(int m=0; m<3; m++) printclause(clsSAT, andclsPos[m]);
							   return;
						   }
					   }
				  }
			  }
		}
	}
	andclsPos[0]=-1; //??? bug
}

//flat200-100
int subsumptionResolution(PPS *pps, int vi, int & deletedVnum,bool & NewUnit, int delta)
{
	int i,j,m,pos,neg,k,k1,pi;
    int andclsPos[5];
    int posA,posB,nextbegin;
    
	int *seen=pps->seen;
	Stack<int> * clsSAT=pps->clause;
	pos=pps->occCls[vi];
    neg=pps->occCls[-vi];
	if(delta<=1){
		if(pos+neg<8) delta=0;
	    else delta=1;
    }
	else delta=-delta;
  
	NewUnit=false;
       if(pps->unit[ABS(vi)]) return _UNKNOWN;
 
		 
	andclsPos[0]=-1;
	if(pos+neg<8){
		ANDgate(vi,andclsPos,pps->occCls,clsSAT);
		if(andclsPos[0]==-1) {
			vi=-vi;
			ANDgate(vi,andclsPos,pps->occCls,clsSAT);
			pos=pps->occCls[vi];
	        neg=pps->occCls[-vi];
		}
	}

	int origsize=clsSAT->nowpos();
	int Newsize=origsize;
	int clsB_size,lenB;
	int newCNFs=0,end=0;
    int *unit=pps->unit;

	for(i=0; i<pos; i++){
		  posA=pps->occCls[vi][i];
		  int len=(*clsSAT)[posA];
		  if( (len & MARKBIT)==DELETED) continue;
		  len=len>>FLAGBIT;
		  int clsbegin=clsSAT->nowpos();
		  clsSAT->push(0);
		  for (pi=posA+1; pi<posA+len; pi++){
			  int alit=(*clsSAT)[pi];
			  int vv=ABS(alit);
			  if(unit[vv]){
				  if(unit[vv]==alit) goto clearSeen;
			  }
			  else if(alit!=vi) {clsSAT->push(alit); seen[vv]=alit;}
		  }
		  k1=clsSAT->nowpos()-clsbegin-1;
		  //if(k1<=0) goto clearSeen; //bug 2011/9/24    
		  for(j=0; j<neg; j++){ // G(x)={x,-a -b} G'={-x,a) V {-x,b},  S= G(x) V G(-x) V R(x) V R(-x) => S"= G(x)*R(-x) V G(-x)*R(x)
   	           posB=pps->occCls[-vi][j];
			   if(andclsPos[0]>=0){// S''=R*G' v R'*G
				   if(andclsPos[0]!=posA) { // R(x)*G(-x)
					   if(andclsPos[1]!=posB && andclsPos[2]!=posB) {
						  // printf(" R*R' ");
						   continue;
					   }
				   }
				   else{ // G(x)*R(-x)
					   if(andclsPos[1]==posB || andclsPos[2]==posB) {
						   //printf(" G*G' ");
						   continue;
					   }
				   }
			   }
		       lenB=(*clsSAT)[posB];
       		   if( (lenB & MARKBIT)==DELETED) continue;
			   lenB=lenB>>FLAGBIT;
	           clsB_size=clsSAT->nowpos();
			   for (pi=posB+1; pi<posB+lenB; pi++){
			       int blit=(*clsSAT)[pi];
	        	        if(blit==-vi) continue;
                   int vv=ABS(blit);
			       if(unit[vv]){
					   if(unit[vv]==blit) goto nextj;
					   continue;
				   }
				   if(seen[vv]==-blit) goto nextj;
				   if(seen[vv]==0) clsSAT->push(blit);
			   }
		       nextbegin=clsSAT->nowpos();
		       k=nextbegin-clsbegin;
			   if(k==1) {// bug 2011/9/24
	        	   clsSAT->shrink(origsize);
				   return UNSAT;
			   }
			   if(k==2){
				   NewUnit=true;
				   int lit=(*clsSAT)[clsbegin+1];
				   unit[ABS(lit)]=lit;
				   end=1; 
				   goto clearSeen;
			   }
		       newCNFs++;
			   if(newCNFs>pos+neg-delta){ end=1; goto clearSeen; }
	           Newsize=nextbegin;
		       (*clsSAT)[clsbegin]=(k<<FLAGBIT) | CNF_CLS;//len
			   clsSAT->push(0);
			   for(m=1; m<=k1; m++) {
				   int clit=(*clsSAT)[clsbegin+m];
				   clsSAT->push(clit); // move A-type CNF to next
			   }
			   clsbegin=nextbegin;
			   continue;
nextj:          
			   clsSAT->shrink(clsB_size);
			}
clearSeen:
		 clsSAT->shrink(Newsize);
         for (pi=posA+1; pi<posA+len; pi++){
			  int alit=(*clsSAT)[pi];
			  seen[ABS(alit)]=0;
		 }
		 if(end){
			 clsSAT->shrink(origsize);
		     return _UNKNOWN;
		 }
	}
	if(newCNFs<=pos+neg-delta){//set delete mark
    	clsSAT->shrink(Newsize);
		int pivot;
		if(pps->occCls[vi]<pps->occCls[-vi]) pivot=vi;
		else pivot=-vi;
		int occN=pps->occCls[pivot];
		for(i=0; i<occN; i++){
				posA=pps->occCls[pivot][i];
		        int len=(*clsSAT)[posA];
                if( (len & MARKBIT)==DELETED) continue;
			    pps->extend.push(0);
                pps->extend.push(pivot);
	     	    len=len>>FLAGBIT;
	
		
				for(int i=posA+1; i<posA+len; i++){
					int lit=(*clsSAT)[i];
					if(pivot!=lit) pps->extend.push(lit);
				}
		}
		
	//
		for(m=0; m<2; m++){
			int vv;
			if(m) vv=vi;
			else vv=-vi;
			
			int occM=pps->occCls[vv];
			for(i=0; i<occM; i++){
				posA=pps->occCls[vv][i];
		        int len=(*clsSAT)[posA];
		  	    len=len>>FLAGBIT;
	            (*clsSAT)[posA]=(len<<FLAGBIT) | DELETED;
				for(int i=posA+1; i<posA+len; i++){
					int lit=(*clsSAT)[i];
					if(vv!=lit){
						pps->occCls[lit].shrink(0);// ??? bug 3 2011
					    pps->occCls[-lit].shrink(0);
					}
				}
			}
		}
	//	if(pps->numClause<100) check((int *)0, clsSAT);
		deletedVnum++;
	}
	else{
	     clsSAT->shrink(origsize);
	}
	return _UNKNOWN;
}	

int XOR_varElimination(PPS *pps,char *tabuVar)
{
	int pos,neg;
	int i,j,clsCnt,k,deletedVnum,preNum;
        int alpha,beta;
        int posB,sz,*litB;
  	
        if(pps->seen==0) pps->seen=(int *)calloc(pps->numVar+1,sizeof(int));
   	if(pps->numClause>150000 && pps->numClause<1000000){ alpha=4; beta=4;}
	else {alpha=2; beta=3;}
        int *seen=pps->seen;
	deletedVnum=0;
	while(1){
     	preNum=deletedVnum;
		int ipos=0;
	    Stack<int> * clsSAT=pps->clause;
        Stack<int> * occCls=pps->occCls;
        int endpos=clsSAT->nowpos();
    	clsCnt=0;
		while(ipos < endpos){
			int len=(*clsSAT)[ipos];
			int mark=len & MARKBIT;
		    len=len>>FLAGBIT;
		    ipos+=len;
			if(mark==DELETED) continue;
			clsCnt++;
	        if(len>21) continue;
		    int MinOcc=1000000;
            int lit=0;  
			for(i=ipos-len+1; i<ipos; i++) {
		       int clit=(*clsSAT)[i];
		       if(occCls[clit]<=0 || occCls[-clit]<=0) continue;
			   int occN=occCls[clit]+occCls[-clit];
			   if(occN<MinOcc) {lit=clit; MinOcc=occN;}
			}
            if(MinOcc>40 || MinOcc<=2) continue;
			if(tabuVar){
				if(tabuVar[ABS(lit)]) continue; //2012/1/12
			}
         	for(i=ipos-len+1; i<ipos; i++) {
		       int clit=(*clsSAT)[i];
		       seen[ABS(clit)]=clit;
			}
			int occN=occCls[-lit];
			int num2=0;
			for(j=0; j<occN; j++){
   	             int posB=occCls[-lit][j];
				 int sz=(*clsSAT)[posB];
				 sz=sz>>FLAGBIT;
		   		 if(sz>64) { num2=100; break;}
				 int *litB=&(*clsSAT)[posB+1];
                 k=0;
			   	 for(sz=sz-2; sz>=0; sz--){
					   int lt=litB[sz];
				 	   if(seen[ABS(lt)]==-lt) k++;
				 }
		         if(k<2) num2++;
			}
		    for(i=ipos-len+1; i<ipos; i++) {
		       int clit=(*clsSAT)[i];
		       seen[ABS(clit)]=0;
			}
			if(num2>2) goto No_delete;
			posB=occCls[-lit][0];
			sz=(*clsSAT)[posB];
			sz=sz>>FLAGBIT;// bug 2011/9/23 
	        litB=&(*clsSAT)[posB+1];
            for(j=sz-2; j>=0; j--) {
		   	seen[ABS(litB[j])]=litB[j];
			}
            occN=occCls[lit];
			for(j=0; j<occN; j++){
   	              int posA=occCls[lit][j];
				  int szA=(*clsSAT)[posA];
				  szA=szA>>FLAGBIT;
		   		  if(szA>64) { num2=10000; break;}
				  k=0;
			      int *litA=&(*clsSAT)[posA+1];
                  for(szA=szA-2; szA>=0; szA--){
					   int lt=litA[szA];
				 	   if(seen[ABS(lt)]==-lt) k++;
				  }
		          if(k<2) num2++;
			}
		    for(j=sz-2; j>=0; j--) seen[ABS(litB[j])]=0;
            if(num2>beta) goto No_delete;
	        pos=occCls[lit];
            neg=occCls[-lit];
	        num2=0;
			int i;
			for(i=0; i<pos; i++){
   	            int posA=occCls[lit][i];
   		        int sz=(*clsSAT)[posA];
				sz=sz>>FLAGBIT;
		   		int *litA=&(*clsSAT)[posA+1];
                int *pcls=litA+sz-1;
				for(; litA<pcls; litA++) seen[ABS(*litA)]=*litA;
   	            for(j=0; j<neg; j++){
   	                posB=occCls[-lit][j];
			        k=0;
			        int sz2=(*clsSAT)[posB];
				    sz2=sz2>>FLAGBIT;
	                int *litB=&(*clsSAT)[posB+1];
                    int *pclsB=litB+sz2-1;
					for(; litB<pclsB; litB++) if(seen[ABS(*litB)]==-(*litB)) k++;
					if(k<2) num2++;
                }
			  	litA=&(*clsSAT)[posA+1];
              	for(; litA<pcls; litA++) seen[ABS(*litA)]=0;
			}
			if(num2/alpha>pos+neg) goto No_delete; //2
			{
				bool NewUnit;
	    	    int rc=subsumptionResolution(pps, lit, deletedVnum,NewUnit,num2);
	  		    if(rc==UNSAT) return UNSAT;
			    if(NewUnit) preNum=-1;
			}
	No_delete:
			;
		}
	    if(preNum!=deletedVnum) {
	  		  int rc=deletegarbage(pps); //bug 2011/9/25
	  		  if(rc==UNSAT) return UNSAT;
	    }
       	setDoubleDataIndex(pps,false);
        if(clsCnt>=pps->numClause || preNum==deletedVnum) break;
	}
    return _UNKNOWN;
}

void sortColumn(Stack<int> * & clause, int j_th, int numVar)
{    int i,j,k,lit,sum;
     int *cluaseLen;
	 
	 int maxLit=2*numVar+2;
	 cluaseLen=(int *) malloc(sizeof(int)*(maxLit));
     for(i = 0; i < maxLit; i++) cluaseLen[i] = 0;
   
	 int *pcls=clause->begin();
	 int *pend=clause->end();
	 int stacksize=pend-pcls;
  	 while(pcls < pend){
            int len=*pcls;
		    len=len>>FLAGBIT;
		    int *lits=pcls+1;
            pcls+=len;
		    if (j_th >= len-1) lit=0;
            else lit=ABS(lits[j_th]);
		    cluaseLen[lit]+=len;
	 }
     Stack<int> * clause2=new Stack<int>;
     clause2->memalloc (stacksize);
	 sum=0;
     for(i = 0; i < maxLit;i++) {
 		 j=cluaseLen[i];  cluaseLen[i]=sum;   sum+=j;
     }
//copy
	 pcls=clause->begin();
	 while(pcls < pend){
            int len=*pcls;
		    int *lits=pcls;
            len=len>>FLAGBIT;
		    pcls+=len;
	 	    if (j_th >= len-1) lit=0;
            else lit=ABS(lits[j_th+1]);
		    k=cluaseLen[lit];
	        for (; lits<pcls; lits++) (*clause2)[k++]=*lits;
           	cluaseLen[lit]=k;
	 }
	 delete clause;
	 clause=clause2;
	 free(cluaseLen);
//	 check((int *)0,clause);
}	 

// l1 <-> l2
// l1 <-> l2 <-> l3
// l1 <-> l2 <-> l3 <-> l4
int get_2_3_4_equivalence(PPS *pps, int mergeFlag)
{   int i,j,k,m,n,mm,lit2=0;
    int *matchCli,match[17],pattern[17];
	int *pair,*XORno,Xn,mergeAB;

	getclausePos(pps);

	Stack<int> * clauseCNF=pps->clause;
    Stack<int> * clausePos=pps->clausePos;
	int numClauses=pps->numClause;

	XORno=(int *) malloc(sizeof(int)*(numClauses+pps->numVar+1));
    pair=XORno+numClauses;
	for(i=0; i <=pps->numVar; i++) pair[i]=0;
   	int msize=64;
    matchCli=(int *) malloc(sizeof(int)*(msize));

	Xn=0;
	for(i=0; i< 16; i++) pattern[i]=0;
	pattern[3]=pattern[5]=pattern[6]=pattern[9]=pattern[10]=pattern[12]=pattern[15]=1;

	i=0; mergeAB=0;
	while (i < numClauses){
		 int iPos=(*clausePos)[i];
		 int len=(*clauseCNF)[iPos];
		 if((len & MARKBIT)==DELETED) {i++; continue;} 
		 len=len>>FLAGBIT;
		 int size1=len-1;
		 if(size1!=4 && size1!=3 && size1!=2) { i=i+1; continue; }
		 mm=n=0;
		 match[3]=match[5]=match[6]=match[9]=match[10]=match[12]=match[15]=0;
		 iPos++;
		 for(j=i+1; j < numClauses; j++){
    	     int jPos=(*clausePos)[j];
		     int jLen=(*clauseCNF)[jPos];
		     jLen=jLen>>FLAGBIT;
		 	 if(jLen!=len) break;
			 m=0;
			 jPos++;
			 for(k=0; k<size1; k++){
			     m=2*m;
	             //if(Clit[i][k]==-Clit[j][k]) m++;
			     //else if(Clit[i][k]!=Clit[j][k]) break;
		         if((*clauseCNF)[iPos+k]==-(*clauseCNF)[jPos+k]) m++;
				 else{
				     if((*clauseCNF)[iPos+k]!=(*clauseCNF)[jPos+k]) break;
				 }
			 }
			 if(k<size1) break;
			 if(pattern[m]!=1) continue;
			 if(mm>=msize){
				msize=2*msize;
		     	matchCli=(int*)realloc(matchCli, sizeof(int)*msize);
			 }
			 matchCli[mm++]=j;
			 if(match[m]!=1){
				  n++;
                  match[m]=1;
			 }
		 }
		 if((size1==4 && n==7) || (size1==3 && n==3) || (size1==2 && n==1)){
			  // for(k=0;k<mm;k++) EqFlag[matchCli[k]]=2;
		  	//		 EqFlag[i]=1;
			   (*clauseCNF)[iPos-1]=(len<<FLAGBIT) | XOR_CLS; // xor clause; 
			   for(k=0;k<mm;k++) {
		            int kPos=(*clausePos)[matchCli[k]];
			       // (*clauseCNF)[kPos]=(len<<FLAGBIT) | DELETED; //  remove clause; 
			          (*clauseCNF)[kPos]=(len<<FLAGBIT) | FROZE; //  freeze clause; 
			   }
//equivalent A <-> B <-> C and A <-> B <-> D ==> C=D    
			  if(size1==3 && mergeFlag==1){  //merge C and D
				   int pi;
				   for(k=0; k<Xn; k++){
 			            int Not,True,lit,lit1;
						for(pi=0; pi<3; pi++) {
							int ilit=(*clauseCNF)[iPos+pi];
							pair[ABS(ilit)]=ilit;
						}
						m=XORno[k]; Not=0, True=0;
                    	int mPos=(*clausePos)[m]+1;
                        for(pi=0; pi<3; pi++) {
							lit=(*clauseCNF)[mPos+pi];
							if(pair[ABS(lit)]==0) {Not++; lit2=lit;}
							else{
								if(pair[ABS(lit)]==-lit) True=True^1;
								pair[ABS(lit)]=0;
							}
						}
						if(Not!=1) continue;
						for(pi=0; pi<3; pi++) {
							//lit1=Clit[i][pi];
							lit1=(*clauseCNF)[iPos+pi];
							if(pair[ABS(lit1)]) break;
						}
			            if(True) lit2=-lit2;
						int a=find1(pps,lit1);
				        int b=find1(pps,lit2);
			            if (a == b) break; //continue;
	                    if (a == -b) { free(XORno); return UNSAT; }
		          		    mergeTwoEqu(pps,a,b);
						mergeAB=1;
						break;
				   }
				   for(pi=0; pi<3; pi++) {
					   int ilit=(*clauseCNF)[iPos+pi];
					   pair[ABS(ilit)]=0;
				   }
				   if(k>=Xn) XORno[Xn++]=i;
				   else {
			  //        (*clauseCNF)[iPos-1]=(len<<FLAGBIT) |  DELETED; // remove clause;
    			        (*clauseCNF)[iPos-1]=(len<<FLAGBIT) |  FROZE; // freeze clause;
				//	 EqFlag[i]=2;  // A==B 
				   } 
			   }
			   if(j-i>n+1) i++;
			   else i=j;
		 }
		 else i=j;
	}
	free(XORno);
    free(matchCli);
	if(mergeAB) {
		 mergeAllEqu(pps);
	}
	return SAT;
}

int Remove_3_4_equivalent(PPS *pps)
{
	 int delrepeat=0;
     sortClause(pps->clause,4,pps->numClause,pps->numVar,delrepeat); //??no duplicate
  	 int mergeFlag=1; 
	 int rc=get_2_3_4_equivalence(pps,mergeFlag);
	 if(rc==UNSAT) return rc;
//delete non-XOR clauses, remain CNF and XOR clauses, replace equ-var 
	// int change;
	// rc=deletegarbage(pps,change);
	// if(rc==UNSAT) return rc;
 	// setDoubleDataIndex(pps,false);
   	 return _UNKNOWN;
}

void sortindex(int *keyvar1,int *keyvar2, int *VarWeight,int pos,int numVar)
{   int *count;
    int i,sum,m,Msize,val,vv;
    int base;

    base=Msize=1024;
    count=(int *) malloc(sizeof(int)*Msize);
 	for (i = 0; i <Msize; i++) count[i]=0;
    for (i = 0; i <numVar; i++) {
		vv=keyvar1[i];
		if(pos) val=VarWeight[vv]/base;
		else val=VarWeight[vv]%base;
		if (val>=Msize) val=Msize-1;
		count[val]++;
	}
	sum=0;
	for(i=Msize-1; i>=0; i--){
        m=count[i];
		count[i]=sum;
	    sum+=m;
	}
//	int real=count[0];
    for (i = 0; i <numVar; i++){
		vv=keyvar1[i];
		if(pos) val=VarWeight[vv]/base;
		else val=VarWeight[vv]%base;
		if (val>=Msize) val=Msize-1;
		m=count[val];
		
		keyvar2[m]=vv;
		count[val]=m+1;
	}
    free(count);
}

int sortkey(int *keyvar,int *VarWeight,int numvar)
{   int i,real,vv;
    int *keyvar2=(int *) malloc(sizeof(int)*numvar);
    for (i = 0; i <numvar; i++) keyvar[i]=i+1;
    sortindex(keyvar, keyvar2, VarWeight,0,numvar);
    sortindex(keyvar2,keyvar,  VarWeight,1,numvar);
    free(keyvar2);
	for (real=numvar-1; real>=0; real--) {
		vv=keyvar[real];
		if(VarWeight[vv]) break;
	}
	real++;
    keyvar[real]=0;
	return real;
}

int XOR_Preprocess(PPS *pps)
{
    int vi,rc;
 
   	rc=Remove_3_4_equivalent(pps);
 	if(rc==UNSAT) return UNSAT;
    
	pps->numXOR=pps->n_inative=0;
	
	Split_XOR_CNF(pps);

    copyXORclause(pps->org_xorClause,pps->numXOR);
    pps->numXOR_org=pps->numXOR;

   
//Eq_simplify:
 	DependentVar=(int *) malloc( sizeof(int) *(pps->numVar+1));
    for(vi=1; vi<=pps->numVar; vi++) DependentVar[vi]=-2;          //independent
    
	int numXOR=pps->numXOR;
	setDoubleDataIndex(pps,false);
	pps->numXOR=numXOR;

	rc=equivalence_reasoning(pps);
	free(DependentVar);
 
	if(rc==UNSAT) return UNSAT;
    printf("c inative var#=%d numXOR=%d \n",pps->n_inative,pps->numXOR);
	return _UNKNOWN;
}

int GetInactiveXOR(int *inactiveVar,int inactivesize,int *clauseFlag,PPS *pps, int & numBigXOR)
{   int i,j,k,n,n1,n2,var=0,lit,Trues,jsum;
    int inaqueue[1000],*px;
	int **inaLit=pps->inaLit;

	int n_inative=pps->n_inative;
	for(i=0; i<pps->numXOR; i++){
		 if(clauseFlag[i]!=inactivesize) continue;
		 Trues=1;
	     n2=0;
		 for(px=Leq[i]; px<Leq[i+1]; px++){
			 lit=*px;
             vBoolookup[lit]=(vBoolookup[lit]+1)%2;
		 	 inaqueue[n2]=inactiveVar[ABS(lit)];   //Equ No. of inactive var
			 if(inaqueue[n2]>0) n2++;     
         }
		 n1=0;
		 if(n2>=2){
			 if(inaqueue[0]>inaqueue[1]) Swap(inaqueue[0],inaqueue[1]);
			 if(n2==3) if(inaqueue[1]>inaqueue[2]) Swap(inaqueue[1],inaqueue[2]);
		 }
		 while(n1<n2){
			 n=inaqueue[n1++];
			 if(n<=0) continue;
			 Trues++;
			 int *p0=inaLit[n-1];
			 for(px=p0; px<inaLit[n]; px++){
				   lit=*px;
                   vBoolookup[lit]=(vBoolookup[lit]+1)%2;
				   if(px==p0) continue;
				   inaqueue[n2]=inactiveVar[ABS(lit)];
				   if(inaqueue[n2]>0) {
					   int pp=n2-1;
					   while(pp>=n1){
						   if(inaqueue[pp]<=inaqueue[n2]){
							   break;
						   }
						   pp--;
                       }
					   if(inaqueue[pp]==inaqueue[n2] && pp>=n1){
						     while(pp<n2) {inaqueue[pp]=inaqueue[pp+1];pp++;}
					 		 n2--;
                       }
					   else{
						    int p2=n2; 
                			while(pp<p2) {inaqueue[p2+1]=inaqueue[p2];p2--;}
                            inaqueue[pp+1]=inaqueue[++n2];
					   } 
				   }
        	 }
		 }
		 jsum=0;
	   	 for(px=Leq[i]; px<Leq[i+1]; px++){
			 lit=*px; 
             if(vBoolookup[lit]==0){
                  if(vBoolookup[-lit]!=0) inaLit[n_inative][jsum++]=-lit;
             }
			 else{
                 if(vBoolookup[-lit]==0) inaLit[n_inative][jsum++]=lit;
                 else Trues++;
			 }	 
			 vBoolookup[lit]=vBoolookup[-lit]=0;
	     }
		 n1=0;
		 while(n1<n2){
		 	 n=inaqueue[n1++];
			 for(px=inaLit[n-1]; px<inaLit[n]; px++){
					lit=*px;
                    if(vBoolookup[lit]==0){
                           if(vBoolookup[-lit]!=0) inaLit[n_inative][jsum++]=-lit;
					}
			        else{
                          if(vBoolookup[-lit]==0) inaLit[n_inative][jsum++]=lit;
                          else Trues++;
					}
					vBoolookup[lit]=vBoolookup[-lit]=0;
			 }
		 }
	  	 if(jsum==0){
			 if(Trues%2==1) return UNSAT;
			 //	 printf(" \n A: fails to obain an inactive var ");
			 continue;
		 }
//move inactive var to 1st position
		 for(j=0; j<jsum; j++){
              var=ABS(inaLit[n_inative][j]);
		      if(inactiveVar[var]==-1) {
			      Swap(inaLit[n_inative][0], inaLit[n_inative][j]);
			      break;
		      }
         }
		 if(Trues%2==0) inaLit[n_inative][0]=-inaLit[n_inative][0];
		 if(inactiveVar[var]!=-1){  //give up
		     for(k=0; k<jsum; k++) BigEq[numBigXOR][k]=inaLit[n_inative][k];
			 BigEq[numBigXOR+1]=BigEq[numBigXOR]+jsum;
			 numBigXOR++;
			 continue;
         }
		 clauseFlag[i]=-1;
		 inaLit[n_inative+1]=inaLit[n_inative]+jsum;
         n_inative++;
		 inactiveVar[var]=n_inative;
	}
 	pps->n_inative=n_inative;
	return _UNKNOWN;
}

//move one A-eqution to B-equtions
int repalceNextXOR(int **A_eq,int Ano,int **B_eq,int Bno, int maxEqno)
{   int n,n1,n2,lit,Trues;
    int *pv,*last;
    int *DepQueue,maxLen;

	maxLen=Bno+4096;//bug equilarge_l2
	DepQueue=(int *) malloc(sizeof(int *)*(maxLen+16)); //dependent Queue
  	
	int *Eqn_seen=(int *)calloc(maxEqno,sizeof(int));
 
	Trues=1;
    n2=0;
	for(pv=A_eq[Ano]; pv<A_eq[Ano+1]; pv++){
		  lit=*pv;
          vBoolookup[lit]=(vBoolookup[lit]+1)%2;
		  DepQueue[n2]=DependentVar[ABS(lit)];   //Equ No. of dependent var
		  if(DepQueue[n2]>0) {
			  Eqn_seen[DepQueue[n2]]=1;
			  n2++;
		  }
	}
	n1=0;
	if(n2>=2){  //for shortening queue size
		 if(DepQueue[0]>DepQueue[1]) Swap(DepQueue[0],DepQueue[1]);
		 if(n2==3) if(DepQueue[1]>DepQueue[2]) Swap(DepQueue[1],DepQueue[2]);
	}
	while(n1<n2){
		 n=DepQueue[n1++];
		 if(n<=0) continue;
		 if(Eqn_seen[n]==0){
              DepQueue[n1-1]=-1;
			  continue;
		 }
		 Trues++;
		 int *p0=B_eq[n-1];
		 Eqn_seen[n]=0;
		 last=B_eq[n-1]+CeqLen[n-1]; //real size
		 for(pv=p0; pv<last; pv++){
			   lit=*pv;
               vBoolookup[lit]=(vBoolookup[lit]+1)%2;
			   if(pv==p0) continue;
			   DepQueue[n2]=DependentVar[ABS(lit)];
			   if(DepQueue[n2]>0) {
				   if(Eqn_seen[DepQueue[n2]]) Eqn_seen[DepQueue[n2]]=0;
				   else { 
					   Eqn_seen[DepQueue[n2]]=1;
				       n2++;
					   if(n2>maxLen){  //reduce memory space
						   int i,j;
						   for(i=j=0; i<n2; i++){ 
							   if(i==n1) n1=j;
							   if(DepQueue[i]>0){
							      DepQueue[j++]=DepQueue[i];
							   }
						   }
						   n2=j;
					   }
				   }
			   }
		 }
	}
	int *Neq=B_eq[Bno];
	for(pv=A_eq[Ano]; pv<A_eq[Ano+1]; pv++){
		lit=*pv;
        if(vBoolookup[lit]==0){
			if(vBoolookup[-lit]!=0) { *Neq=-lit; Neq++;	}
		}
		else{
			if(vBoolookup[-lit]==0) { *Neq=lit;	Neq++;	}
            else Trues++;
		}	 
		vBoolookup[lit]=vBoolookup[-lit]=0;
	}
	n1=0;
	while(n1<n2){
		n=DepQueue[n1++];
		if(n<=0) continue;
		last=B_eq[n-1]+CeqLen[n-1]; //real size
		for(pv=B_eq[n-1]; pv<last; pv++){
			  lit=*pv;
              if(vBoolookup[lit]==0){
                      if(vBoolookup[-lit]!=0) {*Neq=-lit; Neq++;}
			  }
			  else{
                      if(vBoolookup[-lit]==0) {*Neq=lit; Neq++;}
                      else Trues++;
			  }
		      vBoolookup[lit]=vBoolookup[-lit]=0;
		 }
	}
	free(DepQueue);
  	free(Eqn_seen);
	if(Neq==B_eq[Bno]){
		if(Trues%2==1){
			printf("c false Constant XOR equation\n");
			return UNSAT;
		}
		printf("c  Constant XOR equation\n");
		return CONST_EQ; 
	}
    else if(Trues%2==0) *(Neq-1)=-(*(Neq-1));
    B_eq[Bno+1]=Neq;
	return _UNKNOWN;
}

/****************************************************************************
	We selects in all equivalence clauses one 
	variable to eliminate from all other equivalence clauses. The
	selection is based on the occurences of variables in the CNF.
*****************************************************************************/
int getXORdependent(PPS *pps)
{ 
    int i,j,var,rc,weight;
    int *VeqValues;
    
    int maxEqno=pps->numXOR+1;
 	CeqLen=(int *) malloc( sizeof(int)*maxEqno);
    BigEq=(int **) malloc( sizeof(int *)*maxEqno);
	int virtualsize=64*(Leq[pps->numXOR]-Leq[0]);//64
	
	BigEq_set=(int *) malloc( sizeof(int) *virtualsize);
    VeqValues=(int *) malloc( sizeof(int) *(pps->numVar+1));
	
 //computer the occurences of variables in the CNF weight =11 or 1
	for(var=1; var<=pps->numVar; var++) VeqValues[var]=0;
    int *pcls=pps->clause->begin();
	int *pend=pps->clause->end();
  	while(pcls < pend){
         int len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
		 int *lits=pcls+1;
         pcls+=len;
		 if(mark!=CNF_CLS) continue; //remove;
         if(len==3) weight=11;
		 else weight=1;
		 for (; lits<pcls; lits++) {
			 var=ABS(*lits);
             VeqValues[var]+=weight;
		 }
	 }
//copy first XOR
	BigEq[0]=BigEq_set;
	CeqLen[0]=Leq[1]-Leq[0];
	for(j=0; j<CeqLen[0]; j++) BigEq[0][j]=Leq[0][j]; 
	BigEq[1]=BigEq[0]+CeqLen[0];
    int numBigXOR=1;
	int oldeqNo,depFlag=1;
	for(oldeqNo=1; oldeqNo<=pps->numXOR; oldeqNo++){
// find dependent variables
		if(depFlag){
			int *first=BigEq[numBigXOR-1];
		    int *minpos=first;
		    int min=600000;
		    int *p;
            for(p=first; p<BigEq[numBigXOR]; p++){
			   var=ABS(*p);
			   if(DependentVar[var]!=-2) continue; //not independent
			   if(VeqValues[var]<min){ min=VeqValues[var]; minpos=p;}
			}
	        if(min!=600000){
    		   Swap(*first, *minpos);
	           var=ABS(*first);
			   DependentVar[var]=numBigXOR;   //eq. no from 1 (not 0)
			}
		}
        if(oldeqNo==pps->numXOR) break;
//get big XOR clause
		rc=repalceNextXOR(Leq,oldeqNo,BigEq,numBigXOR,maxEqno);
		if(rc==UNSAT) return UNSAT;
		if(rc==CONST_EQ) {
			/*
			free(BigEq_set);
         	free(BigEq);
        	free(VeqValues);
            free(CeqLen);
			return CONST_EQ; //constant equation
			*/
			  depFlag=0; 
		  	  continue;
		}
		depFlag=1;
		CeqLen[numBigXOR]=BigEq[numBigXOR+1]-BigEq[numBigXOR];
		numBigXOR++;
	}
	free(VeqValues);
//save old Leq
	int *old_Leq_base=Leq_base;
	//int old_numXOR=pps->numXOR;
	int **old_Leq=Leq;
    Leq=(int **) malloc( sizeof(int*)*(pps->numXOR+1));
//remove all dependent var;
//	int numXOR=numBigXOR;
	BigEq_set=(int*)realloc(BigEq_set, sizeof(int)*(BigEq[numBigXOR]-BigEq[0]));
	int newEQsize=4*virtualsize;
	Leq_base=(int *) malloc( sizeof(int)*newEQsize);
//copy last XOR
    Leq[0]=Leq_base;
	int Asum=0;
	int *pv;
    for(pv=BigEq[numBigXOR-1]; pv<BigEq[numBigXOR]; pv++) Leq[0][Asum++]=*pv;
	CeqLen[0]=Asum;
	if(Asum<6) Asum=8*Asum;
	else Asum=4*Asum;
	Leq[1]=Leq[0]+Asum;
	int Cur_numXOR=1;
//copy other XOR
	for(var=1; var<=pps->numVar; var++) DependentVar[var]=-2; //-2 : independent  >0 : Equ.no
	for(i=numBigXOR-2; i>=-1; i--){
		var=Leq[Cur_numXOR-1][0];
		var=ABS(var);
		if(DependentVar[var]==-2) DependentVar[var]=Cur_numXOR;
		if(i==-1) break;
		
	    if(newEQsize-8000<Leq[Cur_numXOR]-Leq[0]){ //bug ???
            free(Leq_base);
            free(BigEq_set);
        	free(BigEq);
            free(Leq);
            free(CeqLen);

            Leq=old_Leq;
	        Leq_base=old_Leq_base;
        //    numXOR=old_numXOR;
			return CONST_EQ;
		}
		
		rc=repalceNextXOR(BigEq,i, Leq, Cur_numXOR, maxEqno);
		int size=CeqLen[Cur_numXOR]=Leq[Cur_numXOR+1]-Leq[Cur_numXOR];
		Cur_numXOR++;
    	if(size<6) size=4*size;
	    else size=2*size;
		Leq[Cur_numXOR]+=size; //double (three) space for shortening Eq cluases
	}
//endeq:
	free(old_Leq);
	free(old_Leq_base);

	free(BigEq_set);
	free(BigEq);
	Leq_base=(int*)realloc(Leq_base, sizeof(int)*(Leq[Cur_numXOR]-Leq[0]));
	SetClausePtr(Leq, Leq_base, Cur_numXOR);
	pps->numXOR=Cur_numXOR;
	return _UNKNOWN;
}

// Copy XOR equation and CNF clauses from CNF bases
void Split_XOR_CNF(PPS *pps)
{    int XORsum,size,numXOR,numcls;

     numcls=numXOR=size=0;
	 int *pcls=pps->clause->begin();
	 int *pend=pps->clause->end();
  	 while(pcls < pend){
         int len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
         pcls+=len;
	     if( mark==DELETED) continue; //remove;
         if( mark==XOR_CLS) {
	          numXOR++;
              size+=len;
		 }
		 numcls++;
	 }
	 pps->numClause=numcls;
	 if(numXOR==0) return;
	 
	 Leq_base=(int *) malloc( sizeof(int)*(size));
     
	 Eq_base=(int *) malloc( sizeof(int)*(size+pps->numVar+1));
	 Leq=(int **) malloc( sizeof(int*)*(numXOR+1));
	 //Stack<int> *NewClause=new Stack<int>; 
     numXOR=XORsum=0;
	 Leq[0]=Leq_base;
	 pcls=pps->clause->begin();
	 while(pcls < pend){
         int len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
         int *lits=pcls;
	     pcls+=len;
		 if( mark==DELETED) continue; //remove;
       	 if( mark==XOR_CLS) {
	 	 //    *lits=(len<<FLAGBIT) | DELETED;
		     *lits=(len<<FLAGBIT) | FROZE;
		     for(lits++; lits<pcls; lits++) Leq_base[XORsum++]=*lits;
		     Leq[++numXOR]=Leq_base+XORsum;
			 continue;
	  	 }
	   //  for(; lits<pcls; lits++) NewClause->push(*lits);
	}
    //delete pps->clause;
//	pps->clause=NewClause;
    pps->numXOR=numXOR;
}

void defreezeclause(PPS *pps)
{    
	 int numcls=0;
   	 int *pcls=pps->clause->begin();
	 int *pend=pps->clause->end();
  	 while(pcls < pend){
         int len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
         int *lits=pcls;
         pcls+=len;
	     if( mark==DELETED) continue; //remove;
         if( mark==XOR_CLS || mark==FROZE) *lits=(len<<FLAGBIT) | CNF_CLS;
		 numcls++;
	 }
	 pps->numClause=numcls;
}

Stack<int> *occCNF;
int occCNFcmp( const void *ptrA, const void *ptrB )
{
    int LitA=*(int *)ptrA;
	int numA=occCNF[LitA]+occCNF[-LitA];
	int LitB=*(int *)ptrB;
	int numB=occCNF[LitB]+occCNF[-LitB];
	if(numA>numB) return 1;
    if(numA<numB) return -1;
	return 0;
}

/****************************************************************************
	Find inactive variables in equivalence clauses 
	Eliminate it from all other equivalence clauses. 
	This process is based on the occurences of variables in the CNF and XOR.

*****************************************************************************/
int RemoveInative_XOR_Equ(PPS *pps) //c7bidw_i
{    int i,j;
     int *inactiveVar,*clauseFlag,*px;

   	 inactiveVar=(int *) malloc( sizeof(int) *(2*pps->numVar+8+pps->numXOR));
     int *varVect=clauseFlag=inactiveVar+pps->numVar+1;
     
	 int *XORocc=(int *) malloc(sizeof(int) *(pps->numVar+1));
     for(i=0; i <=pps->numVar;i++) XORocc[i]=0;
     for(int *pv=Leq[0]; pv<Leq[pps->numXOR]; pv++) XORocc[ABS(*pv)]++;

// find inactive variables
     int n_inative=0;     
     pps->inactiveVar=new Stack<int>;
	 j=0;
	 for(i=1; i<=pps->numVar;i++) if(XORocc[i]) varVect[j++]=i;
         occCNF=pps->occCls;
	 Adp_SymPSort((void *)varVect, j, sizeof(int), occCNFcmp);
         for(i=1; i<=pps->numVar; i++) inactiveVar[i]=-2;
  	 int max_ina;
	 if(j>pps->numXOR) max_ina=pps->numXOR;
	 else max_ina=j;
	 max_ina-=((2*max_ina)/3);
     for(i=0; i<j; i++){
		 int v=varVect[i];
		 if(i<max_ina){
			 n_inative++;
			 inactiveVar[v]=-1;
			 pps->inactiveVar->push(v);
		 }
	 }
	 free(XORocc);
     pps->n_inative=n_inative;
     printf("c n_inative=%d \n",n_inative);
  	 if(n_inative==0) {
	    free(inactiveVar);
		delete pps->inactiveVar;
		pps->inactiveVar=0;
		return _UNKNOWN;
	 }
     
	pps->inaLit=(int **) malloc( sizeof(int *) *(n_inative+10));
	int *iLit_set=(int *) malloc( sizeof(int) *(400*n_inative)); //100

// find inactive XOR equtions
	int max=0,min=1000, m=0;
	int numXOR=pps->numXOR;

	for(i=0; i<pps->numXOR; i++){
		clauseFlag[i]=0;
		for(px=Leq[i]; px<Leq[i+1]; px++){
       		  if(inactiveVar[ABS(*px)]==-1) clauseFlag[i]++;
		}
		if(clauseFlag[i]==0) {m++; continue;}
		if(clauseFlag[i]<min) min=clauseFlag[i];
		if(clauseFlag[i]>max) max=clauseFlag[i];
	}
    
	BigEq=(int **) malloc( sizeof(int *)*(numXOR+1));
	int virtualsize=20*(Leq[numXOR]-Leq[0]);
	BigEq_set=(int *) malloc( sizeof(int) *virtualsize);

	pps->inaLit[0]=iLit_set;
	BigEq[0]=BigEq_set;
	int numBigXOR;
	pps->n_inative=numBigXOR=0;
	for(i=min;i<=max; i++) {
    	int rc=GetInactiveXOR(inactiveVar,i,clauseFlag,pps,numBigXOR);
		if(rc==UNSAT) return UNSAT;
    }
  	n_inative=pps->n_inative;
// Copy active XOR equtions
	int numclause=0;
   	for(i=0; i<numXOR; i++){
		 if(clauseFlag[i]!=0) continue;
         j=0;
		 for(px=Leq[i]; px<Leq[i+1]; px++) Leq[numclause][j++]=*px;
  		 Leq[numclause+1]=Leq[numclause]+j;
         numclause++;
 	}
	int newsize=Leq[numclause]-Leq[0];
    newsize+=(BigEq[numBigXOR]-BigEq[0]);
    Leq_base=(int*) realloc(Leq[0], sizeof(int)*(newsize));
    SetClausePtr(Leq, Leq_base, numclause);
 
// Copy big XOR clauses
	for(i=0; i<numBigXOR; i++){
		 j=0;
         for(px=BigEq[i]; px<BigEq[i+1]; px++) Leq[numclause][j++]=*px;
 		 Leq[numclause+1]=Leq[numclause]+j;
         numclause++;
 	}
    
	pps->numXOR=numclause;
	
	free(BigEq);
	free(BigEq_set);
	free(inactiveVar);

//re-adjust memory size
	int isize=pps->inaLit[n_inative]-pps->inaLit[0];
	iLit_set=(int*) realloc(iLit_set, sizeof(int)*isize);
    for(i=1; i<=n_inative; i++){
         pps->inaLit[i]=iLit_set+(pps->inaLit[i]-pps->inaLit[0]);
    }
	pps->inaLit[0]=iLit_set;
	pps->n_inative=n_inative;
	return _UNKNOWN;
}

int equivalence_reasoning(PPS *pps)
{  int i, rc;
   int num;
   int *p1;

   if(pps->numXOR==0) return _UNKNOWN;
   vBoolookup = (int *) malloc( sizeof(int) *(2*pps->numVar+1));
   for(i=0; i<=2*pps->numVar; i++) vBoolookup[i]=0; 
   vBoolookup+=pps->numVar;

   rc=RemoveInative_XOR_Equ(pps);
   if(rc==UNSAT) return UNSAT;
   if(pps->numXOR==0){//bug
       free(vBoolookup-pps->numVar);
   	   return _UNKNOWN;
   }
   int numXOR=pps->numXOR; 
   if(pps->numClause>500000 || pps->numVar>100000 || pps->numXOR>10000){
      free(vBoolookup-pps->numVar);
      goto setpoint;
   }
   
   rc=getXORdependent(pps);
   if(rc==UNSAT) return UNSAT;
   if(rc==CONST_EQ) {
       free(vBoolookup-pps->numVar);
       goto setpoint;
   }

   shorten_equivalence(pps);
   free(vBoolookup-pps->numVar);

 //set active XOR equtions data structure
   numXOR=pps->numXOR; //bug 9/2011
   p1=Leq[0];
   for(i=0; i<numXOR; i++){
       if(CeqLen[i]==0) continue; //empty
           int *pv;
           for(pv=Leq[i]; pv<Leq[i]+CeqLen[i]; pv++) {
		      *p1=*pv; p1++; 
		   }
   }
   num=1;
   for(i=0; i<numXOR; i++){
      if(CeqLen[i]==0) continue; //empty
	   Leq[num]=Leq[num-1]+CeqLen[i];
       num++;
   }
   num--;
   numXOR=num;
   free(CeqLen);
 //  Active size
setpoint:
   int size=Leq[numXOR]-Leq[0];
   Leq_base=(int*) realloc(Leq_base, sizeof(int)*(size));
   SetClausePtr(Leq, Leq_base, numXOR);
   pps->numXOR=numXOR;
   return _UNKNOWN;
}

void buildEQdatastructure(int **VarEq,int *Vspace, int numvar,int numXOR)
{   int i, var,sum;
    int *pv, *last;
	
    for(i = 0; i <= numvar;i++) Vspace[i] = 0;
    for(i=0; i<numXOR; i++) {
	   last=Leq[i]+CeqLen[i];
	   for(pv=Leq[i]; pv<last; pv++) Vspace[ABS(*pv)]++;
	}
	sum=0;
    for(i = 1; i <= numvar;i++){
		if(Vspace[i]>=1){
		    if(Vspace[i]>=40) Vspace[i]+=20;  // resvered space
			else Vspace[i]=2*Vspace[i]+1;
		}
		sum+=Vspace[i];
    }
   	VarEq[0]=(int *) malloc( sizeof(int)*(sum));
    for(i=1; i <= numvar;i++) {
	  	 VarEq[i]=VarEq[i-1]+Vspace[i-1];
		 if(Vspace[i]>0) VarEq[i][0]=1; 
	}
   
	for(i=0; i<numXOR; i++) {
	   last=Leq[i]+CeqLen[i];
	   for(pv=Leq[i]; pv<last; pv++){
          var=ABS(*pv);
		  int k=VarEq[var][0];
		  VarEq[var][k]=i;
		  VarEq[var][0]=k+1;
	   }
	}
}

extern char *FileName;

//int solveLargeCNF(char *FileName, int *solution);
		 
//replace eqJ with eqI+eqJ
void replace_OneEquivalence(int eqI,int eqJ,int **VarEq,int *Vspace,int numvar,int numXOR)
{   int NewEq[2000],m;
    int lit,var,i,j,n,Trues;
    int *last,*pv;

    m=0;
  
	last=Leq[eqJ]+CeqLen[eqJ];
	for(pv=Leq[eqJ]; pv<last; pv++){
		  NewEq[m++]=lit=*pv;
          vBoolookup[lit]=(vBoolookup[lit]+1)%2;
	}
    
	last=Leq[eqI]+CeqLen[eqI];
	for(pv=Leq[eqI]; pv<last; pv++){
		  NewEq[m++]=lit=*pv;
          vBoolookup[lit]=(vBoolookup[lit]+1)%2;
	}

	n=Trues=0;
	for(i=0; i<m; i++){
	     lit=NewEq[i];
         if(vBoolookup[lit]==0){
               if(vBoolookup[-lit]!=0) NewEq[n++]=-lit;
		 }
		 else{
               if(vBoolookup[-lit]==0) NewEq[n++]=lit;
               else Trues++;
		 }
	     vBoolookup[lit]=vBoolookup[-lit]=0;
	}
        if(Leq[eqJ]+n > Leq[eqJ+1]){
	   exit(0);
           return; // No space
     }
	if(Trues%2==0) NewEq[0]=-NewEq[0];
    pv=Leq[eqJ];
	for(i=0; i<CeqLen[eqJ]; i++){
		var=ABS(pv[i]);
		for(j=1;j<VarEq[var][0]; j++){ //delete
			if(VarEq[var][j]==eqJ){
                int k=VarEq[var][0]-1;
				Swap(VarEq[var][j],VarEq[var][k]);
                VarEq[var][0]=k;
				break;
			}
		}
	}
	for(i=0; i<n; i++) pv[i]=NewEq[i]; //add new Eq
   	CeqLen[eqJ]=n;
   	for(i=0; i<n; i++) {
		var=ABS(NewEq[i]);
		if(Vspace[var]<=VarEq[var][0]){
			free(VarEq[0]);
			buildEQdatastructure(VarEq,Vspace,numvar,numXOR);
            return;
        }
		int k=VarEq[var][0];
        VarEq[var][k]=eqJ;
        VarEq[var][0]=k+1;
	}
}
void replace_equivalence(int EqI,int var,int **VarEq,int *Vspace,int *EqnoJ,int numvar,int numXOR)
{   int i,cnt;
    int *first,*last,*pv;

    cnt=0;
    for(i=1; i < VarEq[var][0] ; i++) if(EqI!=VarEq[var][i]) EqnoJ[cnt++]=VarEq[var][i];
   	first=Leq[EqI];
    last=first+CeqLen[EqI];
	for(pv=first+1; pv<last; pv++) if(var==ABS(*pv)) break;
    if(pv<last){ //Exchange Space
          int v1=ABS(*first);
	      Swap(*first,*pv);
          if(VarEq[v1][0]==2){
			  int *tmp=VarEq[v1]; 
			  VarEq[v1]=VarEq[var]; VarEq[var]=tmp;
			  
			  VarEq[v1][0]=VarEq[var][0]=2;
			  VarEq[v1][1]=VarEq[var][1]=EqI;
			  Swap(Vspace[var],Vspace[v1]);
		  }
	}
    for(i=0; i < cnt; i++ ){
       replace_OneEquivalence(EqI,EqnoJ[i],VarEq,Vspace,numvar,numXOR);
	}
}	

void shorten_equivalence(PPS *pps)
{
	int i, j, k,n, doublenf,v1,v2,iterCounter;
	int current, counter,var;
    int **VarEq,*Vspace,*EqnoJ;

    int sum=0;
	for(i=0; i<pps->numXOR; i++) sum+=CeqLen[i];
	printf("c before shortening average=%f, XOR clauses#=%d \n", (double)sum/(double)pps->numXOR,pps->numXOR);

	VarEq =(int **) malloc( sizeof(int *) *(pps->numVar+1));
	Vspace=(int *) malloc( sizeof(int) *(pps->numVar+1));
   	EqnoJ=(int *) malloc( sizeof(int)*pps->numXOR);
	int numVar=pps->numVar;
	int numXOR=pps->numXOR;
	buildEQdatastructure(VarEq,Vspace,numVar,numXOR);
  	do
	{
	       iterCounter = 0;
           for( i = pps->numXOR-1; i >=0; i-- )
		   {   		       
			  if(CeqLen[i]<=2) continue;
        	  int *pv=Leq[i];
		      var=ABS(*pv);
		      if(DependentVar[var]<0) continue; //is not dependent ?
              if(CeqLen[i]== 3 )
			  {   
			      v1=ABS(*(pv+1));
	              v2=ABS(*(pv+2));
				  if(DependentVar[v1]==-3 || DependentVar[v2]==-3) continue; 
	              doublenf = 0;
//both are in the same clause ?
                  for( k=1; k < VarEq[v1][0]; k++ ){
		             for( n = 1; n < VarEq[v2][0]; n++)
						if( VarEq[v1][k] == VarEq[v2][n] ) doublenf++;
				  }
//Change dependent variables
                  if( VarEq[v1][0] <= VarEq[v2][0] )
				  {
                    if( VarEq[v1][0] < (2*doublenf) )
					{
						DependentVar[var]=-3; // -2 or -3 INDEPENDENT;
						DependentVar[v1] =i+1;  // dependent
						replace_equivalence(i,v1,VarEq,Vspace,EqnoJ,numVar,numXOR);
		                iterCounter++;
                    }
				  }
                  else if( VarEq[v2][0] < (2*doublenf) )
				  {
                    	DependentVar[var]=-3; // INDEPENDENT;
						DependentVar[v2] =i+1;  // dependent
						replace_equivalence(i,v2,VarEq,Vspace,EqnoJ,numVar,numXOR);
			            iterCounter++;
				  }
			  }
	          else if(CeqLen[ i ] == 4)
			  {   int *p1=pv+1; 
	  	          for( j = 0; j < 3; j++ )
				  {
			         current = ABS(*(pv+j));
					 v1      = *(p1+(j+1)%3);
					 v1=ABS(v1);
					 v2      = *(p1+(j+2)%3);
			         v2=ABS(v2);

					 if(DependentVar[current]==-3) continue; 
					 counter = 2 - VarEq[current][0];		
			         for( k = 1; k < VarEq[current][0]; k++ )
					 {
				         int eqNo = VarEq[current][k];
					     if( eqNo == i ) continue;
					     int *pn;
                         for(pn=Leq[eqNo]; pn<Leq[eqNo]+CeqLen[eqNo]; pn++ )
						 {	  int vv=ABS(*pn);				        
						      if( (vv==v1) || vv==v2 ) counter++;
						 }
			             if( counter > 0 )
						 {
		          	          DependentVar[var]=-3;    // INDEPENDENT;
						      DependentVar[current]=i+1;  ////dependent
						      replace_equivalence(i,current,VarEq,Vspace,EqnoJ,numVar,numXOR);
							  iterCounter++;
                              break;
						 }
					 }
				  }
			  }
		   }
	} while( iterCounter );
    free(EqnoJ);
//
	sum=0; int Cqcnt=0;
	for(i=0; i<pps->numXOR; i++) {
	    if(CeqLen[i]) Cqcnt++;
		sum+=CeqLen[i];
	}
	printf("c after shortening average=%f XOR clauses#=%d \n",	(double)sum/(double)Cqcnt, Cqcnt);
	
   free(VarEq[0]);
   free(VarEq);
   free(Vspace);
}

void getclausePos(PPS *pps)
{
	if(pps->clausePos) delete pps->clausePos;
	pps->clausePos = new Stack<int>;
	Stack<int> * clausepos=pps->clausePos;
    pps->numClause=0;
    Stack<int> *clauseCNF=pps->clause;
	int *pcls;
	int *pend=clauseCNF->end();
    int len;
   	for(pcls=clauseCNF->begin(); pcls < pend; pcls+=len){
         len=*pcls;
		 int mark=len & MARKBIT;
		 len=len>>FLAGBIT;
       	 if( mark==DELETED) continue; //remove;
		 pps->numClause++;
         int pos=pcls-clauseCNF->begin();
		 clausepos->push(pos);
	}    
}

void save_eqv(PPS *pps)
{
    if(pps->outEquAtom){
       for(int i=pps->numVar; i>=1; i--){
	      int vv=pps->outEquAtom[i];
	      if(vv==0 || vv==i) continue;
          pps->extend.push(0);
 		  pps->extend.push(i);
		  pps->extend.push(-vv);
	 }
	   free(pps->outEquAtom);
	   pps->outEquAtom=0;
	}
}//---------------------------------------------
// l1 (+) l2 (+) l3 (+) l4 +...+ln=1
void get_2_9_equivalence(PPS *pps)
{   unsigned int i,j,k,m,n,cNo,one,pw2;
    int *matchCli,match[512];
        
    getclausePos(pps);
    Stack<int> * clauseCNF=pps->clause;
    Stack<int> * clausePos=pps->clausePos;
    int numClauses=pps->numClause;
    matchCli=(int *) malloc(sizeof(int)*2020);
    i=0; 
    while (i < (unsigned int)numClauses){
           int iPos=(*clausePos)[i];
	   int len=(*clauseCNF)[iPos];
	   if((len & MARKBIT)==DELETED) {i++; continue;} 
	   len=len>>FLAGBIT;
	   unsigned int size1=len-1;
	   if(size1<2 || size1>9) { i++; continue; }
	   pw2=1;
           for(j=0;j<size1; j++) pw2=2*pw2;
           for(j=0;j<pw2; j++) match[j]=0;
	   cNo=n=0;
           iPos++;
	   for(j=i+1; j < (unsigned int)numClauses; j++){
    	         int jPos=(*clausePos)[j];
		 int jLen=(*clauseCNF)[jPos];
		 jLen=jLen>>FLAGBIT;
		 if(jLen!=len) break;
		 m=0;one=0;
		 jPos++;
		 for(k=0; k<size1; k++){
			 m=2*m;
		         if((*clauseCNF)[iPos+k]==-(*clauseCNF)[jPos+k]){
                                 m++;
                                 one++;
                                 continue;
                         }
			 if((*clauseCNF)[iPos+k]!=(*clauseCNF)[jPos+k]) break;
		 }
		 if(k<size1) break;
		 if(one%2) continue;
                 matchCli[cNo++]=j;
		 if(cNo >= 2000) break;
                 if(!match[m] && m) {n++; match[m]=1;}
	   }
	   if((pw2/2-1)==n && cNo<2000){
	         (*clauseCNF)[iPos-1]=(len<<FLAGBIT) | XOR_CLS; // xor clause; 
		 for(k=0;k<cNo;k++) {
		        int kPos=(*clausePos)[matchCli[k]];
			(*clauseCNF)[kPos]=(len<<FLAGBIT) | FROZE; //  freeze clause; 
		 }
	    }
	    i=j;
     }
     free(matchCli);
}

void get_XOR_equivalent(PPS *pps)
{
     int delrepeat=0;
     sortClause(pps->clause,4,pps->numClause,pps->numVar,delrepeat); //??no duplicate
     get_2_9_equivalence(pps);
}

int *XorFrq=0;
int *CNFfrq;
int XORcmp( const void *ptrA, const void *ptrB)
{
    int *litsA=*(int **)ptrA;
    int *litsB=*(int **)ptrB;
    
    int sumA=0;
    int lenA=(*litsA) >> FLAGBIT;
    for(int k=1; k<lenA; k++) sumA += XorFrq[ABS(litsA[k])];
  
    int sumB=0;
    int lenB=(*litsB)>>FLAGBIT;
    for(int k=1; k<lenB; k++) sumB += XorFrq[ABS(litsB[k])];
 
    if(lenA > lenB) return 1;
    if(lenA < lenB) return -1;
    if((lenB-1)*sumA < (lenA-1)*sumB) return 1;
    if((lenB-1)*sumA > (lenA-1)*sumB) return -1;
    return 0;
}

int clsCmp( const void *ptrA, const void *ptrB)
{
    int *litsA=*(int **)ptrA;
    int *litsB=*(int **)ptrB;
    
    int lenA=(*litsA) >> FLAGBIT;
    int lenB=(*litsB)>>FLAGBIT;
    if(lenA < lenB) return -1;
    if(lenA > lenB) return 1;
    
    for(int k=1; k<lenA; k++){
        if(litsA[k] < litsB[k]) return -1;
        if(litsA[k] > litsB[k]) return 1;
    }
    return 0;
}

extern int NowRecursiveDepth;

int vfrqcmp( const void *ptrA, const void *ptrB)
{
    int varA=*(int *)ptrA;
    int varB=*(int *)ptrB;
//6 5
    if(NowRecursiveDepth < 5) if(XorFrq[varA] < 4 && XorFrq[varB] < 4 ) goto cnfCmp;
         if(XorFrq[varA] < XorFrq[varB]) return 1;
         if(XorFrq[varA] > XorFrq[varB]) return -1;
cnfCmp:  
         if(CNFfrq[varA] < CNFfrq[varB]) return 1;
         if(CNFfrq[varA] > CNFfrq[varB]) return -1;

    return 0;
}

void Adp_SymPSort(void *a, int n, int es, int (*cmp)(const void *,const void *));
int *extVarRank=0,numVarRk=0;
void rank_by_XOR_freq(PPS *pps, int way)
{  
     int numXor=0;
     int **XorPos=0;
     if(way==0) XorPos=(int **) malloc(sizeof(int *)*(pps->numClause/2));
     XorFrq=(int *) calloc(pps->numVar+1, sizeof(int));
     CNFfrq=(int *) calloc(pps->numVar+3, sizeof(int));
    
     int *pcls=pps->clause->begin();
     int *pend=pps->clause->end();
     while(pcls < pend){
         int len=*pcls;
	 int mark=len & MARKBIT;
	 int *lits=pcls;
	 len=len>>FLAGBIT;
         pcls+=len;
         if(mark==DELETED) continue;
         if(mark==XOR_CLS){
               if(way==0) XorPos[numXor++]=lits;
               for(int k=1; k<len; k++) XorFrq[ABS(lits[k])]++;
         }
         else{
               for(int k=1; k<len; k++) CNFfrq[ABS(lits[k])]++;
         }
         *lits=(len<<FLAGBIT) | CNF_CLS;
    }
    if(extVarRank==0) extVarRank=(int *) calloc(pps->numVar+50, sizeof(int));     
    int i;
    if(way){
           for(i=0; i < pps->numVar; i++) extVarRank[i]=i+1;
           Adp_SymPSort((void *)extVarRank, pps->numVar, sizeof(int), vfrqcmp);
           numVarRk=pps->numVar;
    }
    else{
          numVarRk=0;
          if(numXor >1 ){
              Adp_SymPSort((void *)XorPos, numXor, sizeof(int *), XORcmp);
              int *Seen=(int *) calloc(pps->numVar+1, sizeof(int));     
              for(int i=0; i < numXor; i++){
                 int *lits=XorPos[i];
                 int  len=(*lits) >> FLAGBIT;
                 for(int k=1; k<len; k++){ 
                    if(Seen[ABS(lits[k])]==0){
                        Seen[ABS(lits[k])]=1;
                        extVarRank[numVarRk++]=ABS(lits[k]);
                     }
                  }
              }
              free(Seen);
           }
     }
     if(XorPos) free(XorPos);
     free(XorFrq);
     free(CNFfrq);
}

void sortClause(PPS *pps,int **clsPos)
{  
     int *pcls=pps->clause->begin();
     int *pend=pps->clause->end();
     int clsNum=0;
     while(pcls < pend){
         int len=*pcls;
	 int mark=len & MARKBIT;
	 int *lits=pcls;
	 len=len>>FLAGBIT;
         pcls+=len;
         if(mark!=DELETED) clsPos[clsNum++]=lits;
     }
     Adp_SymPSort((void *)clsPos, clsNum, sizeof(int *), clsCmp);
}

void XOR_Preprocess(PPS *pps,int way)
{
    get_XOR_equivalent(pps);
    rank_by_XOR_freq(pps,way);
//    printf("c VarRank %d:\n",numVarRk);
}

