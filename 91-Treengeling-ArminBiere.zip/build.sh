#!/bin/sh
rm -rf binary
mkdir binary
cd code/yalsat
./configure.sh --no-stats || exit 1
make || exit 1
cd ../treengeling
./configure.sh || exit 1
make treengeling || exit 1
install -m 755 -s treengeling ../../binary
