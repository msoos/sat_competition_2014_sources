#!/bin/bash

mkdir binary

cd syrup/simp
make r
cp glucose_release ../../binary/syrup
