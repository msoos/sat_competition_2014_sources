/*
 *  SolverCompanion.C
 *  minithreads
 *
 *  Created by Laurent Simon on 06/03/09.
 *  Copyright 2009 LRI, Univ. Paris 11. All rights reserved.
 *
 */

#include "SolverCompanion.h"

SolverCompanion::SolverCompanion()
{}

SolverCompanion::~SolverCompanion()
{}


bool SolverCompanion::addSolver(Solver* s) {
	watchedSolvers.push(s);
	return true;
}

int SolverCompanion::runOnceCompanion() {
	int errcode = 0;
	for(int indexSolver = 0; indexSolver<watchedSolvers.size();indexSolver++) {
	  errcode=runOnceCompanion(watchedSolvers[indexSolver]);
		if (errcode<0) return errcode;
	}
	return errcode;
}

int SolverCompanion::runOnceCompanion(Solver*s) {
	return 0;
}


