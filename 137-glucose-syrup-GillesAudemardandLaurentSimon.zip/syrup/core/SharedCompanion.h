/*
 *  SharedCompanion.h
 *  This companion is responsible for
 *   - Handling the clause databases of all solvers
 *   - Sharing interesting clauses between them
 *  Created by Laurent Simon on 19/03/09.
 *  Copyright 2009 LRI, Univ. Paris 11. All rights reserved.
 *
 */

#include "SolverTypes.h"
#include "Solver.h"
#include "SolverCompanion.h"
#include "ClausesBuffer.h"

namespace Glucose {


class SharedCompanion: public SolverCompanion {
    friend class MultiSolvers;
    friend class Solver;
public:
	SharedCompanion(int nbThreads);
	SharedCompanion();
	void setNbThreads(int _nbThreads);
	void newVar(bool sign);
	void printStats();

	bool jobFinished();
	bool IFinished(Solver *s); // returns true if you are the first solver to finish
	bool addSolver(Solver*); // attach a solver to accompany 
	void addLearnt(Solver *s,Lit unary); // Add a unary clause !
	bool addLearnt(Solver *s, Clause & c, int route = 0); // Add a clause to the shared companion, as a database manager

	bool addLearntInitRoad(int sn, Clause &c, double random);
	bool addLearntFollowRoad(int sn, Clause &c);
	
	bool addLearntForProbation(int from, Clause &c, double random);
        bool addLearntAfterProbation(int from, Clause &c);

	bool getNewClause(Solver *s, int &th, vec<Lit> & nc, int & route); // gets a new interesting clause for solver s 
	Lit getUnary(Solver *s);
	bool canISendMyClauses(int thread); // true if this solver is allowed to send its clauses
	void registerMyPerformances(int thread, int conflict, int originalClauses);
	inline Solver* winner(){return jobFinishedBy;}

	void bumpFUIP(Lit fuip, uint32_t confl); // Bumping FUIP from all cores
	void MutexLockFUIPCore();
        void MutexUnlockFUIPCore();

 protected:

	/*
	struct ClauseOrderLt {
        bool operator () (Clause *x, Clause *y) const { return x->extra.act > y->extra.act; }
    };
*/	
	ClausesBuffer clausesBuffer; // A big blackboard for all threads sharing non unary clauses
	int nbThreads;
	pthread_mutex_t mutexSharedCompanion; // mutex for any high level sync between all threads (like reportf)
	pthread_mutex_t mutexSharedClauseCompanion; // mutex for reading/writing clauses on the blackboard
	pthread_mutex_t mutexSharedUnitCompanion; // mutex for reading/writing unit clauses on the blackboard 

        pthread_mutex_t mutexJobFinished;
	pthread_mutex_t mutexSendAuth;
	pthread_mutex_t mutexFUIP;
	bool bjobFinished;
	Solver *jobFinishedBy;
	bool panicMode;
	Solver *solverFUIP; 
	lbool jobStatus;
        // Shared clauses are a queue of lits...
	//	friend class wholearnt;
	vec<int> nextUnit; // indice of next unit clause to retrieve for solver number i 
	vec<Lit> unitLit;
        vec<lbool> isUnary; // sign of the unary var (if proved)	
	vec<ClausesBuffer* > clausesBufferOfThread;
	vec<pthread_mutex_t*> mutexInputClausesBuffer;
	vec< vec<int> > roads;
	int nbRoads;
	int survivorClauses; // Clauses that followed the road and survived!

	void initRoad(vec<int> & road);


	double    random_seed;

	// Returns a random float 0 <= x < 1. Seed must never be 0.
	static inline double drand(double& seed) {
	    seed *= 1389796;
	    int q = (int)(seed / 2147483647);
	    seed -= (double)q * 2147483647;
	    return seed / 2147483647; }

	// Returns a random integer 0 <= x < size. Seed must never be 0.
	static inline int irand(double& seed, int size) {
	    return (int)(drand(seed) * size); }

};
}

