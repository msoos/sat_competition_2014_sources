/*
 *  MultiSolvers.C
 *  minithreads
 *
 *  Created by Laurent Simon on 06/03/09.
 *  Copyright 2009 LRI, Univ. Paris 11. All rights reserved.
 *
 */
#include <pthread.h>
#include "MultiSolvers.h"
#include "mtl/Sort.h"
#include "utils/System.h"
#include "simp/SimpSolver.h"
#include <errno.h>
#include <string.h>

using namespace Glucose;

extern const char* _parallel ;
// Options at the parallel solver level
static IntOption opt_nbsolversmultithreads (_parallel, "nthreads", "Number of core threads for syrup", 4);
BoolOption opt_coreFUIP (_parallel, "oneFUIP", "true if one core (thread 1) is working on all FUIPs (default=true)", false);
BoolOption opt_coreFUIPIsolated (_parallel, "oneFUIPIsolated", "true if the one FUIP core (thread 1) does not send its own clauses to anybody", false);
BoolOption opt_immediateSharingGlue(_parallel, "shareGlues", "true (default) if we send to all cores all glues (immediately)", true);
BoolOption opt_coreSize (_parallel, "oneSize", "true if one core (thread 2) is working on clauses size (instead of LBD)", false);
BoolOption opt_coreInverseRestarts (_parallel, "oneInverse", "true if one core (thread 3) is inversing the restart strategy of glucose", false);


#define MAXSTR 256

#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>

static inline double cpuTime(void) {
    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);
return (double)ru.ru_utime.tv_sec + (double)ru.ru_utime.tv_usec / 1000000; }


void MultiSolvers::informEnd(lbool res) {
  result = res;
  pthread_cond_broadcast(&cfinished);
}


char** split(char* str, char c) {
  static char* tmp[MAXSTR];
  int current = 0;
  tmp[current++] = str;
  while( *str ) {
    if ( *str == c ) {
      *str = '\0';
      tmp[current++] = str+1;
    }
    ++str;
  }
  tmp[ current ] = 0;
  return tmp;
}
    


MultiSolvers::MultiSolvers(Solver *s):
  ok               (true)
  , maxnbthreads(MAXNBTHREADS), nbthreads(opt_nbsolversmultithreads), nbsolvers(opt_nbsolversmultithreads)
  ,  nbcompanions(4),nbcompbysolver(2)
  ,var_decay(1 / 0.95), clause_decay(1 / 0.999),cla_inc(1), var_inc(1)
  ,random_var_freq(0.02)
  , restart_first(100), restart_inc(1.5)
  , learntsize_factor((double)1/(double)3), learntsize_inc(1.1)
  // Statistics: (formerly in 'SolverStats')
  //
  ,expensive_ccmin(true)
  ,polarity_mode    (polarity_false)
  
  , verb(0) , verbEveryConflicts(10000)
    , numvar(0), numclauses(0)
    , showModel(false)
    , useNCurses(false)
    , coreFUIP(opt_coreFUIP)
    , coreFUIPIsolated(opt_coreFUIPIsolated)
    , immediateSharingGlue(opt_immediateSharingGlue)
    //, coreSize(opt_coreSize)
    , coreInverseRestarts(opt_coreInverseRestarts)
    , solverFUIP(NULL)
    , nbsolversmultithreads (opt_nbsolversmultithreads)
    , allClonesAreBuilt(0)
    , winner(-1)

{
	
  result = l_Undef;
//  printf("list : %s\n",listOfSolvers);
  SharedCompanion *sc = new SharedCompanion();
  this->sharedcomp = sc;

  
  
    // Generate only solver 0.
    // It loads the formula
    // All others solvers are clone of this one
    solvers.push(s);
    s->verbosity = 0; // No reportf in solvers... All is done in MultiSolver
    s->setThreadNumber(0);
    s->nbthreads = nbsolvers;
    s->belongsto = this;
    s->sharedcomp = sc;
    sc->addSolver(s);
    assert(solvers[0]->threadNumber() == 0);
    assert(solvers[0]->coreFUIP == coreFUIP);
   
	
/*  for(int i=1;i<nbsolvers;i++) {
      Solver *s  = retrieveSolver(i, nbsolvers);
      solvers.push(s);
      s->verbosity = 0; // No reportf in solvers... All is done in MultiSolver
      s->setThreadNumber(i);
      s->belongsto = this;
      s->sharedcomp = sc;
      sc->addSolver(s);
      assert(solvers[i]->threadNumber() == i);
      assert(solvers[i]->coreFUIP == coreFUIP);
  }
 */
//  adjustParameters(); 

/*  if(coreFUIP) {
      printf("c One core is a FUIP specialist.\n");
      assert(solverFUIP != NULL);
      solverFUIP->ImTheSolverFUIP = true;
      sc->solverFUIP = solverFUIP;
  }
  
*/
  pthread_mutex_init(&m,NULL);  //PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_init(&mfinished,NULL); //PTHREAD_MUTEX_INITIALIZER;
  pthread_cond_init(&cfinished,NULL);
  
  //  m = PTHREAD_MUTEX_INITIALIZER;
  //cfinished = PTHREAD_COND_INITIALIZER;
  // mfinished = PTHREAD_MUTEX_INITIALIZER;
  
  fprintf(stderr,"c %d solvers engines and 1 companion as a blackboard created.\n", nbsolvers);
  
}

MultiSolvers::~MultiSolvers()
{}

/**
 * Generate All solvers
 */

void MultiSolvers::generateAllSolvers() {
    assert(solvers[0] != NULL);
    assert(allClonesAreBuilt==0);
    
    for(int i=1;i<nbsolvers;i++) {
      Solver *s  = (Solver*)solvers[0]->clone();
      solvers.push(s);
      s->verbosity = 0; // No reportf in solvers... All is done in MultiSolver
      s->setThreadNumber(i);
      s->belongsto = this;
      s->sharedcomp =   this->sharedcomp;
      this->sharedcomp->addSolver(s);
      assert(solvers[i]->threadNumber() == i);
      assert(solvers[i]->coreFUIP == coreFUIP);
  }
    
    
   adjustParameters(); 

  if(coreFUIP) {
      printf("c One core is a FUIP specialist.\n");
      assert(solverFUIP != NULL);
      solverFUIP->ImTheSolverFUIP = true;
      this->sharedcomp->solverFUIP = solverFUIP;
  }
  
  printf("c All clones are built!\n");
  allClonesAreBuilt = 1;
}

/**
 * Choose solver for threads i (if no given in command line see above)
 */


Solver* MultiSolvers::retrieveSolver(int i, int nb) {
    return new Solver(i,  nb);
}

bool MultiSolvers::iwantThisClause(Clause *c) {
    return false;
}

Var MultiSolvers::newVar(bool sign, bool dvar)
{
  assert(solvers[0] != NULL);
  /*	("thread %d : watches %0xd  reason %0xd assigns %0xd level %0xd activity %0xd seen %0xd polarity %0xd decisionvar %0xd.\n",thn,
	(void*)watches, (void*)reason, (void*)assigns, (void*)level, (void*)activity, (void*)seen, (void*)polarity, (void*)decision_var);
  */
  numvar++;
  int v;
  sharedcomp->newVar(sign);
  if(!allClonesAreBuilt) { // At the beginning we want to generate only solvers 0
    v = solvers[0]->newVar(sign,dvar);
    assert(numvar == v+1); // Just a useless check
    return numvar;
  }

  // 
  for(int i=0;i<nbsolvers;i++) {
    v = solvers[i]->newVar(sign,dvar);
  }
  return numvar;
}



bool MultiSolvers::addClause_(vec<Lit>&ps) {
  assert(solvers[0] != NULL); // There is at least one solver.
  // Check if clause is satisfied and remove false/duplicate literals:
  if (!okay())  return false;

  sort(ps);
  Lit p; int i, j;
  for (i = j = 0, p = lit_Undef; i < ps.size(); i++)
    if (solvers[0]->value(ps[i]) == l_True || ps[i] == ~p)
      return true;
    else if (solvers[0]->value(ps[i]) != l_False && ps[i] != p)
      ps[j++] = p = ps[i];
  ps.shrink(i - j);
  
  
  if (ps.size() == 0) {
    return ok = false;
  }
  else if (ps.size() == 1){
    assert(solvers[0]->value(ps[0]) == l_Undef); // TODO : Passes values to all threads
    solvers[0]->uncheckedEnqueue(ps[0]);
    if(!allClonesAreBuilt) {
	return ok = ( (solvers[0]->propagate()) == CRef_Undef); // checks only main solver here for propagation constradiction
    }
    // All clones are built.
    // Gives the unit clause to everybody
    
    for(int i=0;i<nbsolvers;i++)
      solvers[i]->uncheckedEnqueue(ps[0]);
    return ok = ( (solvers[0]->propagate()) == CRef_Undef); // checks only main solver here for propagation constradiction
  }else{

    //		printf("Adding clause %0xd for solver %d.\n",(void*)c, thn);
    // At the beginning only solver 0 load the formula
    solvers[0]->addClause(ps);
    
    if(!allClonesAreBuilt) {
	numclauses++;
	return true;
    }
    
    for(int i=1;i<nbsolvers;i++) {
      solvers[i]->addClause(ps);
    }
    numclauses++;
  }
  return true;
}


bool MultiSolvers::simplify() {
  assert(solvers[0] != NULL); // There is at least one solver.

  if (!okay()) return false;
  return ok = solvers[0]->simplify(); 
}

void *localLaunch(void*arg) {
	SimpSolver* s = (SimpSolver*)arg;
	
	(void)s->solve();
	
	pthread_exit(NULL);
	
}


#define MAXIMUM_SLEEP_DURATION 5
void MultiSolvers::printStats() {
	static int nbprinted = 1;
	double cpu_time = cpuTime();

	//printf("%.0fs | ",cpu_time);
	for(int i=0;i<solvers.size();i++) {
	    solvers[i]->reportProgress();
    //printf(" %2d: %12ld confl. |", i,  (long int) solvers[i]->conflicts);
    }
	long long int totalconf = 0;
	long long int totalprop = 0;
	for(int i=0;i<solvers.size();i++) {
		totalconf+=  (long int) solvers[i]->conflicts;
		totalprop+= solvers[i]->propagations;
    }
	//printf(" %12lld confl.  ||\n", totalconf);
	
	nbprinted ++;
}

void MultiSolvers::printFinalStats() {
    sharedcomp->printStats();
    printf("c conflicts : ");
    long long int totalconf = 0;
    for(int i=0;i<solvers.size();i++)  {
	printf("%ld ",(long int) solvers[i]->conflicts);
	totalconf +=  solvers[i]->conflicts;
    }
    printf("# %lld\n",totalconf);

    printf("c exported  : ");
    uint64_t exported = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbexported);
        exported += solvers[i]->nbexported;
    }
    printf("# %llu\n", exported);

    printf("c imported  : ");
    uint64_t imported = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbimported);
        imported += solvers[i]->nbimported;
    }
    printf("# %llu\n", imported);

    printf("c good import  : ");
    uint64_t importedGood = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbImportedGoodClauses);
        importedGood += solvers[i]->nbImportedGoodClauses;
    }
    printf("# %llu\n", importedGood);

    printf("c purg import  : ");
    uint64_t importedPurg = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbimportedInPurgatory);
        importedPurg += solvers[i]->nbimportedInPurgatory;
    }
    printf("# %llu\n", importedPurg);

    printf("c promoted  : ");
    uint64_t promoted = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbpromoted);
        promoted += solvers[i]->nbpromoted;
    }
    printf("# %llu\n", promoted);

    printf("c survivor  : ");
    uint64_t survivor = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbsurvivor);
        survivor += solvers[i]->nbsurvivor;
    }
    printf("# %llu\n", survivor);
  
    printf("c remove imp: ");
    uint64_t removedimported = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbRemovedImportedClauses);
        removedimported += solvers[i]->nbRemovedImportedClauses;
    }
    printf("# %llu\n", removedimported);

    printf("c road_init : ");
    uint64_t roadinit = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbexportedInit);
        roadinit += solvers[i]->nbexportedInit;
    }
    printf("# %llu\n",roadinit);

    printf("c road_foll : ");
    uint64_t roadfoll = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbexportedFollow);
        roadfoll += solvers[i]->nbexportedFollow;
    }
    printf("# %llu\n",roadfoll);


    printf("c blocked Reuse : ");
    uint64_t blockedreused = 0;
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->nbNotExportedBecauseDirectlyReused);
        blockedreused += solvers[i]->nbNotExportedBecauseDirectlyReused;
    }
    printf("# %llu\n",blockedreused);

    printf("c trail    : ");
    uint64_t trail = 0;
    for(int i=0;i<solvers.size();i++) {
	if (solvers[i]->conflicts > 0)
	    printf("%.0f ",(double) solvers[i]->sumDecisionLevels / (double) solvers[i]->conflicts);
	else
	    printf("0 ");
        trail += solvers[i]->sumDecisionLevels;
    }
    printf("# %.0f\n", (double)trail / (double)totalconf);

    printf("c avg_prop/dec: ");
    uint64_t prop = 0;
    uint64_t deci = 0;
    for(int i=0;i<solvers.size();i++) {
	if (solvers[i]->decisions > 0)
	    printf("%.1f ",(double) solvers[i]->propagations / (double) solvers[i]->decisions);
	else
	    printf("0 ");
        deci += solvers[i]->decisions;
        prop+= solvers[i]->propagations;
    }
    printf("# %.0f\n", (double)prop / (double)deci);

    printf("c orig_seen : ");
    for(int i=0;i<solvers.size();i++) {
	printf("%ld ",(long int) solvers[i]->originalClausesSeen);
    }
    printf("\n"); 

    printf("c unaries : ");
    for(int i=0;i<solvers.size();i++) {
	printf("%llu ", solvers[i]->nbUn);
    }
    printf("\n"); 

    printf("c binaries : ");
    for(int i=0;i<solvers.size();i++) {
	printf("%llu ", solvers[i]->nbBin);
    }
    printf("\n"); 

     printf("c glues : ");
    for(int i=0;i<solvers.size();i++) {
	printf("%llu ", solvers[i]->nbDL2);
    }
    printf("\n"); 


    int winner = -1;
   for(int i=0;i<solvers.size();i++) {
     if(sharedcomp->winner()==solvers[i])
       winner = i;
     }
   
   if(winner==-1) return;
int sum = 0;
   printf("c Hamming : ");
   for(int i = 0;i<solvers.size();i++) {
     if(i==winner) {
       printf("X ");
       continue;
     }
     int nb = 0;
     for(int j = 0;j<nVars();j++) {
       if(solvers[i]->valuePhase(j)!= solvers[winner]->valuePhase(j)) nb++;
     }
     printf("%d ",nb);
     sum+=nb;

   }
   printf(" -- avg : %d\n",sum/(solvers.size()>1?solvers.size()-1:1));
    
 

}

// Well, all those parameteres are just naive guesses... No experimental evidences for this.
void MultiSolvers::adjustParameters() {
    SolverConfiguration::configure(this,nbsolvers);
}

lbool MultiSolvers::solve() {
  pthread_attr_t thAttr; 
  int i; 

  float mem = memUsed();
  int tmpnbsolvers = 8000 / mem;
  if (tmpnbsolvers > 12) tmpnbsolvers = 12;
  if (tmpnbsolvers < 1) tmpnbsolvers = 1;
  if (coreFUIP && tmpnbsolvers < 4) { 
      coreFUIP = false;
      printf("c option oneFUIP was forced off due to a limitation in the number of threads.\n");
  }
  printf("c One Solver is already taking %.2fMb... Let's take %d solvers for this run.\n", mem, tmpnbsolvers);
  nbsolvers = tmpnbsolvers;
  nbthreads = nbsolvers;
  solvers[0]->nbthreads = nbthreads;
  sharedcomp->setNbThreads(nbsolvers); 
  printf("c Generating clones\n"); 
  generateAllSolvers();
  printf("c all clones generated. Memory = %.2fMb.\n", memUsed());
 
  model.clear();
  /* Initialize and set thread detached attribute */
  pthread_attr_init(&thAttr);
  pthread_attr_setdetachstate(&thAttr, PTHREAD_CREATE_JOINABLE);
  
  // Launching all solvers
  for (i = 0; i < nbsolvers; i++) {
    pthread_t * pt = (pthread_t*)malloc(sizeof(pthread_t));
    threads.push(pt);
    solvers[i]->pmfinished = &mfinished;
    solvers[i]->pcfinished = &cfinished;
    pthread_create(threads[i], &thAttr, &localLaunch, (void*)solvers[i]); 
  }
  
  bool done = false;
  
  (void)pthread_mutex_lock(&m);
  while (!done) { 
    struct timespec timeout;
    time(&timeout.tv_sec);
    timeout.tv_sec += MAXIMUM_SLEEP_DURATION;
    timeout.tv_nsec = 0;
    if (pthread_cond_timedwait(&cfinished, &mfinished, &timeout) != ETIMEDOUT) 
	    done = true;
    else
      printStats();

    mem = memUsed();
    printf("c Total Memory so far : %.2fMb\n",  mem);
    if (mem > 20000 && !sharedcomp->panicMode) 
       printf("c ** reduceDB switching to Panic Mode due to memory limitations !\n"), sharedcomp->panicMode = true;
    
  }
  (void)pthread_mutex_unlock(&m);
  
  for (i = 0; i < nbsolvers; i++) { // Wait for all threads to finish
      pthread_join(*threads[i], NULL);
  }
  
  assert(sharedcomp != NULL);
  result = sharedcomp->jobStatus;
  if (result == l_True) {
      int n = sharedcomp->jobFinishedBy->nVars();
	model.growTo(n);
	for(int i = 0; i < n; i++)
	    model[i] = sharedcomp->jobFinishedBy->model[i];
  }

	
  return result;
  /*
  for(int i=0;i<NBTHREADS;i++)
    pthread_join(*threads[i],&status);
  */

}

