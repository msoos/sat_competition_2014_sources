


#ifndef Glucose_Window_h
#define Glucose_Window_h

#include <ncurses.h>


using namespace Glucose;

class Window {

    public:

    Window(char* filename, int nbc, int nbv) {
	thewindow = initscr(); /* Start curses mode  */
	curs_set(0); /* Makes the cursor invisible */
	noecho();
	nonl();
	cbreak();
	if (has_colors()) {
	    start_color();
	    init_pair(1, COLOR_RED,     COLOR_WHITE);
	    init_pair(2, COLOR_GREEN,   COLOR_WHITE);
	    init_pair(3, COLOR_YELLOW,  COLOR_WHITE);
	    init_pair(4, COLOR_BLUE,    COLOR_WHITE);
	    init_pair(5, COLOR_CYAN,    COLOR_WHITE);
	    init_pair(6, COLOR_MAGENTA, COLOR_WHITE);
	    init_pair(7, COLOR_BLACK,   COLOR_WHITE);
	    bkgd(COLOR_PAIR(7));
	}

	attron(COLOR_PAIR(7));
	//box(thewindow, ACS_VLINE, ACS_HLINE);
	 getmaxyx(stdscr,row,col);		/* get the number of rows and columns */
	 const char* mesg = "Hello";
	 attron(A_BOLD);
	 mvprintw(row/2,(col-strlen(mesg))/2,"%s",mesg);
	 attroff(A_BOLD);
                                	/* print the message at the center of the screen */
	 mvprintw(row-2,0,"This screen has %d rows and %d columns\n",row,col);
	 attroff(COLOR_PAIR(7));

         headerw = newwin(3,col, 0,0);
	 wbkgd(headerw, COLOR_PAIR(7));
         printHeader(filename, nbc, nbv);

	 refresh(); /* Print it on to the real screen */
	 wrefresh(headerw);
	 getch(); /* Wait for user input */
    }

    ~Window() {
	endwin(); /* End curses mode */
    }

    protected:
    WINDOW * thewindow;
    WINDOW * headerw;
    int row, col;

    void printHeader(char * f, int nbc, int nbv) {
        
	wprintw(headerw,"This is "); wattron(headerw,COLOR_PAIR(1)|A_BOLD);
	wprintw(headerw,"Glucose-Syrup"); wattroff(headerw,COLOR_PAIR(1)|A_BOLD);
	wprintw(headerw," (a lot of glucose)");

	const char * copyright = "(c) G. Audemard & L. Simon 2009-2014";
        wmove(headerw,0,col-strlen(copyright));
        wprintw(headerw,"(c) "); wattron(headerw,COLOR_PAIR(4));
	wprintw(headerw,"G. Audemard & L. Simon");
        wattroff(headerw,COLOR_PAIR(4));
	wprintw(headerw," 2009-2014");

	const char * version = "1.0 (based on 3.1)";
	mvwprintw(headerw,0,(col-strlen(version))/2, version); 

	mvwprintw(headerw, 1,0, "solving ");  //wattron(headerw,COLOR_PAIR(4));
	wprintw(headerw, f);
	//wattroff(headerw,COLOR_PAIR(4));

	char * buffer = (char*)malloc(100*sizeof(char));
	snprintf(buffer, 100, "n=%d m=%d", nbc, nbv);
	mvwprintw(headerw, 1, col-strlen(buffer), buffer);

    }
    //void print
};


#endif
