/***********************************************************************************[BoundedQueue.h]
 Glucose -- Copyright (c) 2009, Gilles Audemard, Laurent Simon
                CRIL - Univ. Artois, France
                LRI  - Univ. Paris Sud, France
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

// route 1 : 1 2 3 4 5 6 7 8
// route 2 : 2 4 7 8 1 3 5 6 -> 2 : 3 4 5 7 6 2 8 1
// route 3 : 
// ...
// route n : 8 6 7 5 2 4 1 3 
#include "core/ClausesBuffer.h"

//#define _DEBUGME
#ifdef _DEBUGME
extern const int Sentinel UINT_MAX;
#endif
//=================================================================================================

using namespace Glucose;

// index : size clause
// index + 1 : nbSeen
// index + 2 : threadId
// index + 3 : clause route
// index + 4 : .. index + 4 + size : Lit of clause
ClausesBuffer::ClausesBuffer(int _nbThreads, unsigned int _maxsize) : first(0), last(_maxsize-1),  maxsize(_maxsize), queuesize(0), 
    removedClauses(0),
    forcedRemovedClauses(0), nbThreads(_nbThreads) {
	lastOfThread.growTo(_nbThreads);
	for(int i=0;i<nbThreads;i++) lastOfThread[i] = _maxsize-1;
	elems.growTo(maxsize);
#ifdef _DEBUGME
	for(int i=0;i<maxsize;i++)
	    elems[i] = Sentinel;
#endif
    } 

ClausesBuffer::ClausesBuffer() : first(0), last(0), maxsize(0), queuesize(0), removedClauses(0), forcedRemovedClauses(0), nbThreads(0) {}

void ClausesBuffer::setNbThreads(int _nbThreads) {
    unsigned int _maxsize = 100000*_nbThreads;
    last = _maxsize -1;
    maxsize = _maxsize;
    nbThreads = _nbThreads;
    lastOfThread.growTo(_nbThreads);
    for(int i=0;i<nbThreads;i++) lastOfThread[i] = _maxsize-1;
    elems.growTo(maxsize);
}

uint32_t ClausesBuffer::getCap() {
    return elems.capacity();
}
inline unsigned int ClausesBuffer::nextIndex(unsigned int i) {
    i++;
    if (i == maxsize)
	return 0;
    return i;
}

inline unsigned int ClausesBuffer::addIndex(unsigned int i, unsigned int a) {
    i += a;
    if (i >= maxsize)
	return i - maxsize;
    return i;
}

void ClausesBuffer::removeLastClause() {
    assert(queuesize > 0);
    do {
	unsigned int size = (unsigned int) elems[nextIndex(last)];
	unsigned int nextlast = addIndex(last, size+headerSize);

	for(int i=0;i<nbThreads;i++) {
	    if (lastOfThread[i] == last)
		lastOfThread[i] = nextlast;
	}

	// printf("Removing clause starting at %d of size %d.\n",nextIndex(last), size);
	for(unsigned int i=0;i<size+headerSize;i++) {
#ifdef _DEBUGME
	    printf("Removing cell %d\n",nextIndex(last));
	    elems[nextIndex(last)] = Sentinel;
#endif
	    last = nextIndex(last);
	    assert(queuesize > 0);
	    queuesize --;
	}	
	removedClauses ++;
	assert(last >= 0);
	assert(last < maxsize);
	assert(last == nextlast);
    } while (queuesize > 0 && (elems[addIndex(last,2)] == 0)); 	

}

inline void ClausesBuffer::noCheckPush(uint32_t x) {
#ifdef _DEBUGME
    assert(elems[first] == Sentinel);
#endif
    elems[first] = x;
    first = nextIndex(first);
}

inline uint32_t ClausesBuffer::noCheckPop(unsigned int & index) {
    index = nextIndex(index);
    uint32_t ret = elems[index];
    return ret;
}



// Return true if the clause was succesfully added
bool ClausesBuffer::pushClause(int threadId, Clause & c, int route) {
    if (queuesize + c.size() + headerSize >= maxsize)
	return false; // We need to remove some old clauses
#ifdef _DEBUGME
    for(int i=0;i<10;i++) {
	printf("%d ", elems[i]);
    }
    printf(" (%d:%d)\n", first, last);
#endif
    //	    printf("Pushing Clause of size %d at (%d,%d) from thread %d. ", c.size(), first, last, threadId); fflush(stdout);
    while (queuesize + c.size() + headerSize >= maxsize) { // We need to remove some old clauses
	forcedRemovedClauses ++;
	removeLastClause();
	assert(queuesize > 0);
    }
    noCheckPush(c.size());
    noCheckPush(nbThreads>1?nbThreads-1:1);
    noCheckPush(threadId);
    noCheckPush(route);
    for(int i=0;i<c.size();i++)
	noCheckPush(toInt(c[i]));
    queuesize += c.size()+headerSize;
    return true;
    //  printf(" -> (%d, %d)\n", first, last);
}

bool ClausesBuffer::getClause(int threadId, int & threadOrigin, vec<Lit> & resultClause, int & route, bool firstFound) {

#ifdef _DEBUGME
    for(int i=0;i<10;i++) {
	printf("%d ", elems[i]);
    }
    printf(" (%d:%d)\n", first, last);
#endif
    assert(lastOfThread.size() > threadId);
    unsigned int thislast = lastOfThread[threadId];
    assert(!firstFound || thislast == last); // FIXME: Gilles has this assertion on his cluster

    // Early exiting
    if (nextIndex(thislast) == first) return false;

    if ( ( thislast < last && last < first) ||
	    ( first < thislast && thislast < last ) ||
	    ( last < first && first < thislast) ) {
	// Special case where last has moved and lastOfThread[threadId] is no more valid (is behind)
	thislast = last; 
    }

    // Go to next clause for this thread id
    if (!firstFound) // FIXME: Is this the solution for the bug ? (instead of first ?)
	while (nextIndex(thislast) != first && elems[addIndex(thislast,3)] == threadId) { // 3 = 2 + 1 
	    thislast = addIndex(thislast, elems[nextIndex(thislast)] + headerSize); // 
	    assert(thislast >= 0);
	    assert(thislast < maxsize);
	}

    if (nextIndex(thislast) == first) {
	lastOfThread[threadId] = thislast;
	return false;
    }
    int previouslast = thislast;
    bool removeAfter = false;
    int csize = noCheckPop(thislast);
    removeAfter = (--elems[addIndex(thislast,1)] == 0); // We are sure this is not one of our own clause
    thislast = nextIndex(thislast);
    threadOrigin = noCheckPop(thislast);
    route = noCheckPop(thislast);
    resultClause.clear();
    for(int i=0;i<csize;i++) {
	resultClause.push(toLit(noCheckPop(thislast)));
    }
    if (last == previouslast && removeAfter) {
	removeLastClause();
	thislast = last;
    }
    lastOfThread[threadId] = thislast;
    return true;
}


//=================================================================================================

