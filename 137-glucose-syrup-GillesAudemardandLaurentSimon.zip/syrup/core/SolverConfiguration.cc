/****************************************************************************************[Solver.h]
 Glucose -- Copyright (c) 2009, Gilles Audemard, Laurent Simon
				CRIL - Univ. Artois, France
				LRI  - Univ. Paris Sud, France
 
Glucose sources are based on MiniSat (see below MiniSat copyrights). Permissions and copyrights of
Glucose are exactly the same as Minisat on which it is based on. (see below).


Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "core/SolverConfiguration.h"
#include "core/MultiSolvers.h"
#include "core/Solver.h"


 void SolverConfiguration::configure(MultiSolvers *ms, int nbsolvers) {
   if(nbsolvers == 2) {
	printf("c syrup configured for 2 cores\n");
	ms->solvers[1]->var_decay = 0.85;
	ms->solvers[1]->max_var_decay = 0.97;
	ms->solvers[1]->firstReduceDB=1000;
   } else if (nbsolvers > 2 && nbsolvers <=4) {
       printf("c syrup configured for 4 cores\n");
       if (ms->coreFUIP) {
	   ms->solverFUIP = ms->solvers[1];
       } else {
	   ms->solvers[1]->var_decay = 0.94;
	   ms->solvers[1]->max_var_decay = 0.96;
	   ms->solvers[1]->firstReduceDB=600;
       }
       // Glucose 2.0 (+ blocked restarts)
       ms->solvers[2]->var_decay = 0.95;
       ms->solvers[2]->max_var_decay = 0.95;
       ms->solvers[2]->firstReduceDB=4000;
       ms->solvers[2]->lbdQueue.growTo(100);
       ms->solvers[2]->sizeLBDQueue = 100;
       ms->solvers[2]->K = 0.7;

       if (nbsolvers > 3) {
	   ms->solvers[3]->var_decay = 0.85;
	   ms->solvers[3]->max_var_decay = 0.93;
	   ms->solvers[3]->firstReduceDB=400;
       }
   } else if (nbsolvers > 4 && nbsolvers >= 8) {
       printf("c syrup configured for 8 cores or more\n");
       if (ms->coreFUIP) {
	   ms->solverFUIP = ms->solvers[1];
       } else {
	   ms->solvers[1]->var_decay = 0.94;
	   ms->solvers[1]->max_var_decay = 0.96;
	   ms->solvers[1]->firstReduceDB=600;
       }
       ms->solvers[2]->var_decay = 0.90;
       ms->solvers[2]->max_var_decay = 0.97;
       ms->solvers[2]->firstReduceDB=500;

       ms->solvers[3]->var_decay = 0.85;
       ms->solvers[3]->max_var_decay = 0.93;
       ms->solvers[3]->firstReduceDB=400;

       // Glucose 2.0 (+ blocked restarts)
       ms->solvers[4]->var_decay = 0.95;
       ms->solvers[4]->max_var_decay = 0.95;
       ms->solvers[4]->firstReduceDB=4000;
       ms->solvers[4]->lbdQueue.growTo(100);
       ms->solvers[4]->sizeLBDQueue = 100;
       ms->solvers[4]->K = 0.7;
       ms->solvers[4]->incReduceDB = 500;
       if (nbsolvers > 5) {
	   ms->solvers[5]->var_decay = 0.93;
	   ms->solvers[5]->max_var_decay = 0.96;
	   ms->solvers[5]->firstReduceDB=100;
	   ms->solvers[5]->incReduceDB = 500;
	   if (nbsolvers > 6 ) {
	       ms->solvers[6]->var_decay = 0.75;
	       ms->solvers[6]->max_var_decay = 0.94;
	       ms->solvers[6]->firstReduceDB=2000;
	       if (nbsolvers > 7 ) {
		   ms->solvers[7]->var_decay = 0.94;
		   ms->solvers[7]->max_var_decay = 0.96;
		   ms->solvers[7]->firstReduceDB=800;

		   if (nbsolvers > 8) {
		       ms->solvers[8]->reduceOnSize = true;
		       if (nbsolvers > 9) {
			   ms->solvers[9]->reduceOnSize = true;
			   ms->solvers[9]->reduceOnSizeSize = 14;
			   if (nbsolvers > 10) {
			       double noisevar_decay = 0.005;
			       int noiseReduceDB = 50;
			       for (int i=10;i<nbsolvers;i++) {
				   ms->solvers[i]-> var_decay = ms->solvers[i%8]->var_decay;
				   ms->solvers[i]-> max_var_decay = ms->solvers[i%8]->max_var_decay;
				   ms->solvers[i]-> firstReduceDB= ms->solvers[i%8]->firstReduceDB;
				   ms->solvers[i]->var_decay += noisevar_decay;
				   ms->solvers[i]->firstReduceDB+=noiseReduceDB;
				   if ((i+1) % 8 == 0) {
				       noisevar_decay += 0.006;
				       noiseReduceDB += 25;
				   }
			       }
			   }
		       }
		   }

	       }
	   }
       }
   } else {
	printf("c Ooch, no configuration for this number of cores!\n");
    }

    }
