/***********************************************************************************[BoundedQueue.h]
 Glucose -- Copyright (c) 2009, Gilles Audemard, Laurent Simon
                CRIL - Univ. Artois, France
                LRI  - Univ. Paris Sud, France
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

// route 1 : 1 2 3 4 5 6 7 8
// route 2 : 2 4 7 8 1 3 5 6 -> 2 : 3 4 5 7 6 2 8 1
// route 3 : 
// ...
// route n : 8 6 7 5 2 4 1 3 
#ifndef ClausesBuffer_h 
#define ClausesBuffer_h

#include "mtl/Vec.h"
#include "core/SolverTypes.h"

//#define _DEBUGME
#ifdef _DEBUGME
const int Sentinel UINT_MAX;
#endif
//=================================================================================================

namespace Glucose {
    // index : size clause
    // index + 1 : nbSeen
    // index + 2 : threadId
    // index + 3 : clause route
    // index + 4 : .. index + 4 + size : Lit of clause
    class ClausesBuffer {
	vec<uint32_t>  elems;
	unsigned int     first;
	unsigned int	 last;
	unsigned int     maxsize;
	unsigned int     queuesize; // Number of current elements (must be < maxsize !)
	unsigned int     removedClauses;
	unsigned int     forcedRemovedClauses;
        static const int  headerSize = 4;
	int       nbThreads;
	vec<unsigned int> lastOfThread; // Last value for a thread 

	public:
	ClausesBuffer(int _nbThreads, unsigned int _maxsize);
	ClausesBuffer();
	void setNbThreads(int _nbThreads);
	unsigned int nextIndex(unsigned int i);
	unsigned int addIndex(unsigned int i, unsigned int a); 
	void removeLastClause(); 
	   
	void noCheckPush(uint32_t x);
	uint32_t noCheckPop(unsigned int & index);

	// Return true if the clause was succesfully added
        bool pushClause(int threadId, Clause & c, int route);
        bool getClause(int threadId, int & threadOrigin, vec<Lit> & resultClause, int & route, bool firstFound = false); 
	
	int maxSize() const {return maxsize;}
        uint32_t getCap();
	void growTo(int size) {
	    assert(0); // Not implemented
	    elems.growTo(size); 
	    first=0; maxsize=size; queuesize = 0;last = 0;
	    for(int i=0;i<size;i++) elems[i]=0; 
	}

	void fastclear() {first = 0; last = 0; queuesize=0; } // to be called after restarts... Discard the queue

	int  size(void)    { return queuesize; }

	void clear(bool dealloc = false)   { elems.clear(dealloc); first = 0; maxsize=0; queuesize=0;}
	inline  int  toInt     (Lit p)              { return p.x; } 

    };
}
//=================================================================================================

#endif
