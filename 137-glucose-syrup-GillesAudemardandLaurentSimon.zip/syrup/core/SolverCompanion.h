/*
 *  SolverCompanion.h
 *  minithreads
 *
 *  Created by Laurent Simon on 06/03/09.
 *  Copyright 2009 LRI, Univ. Paris 11. All rights reserved.
 *
 */

#ifndef SolverCompanion_h
#define SolverCompanion_h

#include "Solver.h"
using namespace Glucose;

class SolverCompanion {
	public:
	SolverCompanion();
	~SolverCompanion();
	
	bool addSolver(Solver*); // attach a solver to accompany 
	
	int runOnceCompanion(); // run it as a thread, but run it just once... 
	
	protected:
	int runOnceCompanion(Solver*s); // run it only on this watched solver
	friend class Solver;
	vec<Solver*> watchedSolvers; 
};

#endif

