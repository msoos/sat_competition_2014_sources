/*
 *  SharedCompanion.C
 *  minithreads
 *
 *  This companion is responsible for
 *   - Handling the clause databases of all solvers
 *   - Sharing interesting clauses between them
 *  This object is the same for all threads... Used as some kind of blackboard...
 *
 *  Created by Laurent Simon on 19/03/09.
 *  Copyright 2009 LRI, Univ. Paris 11. All rights reserved.
 *
 */

#include "Solver.h"
#include "SolverTypes.h"
#include "SharedCompanion.h"
#include "ClausesBuffer.h"

using namespace Glucose;

SharedCompanion::SharedCompanion(int _nbThreads) :
    nbThreads(_nbThreads), 
    bjobFinished(false),
    jobFinishedBy(NULL),
    panicMode(false),
    solverFUIP(NULL),
    jobStatus(l_Undef),
    clausesBuffer(_nbThreads, 100000*_nbThreads),
    nbRoads(_nbThreads * 3),
    survivorClauses(0),
    random_seed(91648253) {

	pthread_mutex_init(&mutexSharedClauseCompanion,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexSharedUnitCompanion,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexSharedCompanion,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexJobFinished,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexSendAuth,NULL); // This is the shared companion lock for allowing/not a thread to send a message
	pthread_mutex_init(&mutexFUIP,NULL); // Mutex for bumping a FUIP from another thread
	fprintf(stdout,"c Shared companion initialized: handling of clauses of %d threads.\nc %d ints for the sharing clause buffer (not expandable) .\n", _nbThreads, clausesBuffer.maxSize());

	roads.push(); // Road 0 is a dummy road
	while (roads.size() <= nbRoads) {
	    roads.push();
	    initRoad(roads[roads.size()-1]);
	}
	fprintf(stdout, "c %d random walks for shared clauses generated.\n", roads.size()-1);
}
SharedCompanion::SharedCompanion() :
    nbThreads(0), 
    bjobFinished(false),
    jobFinishedBy(NULL),
    solverFUIP(NULL),
    jobStatus(l_Undef),
    nbRoads(10),
    survivorClauses(0),
    random_seed(91648253) {

	pthread_mutex_init(&mutexSharedClauseCompanion,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexSharedUnitCompanion,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexSharedCompanion,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexJobFinished,NULL); // This is the shared companion lock
	pthread_mutex_init(&mutexSendAuth,NULL); // This is the shared companion lock for allowing/not a thread to send a message
	pthread_mutex_init(&mutexFUIP,NULL); // Mutex for bumping a FUIP from another thread
	//fprintf(stdout,"c Shared companion initialized: handling of clauses of %d threads.\nc %d ints for the sharing clause buffer (not expandable) .\n", _nbThreads, clausesBuffer.maxSize());

	roads.push(); // Road 0 is a dummy road
	while (roads.size() <= nbRoads) {
	    roads.push();
	    initRoad(roads[roads.size()-1]);
	}
	fprintf(stdout, "c %d random walks for shared clauses generated.\n", roads.size()-1);
}

void SharedCompanion::setNbThreads(int _nbThreads) {
   nbThreads = _nbThreads;
   clausesBuffer.setNbThreads(_nbThreads); 
}


void SharedCompanion::printStats() {
    printf("c survivor clauses : %d\n", survivorClauses);
}

void SharedCompanion::initRoad(vec<int> & road) {
    vec<int> vtmp;
    road.clear();
    for(int i=0; i< nbThreads; i++) {
	vtmp.push(i);
    }
    for(int i=0;i<nbThreads-1;i++) {
	int pos = irand(random_seed, nbThreads-i)+i;
        int tmp = vtmp[i];
        vtmp[i] = vtmp[pos];
	vtmp[pos] = tmp;
    }

    road.growTo(vtmp.size());
    for(int i=0;i<road.size();i++) {
	road[vtmp[i]] = vtmp[(i+1) % road.size()];
    }
    /*
    printf("c Road %d: ", roads.size()-1);
    for(int i=0; i< nbThreads; i++) {
	printf("%d ", road[i]);
    }
    printf("\n");
*/

}

// No multithread safe
bool SharedCompanion::addSolver(Solver* s) {
	watchedSolvers.push(s);
	pthread_mutex_t* mu = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
	pthread_mutex_init(mu,NULL);
	mutexInputClausesBuffer.push(mu);
	clausesBufferOfThread.push(new ClausesBuffer(1,100));
	assert(s->thn == watchedSolvers.size()-1); // all solvers must have been registered in the good order
	nextUnit.push(0);

	return true;
}
void SharedCompanion::newVar(bool sign) {
   isUnary .push(l_Undef);
}

void SharedCompanion::addLearnt(Solver *s,Lit unary) {
  pthread_mutex_lock(&mutexSharedUnitCompanion);
  if (isUnary[var(unary)]==l_Undef) {
      unitLit.push(unary);
      isUnary[var(unary)] = sign(unary)?l_False:l_True;
  } 
  pthread_mutex_unlock(&mutexSharedUnitCompanion);
}

Lit SharedCompanion::getUnary(Solver *s) {
  int sn = s->thn;
  Lit ret = lit_Undef;

  pthread_mutex_lock(&mutexSharedUnitCompanion);
  if (nextUnit[sn] < unitLit.size())
      ret = unitLit[nextUnit[sn]++];
  pthread_mutex_unlock(&mutexSharedUnitCompanion);
 return ret;
}

// Specialized functions for this companion
// must be multithread safe
// Add a clause to the threads-wide clause database (all clauses, through)
bool SharedCompanion::addLearnt(Solver *s, Clause & c, int route) { // route = 0 by default
  int sn = s->thn; // thread number of the solver
  bool ret = false;
  assert(watchedSolvers.size()>sn);

  assert(!(c.wasImported() && c.importedRoute() > 1)); 

  pthread_mutex_lock(&mutexSharedClauseCompanion);
  ret = clausesBuffer.pushClause(sn, c, route);
  pthread_mutex_unlock(&mutexSharedClauseCompanion);
  return ret;
}

bool SharedCompanion::addLearntFollowRoad(int from, Clause &c) {
    bool ret = false;
    int origin = c.importedFrom();
    int route = c.importedRoute();
    assert(route < roads.size());
    int to = roads[route][from];
    if (to != origin) {// Otherwise we have a loop
	ClausesBuffer& cb = *(clausesBufferOfThread[to]);
	pthread_mutex_lock(mutexInputClausesBuffer[to]);
        ret = cb.pushClause(origin, c, route);
	pthread_mutex_unlock(mutexInputClausesBuffer[to]);
    } else {
	survivorClauses++;
    }
    return ret;
}

bool SharedCompanion::addLearntInitRoad(int from, Clause &c, double random) {
    bool ret = false;
    
    int route = 1 + (int) (random * (double)(roads.size()-1));
    assert(route < roads.size());
    int to = roads[route][from];
    pthread_mutex_lock(mutexInputClausesBuffer[to]); 
    ClausesBuffer& cb = *(clausesBufferOfThread[to]);
    ret = cb.pushClause(from, c, route);
    pthread_mutex_unlock(mutexInputClausesBuffer[to]);
    return ret;
}


// The clause came from "origin", was send to "from" for probation.
// We need to add it to all the other threads as an interesting clause
bool SharedCompanion::addLearntAfterProbation(int from, Clause &c) {
    bool ret = false;
    int origin = c.importedFrom();
    int route = c.importedRoute();
    assert(route < roads.size());
    assert(route == 1); // probations by one friend are only asked for route = 1
    for(int to = 0; to< nbThreads; to++) 
	if (to != origin && to !=from) {// Otherwise we have a loop
	    ClausesBuffer& cb = *(clausesBufferOfThread[to]);
	    pthread_mutex_lock(mutexInputClausesBuffer[to]);
	    ret |= cb.pushClause(origin, c, route);
	    pthread_mutex_unlock(mutexInputClausesBuffer[to]);
	} 
    return ret;
}

// The clause will be sent to a random friend for probation
bool SharedCompanion::addLearntForProbation(int from, Clause &c, double random) {
    bool ret = false;
   
    int route;
    if (c.wasImported())
	route = c.importedRoute(); 
    else 
	route = watchedSolvers[0]->survivorLayers;
    int to =  (int)(random * (double)nbThreads);
    if (to == from) {
       to = (to + 1) % nbThreads;
    }	
    pthread_mutex_lock(mutexInputClausesBuffer[to]); 
    ClausesBuffer& cb = *(clausesBufferOfThread[to]);
    ret = cb.pushClause(from, c, route);
    pthread_mutex_unlock(mutexInputClausesBuffer[to]);
    return ret;
}



bool SharedCompanion::getNewClause(Solver *s, int & threadOrigin, vec<Lit>& newclause, int & route) { // gets a new interesting clause for solver s 
  int sn = s->thn;
  
    // First, let's get the clauses on the big blackboard
    route = -1; // no route yet
    pthread_mutex_lock(&mutexSharedClauseCompanion);
    bool b = clausesBuffer.getClause(sn, threadOrigin, newclause, route);
    assert(!b || route == 0); // Those global clauses don't have any roads
    pthread_mutex_unlock(&mutexSharedClauseCompanion);
 
   // If none, let's get the clauses registered for this particular thread
   if (!b) {
       ClausesBuffer & cb = *clausesBufferOfThread[sn];
       pthread_mutex_lock(mutexInputClausesBuffer[sn]);
       b = cb.getClause(0, threadOrigin, newclause, route, true); // FIXME Is sn or threadOrigin the real lock for this clause?
       assert(!b || route > 0);
       pthread_mutex_unlock(mutexInputClausesBuffer[sn]);
   } 
   
  return b;
}

bool SharedCompanion::jobFinished() {
    bool ret = false;
    pthread_mutex_lock(&mutexJobFinished);
    ret = bjobFinished;
    pthread_mutex_unlock(&mutexJobFinished);
    return ret;
}

bool SharedCompanion::IFinished(Solver *s) {
    bool ret = false;
    pthread_mutex_lock(&mutexJobFinished);
    if (!bjobFinished) {
	ret = true;
	bjobFinished = true;
	jobFinishedBy = s;
    }
    pthread_mutex_unlock(&mutexJobFinished);
    return ret;
}

bool SharedCompanion::canISendMyClauses(int thread) {
     bool ret = false;
     assert(thread < nbThreads);
     pthread_mutex_lock(&mutexSendAuth);

     pthread_mutex_unlock(&mutexSendAuth);
     return ret; 
}

void SharedCompanion::registerMyPerformances(int thread, int conflict, int score) {
     assert(thread < nbThreads);
     pthread_mutex_lock(&mutexSendAuth);
     // printf("c registering perfs = %d for thread %d at conflict %d\n", originalClauses, thread, conflict);
     pthread_mutex_unlock(&mutexSendAuth);
}

int mutexCounter = 0;
void SharedCompanion::bumpFUIP(Lit fuip, uint32_t confl) {
    while (pthread_mutex_lock(&mutexFUIP)) {
	assert(0);
    }	// TODO: use a data structure to prevent all threads to be locked here
    mutexCounter++;
    assert(mutexCounter==1);
    assert(solverFUIP != NULL);
    solverFUIP->varBumpActivity(var(fuip));
    mutexCounter--;
    pthread_mutex_unlock(&mutexFUIP);
}

void SharedCompanion::MutexLockFUIPCore() {
    while (pthread_mutex_lock(&mutexFUIP)) {
	assert(0);
    };
    mutexCounter++;
    assert(mutexCounter==1);
}

void SharedCompanion::MutexUnlockFUIPCore() {
    assert(mutexCounter==1);
    mutexCounter--;
    pthread_mutex_unlock(&mutexFUIP);
}


