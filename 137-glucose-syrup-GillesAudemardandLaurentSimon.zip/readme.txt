Solver name : syrup
Solver version : 1.0
Authors : Gilles Audemard and Laurent Simon


For compiling : 
   ./build.sh

For running 
syrup BENCHNAME -model

