make -C code cleaner
rm -f binary/penelope binary/SatELite_release binary/configuration.ini binary/solver.sh 
rmdir binary
