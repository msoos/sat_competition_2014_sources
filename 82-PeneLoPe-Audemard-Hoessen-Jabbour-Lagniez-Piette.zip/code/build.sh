export FM=$PWD/SatELite/ForMani

#cd ./SatELite/SatELite
make -C ./SatELite/SatELite r
cp ./SatELite/SatELite/SatELite_release ./
