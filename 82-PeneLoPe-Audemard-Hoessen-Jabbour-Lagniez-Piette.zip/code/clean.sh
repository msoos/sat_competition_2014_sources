export FM=$PWD/SatELite/ForMani

rm -f ./SatELite/ForMani/Global/depend.mak ./SatELite/ForMani/depend.mak ./SatELite/ForMani/ADTs/depend.mak
rm -f SatELite_release

#cd ./SatELite/SatELite
make -C ./SatELite/SatELite realclean

