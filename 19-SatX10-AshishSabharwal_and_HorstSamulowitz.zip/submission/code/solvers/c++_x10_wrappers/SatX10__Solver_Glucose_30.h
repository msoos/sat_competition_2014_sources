// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Saraswat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#ifndef SatX10__Solver_Glucose_30_h
#define SatX10__Solver_Glucose_30_h

#include "../../SatX10__Solver.h"

#include "../c++/glucose_30/core/Solver.h"
#include "../c++/glucose_30/utils/Options.h"


// Native c++ code for the x10 class Solver_Glucose_30
// Creates a solver object, parses commandline options, and reads CNF input file
class SatX10__Solver_Glucose_30 : public SatX10__Solver {
public:
    RTT_H_DECLS_CLASS

    // constructor
    SatX10__Solver_Glucose_30 (
            x10_int placeID,
            x10_int nPlaces,
            x10_boolean isHub,
            x10::lang::String* instanceName,
            x10_int maxlen,
            x10_int outgoingClausesBufferSize,
            x10::lang::Rail<x10::lang::String* >* arguments) :
                SatX10__Solver(instanceName->c_str(), maxlen) {

        // first parse command-line options; to do this, convert arguments into the usual argc, argv format
        int argc = arguments->FMGL(size) + 1;
        char** argv = convertX10StringArrayToCStyleArgvWithOffset(arguments);
        Glucose_30::parseOptions(argc, argv);
        // should normally have freed up the memory for argv here, but not worth the effort

        // now create the solver object
        solver = new Glucose_30::Solver(instanceName->c_str(), placeID, nPlaces, isHub, this, maxlen, outgoingClausesBufferSize);

        // parse CNF file
        solver->x10_parseDIMACS(instanceName->c_str());

        // print instance information if this is place 0
        if (placeID == 0)
            printInstanceInfo();
    }

    // destructor
    virtual ~SatX10__Solver_Glucose_30() { }

    // _make for X10
    static SatX10__Solver_Glucose_30* _make(
            x10_int placeID,
            x10_int nPlaces,
            x10_boolean isHub,
            x10::lang::String* s,
            x10_int maxlen,
            x10_int outgoingClausesBufferSize,
            x10::lang::Rail<x10::lang::String* >* arguments) {

    	SatX10__Solver_Glucose_30* self =
            new (x10aux::alloc<SatX10__Solver_Glucose_30>()) SatX10__Solver_Glucose_30(placeID, nPlaces, isHub, s, maxlen, outgoingClausesBufferSize, arguments);

        return self;
    }

    // type 2: solve with XOR based splitting, to be called by SatX10.x10
    x10_int solveWithXors (x10::lang::VoidFun_0_1<x10::lang::Rail<int>* >* closure1_,
                           x10::lang::Fun_0_0<x10_int>* closure2_,
                           x10::lang::Rail<int>* xorVars_,
                           x10_boolean xorsAsCnf_);

    // type 2: solve with random prefix of variables, to be called by SatX10.x10
    x10_int solveWithPrefix (x10::lang::VoidFun_0_1<x10::lang::Rail<int>* >* closure1_,
                             x10::lang::Fun_0_0<x10_int>* closure2_,
                             x10::lang::Rail<int>* randomVars_);

    // type 2: a method to get a rail of free variables, to be called by SatX10.x10
    x10::lang::Rail<x10_int>* getFreeVars() {
    	vector<int> freeVars;
    	(dynamic_cast<Glucose_30::Solver*>(solver))->x10_getFreeVars(freeVars);
    	x10::lang::Rail<int>* freeVars_ = x10::lang::Rail<x10_int>::_make(freeVars.size());
    	for (unsigned i=0 ; i<freeVars.size() ; i++)
    		freeVars_->raw[(x10_int)i] = freeVars[i];
    	return freeVars_;
    }

    // type 2: solve with assumptions, to be called by SatX10.x10
    x10_int solveWithAssumptions (x10::lang::VoidFun_0_1<x10::lang::Rail<int>* >* closure1_,
                                  x10::lang::Fun_0_0<x10_int>* closure2_,
                                  x10::lang::Rail<int>* randomVars_);

    // type 2: a method to get a rail containing the last clause, to be called by SatX10.x10
    x10::lang::Rail<x10_int>* getLastClause() {
    	vector<int> lastClause;
    	(dynamic_cast<Glucose_30::Solver*>(solver))->x10_getLastClause(lastClause);
    	x10::lang::Rail<int>* lastClause_ = x10::lang::Rail<x10_int>::_make(lastClause.size());
    	for (unsigned i=0 ; i<lastClause.size() ; i++)
    		lastClause_->raw[(x10_int)i] = lastClause[i];
    	return lastClause_;
    }
};

// type 2: solve with XOR based splitting, to be called by SatX10.x10
inline x10_int SatX10__Solver_Glucose_30::solveWithXors (x10::lang::VoidFun_0_1<x10::lang::Rail<int>* >* closure1_,
                                                         x10::lang::Fun_0_0<x10_int>* closure2_,
                                                         x10::lang::Rail<int>* xorVars_,
                                                         x10_boolean xorsAsCnf_) {
    closure1 = closure1_;
    closure2 = closure2_;
    // convert Rail[Int] to vector<vector<int>> to pass on to x10_solve
    static const int sep = 0;  // must be identical to what was used when creating xorVars_ !
    vector< vector<int> > xorVars;
    vector<int> oneXor;
    for (x10_int i=0 ; i<xorVars_->FMGL(size); i++) {
    	const int var = xorVars_->raw[i];
    	if (var != sep)
    		oneXor.push_back(var);
    	else {
    		!oneXor.empty();
    		xorVars.push_back(oneXor);
    		oneXor.clear();
    	}
    }
    solveStatus = (dynamic_cast<Glucose_30::Solver*>(solver))->x10_solveWithXors(xorVars, xorsAsCnf_);
    return solveStatus;
}

// type 2: solve with random prefix of variables, to be called by SatX10.x10
inline x10_int SatX10__Solver_Glucose_30::solveWithPrefix (x10::lang::VoidFun_0_1<x10::lang::Rail<int>* >* closure1_,
                                                           x10::lang::Fun_0_0<x10_int>* closure2_,
                                                           x10::lang::Rail<int>* randomVars_) {
    closure1 = closure1_;
    closure2 = closure2_;
    // convert Rail[Int] to vector<vector<int>> to pass on to x10_solve
    static const int sep = 0;  // must be identical to what was used when creating randomVars_ !
    vector< vector<int> > randomVars;
    vector<int> oneRandomSet;
    for (x10_int i=0 ; i<randomVars_->FMGL(size); i++) {
    	const int var = randomVars_->raw[i];
    	if (var != sep)
    		oneRandomSet.push_back(var);
    	else {
    		!oneRandomSet.empty();
    		randomVars.push_back(oneRandomSet);
    		oneRandomSet.clear();
    	}
    }
    solveStatus = (dynamic_cast<Glucose_30::Solver*>(solver))->x10_solveWithPrefix(randomVars);
    return solveStatus;
}

// type 2: solve with assumptions, to be called by SatX10.x10
inline x10_int SatX10__Solver_Glucose_30::solveWithAssumptions (x10::lang::VoidFun_0_1<x10::lang::Rail<int>* >* closure1_,
                                                                x10::lang::Fun_0_0<x10_int>* closure2_,
                                                                x10::lang::Rail<int>* assumptions_) {
    closure1 = closure1_;
    closure2 = closure2_;
    // convert Rail[Int] to vector<int> to pass on to x10_solve
    vector<int> assumptions(assumptions_->FMGL(size));
    for (x10_int i=0 ; i<assumptions_->FMGL(size); i++)
    	assumptions[i] = assumptions_->raw[i];
    solveStatus = (dynamic_cast<Glucose_30::Solver*>(solver))->x10_solveWithAssumptions(assumptions);
    return solveStatus;
}


#endif
