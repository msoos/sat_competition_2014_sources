package com.ibm.satx10.config.tests;


@x10.core.X10Generated public class ExplicitPPTests extends x10.core.Ref implements x10.x10rt.X10JavaSerializable
{
    private static final long serialVersionUID = 1L;
    private static final short $_serialization_id = x10.x10rt.DeserializationDispatcher.addDispatcher(x10.x10rt.DeserializationDispatcher.ClosureKind.CLOSURE_KIND_NOT_ASYNC, ExplicitPPTests.class);
    
    public static final x10.rtt.RuntimeType<ExplicitPPTests> $RTT = x10.rtt.NamedType.<ExplicitPPTests> make(
    "com.ibm.satx10.config.tests.ExplicitPPTests", /* base class */ExplicitPPTests.class
    , /* parents */ new x10.rtt.Type[] {x10.rtt.Types.OBJECT}
    );
    public x10.rtt.RuntimeType<?> $getRTT() {return $RTT;}
    
    
    private void writeObject(java.io.ObjectOutputStream oos) throws java.io.IOException { if (x10.runtime.impl.java.Runtime.TRACE_SER) { java.lang.System.out.println("Serializer: writeObject(ObjectOutputStream) of " + this + " calling"); } oos.defaultWriteObject(); }
    public static x10.x10rt.X10JavaSerializable $_deserialize_body(ExplicitPPTests $_obj , x10.x10rt.X10JavaDeserializer $deserializer) throws java.io.IOException { 
    
        if (x10.runtime.impl.java.Runtime.TRACE_SER) { x10.runtime.impl.java.Runtime.printTraceMessage("X10JavaSerializable: $_deserialize_body() of " + ExplicitPPTests.class + " calling"); } 
        return $_obj;
        
    }
    
    public static x10.x10rt.X10JavaSerializable $_deserializer(x10.x10rt.X10JavaDeserializer $deserializer) throws java.io.IOException { 
    
        ExplicitPPTests $_obj = new ExplicitPPTests((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
        
    }
    
    public short $_get_serialization_id() {
    
         return $_serialization_id;
        
    }
    
    public void $_serialize(x10.x10rt.X10JavaSerializer $serializer) throws java.io.IOException {
    
        
    }
    
    // constructor just for allocation
    public ExplicitPPTests(final java.lang.System[] $dummy) { 
    super($dummy);
    }
    
        
//#line 7 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
@x10.core.X10Generated public static class TestFailure extends x10.lang.Error implements x10.x10rt.X10JavaSerializable
                                                                                                                      {
            private static final long serialVersionUID = 1L;
            private static final short $_serialization_id = x10.x10rt.DeserializationDispatcher.addDispatcher(x10.x10rt.DeserializationDispatcher.ClosureKind.CLOSURE_KIND_NOT_ASYNC, TestFailure.class);
            
            public static final x10.rtt.RuntimeType<TestFailure> $RTT = x10.rtt.NamedType.<TestFailure> make(
            "com.ibm.satx10.config.tests.ExplicitPPTests.TestFailure", /* base class */TestFailure.class
            , /* parents */ new x10.rtt.Type[] {x10.lang.Error.$RTT}
            );
            public x10.rtt.RuntimeType<?> $getRTT() {return $RTT;}
            
            
            private void writeObject(java.io.ObjectOutputStream oos) throws java.io.IOException { if (x10.runtime.impl.java.Runtime.TRACE_SER) { java.lang.System.out.println("Serializer: writeObject(ObjectOutputStream) of " + this + " calling"); } oos.defaultWriteObject(); }
            public static x10.x10rt.X10JavaSerializable $_deserialize_body(TestFailure $_obj , x10.x10rt.X10JavaDeserializer $deserializer) throws java.io.IOException { 
            
                if (x10.runtime.impl.java.Runtime.TRACE_SER) { x10.runtime.impl.java.Runtime.printTraceMessage("X10JavaSerializable: $_deserialize_body() of " + TestFailure.class + " calling"); } 
                x10.lang.Error.$_deserialize_body($_obj, $deserializer);
                return $_obj;
                
            }
            
            public static x10.x10rt.X10JavaSerializable $_deserializer(x10.x10rt.X10JavaDeserializer $deserializer) throws java.io.IOException { 
            
                TestFailure $_obj = new TestFailure((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
                
            }
            
            public short $_get_serialization_id() {
            
                 return $_serialization_id;
                
            }
            
            public void $_serialize(x10.x10rt.X10JavaSerializer $serializer) throws java.io.IOException {
            
                super.$_serialize($serializer);
                
            }
            
            // constructor just for allocation
            public TestFailure(final java.lang.System[] $dummy) { 
            super($dummy);
            }
            
                
                
//#line 7 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final public com.ibm.satx10.config.tests.ExplicitPPTests.TestFailure
                                                                                                                                com$ibm$satx10$config$tests$ExplicitPPTests$TestFailure$$com$ibm$satx10$config$tests$ExplicitPPTests$TestFailure$this(
                                                                                                                                ){
                    
//#line 7 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
return com.ibm.satx10.config.tests.ExplicitPPTests.TestFailure.this;
                }
                
                
//#line 7 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
public TestFailure() {super();
                                                                                                                                                         {
                                                                                                                                                            
//#line 7 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"

                                                                                                                                                        }}
                
            }
            
        
        
//#line 8 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
public static void
                                                                                                                        test1(
                                                                                                                        ){
            
//#line 9 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final x10.array.Array<java.lang.String> pp =
              ((x10.array.Array)(x10.core.ArrayFactory.<java.lang.String> makeArrayFromJavaArray(x10.rtt.Types.STRING, new java.lang.String[] {"c This is a comment.", "H 0 1 2 3 a a1 a2", "H 3 3 2 1 0 b b1 b2 b3", "L 1 3 2 0 c  c1 c2 c3 c4", "c This is a comment.", "L 1 3 2 0 d d1 d2 d3 d4"})));
            
//#line 16 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final x10.lang.Iterable<java.lang.String> t3041 =
              ((x10.lang.Iterable<java.lang.String>)
                ((x10.array.Array<java.lang.String>)pp).values());
            
//#line 16 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final ExplicitPPConfiguration config =
              ((ExplicitPPConfiguration)(ExplicitPPConfiguration.makeConfig__3$1x10$lang$String$2(((java.lang.String)("foo.txt")),
                                                                                                  (int)(1),
                                                                                                  (int)(10),
                                                                                                  ((x10.lang.Iterable)(t3041)),
                                                                                                  (int)(4))));
            
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int i3024min3063 =
              0;
            
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int i3024max3064 =
              3;
            
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
int i3060 =
              i3024min3063;
            
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
for (;
                                                                                                                                true;
                                                                                                                                ) {
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int t3061 =
                  i3060;
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final boolean t3062 =
                  ((t3061) <= (((int)(i3024max3064))));
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
if (!(t3062)) {
                    
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
break;
                }
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int p3057 =
                  i3060;
                
//#line 18 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final x10.array.Array<x10.array.Array<x10.core.Int>> t3055 =
                  ((x10.array.Array)(config.
                                       receiverss));
                
//#line 18 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final x10.array.Array<x10.core.Int> rec3056 =
                  ((x10.array.Array)(((x10.array.Array<x10.array.Array<x10.core.Int>>)t3055).$apply$G((int)(p3057))));
                
//#line 19 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert ((int) ((x10.array.Array<x10.core.Int>)rec3056).
                                                                                                                                               region.size$O()) ==
                ((int) 3);
                
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final x10.lang.Iterable<x10.core.Int> t3052 =
                  ((x10.lang.Iterable<x10.core.Int>)
                    ((x10.array.Array<x10.core.Int>)rec3056).values());
                
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final x10.lang.Iterator<x10.core.Int> q3053 =
                  ((x10.lang.Iterator<x10.core.Int>)
                    ((x10.lang.Iterable<x10.core.Int>)t3052).iterator());
                
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
for (;
                                                                                                                                    true;
                                                                                                                                    ) {
                    
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final boolean t3054 =
                      ((x10.lang.Iterator<x10.core.Int>)q3053).hasNext$O();
                    
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
if (!(t3054)) {
                        
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
break;
                    }
                    
//#line 20 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int q3051 =
                      x10.core.Int.$unbox(((x10.lang.Iterator<x10.core.Int>)q3053).next$G());
                    
//#line 21 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert ((q3051) >= (((int)(0)))) &&
                    ((q3051) < (((int)(4)))) &&
                    ((int) q3051) !=
                    ((int) p3057): (((((x10.core.Int.$box(q3051))) + (" should not be a receiver for place "))) + ((x10.core.Int.$box(p3057))));
                }
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int t3058 =
                  i3060;
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final int t3059 =
                  ((t3058) + (((int)(1))));
                
//#line 17 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
i3060 = t3059;
            }
            
//#line 23 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert config.isH$O((int)(0)): "Solver 0 should be an H.";
            
//#line 24 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert config.isH$O((int)(1)): "Solver 1 should be an H.";
            
//#line 25 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert !(config.isH$O((int)(2))): "Solver 2 should be an L.";
            
//#line 26 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert !(config.isH$O((int)(3))): "Solver 3 should be an L.";
            
//#line 28 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert (config.kind$O((int)(0))).equals("a"): (("Solver 0 is erroneously ") + (config.kind$O((int)(0))));
            
//#line 29 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert (config.kind$O((int)(1))).equals("b"): (("Solver 1 is erroneously ") + (config.kind$O((int)(1))));
            
//#line 30 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert (config.kind$O((int)(2))).equals("c"): (("Solver 2 is erroneously ") + (config.kind$O((int)(2))));
            
//#line 31 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
assert (config.kind$O((int)(3))).equals("d"): (("Solver 3 is erroneously ") + (config.kind$O((int)(3))));
        }
        
        
//#line 37 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
public static class $Main extends x10.runtime.impl.java.Runtime {
        private static final long serialVersionUID = 1L;
        public static void main(java.lang.String[] args)  {
        // start native runtime
        new $Main().start(args);
        }
        
        // called by native runtime inside main x10 thread
        public void runtimeCallback(final x10.array.Array<java.lang.String> args)  {
        // call the original app-main method
        ExplicitPPTests.main(args);
        }
        }
        
        // the original app-main method
        public static void main(final x10.array.Array<java.lang.String> id$0)  {
            
//#line 38 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
com.ibm.satx10.config.tests.ExplicitPPTests.test1();
        }
        
        
//#line 5 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
final public com.ibm.satx10.config.tests.ExplicitPPTests
                                                                                                                        com$ibm$satx10$config$tests$ExplicitPPTests$$com$ibm$satx10$config$tests$ExplicitPPTests$this(
                                                                                                                        ){
            
//#line 5 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
return com.ibm.satx10.config.tests.ExplicitPPTests.this;
        }
        
        
//#line 5 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"
// creation method for java code (1-phase java constructor)
        public ExplicitPPTests(){this((java.lang.System[]) null);
                                     $init();}
        
        // constructor for non-virtual call
        final public com.ibm.satx10.config.tests.ExplicitPPTests com$ibm$satx10$config$tests$ExplicitPPTests$$init$S() { {
                                                                                                                                
//#line 5 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"

                                                                                                                                
//#line 5 "/gsa/yktgsa-p4/07/x10/PolySat/SatX10_test_vj/src/com/ibm/satx10/config/tests/ExplicitPPTests.x10"

                                                                                                                            }
                                                                                                                            return this;
                                                                                                                            }
        
        // constructor
        public com.ibm.satx10.config.tests.ExplicitPPTests $init(){return com$ibm$satx10$config$tests$ExplicitPPTests$$init$S();}
        
        
    }
    