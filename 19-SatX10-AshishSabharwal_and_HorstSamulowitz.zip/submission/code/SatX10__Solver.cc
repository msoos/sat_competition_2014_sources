// -----------------------------------------------------------------
// Licensed Materials - Property of IBM
//
// SatX10
//
// (C) Copyright IBM Corporation 2012.  All Rights Reserved.
//
// Authors: Bard Bloom, David Grove, Benjamin Herta,
//          Vijay Sarawat, Ashish Sabharwal, Horst Samulowitz
// -----------------------------------------------------------------


#include "x10/lang/Rail.h"
#include "x10/lang/String.h"

#include "SatX10__Solver.h"
#include "utils.h"


void CallbackStats::printStats(const SolverSatX10Base * const solver) const {
    cout.setf(std::ios::fixed); cout.precision(2);  // set precision to 2 decimal digits

    cout << "c x10 hub level               : " << solver->x10_getHubLevel() << endl;
    cout << "c x10 maxlen pass through     : " << solver->x10_getMaxLenPassThrough() << " (applies only to Strong Hubs, level >= 2)" << endl;
    cout << "c x10 dupl detection long cls : " << (solver->x10_usingDuplDetectionLongCls() ? "ON" : "OFF") << endl;
    cout << "c x10 shared clause %         : "
            << 100.0 * (getNumOutgoingClauses() / (double) solver->x10_nConflicts());
    if (solver->x10_isSharingCutoffDynamic())
        cout << " [ target " << 100.0 * solver->x10_getRatioSharedToLearnt() << " ]";
    cout << endl;

    cout << "c x10 outgoing clauses        : " << numOutgoingClauses << " [ ";
    for (unsigned i=1; i<numOutgoingClausesPerLen.size(); i++)
        cout << numOutgoingClausesPerLen[i] << ' ';
    cout << ']' << endl;

    cout << "c x10 incoming clauses        : " << numIncomingClauses << " [ ";
    for (unsigned i=1; i<numIncomingClausesPerLen.size(); i++)
        cout << numIncomingClausesPerLen[i] << ' ';
    cout << ']' << endl;

    // NOTE: see the NOTE in x10_processOutgoingClauses() regarding incrementUsedMaxLength;
    //       what's printed below is only a rough estimate
    if (solver->x10_isSharingCutoffDynamic()) {
        cout << "c x10 maxLength changes[ROUGH]: " << numClauseLengthTotalUsed << " [ ";
        for (unsigned i=1; i<numOutgoingClauseLength.size(); i++)
            cout << (numOutgoingClauseLength[i] / (double)numClauseLengthTotalUsed) * 100 << "% ";
        cout << ']' << endl;
    }
    cout << "c x10 incoming with self ID   : " << numIncomingWithSelfInIDs << endl;
    cout << "c x10 incoming duplicates     : " << numIncomingDuplicates << endl;
    cout << "c x10 incoming passed thru    : " << numIncomingPassedThrough << endl;
}

char** SatX10__Solver::convertX10StringArrayToCStyleArgvWithOffset(x10::lang::Rail<x10::lang::String*>* arguments, const char * filename) {
	const int gotFilename = (filename != NULL ? 1 : 0);
    const int argc = arguments->FMGL(size) + 1 + gotFilename;
    char** argv = new char*[argc];
    argv[0] = new char[5];
    strcpy(argv[0], "dummy");
    for (int i=1; i<argc-gotFilename; i++) {
        // convert arguments[i-1] to argv[i] here
        argv[i] = new char[64];
        strcpy(argv[i], arguments->__apply(i-1)->c_str());
    }
    if (gotFilename == 1) {
        argv[argc-1] = new char[512];
    	strcpy(argv[argc-1], filename);
    }
    return argv;
}

// type 1: implement for base class SolverX10Callback:
//   process outgoing clauses: serialize all clauses in solver->outgoingClauses
//   for x10 and call the appropriate closure
void SatX10__Solver::x10_processOutgoingClauses(bool bProcessImmediately) {
    if (!bProcessImmediately && solver->x10_getNumOutgoingClauses() < solver->x10_getOutgoingClausesBufferSize())
        // no need to do anything; simply return
        return;

    // go through all clauses in the outgoing clauses vector and put them in a
    // SINGLE vector using the "serialize" method of ClauseWithInfo
    vector<int> allSerializedClausesWithInfo;
    for (unsigned i=0; i<solver->x10_getNumOutgoingClauses(); i++) {
        // if the clause is small enough so that it might be passed through by other
        // places, SORT it (in place) before sending it out so that receiving places
        // can do duplicate detection efficiently
        vector<int> & clause = solver->x10_getOutgoingClause(i).clause;
        assert(clause.size() > 0);
        if (clause.size() <= (unsigned) solver->x10_getMaxLenPassThrough() && clause.size() > 1)
            std::sort(clause.begin(), clause.end());

        // append the outgoing clause with info to allSerializedClausesWithInfo
        solver->x10_getOutgoingClause(i).serializeAndAppendTo(allSerializedClausesWithInfo);

        // update x10 callback statistics
        cb_stats.incrementOutgoing(clause.size());
    }
    // empty the outgoing clauses vector
    solver->x10_clearOutgoingClauses();

    // Keep track on how often what max length has been used
    // NOTE: length adjustment code was moved to SolverSatX10Base.h so that
    //       it can be triggered more often, even if the control doesn't
    //       reach this point (which could happen is the solver is not
    //       learning enough short clauses). Therefore, x10_getMaxLenSharedClauses()
    //       is NOT the right thing to store!  Technically, the stats below
    //       should also be moved to SolverSatX10Base.h !!!
    cb_stats.incrementUsedMaxLength(solver->x10_getMaxLenSharedClauses());

    // convert allSerializedClausesWithInfo to x10 Rail
    x10::lang::Rail<x10_int>* clauses_ = x10::lang::Rail<x10_int>::_make(allSerializedClausesWithInfo.size());
    for (unsigned i=0 ; i<allSerializedClausesWithInfo.size() ; i++) {
        //(*clause_)[i] = toInt(clause[i]); // original
        //(*clause_).__set(i, toInt(clause[i])); // valid?
        clauses_->raw[(x10_int)i] = allSerializedClausesWithInfo[i];
    }

    // apply the closure to the clauses with info
    // IMPORTANT NOTE: when passing control to X10 to execute the closure, X10 may
    // very well process incoming messages, including the kill() message and the
    // bufferIncomingClauses() message! Hence, best to call the closure at the end
    // here, when we are not actively handling incoming or outgoing buffers
    x10::lang::VoidFun_0_1<x10::lang::Rail<x10_int>* >::__apply(closure1, clauses_);
}

// type 2: print instance information
void SatX10__Solver::printInstanceInfo(void) const {
    if (solver == NULL) {
        printf("WARNING: instance information can be printed only after a Solver object has been created. \n");
        return;
    }
    printf("c Instance information:\n");
    printf("c   filename                  : %s\n", instanceName.c_str());
    printf("c   number of variables       : %d\n", solver->x10_nVars());
    printf("c   number of clauses         : %d\n", solver->x10_nClauses());
}

// type 2: print final result (solver statistics, sat/unsat, plus solution if requested)
void SatX10__Solver::printResults(const bool flag_printsoln) const {
    // print result and possibly the solution, if found and asked for
    switch (solveStatus) {
    case -1:
        printf("s UNSATISFIABLE\n");
        break;

    case 0:
        printf("s UNKNOWN\n");
        break;

    case 1:
        printf("s SATISFIABLE\n");
        if (flag_printsoln)
            printSolution();
        break;

    default:
        abort();
    }

    // print solver's native statistics along with x10 callback statistics
    printStats(true);

    // flush the output, just in case the process gets killed
    fflush(stdout);
}

// type 2: when an external clause (with IDs) arrives from another place, convert it to
//   ClauseWithInfo and buffer it to be processed later by the solver
void SatX10__Solver::bufferIncomingClauses(x10::lang::Rail<x10_int>* clauses_) {
    // de-serialize: first convert from x10 array to vector<int>
    vector<int> allSerializedClausesWithInfo(clauses_->FMGL(size));
    //for (x10_int i=0 ; i<clause_->length() ; ++i) {
    for (x10_int i=0 ; i<clauses_->FMGL(size); i++) {
        //clause.push(toLit((*clause_)[i]));
        allSerializedClausesWithInfo[(unsigned)i] = clauses_->raw[i];
    }

    // a hash map to be used for duplicate detection in a subset of received clauses; maps a
    // a string representation of a clause to its position in the outgoing clauses buffer vector
    hashMapStrInt_t clausesHashMap;
    // a similar but simpler hash map for unit clauses
    hash_map<int,int> unitClausesHashMap;

    // push each clause and respective IDs on to the incoming clauses vector of the solver
    ClauseWithInfo clauseWithInfo;
    unsigned i = 0;
    while (i < allSerializedClausesWithInfo.size()) {
        const bool discardClause = clauseWithInfo.createFromSerializedObject(allSerializedClausesWithInfo,
                                                                             i,
                                                                             solver->x10_getPlaceID(),
                                                                             (solver->x10_getHubLevel() == 0));

        if (discardClause) {
            // nothing to be done
            cb_stats.incrementIncomingWithSelfInIDs();
            continue;
        }

        // push clause with info into solver's incoming buffer
        solver->x10_bufferIncomingClause(clauseWithInfo);
        // update x10 callback statistics
        cb_stats.incrementIncoming(clauseWithInfo.clause.size());

        // if this is a Hub solver and the clause is small enough,
        // buffer it for passing through
        if (solver->x10_getHubLevel() > 0 && clauseWithInfo.clause.size() <= (unsigned) solver->x10_getMaxLenPassThrough()) {
            // if it is a unit clause, do duplicate detection and pass it through
            if (clauseWithInfo.clause.size() == 1) {
                // always perform Duplicate Detection for unit clauses
                hash_map<int,int>::iterator itr = unitClausesHashMap.find(clauseWithInfo.clause[0]);
                if (itr == unitClausesHashMap.end()) {
                    // encountered this clauses for the first time; push it onto outgoing buffer
                    const int pos = solver->x10_bufferOutgoingClause(clauseWithInfo);
                    cb_stats.incrementIncomingPassedThrough();
                    // also insert it into the hash map, along with 'pos'
                    const pair<int,int> tmp(clauseWithInfo.clause[0], pos);
                    unitClausesHashMap.insert(tmp);
                }
                else {
                    // clause already exists in the hash map; append place IDs of this instance
                    // of the clause to the IDs list of the one already in the outgoing buffer
                    const int           prevPos = itr->second;
                    vector<int> &       prevIDs = solver->x10_getOutgoingClause(prevPos).placeIDs;
                    const vector<int> & newIDs = clauseWithInfo.placeIDs;
                    if (newIDs.size() > 0)
                        prevIDs.insert(prevIDs.end(), newIDs.begin(), newIDs.end());
                    cb_stats.incrementIncomingDuplicates();
                }
                continue;
            }

            // otherwise, continue only if this is a "strong" Hub (i.e., hubLevel >= 2)
            if (solver->x10_getHubLevel() < 2)
                continue;

            // if not using duplicate detection for long clauses, simple add the clause to outgoing buffer
            if (solver->x10_usingDuplDetectionLongCls() == false) {
                solver->x10_bufferOutgoingClause(clauseWithInfo);
                cb_stats.incrementIncomingPassedThrough();
                continue;
            }

            // Perform Duplicate Detection using hash map;
            // note that the incoming clause is expected to be already sorted,
            // which should allow detection of more duplicates
            const string clauseHash(intVectorToString(clauseWithInfo.clause));
            hashMapStrInt_t::iterator itr = clausesHashMap.find(clauseHash);
            if (itr == clausesHashMap.end()) {
                // encountered this clauses for the first time; push it onto outgoing buffer
                const int pos = solver->x10_bufferOutgoingClause(clauseWithInfo);
                cb_stats.incrementIncomingPassedThrough();
                // also insert it into the hash map, along with 'pos'
                const pair<string,int> tmp(clauseHash, pos);
                clausesHashMap.insert(tmp);
            }
            else {
                // clause already exists in the hash map; append place IDs of this instance
                // of the clause to the IDs list of the one already in the outgoing buffer
                const int          prevPos = itr->second;
                vector<int> &      prevIDs = solver->x10_getOutgoingClause(prevPos).placeIDs;
                const vector<int> & newIDs = clauseWithInfo.placeIDs;
                if (newIDs.size() > 0)
                    prevIDs.insert(prevIDs.end(), newIDs.begin(), newIDs.end());
                cb_stats.incrementIncomingDuplicates();
            }
        }
    }
}

RTT_CC_DECLS0(SatX10__Solver, "SatX10.Solver", x10aux::RuntimeType::class_kind)
