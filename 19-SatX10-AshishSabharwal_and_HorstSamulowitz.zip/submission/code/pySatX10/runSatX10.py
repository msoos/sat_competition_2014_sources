#!/usr/bin/env python

##  -----------------------------------------------------------------
##  Licensed Materials - Property of IBM
##  
##  A script to launch SatX10 after applying a preprocessor to the
##  given instance and translating the solution back
##  
##  (C) Copyright IBM Corporation 2013.  All Rights Reserved.
##  
##  US Government Users Restricted Rights -  Use, duplication or
##  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
##  
##  Authors:  Ashish Sabharwal, Horst Samulowitz
##  
##  This program and its associated documentation files ('Software')
##  are provided 'as is', without warranty of any kind, express or
##  implied, including but not limited to the warranties of
##  merchantability or fitness for a particular purpose. In no
##  event shall the authors or copyright holders be liable for any
##  claim, damages, or other liability, whether in an action of
##  contract, tort, or otherwise, arising from, out of, or in
##  connection with the use of the Software.
##  -----------------------------------------------------------------


#############################################################################
## A script to launch SatX10 after applying a preprocessor to the          ##
## given instance and translating the solution back                        ##
##                                                                         ##
##   version 1.0, April 2013:                                              ##
##         uses a variable name preserving version of SatELite             ##
##         supports solution verification                                  ##
##                                                                         ##
#############################################################################


# name of the program
__mymodulename__      = 'runSatX10.py'
# version number
__version__           = '1.0'


import sys
import os
import shutil
import shlex
import getopt
import time
import socket
import signal
import subprocess
#import pdb     ## the debugger; use pdb.set_trace() to start tracing for interactive python


# get program usage
def getUsage():
  program_name = os.path.basename(sys.argv[0])

  usage  = '\nUSAGE: ' + program_name + ' OPTIONS filename.cnf'
  usage += '\n'
  usage += '\nOPTIONS:'
  usage += '\n    --hardtimelimit        LIMIT             : optional *hard* time limit for the whole process'
  usage += '\n    -s,--seed              RANDOMSEED        : random seed; default = 87360941'
  usage += '\n    -d,--tmpdir            TMPDIR            : folder to use for creating temporary files (default = WORKING-DIR)'
  usage += '\n    --nosolution                             : do not print solution even if satisfiable (default = print solution)'
  usage += '\n    --noverify                               : do not verify solution when one is found (default = verify solution)'
  usage += '\n    --basefolder           BASEDIR           : base folder where solvers, data, etc., are located (default = location of this script)'
  usage += '\n    --debug                                  : turns on debug mode, forcing verbosity=1, nofilecleanup=True'
  usage += '\n    --nofilecleanup                          : leave temporary files in TMPDIR for debugging purposes (default = off)'
  usage += '\n    --checkall             NUM               : ensure required executables are present with proper permission, 0: no check, 1: check (default), 2: check and exit'
  usage += '\n    -v,--verbosity         NUM               : control verbosity level [0..2] (default = 0)'

  usage += '\n    -h,--help                                : print this help text and exit'
  usage += '\n'
  usage += '\n    --x10usepre                              : SatX10: use preprocessing when calling SatX10 (default = False)'
  usage += '\n    --x10nplaces                             : SatX10: how many places/solvers to launch (default = False)'
  usage += '\n    --x10ppconfig                            : SatX10: ppconfig file to use'
  usage += '\n    --x10maxlen                              : SatX10: maxlength of clauses to share (default = -10)'
  usage += '\n    --x10outbuf                              : SatX10: outgoing clause buffer size (default = 100)'

  # return the constructed usage
  return usage


# set global constants here
# class containing command line parameters
class CParamsCommandline:
  def __init__(self):
    # set defaults here
    self.filename_orig             = ''     # name of the original CNF file
    self.hardtimelimit             = -1     # default value, meaning no enforced limit for the whole process
    self.seed                      = '87360941'
    self.tmpdir                    = 'WORKING-DIR'
    self.nosolution                = False
    self.noverify                  = False
    self.default_solver_id         = 1      # to be used, e.g., to convert partial solution to full solution, or as a fallback solver
    self.default_solver_name       = ''     # will be filled in after initializing all solver objects
    self.basefolder                = ''     # optional name of a different folder in which solvers, data, etc., are present (useful for slow NFS mounts!)    
    self.debugmode                 = False
    self.nofilecleanup             = False
    self.checkall                  = 1
    self.verbosity                 = 0
    self.x10usepre                 = False
    self.x10nplaces                = 1
    self.x10ppconfig               = ''
    self.x10maxlen                 = -10
    self.x10outbuf                 = 100
    base_folder_name = os.path.dirname(sys.argv[0])
    if base_folder_name != '' and base_folder_name != '.':
      self.basefolder = base_folder_name + '/'

  def printParams(self):
    print 'c Commandline parameters:'
    print 'c    filename_orig                          ' + self.filename_orig
    print 'c    hardtimelimit                          ' + str(self.hardtimelimit)
    print 'c    seed                                   ' + str(self.seed)
    print 'c    tmpdir                                 ' + self.tmpdir
    print 'c    nosolution                             ' + str(self.nosolution)
    print 'c    noverify                               ' + str(self.noverify)
    print 'c    default_solver_id                      ' + str(self.default_solver_id)
    print 'c    default_solver_name                    ' + self.default_solver_name
    print 'c    basefolder                             ' + self.basefolder
    print 'c    debugmode                              ' + str(self.debugmode)
    print 'c    nofilecleanup                          ' + str(self.nofilecleanup)
    print 'c    checkall                               ' + str(self.checkall)
    print 'c    verbosity                              ' + str(self.verbosity)
    print 'c    x10usepre                              ' + str(self.x10usepre)
    print 'c    x10nplaces                             ' + str(self.x10nplaces)
    print 'c    x10ppconfig                            ' + str(self.x10ppconfig)
    print 'c    x10maxlen                              ' + str(self.x10maxlen)
    print 'c    x10outbuf                              ' + str(self.x10outbuf)


# timelimits related parameters that are not specified on the commandline
class CParamsTimelimits:
  def __init__(self):
    self.prog_preprocessor_timelimit     = 100   # spend at most so many seconds on preprocessing

  def printParams(self):
    print 'c Other, timing related parameters:'
    print 'c    prog_preprocessor_timelimit            ' + str(self.prog_preprocessor_timelimit)


# miscelleneous parameters not specified on the commandline
class CParamsMisc:
  def __init__(self):
    self.filename_pre                       = ''  # preprocessed CNF file
    self.filename_extended                  = ''  # cnf file (orig or pre, as appropriate) extended with unit lits for a partial soln
    self.elimedvars_pre                     = []  # list of vars eliminated by preprocessor, i.e., missing from filename_pre


# all parameters; class extends CParamsCommandline, CParamsTimelimit, and CParamsMisc
class CParams(CParamsCommandline, CParamsTimelimits, CParamsMisc):
  def __init__(self):
    # first call constructors of the base classes
    CParamsCommandline.__init__(self)
    CParamsTimelimits.__init__(self)
    CParamsMisc.__init__(self)

    # PID of the current process, to be used in the names of temporary
    # files in order to avoid confusion if this script is called
    # concurrently on the same CNF file
    self.PIDsuffix              = socket.gethostname() + '-' + str(os.getpid())
    self.solution_line_len      = 20     # how many variables to print per line when printing solution
    # name of solver to use for converting partial solution to full. Note that
    # this solver must not omit variables from the solution even if they do
    # not appear in the CNF file but are within the numvars limit in the
    # 'p cnf ...' header line. E.g., cannot use ebminisat, glucose, lingeling,
    # LySATi, minisat20SAT07, and satelite, as they exclude all vars after the
    # highest numbered var that actually appears in constraints; also, cannot
    # use march_dl2004, march_hi, march_nn, and tts-4-0, as they do not print
    # values of any missing vars. "precosat" seems safe and fast -- using that
    # for now.
    self.extend_partial_soln_solver_name = 'glucose'
    self.extend_partial_soln_solver_id   = -1  # to be set after reading solvers list


  def printParams(self):
    # first print command line parameters
    CParamsCommandline.printParams(self)
    # now print the rest
    print 'c Other parameters:'
    print 'c    PID suffix                             ' + self.PIDsuffix
    print 'c    solution_line_len                      ' + str(self.solution_line_len)
    print 'c    partial soln extended with solver id   ' + str(self.extend_partial_soln_solver_id)
    print 'c    partial soln extended with solver name ' + str(self.extend_partial_soln_solver_name)
    # now print other, timing related parameters
    CParamsTimelimits.printParams(self)
    # now print other, misc parameters
    #CParamsMisc.printParams(self)


class CSolver:
  def __init__(self, name, progname, pre_params, post_params, nthreads=1, on_preprocessed_cnf=False, is_randomized=False, env_vars={}):
    self.name                    = name.strip()
    self.progname                = progname.strip()
    self.pre_instance_params     = pre_params.strip()
    self.post_instance_params    = post_params.strip()
    self.nthreads                = nthreads                # how many parallel threads does this solver use?
    self.on_preprocessed_cnf     = on_preprocessed_cnf     # whether it should be run on preprocessed CNF
    self.is_randomized           = is_randomized           # whether the solver is randomized
    self.env_vars                = env_vars                # any environment variables the solver expects
    self.env_vars.update(os.environ)

  # create solver object from a sample commandline
  @classmethod
  def createFromSampleCommandline(cls, name, sample_commandline, nthreads=1, on_preprocessed_cnf=False, instance_name='INSTANCE.CNF', seed='SEEDVALUE', threads='THREADS'):
    is_randomized = False
    if str(seed) in sample_commandline:     # check whether seed value is used in the sample commandline
      is_randomized = True
      sample_commandline = sample_commandline.replace(seed, params.seed)   # replace with params.seed
    initialPart, dummy, post_params = sample_commandline.partition(instance_name)   # split at instance name
    if dummy == '':
      print 'c ERROR: solver object could not be created for the following sample commandline; ignoring it'
      print 'c ' + sample_commandline
      cleanUpAndExit(1)
    progname, dummy, pre_params = initialPart.partition(' ') # further split the initial part by space
    return cls(name, progname, pre_params, post_params, nthreads, on_preprocessed_cnf, is_randomized)

  def getCommandline(self, cnf_filename):
    global params
    command = params.basefolder + self.progname + ' ' + self.pre_instance_params + ' ' + cnf_filename + ' ' + self.post_instance_params
    return command

  def getSampleCommandline(self):
    return self.getCommandline('INSTANCE.CNF', 0).replace(params.seed, 'SEEDVALUE')


# SatX10 solver class; extends regular solver
class CSatX10Solver(CSolver):
  def __init__(self, name, progname, ppconfig, nplaces=1, on_preprocessed_cnf=False, max_len_shared_clauses=-10, outgoing_buffer_size=100):
    x10_env     = {'X10_NTHREADS':'1', 'X10_STATIC_THREADS':'true', 'X10_NPLACES':str(nplaces)}
    pre_params  = ppconfig + ' ' + str(max_len_shared_clauses) + ' ' + str(outgoing_buffer_size)
    post_params = '1'
    # first call constructor of the base class
    CSolver.__init__(self, name, progname, pre_params, post_params, 1, on_preprocessed_cnf, False, x10_env)
    # initialize own data members
    self.ppconfig                = ppconfig
    self.nplaces                 = nplaces
    self.max_len_shared_clauses  = max_len_shared_clauses
    self.outgoing_buffer_size    = outgoing_buffer_size


# a class to define the preprocessor
class CPreprocessor:
  def __init__(self):
    self.progname                     = './SatELite_2005_nomap'
    self.pre_instance_params          = '+pre --verbosity=0'
    self.pre_instance_params_unitprop = '+pre --verbosity=0 -cs1 -s0 -s1'   # unit propagation only

  def getCommandline(self, filename_input, filename_output):
    global params
    return params.basefolder + self.progname + ' ' + self.pre_instance_params + ' ' + filename_input + ' ' + filename_output

  def getCommandlineUnitPropOnly(self, filename_input, filename_output):
    global params
    return params.basefolder + self.progname + ' ' + self.pre_instance_params_unitprop + ' ' + filename_input + ' ' + filename_output
    

# a class to define the program for running commands with a
# wall clock based time limit (enforced with GNU timerun, part
# of GNU coreutils package)
class CTimerun:
  def __init__(self):
    self.progname = 'timeout'

  def getCommandline(self, t, command):
    global params
    return self.progname + ' ' + str(t) + ' ' + command


# a class to store various statistics
class CStats:
  def __init__(self):
    self.numSolversCalled             = 0
    self.successfulSolverID           = -1
    self.successfulSolverName         = ''
    self.runtimes                     = {}
    self.runtimes['AllSolvers']       = 0.0
    self.runtimes['Preprocessor']     = 0.0
    self.runtimes['SolnExtension']    = 0.0
    self.runtimes['SolnVerification'] = 0.0
    self.runtimes['SolnPrinting']     = 0.0
    self.runtimes['Misc']             = 0.0
    
  def printStats(self):
    global timer
    runtime_total = timer.getTotalElapsedTime()
    
    # runtimes['Misc']: in addition to what's in it, take total
    # time and subtract away all categorized runtimes
    t_misc = runtime_total
    for (category, t) in self.runtimes.items():
      if category != 'Misc':
        t_misc -= t
    self.runtimes['Misc'] = t_misc
    
    print 'c '
    print 'c ' + __mymodulename__ + ' ' + __version__ + ' statistics:'
    print 'c    Number of Solvers Called     ' + str(self.numSolversCalled).rjust(10)
    print 'c    Successful Solver ID         ' + str(self.successfulSolverID).rjust(10)
    print 'c    Successful Solver Name       ' + '         ' + self.successfulSolverName
    print 'c    TOTAL RUNTIME                ' + ' {0:.2f} sec'.format(runtime_total).rjust(17)
    print 'c      AllSolvers                 ' + self.getRuntimeStr('AllSolvers')
    print 'c      Preprocessor               ' + self.getRuntimeStr('Preprocessor')
    print 'c      Solution Extension         ' + self.getRuntimeStr('SolnExtension')
    print 'c      Solution Verification      ' + self.getRuntimeStr('SolnVerification')
    print 'c      Solution Printing          ' + self.getRuntimeStr('SolnPrinting')
    print 'c      Misc                       ' + self.getRuntimeStr('Misc')
    
  def getRuntimeStr(self, category):
    return '{0:.2f} sec'.format(self.runtimes[category]).rjust(17)


# a class to store a timer object (wall clock timer)
class CTimer:
  def __init__(self):
    print 'c'
    print 'c Starting *WALL CLOCK* TIMER'
    print 'c'
    self.start              = time.time()
    self.last_reset         = self.start
    
  def reset(self):
    self.last_reset         = time.time()

  def get(self, printTimer, resetTimer):
    time_current            = time.time()
    time_since_start        = time_current - self.start
    time_since_last_reset   = time_current - self.last_reset
    if printTimer:
      print 'c TIMER: {0:.2f} sec total, {1:.2f} sec since last reset'.format(time_since_start, time_since_last_reset)
      print 'c'
      sys.stdout.flush()
    if resetTimer:
      self.last_reset = time_current
    return time_since_start, time_since_last_reset

  def getTimeSinceLastResetAndPrint(self):
    return self.get(True, True)[1]

  def getTotalElapsedTime(self):
    return time.time() - self.start

  def getRemainingTime(self):
    global params
    remaining_time = params.hardtimelimit - int(time.time() - self.start)
    if remaining_time > 0:
      return remaining_time
    else:
      return 0



##########################
##### GLOBAL OBJECTS #####
##########################

params             = CParams()             # various parameters
solvers            = []                    # a list of CSolver objects
preprocessor       = CPreprocessor()       # an object for the SAT preprocessor
timerun            = CTimerun()            # an object for the 'timerun' utility
stats              = CStats()              # an object to keep track of solver statistics
timer              = CTimer()              # an object to keep track of WALL clock time
childPID           = -1                    # PID of active child, if there is one, spawned by Popen()



###################################
## main routine
###################################
def main():
  global params, solvers, preprocessor, timerun, stats, timer

  # set SIGTERM to be handled by my routine which will also kill
  # subprocesses spawned by Popen
  signal.signal(signal.SIGTERM, sigterm_handler)
  
  # START TRACING FOR DEBUGGER
  #pdb.set_trace()

  # print command line
  print 'c COMMAND LINE: ' + reduce(lambda x, y: x + ' ' + y, sys.argv)
  print 'c '
  
  # parse command-line
  parseCommandLine()     # populates the global params object based on command line parameters

  # Look at number of variables and clauses
  num_clauses = 0
  num_vars    = 0
  cnf_stream = open(params.filename_orig, 'r')     # open file in read-write mode
  # note: must use readline() here for tell() and seek() to work properly,
  # rather than 'for line in cnf_stream:' which can internally read big
  # blocks at a time
  line = cnf_stream.readline()
  while line:
    if line.startswith('p cnf '):
      line = line.rstrip()      
      words = line.split()
      num_vars = int(words[2])
      num_clauses = int(words[3])      
      break
    line = cnf_stream.readline()
  # Close file
  cnf_stream.close()
  print "c Original Number of Clauses: " + str(num_clauses)
  print "c Original Number of Variables: " + str(num_vars)
  
  if num_clauses >= 6500000 and num_clauses < 10000000:
    # Reducing number of places if too many clauses exist
    params.x10nplaces = 5
    print "c Reducing number of places to: " + str(params.x10nplaces)
  elif num_clauses >= 10000000 and num_clauses < 20000000:
    # Reducing number of places if too many clauses exist
    params.x10nplaces = 2
    print "c Reducing number of places to: " + str(params.x10nplaces)
  elif num_clauses >= 20000000:
    # Reducing number of places if too many clauses exist
    params.x10nplaces = 1
    print "c Reducing number of places to: " + str(params.x10nplaces)
  
  # create objects for all solvers
  solvers.append( CSatX10Solver('GlucoseX10', './SatX10', params.x10ppconfig, params.x10nplaces, params.x10usepre, params.x10maxlen, params.x10outbuf) )
  solvers.append( CSolver.createFromSampleCommandline('glucose', './glucose_static INSTANCE.CNF', 1, False) )

  # set name of default solver and ID of solver to use for extending partial solution to full
  if params.default_solver_id in range(len(solvers)):
    params.default_solver_name = solvers[params.default_solver_id].name
  else:
    if params.default_solver_id >= len(solvers):
      print 'c WARNING: default solver ID ' + str(params.default_solver_id) + ' not present in solver list. Using None.'
    params.default_solver_id   = -1
    params.default_solver_name = 'None'
    
  # set ID of the solver to use for extending partial solution to full
  i = 0
  while i < len(solvers):
    if solvers[i].name == params.extend_partial_soln_solver_name and solvers[i].on_preprocessed_cnf == False:
      params.extend_partial_soln_solver_id = i
      break
    i += 1
  if i == len(solvers):
    print 'c ERROR: solver ' + params.extend_partial_soln_solver_name + ' to be used for extending partial solution'
    print 'c        to full not found in the list of available solvers that do not rely on preprocessed CNF. Aborting.'
    cleanUpAndExit(1)
  
  # print various parameters, including commandline parameters
  params.printParams()
  print 'c'
  print 'c Parsed command line and set default values'

  #for solver in solvers:
  #  print solver.getCommandline('test.cnf')

  if not os.path.exists(params.tmpdir):
    os.system('mkdir -p ' + params.tmpdir)

  # check to make sure all necessary executables and folders are present
  if params.checkall > 0:
    success = checkAllFilesFoldersAreAvailable()
    if not success:
      cleanUpAndExit(1)
    timer.reset()
    if params.checkall >= 2:
      # exit now
      cleanUpAndExit(0)

  
  
  # initialize various solver execution related items
  preprocessor_used  = params.x10usepre
  solver_schedule    = []
  solver_schedule.append( (0, -1) )    # add satx10 solver without a timelimit
  
  # declare the solver(s) to be used, with or without preprocessing
  if preprocessor_used:
    print 'c Preprocessing ON (for solvers that want to use it)'
  else:
    print 'c Preprocessing OFF'
  print 'c '
  print 'c Solvers and corresponding runtimes to be used, and whether on the preprocessed instance:'
  print 'c solver_id', '\t', 'solver_name'.ljust(15), '\t', 'runtime'.rjust(15), '\t', 'pre+'
  for (solver_id, runtime) in solver_schedule:
    if runtime < 0:
      runtime = 'no limit'
    print 'c   ', str(solver_id).rjust(3), '\t', solvers[solver_id].name.ljust(15), '\t', str(runtime).rjust(15), '\t', solvers[solver_id].on_preprocessed_cnf

  # append default solver to the schedule, without a time limit;
  # default solver should not rely on preprocessing the instance
  if params.default_solver_id != -1:
    assert solvers[params.default_solver_id].on_preprocessed_cnf == False
    solver_schedule.append( (params.default_solver_id, -1) )
    solver_schedule.append( (params.default_solver_id, -1) )
    print 'c Default solver to fall back on, in case everything fails:'
    print 'c   ', str(params.default_solver_id).rjust(3), '\t', params.default_solver_name.ljust(15), '\t', 'no limit'.rjust(15), '\t', False
    print 'c'

  # Run the suggested SAT solvers and hope for the best!

  # Flag indicating whether the preprocessed file has already been generated
  # (generated only on a need basis, when a solver actually wants to use a
  #  preprocessed file for the first time)
  preprocessed_file_already_generated = False

  # Make sure auxiliary files do not exist from previous runs
  deleteFileSafely(params.filename_pre)

  # Initialize flag to indicate whether the solution process was successful
  success = False
  # Initialize flag to indicate whether the preprocessor (SatELite) has failed or not
  satelite_failed = False
  # Loop over the solver schedule and launch solvers
  solver_number = 0
  is_last_or_default_solver = False
  for (solver_id, runtime) in solver_schedule:
    usepre = solvers[solver_id].on_preprocessed_cnf
    # Make sure that we don't use a positive preprocessing flag if Satelite has previously failed
    if satelite_failed:
      usepre = False
    # keep track of whether this is the last solver in the schedule
    # or the default solver that was appended manually to the schedule
    solver_number += 1
    if (solver_number >= len(solver_schedule) - 1):
      is_last_or_default_solver = True
    # If preprocessing flag is set to true, call Satelite
    if usepre and not preprocessed_file_already_generated:
      # call SatELite to preprocess the instance
      return_code = runPreprocessor(params.filename_orig, params.filename_pre, params.elimedvars_pre)
      # If the return code is not equal to 0, Satelite has failed
      if return_code != 0:
        # Turn off pre-processing flag
        usepre = False
        # Never call Satelite again on this instance
        satelite_failed = True
      else:
        # Remember that we have successfully created the preprocessed file
        preprocessed_file_already_generated = True

    # Check if --hardtimelimit is defined and adjust runtime as needed
    if (params.hardtimelimit != -1):  # hard time limit was specified as a command-line argument
      remaining_time = timer.getRemainingTime()
      assert remaining_time >= 0
      if remaining_time == 0:
        print 'c Out of time. Aborting'
        print 's UNKNOWN'
        stats.printStats()
        cleanUpAndExit(2)
      if (runtime < 0 or remaining_time < runtime):
        print 'c Specified hardtimelimit = ' + str(params.hardtimelimit)
        print 'c Remaining time = ' + str(remaining_time)
        runtime = remaining_time
        print 'c Enforcing time limit for the solver to be ' + str(remaining_time)

    # set name of file to solve
    if usepre:
      filename_to_solve = params.filename_pre
    else:
      filename_to_solve = params.filename_orig

    # If no time limit is specified (i.e., -1), execute solver without any time limit
    if runtime == -1:
      print 'c Running ' + solvers[solver_id].name + ' WITHOUT TIME LIMIT on ' + filename_to_solve
      command = solvers[solver_id].getCommandline(filename_to_solve)
    # otherwise, execute solver with given time limit
    else:
      print 'c Running ' + solvers[solver_id].name + ' for ' + str(runtime) + ' seconds on ' + filename_to_solve
      command = timerun.getCommandline(runtime*solvers[solver_id].nthreads, solvers[solver_id].getCommandline(filename_to_solve))
    if solvers[solver_id].env_vars:
      print 'c    ' + str(solvers[solver_id].env_vars)
    print 'c    ' + command

    # Execute solver command
    success = runSolver(command, solver_id, filename_to_solve)

    # If the solver solved the instance, break out of the schedule loop 
    if success:
      break
    
  if not success:
    # We should never get here, as the default solver was supposed to
    # be run without a timeout... well, unless it crashed or hit hard timelimit
    if (params.hardtimelimit != -1):
      print 'c No solver, including the default solver ' + params.default_solver_name + ', could find a solution in hardtimelimit ' + str(params.hardtimelimit) + ' sec'
    else:
      print 'c No solver, including the default solver ' + params.default_solver_name + ' without timelimit, could find a solution'
    print 's UNKNOWN'
    stats.printStats()
    cleanUpAndExit(2)

  # successful! print final stats and exit
  stats.printStats()
  cleanUpAndExit(0)



################################
##  parse command line arguments and put results in the global
##  variable params of type CParams
################################
def parseCommandLine():
  global params

  try:
    opts, args = getopt.getopt(sys.argv[1:], 'd:hs:v:', ['checkall=', 'tmpdir=', 'help', 'hardtimelimit=', 'seed=', 'nosolution', 'noverify', 'nofilecleanup', 'basefolder=', 'verbosity=', 'x10usepre', 'x10nplaces=', 'x10ppconfig=', 'x10maxlen=', 'x10outbuf='])
  except getopt.GetoptError, err:
    print str(err)
    print getUsage()
    cleanUpAndExit(1)

  for option, value in opts:
    if option in ('--checkall'):
      params.checkall = int(value)
    elif option in ('-d', '--tmpdir'):
      params.tmpdir = value
    elif option in ('-h', '--help'):
      print getUsage()
      cleanUpAndExit(0)
    elif option in ('--hardtimelimit'):
      params.hardtimelimit = int(value)
      if params.hardtimelimit <= 0:
        print 'c ERROR: hardtimelimit must be a positive integer'
        cleanUpAndExit(1)
    elif option in ('-s', '--seed'):
      params.seed = value
    elif option in ('--nosolution'):
      params.nosolution = True
    elif option in ('--noverify'):
      params.noverify = True
    elif option in ('--nofilecleanup'):
      params.nofilecleanup = True
    elif option in ('--basefolder'):
      params.basefolder = value
      if value[-1] != '/':
        params.basefolder += '/'
    elif option in ('--debug'):
      params.debugmode = True
    elif option in ('-v', '--verbosity'):
      params.verbosity = int(value)
    elif option in ('--x10usepre'):
      params.x10usepre = True
    elif option in ('--x10nplaces'):
      params.x10nplaces = int(value)
    elif option in ('--x10ppconfig'):
      params.x10ppconfig = value
    elif option in ('--x10maxlen'):
      params.x10maxlen = int(value)
    elif option in ('--x10outbuf'):
      params.x10outbuf = int(value)
    else:
      print 'c ERROR: unrecognized option'
      print getUsage()
      cleanUpAndExit(1)

  if params.checkall >= 2:
    # simply return; will do the check after creating solver
    # objects and exit
    return

  if params.debugmode:
    # if running in debug mode, force verbosity to at least 1 and nofilecleanup to True
    if params.verbosity < 1:
      params.verbosity = 1
    params.nofilecleanup = True
    
  if len(args) != 1:
    print getUsage()
    cleanUpAndExit(1)
  elif params.x10ppconfig == '':
    print 'ERROR: option x10ppconfig must be specified'
    cleanUpAndExit(1)
  else:
    # set name of the original CNF file
    params.filename_orig = args[0]
    if not os.path.isfile(params.filename_orig):
      print 'c ERROR: cannot open CNF file ' + params.filename_orig
      print getUsage()
      cleanUpAndExit(1)

  # set names to be used for preprocessed CNF file, etc.
  params.filename_pre                 = createTmpFilename(os.path.basename(params.filename_orig), '.pre')
  params.filename_extended            = createTmpFilename(os.path.basename(params.filename_orig), '.extended')


#############################################
## check to make sure all necessary files
## and folders are present!
#############################################
def checkAllFilesFoldersAreAvailable():
  global params, solvers, features_generator, preprocessor, timerun

  success = True

  print 'c Making sure all necessary files and folders are present...'
  #all_progs = [timerun.progname, preprocessor.progname]
  all_progs = [preprocessor.progname]
  all_progs.extend([solver.progname for solver in solvers])
  # use a little hack to get unique elements -- convert to set then back to list
  all_progs = list(set(all_progs))
  for prog in sorted(all_progs, key=str.lower):
    prog = params.basefolder + prog
    sys.stdout.write(('c   Checking for ' + prog + ' ').ljust(80))
    foundProg = True
    if prog == 'java':
      try:
        proc = myPopenNoPipe('java -version')
      except:
        foundProg = False
    else:
      foundProg = (os.path.isfile(prog) and os.access(prog, os.X_OK))
    if foundProg:
      print ' OK'
    else:
      print ' NOT EXECUTABLE'
      success = False

  if not success:
    print 'c Check failed. Please make sure all necessary files are available.'
  else:
    print 'c Check successful'
    
  return success


#####################################################################
# Run the default solver, if set, and exit
#####################################################################
def runDefaultSolverAndExit(filename):
  global params, stats, solvers, timer
  
  success = False
  # if a default solver has been set, run it
  if params.default_solver_id != -1:
    if (params.hardtimelimit == -1):
      print 'c Calling default solver with no time limit!'
      command = solvers[params.default_solver_id].getCommandline(filename)
    else:
      remaining_time = timer.getRemainingTime()
      if remaining_time > 0:
        print 'c Calling default solver with timelimit', remaining_time
        command = timerun.getCommandline(remaining_time*solvers[params.default_solver_id].nthreads, solvers[params.default_solver_id].getCommandline(filename))
      else:
        assert remaining_time == 0
        print 'c Out of time. Aborting'
        print 's UNKNOWN'
        stats.printStats()
        cleanUpAndExit(2)
    if solvers[default_solver_id].env_vars:
      print 'c    ' + str(solvers[default_solver_id].env_vars)
    print 'c    ' + command
    # Turn off pre-processing and simply call the default solver on the instance
    success, dummy1, dummy2 = runSolver(command, params.default_solver_id, False, filename)
  
  # Should never get here!
  if not success:
    print 's UNKNOWN'
    stats.printStats()
    cleanUpAndExit(2)
  
  # Exit and don't continue with the script
  stats.printStats()
  cleanUpAndExit(0)


#####################################################################
# Run preprocessor and store eliminated variables in a list
#####################################################################
def runPreprocessor(file_input, file_output, elimed_vars):
  global params, stats, timerun, timer, childPID

  print 'c <<<< Running SatELite (without variable mapping) for ' + str(params.prog_preprocessor_timelimit) + ' sec to preprocess instance >>>>' 
  command = timerun.getCommandline(params.prog_preprocessor_timelimit, preprocessor.getCommandline(file_input, file_output))
  print 'c    ' + command

  # Execute Satelite, parse list of eliminated variables, and get return code
  proc = myPopenPipeStdout(command)
  childPID = proc.pid    # store PID of child
  new_elimed_vars = []
  for line in proc.stdout:
    if line.startswith('c SatELite eliminated variable '):
      words = line.split()
      new_elimed_vars.append(int(words[4]))
  proc.wait()   # make sure proc has terminated before proceeding
  childPID = -1          # clear PID of child
  return_code = proc.returncode
  if return_code != 0:
    print 'c    SatELite failed (Return code ' + str(return_code) + '). TURNING OFF preprocessing for all solvers.'
  else:
    print 'c    SatELite eliminated ' + str(len(new_elimed_vars)) + ' variables in total so far'
    # simply replace elimed_vars with new ones, as the new list from
    # SatELite includes anything that currently doesn't appear in
    # the formula (and hence includes what was previously in elimed_vars)
    # Note: can't simply do elimed_vars = new_elimed_vars, as it is the
    #   pointer to elimed_vars that's passed by ref, not elimed_vars itself
    del elimed_vars[:]
    elimed_vars.extend(new_elimed_vars)

  stats.runtimes['Preprocessor'] += timer.getTimeSinceLastResetAndPrint()

  return return_code

        
#################################################################
# Make a copy of the input file and extend its "p cnf nVars nCls"
# line with enough padded spaces that it will be easy to append
# clauses to the file later, without having to read the whole file
#################################################################
def copyCNFFileAndMakeItInPlaceExtendible(filename_input, filename_output):
  input_stream  = open(filename_input, 'r')
  output_stream = open(filename_output, 'w')
  print >>output_stream, "c Generated by 3S with a specially formatted 'p cnf ... ' line"
  for line in input_stream:
    line = line.rstrip()
    if len(line) == 0:               # ignore empty lines (shouldn't really be there)
      continue
    if line[0] != 'p':               # print lines other than 'p cnf ...' as they are
      print >>output_stream, line
    else:
      words = line.split()
      assert words[0] == 'p'
      assert words[1] == 'cnf'
      assert len(words) >= 4
      numvars = int(words[2])
      numcls  = int(words[3])
      print >>output_stream, getFormattedCNFHeaderLine(numvars, numcls)
  input_stream.close()
  output_stream.close()


############################################################
# Execute given solver command and options and return result
############################################################
def runSolver(command, solver_id, filename_to_solve):
  global params, stats, timer, childPID

  # initialize return values
  success = False
  
  proc = myPopenPipeBoth(command, True, solvers[solver_id].env_vars)
  childPID = proc.pid    # store PID of child
  stats.numSolversCalled += 1
  solver_result = proc.communicate()[0]
  childPID = -1          # clear PID of child
  solver_status, solver_solution = parseSolverResult(solver_id, solver_result)
  stats.runtimes['AllSolvers'] += timer.getTimeSinceLastResetAndPrint()

  if solver_status != 'UNKNOWN':
    # instance solved!
    print 'c Instance solved!'
    print 'c'
    success = True
    # special handling if the reported status is SATISFIABLE
    if solver_status == 'SATISFIABLE':
      # if the CNF file that was solved is not the original CNF file
      # and unless both --nosolution and --noverify flags are specified,
      # convert partial solution to full solution
      if filename_to_solve != params.filename_orig and not (params.nosolution and params.noverify):
        solver_solution = convertPartialSolutionToFull(solver_solution, filename_to_solve)
      # unless --noverify is specified, do a sanity check: ensure the produced solution
      # satisfies the formula!
      if not params.noverify:
        solver_status = verifySolution(params.filename_orig, solver_solution)
      if solver_status != 'SATISFIABLE':
        success = False

    print 's ' + solver_status
    if solver_status == 'SATISFIABLE' and not params.nosolution:
      i = 0
      for lit in solver_solution:
        if i % params.solution_line_len == 0:
          if i != 0:
            sys.stdout.write('\n')
          sys.stdout.write('v')
        sys.stdout.write(' ' + str(lit))
        i += 1
      sys.stdout.write('\n')
      stats.runtimes['SolnPrinting'] += timer.getTimeSinceLastResetAndPrint()

  # record ID and name of the solver if successful
  if success:
    stats.successfulSolverID   = solver_id
    stats.successfulSolverName = solvers[solver_id].name

  # Return result
  return success

 
########################################
## parse output of a solver
########################################
def parseSolverResult(solver_id, solver_result):
  global params, stats, solvers

  # initialize return values
  solver_status          = 'UNKNOWN'
  solver_solution        = []
  
  # the output of the solver should be in the SAT Competition format
  lines = solver_result.split('\n')
  for line in lines:
    words = line.split()
    if params.verbosity >= 1 or (len(words) >= 1 and words[0] != 'v'):
      print 'c' + line.rstrip()
    if len(words) == 0:
      continue
    if words[0] == 's':
      solver_status = words[1]
    elif words[0] == 'v':
      solver_solution.extend(words[1:])
    else:
      continue

  return solver_status, solver_solution


#######################################
# append a set of clauses to a formula
#######################################
def appendClausesToFormula(clauses, filename_cnf):
  global stats
  
  # filename_cnf is guaranteed to have a 'p cnf ... ' line that can be updated
  # in place, i.e., it will have enough chars to accommodate a bigger number
  # for numclauses

  assert filename_cnf in [params.filename_pre, params.filename_extended]
  print 'c Appending ' + str(len(clauses)) + ' clauses to ' + filename_cnf + ' (in place)'

  # parse the initial part of the source CNF file and modify number of clauses *in place*
  num_clauses_orig = 0
  cnf_stream = open(filename_cnf, 'r+')     # open file in read-write mode
  seekpos_prev_line = 0
  # note: must use readline() here for tell() and seek() to work properly,
  # rather than 'for line in cnf_stream:' which can internally read big
  # blocks at a time
  line = cnf_stream.readline()
  while line:
    if line.startswith('p cnf '):
      line = line.rstrip()
      assert len(line) == getFormattedCNFHeaderLineLength()
      words = line.split()
      num_vars = int(words[2])
      num_clauses = int(words[3])
      cnf_stream.seek(seekpos_prev_line)    # go back to the start of the line
      print >>cnf_stream, getFormattedCNFHeaderLine(num_vars, num_clauses  + len(clauses))
      break
    seekpos_prev_line = cnf_stream.tell() # store seek pos right after line, before reading the next line
    line = cnf_stream.readline()
  cnf_stream.close()

  # now append provided clauses
  cnf_stream = open(filename_cnf, 'a')      # open file in append mode
  for clause in clauses:
    print >>cnf_stream, ' '.join(str(lit) for lit in clause), '0'
  cnf_stream.close()


#######################################
# to get full original solution, append these literals from
# solution to the preprocessed instance as unit clauses to the
# original formula, and then run a solver on the extended file
#######################################
def convertPartialSolutionToFull(partial_soln, filename_to_solve):
  global params, solvers, timer, childPID

  if filename_to_solve == params.filename_orig:
    return partial_soln   # already have the full solution! Will normally not come here, but just in case

  # obtain the list of possibly eliminated variables associated with filename_to_solve
  assert filename_to_solve == params.filename_pre
  elimedvars = params.elimedvars_pre

  # if no vars are in the eliminated list, we already have a full solution!
  if elimedvars == []:
    print 'c    CNF file has all variables of the original formula. No solution extension needed.'
    return partial_soln

  # otherwise, start converting the partial solution to full by appending
  # as unit clauses those lits in it whose vars are not in elimedvars; then
  # run the default solver to infer values of eliminated vars

  # to efficiently check membership in elimedvars, first convert it
  # into a bitvector with a 0/1 entry per variable appearing in it;
  # also keep track of the max var seen in elimedvars
  elimedvars_bitvector = [False]   # initialize a dummy value for variable "0" (which won't exist)
  elimedvars_max = 0
  for var in elimedvars:
    if var <= elimedvars_max:
      assert var > 0                # has to be positive
      assert var != elimedvars_max  # should not be a duplicate of a previously seen variable
      elimedvars_bitvector[var] = True
    else:
      # expand the bitvector to accommodate var
      for i in range(elimedvars_max+1, var):
        elimedvars_bitvector.append(False)
      elimedvars_bitvector.append(True)
      elimedvars_max = var
  
  # create unit clauses for lits in partial solution
  unit_clauses = []
  for lit in partial_soln:
    var = abs(int(lit))
    if var > elimedvars_max or not elimedvars_bitvector[var]:
      unit_clauses.append( [int(lit)] )
  assert unit_clauses[-1] == [0]
  unit_clauses.pop()     # discard last entry, which is always [0]

  # extend original CNF file with partial solution appended as unit clauses;
  # first copy it over to an in-place extendible file, then append units to it
  print 'c    Writing unit-clause-extended original CNF file to ' + params.filename_extended
  copyCNFFileAndMakeItInPlaceExtendible(params.filename_orig, params.filename_extended)
  appendClausesToFormula(unit_clauses, params.filename_extended)

  # now run a solver on this extended instance!
  print 'c    Running ' + params.extend_partial_soln_solver_name + ' on ' + params.filename_extended
  command = solvers[params.extend_partial_soln_solver_id].getCommandline(params.filename_extended)
  print 'c       ' + command
  proc = myPopenPipeStdout(command)
  childPID = proc.pid    # store PID of child
  solver_result = proc.communicate()[0]
  childPID = -1          # clear PID of child

  solver_status, solver_solution = parseSolverResult(params.extend_partial_soln_solver_id, solver_result)
  assert solver_status == 'SATISFIABLE'
  if not params.nofilecleanup:
    deleteFileSafely(params.filename_extended)

  stats.runtimes['SolnExtension'] += timer.getTimeSinceLastResetAndPrint()

  return solver_solution


#######################################
# verify that a proposed solution actually satisfy the instance
#######################################
def verifySolution(cnf_file, solver_solution):
  global timer

  print 'c Verifying solution'
  # convert solution, which may be missing some literals or may not
  # even have variables appearing in a sorted order, into a bit-vector
  # style array with values: 0: false, 1: true, -10: not specified
  unspecified = -10
  soln = [ unspecified ]  # put in a dummy value for "variable 0"
  for item in solver_solution:
    lit = int(item)
    var = abs(lit)
    lastvar = len(soln)-1
    if var > lastvar+1:    # fill in some gaps with unspecified values
      soln.extend( [ unspecified for i in range(lastvar+1, var) ] )
    if lit > 0:
      soln.append(1)
    else:
      soln.append(0)
  # now verify that every clause of cnf_file is satisfied
  updated_solver_status = 'SATISFIABLE'
  cnf_stream = open(cnf_file, 'r')
  for line in cnf_stream:
    if line.startswith('c') or line.startswith('p'):
      continue
    clause = line.split()
    assert clause[-1] == '0'
    del clause[-1]
    clause_satisfied = False
    for lit in clause:
      lit = int(lit)
      var = abs(lit)
      if var < len(soln) and ((lit > 0 and soln[var] == 1) or soln[var] == 0):
        clause_satisfied = True
        break
    if not clause_satisfied:
      print 'c    INVALID SOLUTION: the following clause is violated:'
      print 'c', line
      updated_solver_status = 'UNKNOWN'
      break

  cnf_stream.close()
  if updated_solver_status == 'SATISFIABLE':
    print 'c    Solution successfully verified!'
  stats.runtimes['SolnVerification'] += timer.getTimeSinceLastResetAndPrint()

  return updated_solver_status


#########################################################
# Delete temporary files and exit with the given status code
#########################################################
def cleanUpAndExit(status_code):
  if not params.nofilecleanup:
    deleteFileSafely(params.filename_pre)
  sys.exit(status_code)


#########################################################
# A bunch of convenience utilities

def getFormattedCNFHeaderLine(numvars, numcls):
  # use 16 chars to represent each of numvars and numcls
  return 'p cnf {0:16d} {1:16d}'.format(numvars, numcls)
  
def getFormattedCNFHeaderLineLength():
  return len(getFormattedCNFHeaderLine(1000, 1000))   # use dummy parameters to compute length

def myPopenNoPipe(command, myenv=None):
  return subprocess.Popen(shlex.split(command), stdout=open(os.devnull, 'w'), stderr=subprocess.STDOUT, env=myenv)

def myPopenPipeStdout(command, myenv=None):
  return subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE, stderr=open(os.devnull, 'w'), env=myenv)

def myPopenPipeStderr(command, myenv=None):
  return subprocess.Popen(shlex.split(command), stdout=open(os.devnull, 'w'), stderr=subprocess.PIPE, env=myenv)

def myPopenPipeBoth(command, merge=False, myenv=None):
  if not merge:
    return subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE, stderr=PIPE, env=myenv)
  else:
    return subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=myenv)

def deleteFileSafely(filename):
  if os.path.exists(filename):
    os.remove(filename)

def createTmpFilename(filename_base, filename_suffix):
  global params
  return params.tmpdir + '/' + filename_base + '.' + params.PIDsuffix + filename_suffix

def sigterm_handler(signum, frame):
  global __mymodulename__, __version__, childPID, stats
  print_prefix = 'c ' + __mymodulename__ + ' ' + __version__ + ': '
  print print_prefix + 'SIGTERM received! Exiting and killing child processes.'
  # send SIGTERM to all child processes (only one in this case)
  num_child_procs = 0
  if childPID > 0:
    num_child_procs += 1
    print print_prefix + 'sending SIGTERM to child PID ' + str(childPID)
    try:
      os.kill(childPID, signal.SIGTERM)
    except OSError:
      num_child_procs -= 1
  # wait for all child processes to stop (only one in this case)
  for i in range(num_child_procs):
    try:
      (pid, exit_status) = os.wait()
    except OSError:
      print print_prefix + '   No more child processes'
      break
    print print_prefix + '   PID ' + str(pid) + ' stopped'
  # print stats
  stats.printStats()
  # exit with status 1
  cleanUpAndExit(1)
  

  
#######################################
if __name__ == '__main__':
  main()
#######################################


