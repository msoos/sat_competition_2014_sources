#!/bin/bash

timeout=$1
shift
ulimit -t $timeout
exec $@
