#ifndef __X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H
#define __X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H

#include <x10rt.h>


#define X10_LANG_FINISHSTATE__ROOTFINISH_H_NODEPS
#include <x10/lang/FinishState__RootFinish.h>
#undef X10_LANG_FINISHSTATE__ROOTFINISH_H_NODEPS
#define X10_LANG_FINISHSTATE__COLLECTINGFINISHSTATE_H_NODEPS
#include <x10/lang/FinishState__CollectingFinishState.h>
#undef X10_LANG_FINISHSTATE__COLLECTINGFINISHSTATE_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class FinishState__StatefulReducer;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Reducible;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace util { namespace concurrent { 
class Lock;
} } } 
namespace x10 { namespace util { 
template<class TPMGL(T), class TPMGL(U)> class Pair;
} } 
namespace x10 { namespace lang { 

template<class TPMGL(T)> class FinishState__RootCollectingFinish;
template <> class FinishState__RootCollectingFinish<void>;
template<class TPMGL(T)> class FinishState__RootCollectingFinish : public x10::lang::FinishState__RootFinish
  {
    public:
    RTT_H_DECLS_CLASS
    
    static x10aux::itable_entry _itables[4];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static x10::lang::Runtime__Mortal::itable<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::FinishState__CollectingFinishState<TPMGL(T)>::template itable<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> > _itable_2;
    
    virtual x10_boolean _isMortal() { return true; }
    
    x10::lang::FinishState__StatefulReducer<TPMGL(T)>* FMGL(sr);
    
    void _constructor(x10::lang::Reducible<TPMGL(T)>* reducer);
    
    static x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* _make(
             x10::lang::Reducible<TPMGL(T)>* reducer);
    
    virtual void accept(TPMGL(T) t, x10_int id);
    virtual void notifyValue(x10::lang::Rail<x10_int >* rail, TPMGL(T) v);
    virtual void notifyValue(x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* rail,
                             TPMGL(T) v);
    virtual TPMGL(T) waitForFinishExpr();
    virtual x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>*
      x10__lang__FinishState__RootCollectingFinish____this__x10__lang__FinishState__RootCollectingFinish(
      );
    virtual void __fieldInitializers_x10_lang_FinishState_RootCollectingFinish(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::lang::FinishState__RootCollectingFinish<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::lang::FinishState__RootFinish>(), x10aux::getRTT<x10::lang::FinishState__CollectingFinishState<TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.lang.FinishState.RootCollectingFinish";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class FinishState__RootCollectingFinish<void> : public x10::lang::FinishState__RootFinish
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } 
#endif // X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H

namespace x10 { namespace lang { 
template<class TPMGL(T)> class FinishState__RootCollectingFinish;
} } 

#ifndef X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_NODEPS
#define X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_NODEPS
#include <x10/lang/FinishState__RootFinish.h>
#include <x10/lang/FinishState__CollectingFinishState.h>
#include <x10/lang/FinishState__StatefulReducer.h>
#include <x10/lang/Reducible.h>
#include <x10/lang/Int.h>
#include <x10/lang/Rail.h>
#include <x10/util/concurrent/Lock.h>
#include <x10/util/Pair.h>
#ifndef X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_GENERICS
#define X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_GENERICS
#endif // X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_GENERICS
#ifndef X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_IMPLEMENTATION
#define X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_IMPLEMENTATION
#include <x10/lang/FinishState__RootCollectingFinish.h>

template<class TPMGL(T)> x10::lang::Runtime__Mortal::itable<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> >  x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> >  x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::FinishState__CollectingFinishState<TPMGL(T)>::template itable<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> >  x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_itable_2(&x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::accept, &x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_itables[4] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Runtime__Mortal>, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::FinishState__CollectingFinishState<TPMGL(T)> >, &_itable_2), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> >())};

//#line 790 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10FieldDecl_c

//#line 791 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_constructor(
                           x10::lang::Reducible<TPMGL(T)>* reducer) {
    
    //#line 792 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::lang::FinishState__RootFinish::_constructor();
    
    //#line 791 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.AssignPropertyCall_c
    
    //#line 789 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* this58527 =
      this;
    
    //#line 793 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(sr) = (__extension__ ({
        
        //#line 793 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState__StatefulReducer<TPMGL(T)>* alloc55354 =
           ((new (memset(x10aux::alloc<x10::lang::FinishState__StatefulReducer<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__StatefulReducer<TPMGL(T)>))) x10::lang::FinishState__StatefulReducer<TPMGL(T)>()))
        ;
        
        //#line 793 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorCall_c
        (alloc55354)->::x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_constructor(
          reducer);
        alloc55354;
    }))
    ;
}
template<class TPMGL(T)> x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_make(
                           x10::lang::Reducible<TPMGL(T)>* reducer)
{
    x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>))) x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>();
    this_->_constructor(reducer);
    return this_;
}



//#line 795 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::accept(
  TPMGL(T) t, x10_int id) {
    
    //#line 796 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->accept(t, id);
}

//#line 798 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::notifyValue(
  x10::lang::Rail<x10_int >* rail, TPMGL(T) v) {
    
    //#line 799 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(latch))->lock();
    
    //#line 800 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->accept(v);
    
    //#line 801 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    this->process(rail);
    
    //#line 802 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(latch))->unlock();
}

//#line 804 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::notifyValue(
  x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* rail,
  TPMGL(T) v) {
    
    //#line 805 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(latch))->lock();
    
    //#line 806 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->accept(v);
    
    //#line 807 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    this->process(rail);
    
    //#line 808 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(latch))->unlock();
}

//#line 810 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::waitForFinishExpr(
  ) {
    
    //#line 811 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    this->waitForFinish();
    
    //#line 812 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->placeMerge();
    
    //#line 813 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) result = x10aux::nullCheck(this->FMGL(sr))->result();
    
    //#line 814 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->reset();
    
    //#line 815 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
    return result;
    
}

//#line 789 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>*
  x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::x10__lang__FinishState__RootCollectingFinish____this__x10__lang__FinishState__RootCollectingFinish(
  ) {
    
    //#line 789 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 789 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::__fieldInitializers_x10_lang_FinishState_RootCollectingFinish(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::lang::FinishState__RootFinish::_serialize_body(buf);
    buf.write(this->FMGL(sr));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>))) x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::lang::FinishState__RootFinish::_deserialize_body(buf);
    FMGL(sr) = buf.read<x10::lang::FinishState__StatefulReducer<TPMGL(T)>*>();
}

#endif // X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_IMPLEMENTATION
#endif // __X10_LANG_FINISHSTATE__ROOTCOLLECTINGFINISH_H_NODEPS
