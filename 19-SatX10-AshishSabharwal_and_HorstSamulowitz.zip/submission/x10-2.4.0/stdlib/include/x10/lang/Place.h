#ifndef __X10_LANG_PLACE_H
#define __X10_LANG_PLACE_H

#include <x10rt.h>


#define X10_LANG_ANY_H_NODEPS
#include <x10/lang/Any.h>
#undef X10_LANG_ANY_H_NODEPS
#define X10_LANG_ANY_H_NODEPS
#include <x10/lang/Any.h>
#undef X10_LANG_ANY_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace lang { 
class BadPlaceException;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(Z1), class TPMGL(U)> class Fun_0_1;
} } 
namespace x10 { namespace lang { 
class PlaceGroup;
} } 
namespace x10 { namespace lang { 
class IllegalArgumentException;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRef;
} } 
namespace x10 { namespace compiler { 
class NonEscaping;
} } 
namespace x10 { namespace lang { 

class Any; class String; // Forward reference are required in Place to prevent circularity
class Place   {
    public:
    RTT_H_DECLS_STRUCT
    
    x10::lang::Place* operator->() { return this; }
    
    x10_long FMGL(id);
    
    static x10aux::itable_entry _itables[2];
    
    x10aux::itable_entry* _getITables() { return _itables; }
    
    static x10::lang::Any::itable<x10::lang::Place > _itable_0;
    
    static x10aux::itable_entry _iboxitables[2];
    
    x10aux::itable_entry* _getIBoxITables() { return _iboxitables; }
    
    static x10::lang::Place _alloc(){x10::lang::Place t; return t; }
    
    x10_long id() {
        
        //#line 32 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (*this)->FMGL(id);
        
    }
    static x10_long numDead() {
        
        //#line 49 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return ((x10_long)0ll);
        
    }
    static x10_long FMGL(NUM_ACCELS);
    static void FMGL(NUM_ACCELS__do_init)();
    static void FMGL(NUM_ACCELS__init)();
    static volatile x10aux::StaticInitController::status FMGL(NUM_ACCELS__status);
    static x10::lang::CheckedThrowable* FMGL(NUM_ACCELS__exception);
    static x10_long FMGL(NUM_ACCELS__get)();
    
    static x10_long numChildren(x10_long id) {
        
        //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return ((x10_long)0ll);
        
    }
    static x10_boolean isHost(x10_long id) {
        
        //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return true;
        
    }
    static x10_boolean isDead(x10_long id) {
        
        //#line 73 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return false;
        
    }
    static x10_boolean isCUDA(x10_long id) {
        
        //#line 79 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return false;
        
    }
    static x10_long parent(x10_long id) {
        
        //#line 87 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return id;
        
    }
    static x10_long child(x10_long p, x10_long i);
    static x10_long childIndex(x10_long id);
    static x10::lang::Rail<x10::lang::Rail<x10::lang::Place >* >* FMGL(children);
    static void FMGL(children__do_init)();
    static void FMGL(children__init)();
    static volatile x10aux::StaticInitController::status FMGL(children__status);
    static x10::lang::CheckedThrowable* FMGL(children__exception);
    static x10::lang::Rail<x10::lang::Rail<x10::lang::Place >* >* FMGL(children__get)();
    
    static x10::lang::PlaceGroup* places();
    static x10::lang::Place FMGL(FIRST_PLACE);
    static void FMGL(FIRST_PLACE__do_init)();
    static void FMGL(FIRST_PLACE__init)();
    static volatile x10aux::StaticInitController::status FMGL(FIRST_PLACE__status);
    static x10::lang::CheckedThrowable* FMGL(FIRST_PLACE__exception);
    static x10::lang::Place FMGL(FIRST_PLACE__get)();
    
    static x10::lang::Place FMGL(INVALID_PLACE);
    static void FMGL(INVALID_PLACE__do_init)();
    static void FMGL(INVALID_PLACE__init)();
    static volatile x10aux::StaticInitController::status FMGL(INVALID_PLACE__status);
    static x10::lang::CheckedThrowable* FMGL(INVALID_PLACE__exception);
    static x10::lang::Place FMGL(INVALID_PLACE__get)();
    
    void _constructor(x10_long id);
    
    static x10::lang::Place _make(x10_long id);
    
    static x10::lang::Place place(x10_long id) {
        
        //#line 136 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10LocalDecl_c
        x10::lang::Place alloc59164 =  x10::lang::Place::_alloc();
        
        //#line 136 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10ConstructorCall_c
        (alloc59164)->::x10::lang::Place::_constructor(id);
        
        //#line 136 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return alloc59164;
        
    }
    x10::lang::Place next() {
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (*this)->x10::lang::Place::next(((x10_long)1ll));
        
    }
    x10::lang::Place prev() {
        
        //#line 146 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (*this)->x10::lang::Place::next(((x10_long)-1ll));
        
    }
    x10::lang::Place prev(x10_long i) {
        
        //#line 151 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (*this)->x10::lang::Place::next(((x10_long) -(i)));
        
    }
    x10::lang::Place next(x10_long i) {
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10If_c
        if (x10aux::is_host((x10_int)(*this)->FMGL(id))) {
            
            //#line 159 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10LocalDecl_c
            x10_long k = ((x10_long) ((((x10_long) ((((x10_long) (((*this)->
                                                                     FMGL(id)) + (((x10_long) ((i) % x10aux::zeroCheck(((x10_long)x10aux::num_hosts)))))))) + (((x10_long)x10aux::num_hosts))))) % x10aux::zeroCheck(((x10_long)x10aux::num_hosts))));
            
            //#line 136 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10LocalDecl_c
            x10_long id59165 = k;
            
            //#line 160 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
            return (__extension__ ({
                
                //#line 136 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10LocalDecl_c
                x10::lang::Place alloc59166 =  x10::lang::Place::_alloc();
                
                //#line 136 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10ConstructorCall_c
                (alloc59166)->::x10::lang::Place::_constructor(id59165);
                alloc59166;
            }))
            ;
            
        }
        
        //#line 163 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (*this);
        
    }
    static x10_long numPlaces() {
        
        //#line 169 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return ((x10_long)x10aux::num_places);
        
    }
    x10_boolean isFirst() {
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (x10aux::struct_equals((*this)->FMGL(id), ((x10_long)0ll)));
        
    }
    x10_boolean isLast() {
        
        //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (x10aux::struct_equals((*this)->FMGL(id), ((x10_long) ((((x10_long)x10aux::num_hosts)) - (((x10_long)1ll))))));
        
    }
    x10_boolean isHost() {
        
        //#line 178 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return x10aux::is_host((x10_int)(*this)->FMGL(id));
        
    }
    x10_boolean isCUDA() {
        
        //#line 181 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return x10aux::is_cuda((x10_int)(*this)->FMGL(id));
        
    }
    x10_boolean isDead() {
        
        //#line 184 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return x10rt_is_place_dead((x10_int)(*this)->FMGL(id));
        
    }
    x10_long numChildren() {
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return ((x10_long)x10aux::num_children((x10_int)(*this)->FMGL(id)));
        
    }
    x10::lang::Place child(x10_long i) {
        
        //#line 195 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10LocalDecl_c
        x10::lang::Place alloc59167 =  x10::lang::Place::_alloc();
        
        //#line 195 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10ConstructorCall_c
        (alloc59167)->::x10::lang::Place::_constructor(((x10_long)x10aux::child((x10_int)(*this)->
                                                                                           FMGL(id),(x10_int)i)));
        
        //#line 195 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return alloc59167;
        
    }
    x10::lang::Rail<x10::lang::Place >* children();
    x10::lang::Place parent() {
        
        //#line 201 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10LocalDecl_c
        x10::lang::Place alloc59168 =  x10::lang::Place::_alloc();
        
        //#line 201 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10ConstructorCall_c
        (alloc59168)->::x10::lang::Place::_constructor(x10aux::parent((x10_int)(*this)->
                                                                                 FMGL(id)));
        
        //#line 201 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return alloc59168;
        
    }
    x10_long childIndex();
    x10::lang::String* toString();
    x10_boolean equals(x10::lang::Place p) {
        
        //#line 214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (x10aux::struct_equals(p->FMGL(id), (*this)->
                                                     FMGL(id)));
        
    }
    x10_boolean equals(x10::lang::Any* p);
    x10_int hashCode() {
        
        //#line 216 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return ((x10_int) ((*this)->FMGL(id)));
        
    }
    x10::lang::String* typeName();
    x10_boolean _struct_equals(x10::lang::Any* other);
    x10_boolean _struct_equals(x10::lang::Place other) {
        
        //#line 31 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (x10aux::struct_equals((*this)->FMGL(id), other->
                                                           FMGL(id)));
        
    }
    x10::lang::Place x10__lang__Place____this__x10__lang__Place(
      ) {
        
        //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Place.x10": x10.ast.X10Return_c
        return (*this);
        
    }
    void __fieldInitializers_x10_lang_Place() {
     
    }
    
    static void _serialize(x10::lang::Place this_, x10aux::serialization_buffer& buf);
    
    static x10::lang::Place _deserialize(x10aux::deserialization_buffer& buf) {
        x10::lang::Place this_;
        this_->_deserialize_body(buf);
        return this_;
    }
    
    void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_PLACE_H

namespace x10 { namespace lang { 
class Place;
} } 

#ifndef X10_LANG_PLACE_H_NODEPS
#define X10_LANG_PLACE_H_NODEPS
#include <x10/lang/Any.h>
#include <x10/lang/Long.h>
#include <x10/compiler/Native.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/BadPlaceException.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/PlaceGroup.h>
#include <x10/lang/IllegalArgumentException.h>
#include <x10/lang/String.h>
#include <x10/lang/Int.h>
#include <x10/lang/GlobalRef.h>
#include <x10/compiler/NonEscaping.h>
#ifndef X10_LANG_PLACE_H_GENERICS
#define X10_LANG_PLACE_H_GENERICS
inline x10_long x10::lang::Place::FMGL(NUM_ACCELS__get)() {
    if (FMGL(NUM_ACCELS__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(NUM_ACCELS__init)();
    }
    return x10::lang::Place::FMGL(NUM_ACCELS);
}

inline x10::lang::Rail<x10::lang::Rail<x10::lang::Place >* >* x10::lang::Place::FMGL(children__get)() {
    if (FMGL(children__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(children__init)();
    }
    return x10::lang::Place::FMGL(children);
}

inline x10::lang::Place x10::lang::Place::FMGL(FIRST_PLACE__get)() {
    if (FMGL(FIRST_PLACE__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(FIRST_PLACE__init)();
    }
    return x10::lang::Place::FMGL(FIRST_PLACE);
}

inline x10::lang::Place x10::lang::Place::FMGL(INVALID_PLACE__get)() {
    if (FMGL(INVALID_PLACE__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(INVALID_PLACE__init)();
    }
    return x10::lang::Place::FMGL(INVALID_PLACE);
}

#endif // X10_LANG_PLACE_H_GENERICS
#endif // __X10_LANG_PLACE_H_NODEPS
