#ifndef __X10_LANG_MATH_H
#define __X10_LANG_MATH_H

#include <x10rt.h>

#include "x10/lang/MathNatives.h"

namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace lang { 
class Complex;
} } 
namespace x10 { namespace compiler { 
class NativeCPPInclude;
} } 
namespace x10 { namespace lang { 

class Math : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    static x10_double FMGL(E);
    static void FMGL(E__do_init)();
    static void FMGL(E__init)();
    static volatile x10aux::StaticInitController::status FMGL(E__status);
    static x10::lang::CheckedThrowable* FMGL(E__exception);
    static x10_double FMGL(E__get)();
    
    static x10_double FMGL(PI);
    static void FMGL(PI__do_init)();
    static void FMGL(PI__init)();
    static volatile x10aux::StaticInitController::status FMGL(PI__status);
    static x10::lang::CheckedThrowable* FMGL(PI__exception);
    static x10_double FMGL(PI__get)();
    
    static x10_int abs(x10_int a);
    static x10_long abs(x10_long a);
    static x10_float abs(x10_float a);
    static x10_double abs(x10_double a);
    static x10::lang::Complex pow(x10::lang::Complex a, x10::lang::Complex b);
    static x10::lang::Complex exp(x10::lang::Complex a);
    static x10::lang::Complex cos(x10::lang::Complex z);
    static x10::lang::Complex sin(x10::lang::Complex z);
    static x10::lang::Complex tan(x10::lang::Complex z);
    static x10::lang::Complex acos(x10::lang::Complex z);
    static x10::lang::Complex asin(x10::lang::Complex z);
    static x10::lang::Complex atan(x10::lang::Complex z);
    static x10::lang::Complex cosh(x10::lang::Complex z);
    static x10::lang::Complex sinh(x10::lang::Complex z);
    static x10::lang::Complex tanh(x10::lang::Complex z);
    static x10::lang::Complex sqrt(x10::lang::Complex z);
    static x10::lang::Complex log(x10::lang::Complex a);
    static x10_int max(x10_int a, x10_int b);
    static x10_int min(x10_int a, x10_int b);
    static x10_uint max(x10_uint a, x10_uint b);
    static x10_uint min(x10_uint a, x10_uint b);
    static x10_long max(x10_long a, x10_long b);
    static x10_long min(x10_long a, x10_long b);
    static x10_ulong max(x10_ulong a, x10_ulong b);
    static x10_ulong min(x10_ulong a, x10_ulong b);
    static x10_float max(x10_float a, x10_float b);
    static x10_float min(x10_float a, x10_float b);
    static x10_double max(x10_double a, x10_double b);
    static x10_double min(x10_double a, x10_double b);
    static x10_int signum(x10_int a);
    static x10_long signum(x10_long a);
    static x10_float signum(x10_float a);
    static x10_double signum(x10_double a);
    static x10_int nextPowerOf2(x10_int p);
    static x10_long nextPowerOf2(x10_long p);
    static x10_boolean powerOf2(x10_int p);
    static x10_boolean powerOf2(x10_long p);
    static x10_int log2(x10_int p);
    static x10_long log2(x10_long p);
    static x10_int pow2(x10_int i);
    static x10_long pow2(x10_long i);
    virtual x10::lang::Math* x10__lang__Math____this__x10__lang__Math();
    void _constructor();
    
    static x10::lang::Math* _make();
    
    virtual void __fieldInitializers_x10_lang_Math();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_MATH_H

namespace x10 { namespace lang { 
class Math;
} } 

#ifndef X10_LANG_MATH_H_NODEPS
#define X10_LANG_MATH_H_NODEPS
#ifndef X10_LANG_MATH_H_GENERICS
#define X10_LANG_MATH_H_GENERICS
inline x10_double x10::lang::Math::FMGL(E__get)() {
    if (FMGL(E__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(E__init)();
    }
    return x10::lang::Math::FMGL(E);
}

inline x10_double x10::lang::Math::FMGL(PI__get)() {
    if (FMGL(PI__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(PI__init)();
    }
    return x10::lang::Math::FMGL(PI);
}

#endif // X10_LANG_MATH_H_GENERICS
#endif // __X10_LANG_MATH_H_NODEPS
