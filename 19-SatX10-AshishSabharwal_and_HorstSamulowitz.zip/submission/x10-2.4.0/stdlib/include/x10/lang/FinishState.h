#ifndef __X10_LANG_FINISHSTATE_H
#define __X10_LANG_FINISHSTATE_H

#include <x10rt.h>


namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace util { namespace concurrent { 
class SimpleLatch;
} } } 
namespace x10 { namespace lang { 
class VoidFun_0_0;
} } 
namespace x10 { namespace lang { 
class Runtime__Profile;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(U)> class Fun_0_0;
} } 
namespace x10 { namespace lang { 
class Any;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRef;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace compiler { 
class CompilerFlags;
} } 
namespace x10 { namespace lang { 
class FailedDynamicCheckException;
} } 
namespace x10 { namespace lang { 
class FinishState__UncountedFinish;
} } 
namespace x10 { namespace lang { 

class FinishState : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    virtual void notifySubActivitySpawn(x10::lang::Place place) = 0;
    virtual x10_boolean notifyActivityCreation(x10::lang::Place srcPlace) = 0;
    virtual void notifyActivityTermination() = 0;
    virtual void pushException(x10::lang::Exception* t) = 0;
    virtual void waitForFinish() = 0;
    virtual x10::util::concurrent::SimpleLatch* simpleLatch() = 0;
    virtual void runAt(x10::lang::Place place, x10::lang::VoidFun_0_0* body,
                       x10::lang::Runtime__Profile* prof) = 0;
    virtual x10::lang::Any* evalAt(x10::lang::Place place, x10::lang::Fun_0_0<x10::lang::Any*>* body,
                                   x10::lang::Runtime__Profile* prof) = 0;
    virtual void notifyPlaceDeath();
    template<class TPMGL(T)> static TPMGL(T) deref(x10::lang::GlobalRef<x10::lang::FinishState* > root);
    static x10::lang::FinishState__UncountedFinish* FMGL(UNCOUNTED_FINISH);
    static void FMGL(UNCOUNTED_FINISH__do_init)();
    static void FMGL(UNCOUNTED_FINISH__init)();
    static volatile x10aux::StaticInitController::status FMGL(UNCOUNTED_FINISH__status);
    static x10::lang::CheckedThrowable* FMGL(UNCOUNTED_FINISH__exception);
    static x10::lang::FinishState__UncountedFinish* FMGL(UNCOUNTED_FINISH__get)();
    
    virtual x10::lang::FinishState* x10__lang__FinishState____this__x10__lang__FinishState(
      );
    void _constructor();
    
    virtual void __fieldInitializers_x10_lang_FinishState(
      );
    
    // Serialization
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_FINISHSTATE_H

namespace x10 { namespace lang { 
class FinishState;
} } 

#ifndef X10_LANG_FINISHSTATE_H_NODEPS
#define X10_LANG_FINISHSTATE_H_NODEPS
#include <x10/lang/Place.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Exception.h>
#include <x10/util/concurrent/SimpleLatch.h>
#include <x10/lang/VoidFun_0_0.h>
#include <x10/lang/Runtime__Profile.h>
#include <x10/lang/Fun_0_0.h>
#include <x10/lang/Any.h>
#include <x10/lang/GlobalRef.h>
#include <x10/lang/Runtime.h>
#include <x10/compiler/CompilerFlags.h>
#include <x10/lang/FailedDynamicCheckException.h>
#include <x10/lang/FinishState__UncountedFinish.h>
#ifndef X10_LANG_FINISHSTATE_H_GENERICS
#define X10_LANG_FINISHSTATE_H_GENERICS
#ifndef X10_LANG_FINISHSTATE_H_deref_733
#define X10_LANG_FINISHSTATE_H_deref_733
template<class TPMGL(T)> TPMGL(T) x10::lang::FinishState::deref(x10::lang::GlobalRef<x10::lang::FinishState* > root) {
    
    //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
    return x10aux::class_cast<TPMGL(T)>(((__extension__ ({
        
        //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
        x10::lang::GlobalRef<x10::lang::FinishState* > __desugarer__var__21__56380 =
          root;
        
        //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
        x10::lang::GlobalRef<x10::lang::FinishState* > ret56381;
        
        //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
        if (!((x10aux::struct_equals(x10::lang::Place::place((__desugarer__var__21__56380)->location),
                                     x10::lang::Place::_make(x10aux::here)))))
        {
            
            //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.lang.GlobalRef[x10.lang.FinishState]{self.home==here}"))));
            }
            
        }
        
        //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
        ret56381 = __desugarer__var__21__56380;
        ret56381;
    }))
    )->__apply());
    
}
#endif // X10_LANG_FINISHSTATE_H_deref_733
inline x10::lang::FinishState__UncountedFinish* x10::lang::FinishState::FMGL(UNCOUNTED_FINISH__get)() {
    if (FMGL(UNCOUNTED_FINISH__status) != x10aux::StaticInitController::INITIALIZED) {
        FMGL(UNCOUNTED_FINISH__init)();
    }
    return x10::lang::FinishState::FMGL(UNCOUNTED_FINISH);
}

#endif // X10_LANG_FINISHSTATE_H_GENERICS
#endif // __X10_LANG_FINISHSTATE_H_NODEPS
