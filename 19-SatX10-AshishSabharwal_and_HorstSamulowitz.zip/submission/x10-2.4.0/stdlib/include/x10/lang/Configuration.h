#ifndef __X10_LANG_CONFIGURATION_H
#define __X10_LANG_CONFIGURATION_H

#include <x10rt.h>


namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace util { 
template<class TPMGL(K), class TPMGL(V)> class HashMap;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Any;
} } 
namespace x10 { namespace lang { 
class NumberFormatException;
} } 
namespace x10 { namespace lang { 

class Configuration : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    static x10_boolean envOrElse(x10::lang::String* s, x10_boolean b);
    static x10_boolean strict_finish();
    static x10_boolean static_threads();
    static x10_boolean warn_on_thread_creation();
    static x10_boolean busy_waiting();
    static x10_int nthreads();
    static x10_int max_threads();
    virtual x10::lang::Configuration* x10__lang__Configuration____this__x10__lang__Configuration(
      );
    void _constructor();
    
    static x10::lang::Configuration* _make();
    
    virtual void __fieldInitializers_x10_lang_Configuration();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_CONFIGURATION_H

namespace x10 { namespace lang { 
class Configuration;
} } 

#ifndef X10_LANG_CONFIGURATION_H_NODEPS
#define X10_LANG_CONFIGURATION_H_NODEPS
#include <x10/lang/Int.h>
#include <x10/compiler/Native.h>
#include <x10/lang/Boolean.h>
#include <x10/util/HashMap.h>
#include <x10/lang/String.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Any.h>
#include <x10/lang/NumberFormatException.h>
#include <x10/lang/Long.h>
#ifndef X10_LANG_CONFIGURATION_H_GENERICS
#define X10_LANG_CONFIGURATION_H_GENERICS
#endif // X10_LANG_CONFIGURATION_H_GENERICS
#endif // __X10_LANG_CONFIGURATION_H_NODEPS
