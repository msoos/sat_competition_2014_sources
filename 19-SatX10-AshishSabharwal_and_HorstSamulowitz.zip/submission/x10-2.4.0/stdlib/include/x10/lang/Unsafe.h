#ifndef __X10_LANG_UNSAFE_H
#define __X10_LANG_UNSAFE_H

#include <x10rt.h>

#include "x10/lang/UnsafeNatives.h"

namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace lang { 
class UnsupportedOperationException;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRef;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRail;
} } 
namespace x10 { namespace compiler { 
class NativeCPPInclude;
} } 
namespace x10 { namespace lang { 

class Unsafe : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    template<class TPMGL(T)> static TPMGL(T) uncheckedRailApply(x10::lang::Rail<TPMGL(T) >* r,
                                                                x10_long i);
    template<class TPMGL(T)> static TPMGL(T) uncheckedRailSet(x10::lang::Rail<TPMGL(T) >* r,
                                                              x10_long i,
                                                              TPMGL(T) v);
    template<class TPMGL(T)> static void dealloc(TPMGL(T) o);
    template<class TPMGL(T)> static x10::lang::Rail<TPMGL(T) >*
      getCongruentSibling(x10::lang::Rail<TPMGL(T) >* r, x10_long dst);
    template<class TPMGL(T)> static x10::lang::GlobalRail<TPMGL(T)>
      getCongruentSibling(x10::lang::Rail<TPMGL(T) >* r, x10::lang::Place dst);
    virtual x10::lang::Unsafe* x10__lang__Unsafe____this__x10__lang__Unsafe(
      );
    void _constructor();
    
    static x10::lang::Unsafe* _make();
    
    virtual void __fieldInitializers_x10_lang_Unsafe();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_UNSAFE_H

namespace x10 { namespace lang { 
class Unsafe;
} } 

#ifndef X10_LANG_UNSAFE_H_NODEPS
#define X10_LANG_UNSAFE_H_NODEPS
#include <x10/lang/Long.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/Native.h>
#include <x10/compiler/Inline.h>
#include <x10/lang/UnsupportedOperationException.h>
#include <x10/lang/Place.h>
#include <x10/lang/GlobalRef.h>
#include <x10/lang/GlobalRail.h>
#include <x10/compiler/NativeCPPInclude.h>
#ifndef X10_LANG_UNSAFE_H_GENERICS
#define X10_LANG_UNSAFE_H_GENERICS
#ifndef X10_LANG_UNSAFE_H_uncheckedRailApply_1444
#define X10_LANG_UNSAFE_H_uncheckedRailApply_1444
template<class TPMGL(T)> TPMGL(T) x10::lang::Unsafe::uncheckedRailApply(x10::lang::Rail<TPMGL(T) >* r,
                                                                        x10_long i) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": x10.ast.X10Return_c
    return x10aux::nullCheck(r)->x10::lang::template Rail<TPMGL(T) >::__apply(
             i);
    
}
#endif // X10_LANG_UNSAFE_H_uncheckedRailApply_1444
#ifndef X10_LANG_UNSAFE_H_uncheckedRailSet_1445
#define X10_LANG_UNSAFE_H_uncheckedRailSet_1445
template<class TPMGL(T)> TPMGL(T) x10::lang::Unsafe::uncheckedRailSet(
  x10::lang::Rail<TPMGL(T) >* r, x10_long i, TPMGL(T) v) {
    
    //#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(r)->x10::lang::template Rail<TPMGL(T) >::__set(
      i, v);
    
    //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": x10.ast.X10Return_c
    return v;
    
}
#endif // X10_LANG_UNSAFE_H_uncheckedRailSet_1445
#ifndef X10_LANG_UNSAFE_H_dealloc_1446
#define X10_LANG_UNSAFE_H_dealloc_1446
template<class TPMGL(T)> void x10::lang::Unsafe::dealloc(TPMGL(T) o) {
 
}
#endif // X10_LANG_UNSAFE_H_dealloc_1446
#ifndef X10_LANG_UNSAFE_H_getCongruentSibling_1447
#define X10_LANG_UNSAFE_H_getCongruentSibling_1447
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::lang::Unsafe::getCongruentSibling(
  x10::lang::Rail<TPMGL(T) >* r, x10_long dst) {
    
    //#line 51 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": polyglot.ast.Throw_c
    x10aux::throwException(x10aux::nullCheck(x10::lang::UnsupportedOperationException::_make(x10aux::makeStringLit("Congruent memory not available on Managed X10"))));
}
#endif // X10_LANG_UNSAFE_H_getCongruentSibling_1447
#ifndef X10_LANG_UNSAFE_H_getCongruentSibling_1448
#define X10_LANG_UNSAFE_H_getCongruentSibling_1448
template<class TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)> x10::lang::Unsafe::getCongruentSibling(
  x10::lang::Rail<TPMGL(T) >* r, x10::lang::Place dst) {
    
    //#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* remoteRail = x10::lang::UnsafeNatives::getCongruentSibling(r, dst->
                                                                                                FMGL(id));
    
    //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > globalRef =
      x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* >((x10aux::place)((dst).FMGL(id)), (x10_ulong)(remoteRail));
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRail<TPMGL(T)> globalRail =  x10::lang::GlobalRail<TPMGL(T)>::_alloc();
    
    //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10LocalDecl_c
    x10_long size59746 = (x10_long)(x10aux::nullCheck(r)->FMGL(size));
    
    //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > raw59747 =
      globalRef;
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": Eval of x10.ast.X10FieldAssign_c
    globalRail->FMGL(size) = size59746;
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": Eval of x10.ast.X10FieldAssign_c
    globalRail->FMGL(rail) = raw59747;
    
    //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Unsafe.x10": x10.ast.X10Return_c
    return globalRail;
    
}
#endif // X10_LANG_UNSAFE_H_getCongruentSibling_1448
#endif // X10_LANG_UNSAFE_H_GENERICS
#endif // __X10_LANG_UNSAFE_H_NODEPS
