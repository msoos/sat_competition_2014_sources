#ifndef __X10_LANG_FINISHSTATE__STATEFULREDUCER_H
#define __X10_LANG_FINISHSTATE__STATEFULREDUCER_H

#include <x10rt.h>


#define X10_LANG_BOOLEAN_H_NODEPS
#include <x10/lang/Boolean.h>
#undef X10_LANG_BOOLEAN_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Reducible;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 

template<class TPMGL(T)> class FinishState__StatefulReducer;
template <> class FinishState__StatefulReducer<void>;
template<class TPMGL(T)> class FinishState__StatefulReducer : public x10::lang::X10Class
  {
    public:
    RTT_H_DECLS_CLASS
    
    x10::lang::Reducible<TPMGL(T)>* FMGL(reducer);
    
    TPMGL(T) FMGL(result);
    
    x10::lang::Rail<TPMGL(T) >* FMGL(resultRail);
    
    x10::lang::Rail<x10_boolean >* FMGL(workerFlag);
    
    void _constructor(x10::lang::Reducible<TPMGL(T)>* r);
    
    static x10::lang::FinishState__StatefulReducer<TPMGL(T)>* _make(
             x10::lang::Reducible<TPMGL(T)>* r);
    
    virtual void accept(TPMGL(T) t);
    virtual void accept(TPMGL(T) t, x10_int id);
    virtual void placeMerge();
    virtual TPMGL(T) result();
    virtual void reset();
    virtual x10::lang::FinishState__StatefulReducer<TPMGL(T)>* x10__lang__FinishState__StatefulReducer____this__x10__lang__FinishState__StatefulReducer(
      );
    virtual void __fieldInitializers_x10_lang_FinishState_StatefulReducer(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::lang::FinishState__StatefulReducer<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::lang::FinishState__StatefulReducer<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType** parents = NULL; 
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.lang.FinishState.StatefulReducer";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 0, parents, 1, params, variances);
}

template <> class FinishState__StatefulReducer<void> : public x10::lang::X10Class
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } 
#endif // X10_LANG_FINISHSTATE__STATEFULREDUCER_H

namespace x10 { namespace lang { 
template<class TPMGL(T)> class FinishState__StatefulReducer;
} } 

#ifndef X10_LANG_FINISHSTATE__STATEFULREDUCER_H_NODEPS
#define X10_LANG_FINISHSTATE__STATEFULREDUCER_H_NODEPS
#include <x10/lang/Boolean.h>
#include <x10/lang/Reducible.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Unsafe.h>
#include <x10/lang/Long.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Int.h>
#ifndef X10_LANG_FINISHSTATE__STATEFULREDUCER_H_GENERICS
#define X10_LANG_FINISHSTATE__STATEFULREDUCER_H_GENERICS
#endif // X10_LANG_FINISHSTATE__STATEFULREDUCER_H_GENERICS
#ifndef X10_LANG_FINISHSTATE__STATEFULREDUCER_H_IMPLEMENTATION
#define X10_LANG_FINISHSTATE__STATEFULREDUCER_H_IMPLEMENTATION
#include <x10/lang/FinishState__StatefulReducer.h>


//#line 724 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10FieldDecl_c

//#line 725 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10FieldDecl_c

//#line 726 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10FieldDecl_c

//#line 727 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10FieldDecl_c

//#line 728 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_constructor(
                           x10::lang::Reducible<TPMGL(T)>* r) {
    
    //#line 728 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.AssignPropertyCall_c
    
    //#line 723 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    this->x10::lang::template FinishState__StatefulReducer<TPMGL(T)>::__fieldInitializers_x10_lang_FinishState_StatefulReducer();
    
    //#line 729 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(reducer) = r;
    
    //#line 730 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) zero = x10::lang::Reducible<TPMGL(T)>::zero(x10aux::nullCheck(this->
                                                                             FMGL(reducer)));
    
    //#line 731 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(result) = zero;
    
    //#line 732 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(resultRail) = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(((x10_long) (x10::lang::Runtime::
                                                                                    FMGL(MAX_THREADS__get)())), false);
    
    //#line 733 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10_long i55392max58521 = ((x10_long) (((x10_long)(x10aux::nullCheck(this->
                                                                           FMGL(resultRail))->FMGL(size))) - (((x10_long)1ll))));
    
    //#line 733 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": polyglot.ast.For_c
    {
        x10_long i58522;
        for (
             //#line 733 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
             i58522 = ((x10_long)0ll); ((i58522) <= (i55392max58521));
             
             //#line 733 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
             i58522 = ((x10_long) ((i58522) + (((x10_long)1ll)))))
        {
            
            //#line 733 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
            x10_long i58523 = i58522;
            
            //#line 734 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(this->FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__set(
              i58523, zero);
        }
    }
    
}
template<class TPMGL(T)> x10::lang::FinishState__StatefulReducer<TPMGL(T)>* x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_make(
                           x10::lang::Reducible<TPMGL(T)>* r)
{
    x10::lang::FinishState__StatefulReducer<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::lang::FinishState__StatefulReducer<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__StatefulReducer<TPMGL(T)>))) x10::lang::FinishState__StatefulReducer<TPMGL(T)>();
    this_->_constructor(r);
    return this_;
}



//#line 737 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::accept(
  TPMGL(T) t) {
    
    //#line 738 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(result) = x10::lang::Reducible<TPMGL(T)>::__apply(x10aux::nullCheck(this->
                                                                                     FMGL(reducer)), 
                           this->FMGL(result), t);
}

//#line 740 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::accept(
  TPMGL(T) t, x10_int id) {
    
    //#line 741 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
    if (((((x10_long) (id))) >= (((x10_long)0ll))) && ((id) < (x10::lang::Runtime::
                                                                 FMGL(MAX_THREADS__get)())))
    {
        
        //#line 742 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(this->FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__set(
          ((x10_long) (id)), x10::lang::Reducible<TPMGL(T)>::__apply(x10aux::nullCheck(this->
                                                                                         FMGL(reducer)), 
                               x10aux::nullCheck(this->FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__apply(
                                 ((x10_long) (id))), t));
        
        //#line 743 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(this->FMGL(workerFlag))->x10::lang::template Rail<x10_boolean >::__set(
          ((x10_long) (id)), true);
    }
    
}

//#line 746 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::placeMerge(
  ) {
    
    //#line 747 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": polyglot.ast.For_c
    {
        x10_int i;
        for (
             //#line 747 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
             i = ((x10_int)0); ((i) < (x10::lang::Runtime::
                                         FMGL(MAX_THREADS__get)()));
             
             //#line 747 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
             i = ((x10_int) ((i) + (((x10_int)1))))) {
            
            //#line 748 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
            if (x10aux::nullCheck(this->FMGL(workerFlag))->x10::lang::template Rail<x10_boolean >::__apply(
                  ((x10_long) (i)))) {
                
                //#line 749 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
                this->FMGL(result) = x10::lang::Reducible<TPMGL(T)>::__apply(x10aux::nullCheck(this->
                                                                                                 FMGL(reducer)), 
                                       this->FMGL(result),
                                       x10aux::nullCheck(this->
                                                           FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__apply(
                                         ((x10_long) (i))));
                
                //#line 750 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
                x10aux::nullCheck(this->FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__set(
                  ((x10_long) (i)), x10::lang::Reducible<TPMGL(T)>::zero(x10aux::nullCheck(this->
                                                                                             FMGL(reducer))));
            }
            
        }
    }
    
}

//#line 754 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::lang::FinishState__StatefulReducer<TPMGL(T)>::result(
  ) {
    
    //#line 754 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
    return this->FMGL(result);
    
}

//#line 755 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::reset(
  ) {
    
    //#line 756 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(result) = x10::lang::Reducible<TPMGL(T)>::zero(x10aux::nullCheck(this->
                                                                                  FMGL(reducer)));
}

//#line 723 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::FinishState__StatefulReducer<TPMGL(T)>*
  x10::lang::FinishState__StatefulReducer<TPMGL(T)>::x10__lang__FinishState__StatefulReducer____this__x10__lang__FinishState__StatefulReducer(
  ) {
    
    //#line 723 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 723 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::__fieldInitializers_x10_lang_FinishState_StatefulReducer(
  ) {
    
    //#line 723 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(resultRail) = (x10aux::class_cast_unchecked<x10::lang::Rail<TPMGL(T) >*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 723 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(workerFlag) = x10::lang::Rail<x10_boolean >::_make(((x10_long) (x10::lang::Runtime::
                                                                                 FMGL(MAX_THREADS__get)())));
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    buf.write(this->FMGL(reducer));
    buf.write(this->FMGL(result));
    buf.write(this->FMGL(resultRail));
    buf.write(this->FMGL(workerFlag));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::lang::FinishState__StatefulReducer<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::lang::FinishState__StatefulReducer<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__StatefulReducer<TPMGL(T)>))) x10::lang::FinishState__StatefulReducer<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(reducer) = buf.read<x10::lang::Reducible<TPMGL(T)>*>();
    FMGL(result) = buf.read<TPMGL(T)>();
    FMGL(resultRail) = buf.read<x10::lang::Rail<TPMGL(T) >*>();
    FMGL(workerFlag) = buf.read<x10::lang::Rail<x10_boolean >*>();
}

#endif // X10_LANG_FINISHSTATE__STATEFULREDUCER_H_IMPLEMENTATION
#endif // __X10_LANG_FINISHSTATE__STATEFULREDUCER_H_NODEPS
