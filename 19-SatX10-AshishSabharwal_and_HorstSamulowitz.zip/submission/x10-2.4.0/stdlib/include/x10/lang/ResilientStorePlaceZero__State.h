#ifndef __X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H
#define __X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H

#include <x10rt.h>


#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_INT_H_NODEPS
#include <x10/lang/Int.h>
#undef X10_LANG_INT_H_NODEPS
#define X10_LANG_BOOLEAN_H_NODEPS
#include <x10/lang/Boolean.h>
#undef X10_LANG_BOOLEAN_H_NODEPS
#define X10_LANG_BOOLEAN_H_NODEPS
#include <x10/lang/Boolean.h>
#undef X10_LANG_BOOLEAN_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace util { 
template<class TPMGL(T)> class GrowableRail;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace util { namespace concurrent { 
class SimpleLatch;
} } } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class DeadPlaceException;
} } 
namespace x10 { namespace lang { 
class CheckedThrowable;
} } 
namespace x10 { namespace lang { 

class ResilientStorePlaceZero__State : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    x10_long FMGL(id);
    
    x10::lang::ResilientStorePlaceZero__State* FMGL(parent);
    
    x10::lang::Rail<x10_int >* FMGL(transit);
    
    x10::lang::Rail<x10_int >* FMGL(live);
    
    x10_long FMGL(homeId);
    
    x10_boolean FMGL(adopted);
    
    x10::util::GrowableRail<x10::lang::Exception*>* FMGL(multipleExceptions);
    
    x10::util::concurrent::SimpleLatch* FMGL(latch);
    
    x10::util::GrowableRail<x10::lang::Exception*>* ensureMultipleExceptions(
      );
    void _constructor(x10::lang::ResilientStorePlaceZero__State* pfs, x10_long homeId,
                      x10_long id, x10::util::concurrent::SimpleLatch* latch);
    
    static x10::lang::ResilientStorePlaceZero__State* _make(x10::lang::ResilientStorePlaceZero__State* pfs,
                                                            x10_long homeId,
                                                            x10_long id,
                                                            x10::util::concurrent::SimpleLatch* latch);
    
    virtual x10::lang::ResilientStorePlaceZero__State* findFirstNonDeadParent(
      );
    virtual void stealCounters(x10::lang::ResilientStorePlaceZero__State* child);
    virtual void addDeadPlaceException(x10::lang::Place p);
    virtual x10::lang::ResilientStorePlaceZero__State* x10__lang__ResilientStorePlaceZero__State____this__x10__lang__ResilientStorePlaceZero__State(
      );
    virtual void __fieldInitializers_x10_lang_ResilientStorePlaceZero_State(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H

namespace x10 { namespace lang { 
class ResilientStorePlaceZero__State;
} } 

#ifndef X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H_NODEPS
#define X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H_NODEPS
#ifndef X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H_GENERICS
#define X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H_GENERICS
#endif // X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H_GENERICS
#endif // __X10_LANG_RESILIENTSTOREPLACEZERO__STATE_H_NODEPS
