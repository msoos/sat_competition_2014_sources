#ifndef __X10_LANG_COMPLEX_H
#define __X10_LANG_COMPLEX_H

#include <x10rt.h>


#define X10_LANG_ANY_H_NODEPS
#include <x10/lang/Any.h>
#undef X10_LANG_ANY_H_NODEPS
#define X10_LANG_ARITHMETIC_H_NODEPS
#include <x10/lang/Arithmetic.h>
#undef X10_LANG_ARITHMETIC_H_NODEPS
#define X10_LANG_ANY_H_NODEPS
#include <x10/lang/Any.h>
#undef X10_LANG_ANY_H_NODEPS
#define X10_LANG_DOUBLE_H_NODEPS
#include <x10/lang/Double.h>
#undef X10_LANG_DOUBLE_H_NODEPS
#define X10_LANG_DOUBLE_H_NODEPS
#include <x10/lang/Double.h>
#undef X10_LANG_DOUBLE_H_NODEPS
namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace lang { 
class Math;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace compiler { 
class NonEscaping;
} } 
namespace x10 { namespace lang { 

class Complex   {
    public:
    RTT_H_DECLS_STRUCT
    
    x10::lang::Complex* operator->() { return this; }
    
    static x10aux::itable_entry _itables[3];
    
    x10aux::itable_entry* _getITables() { return _itables; }
    
    static x10::lang::Any::itable<x10::lang::Complex > _itable_0;
    
    static x10::lang::Arithmetic<x10::lang::Complex >::itable<x10::lang::Complex > _itable_1;
    
    static x10aux::itable_entry _iboxitables[3];
    
    x10aux::itable_entry* _getIBoxITables() { return _iboxitables; }
    
    static x10::lang::Complex _alloc(){x10::lang::Complex t; return t; }
    
    x10_double FMGL(re);
    
    x10_double FMGL(im);
    
    void _constructor(x10_double real, x10_double imaginary) {
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.AssignPropertyCall_c
        
        //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex this56210 = (*this);
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        (*this)->FMGL(re) = real;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        (*this)->FMGL(im) = imaginary;
    }
    static x10::lang::Complex _make(x10_double real, x10_double imaginary)
    {
        x10::lang::Complex this_; 
        this_->_constructor(real, imaginary);
        return this_;
    }
    
    x10::lang::Complex __plus(x10::lang::Complex that) {
        
        //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56213 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56211 = (((*this)->FMGL(re)) + (that->FMGL(re)));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56212 = (((*this)->FMGL(im)) + (that->FMGL(im)));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56213->FMGL(re) = real56211;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56213->FMGL(im) = imaginary56212;
        
        //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56213;
        
    }
    static x10::lang::Complex __plus(x10_double x, x10::lang::Complex y) {
        
        //#line 67 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return y->x10::lang::Complex::__plus(x);
        
    }
    x10::lang::Complex __plus(x10_double that) {
        
        //#line 73 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56216 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56214 = (((*this)->FMGL(re)) + (that));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56215 = (*this)->FMGL(im);
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56216->FMGL(re) = real56214;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56216->FMGL(im) = imaginary56215;
        
        //#line 73 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56216;
        
    }
    x10::lang::Complex __minus(x10::lang::Complex that) {
        
        //#line 80 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56219 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56217 = (((*this)->FMGL(re)) - (that->FMGL(re)));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56218 = (((*this)->FMGL(im)) - (that->FMGL(im)));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56219->FMGL(re) = real56217;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56219->FMGL(im) = imaginary56218;
        
        //#line 80 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56219;
        
    }
    static x10::lang::Complex __minus(x10_double x, x10::lang::Complex y) {
        
        //#line 86 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56222 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56220 = ((x) - (y->FMGL(re)));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56221 = (-(y->FMGL(im)));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56222->FMGL(re) = real56220;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56222->FMGL(im) = imaginary56221;
        
        //#line 86 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56222;
        
    }
    x10::lang::Complex __minus(x10_double that) {
        
        //#line 92 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56225 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56223 = (((*this)->FMGL(re)) - (that));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56224 = (*this)->FMGL(im);
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56225->FMGL(re) = real56223;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56225->FMGL(im) = imaginary56224;
        
        //#line 92 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56225;
        
    }
    x10::lang::Complex __times(x10::lang::Complex that) {
        
        //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56228 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56226 = (((((*this)->FMGL(re)) * (that->FMGL(re)))) - ((((*this)->
                                                                                  FMGL(im)) * (that->
                                                                                                 FMGL(im)))));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56227 = (((((*this)->FMGL(re)) * (that->
                                                                FMGL(im)))) + ((((*this)->
                                                                                   FMGL(im)) * (that->
                                                                                                  FMGL(re)))));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56228->FMGL(re) = real56226;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56228->FMGL(im) = imaginary56227;
        
        //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56228;
        
    }
    static x10::lang::Complex __times(x10_double x, x10::lang::Complex y) {
        
        //#line 106 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return y->x10::lang::Complex::__times(x);
        
    }
    x10::lang::Complex __times(x10_double that) {
        
        //#line 112 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56231 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56229 = (((*this)->FMGL(re)) * (that));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56230 = (((*this)->FMGL(im)) * (that));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56231->FMGL(re) = real56229;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56231->FMGL(im) = imaginary56230;
        
        //#line 112 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56231;
        
    }
    x10::lang::Complex __over(x10::lang::Complex that);
    static x10::lang::Complex __over(x10_double x, x10::lang::Complex y) {
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return (__extension__ ({
                   
                   //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
                   x10::lang::Complex alloc56128 =  x10::lang::Complex::_alloc();
                   
                   //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
                   x10_double real56244 = x;
                   
                   //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": polyglot.ast.Empty_c
                   ;
                   
                   //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
                   alloc56128->FMGL(re) = real56244;
                   
                   //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
                   alloc56128->FMGL(im) = 0.0;
                   alloc56128;
               }))
               ->x10::lang::Complex::__over(y);
        
    }
    x10::lang::Complex __over(x10_double that) {
        
        //#line 164 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56247 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56245 = (((*this)->FMGL(re)) / (that));
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56246 = (((*this)->FMGL(im)) / (that));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56247->FMGL(re) = real56245;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56247->FMGL(im) = imaginary56246;
        
        //#line 164 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56247;
        
    }
    x10::lang::Complex conjugate() {
        
        //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10::lang::Complex alloc56250 =  x10::lang::Complex::_alloc();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double real56248 = (*this)->FMGL(re);
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
        x10_double imaginary56249 = (-((*this)->FMGL(im)));
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56250->FMGL(re) = real56248;
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
        alloc56250->FMGL(im) = imaginary56249;
        
        //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return alloc56250;
        
    }
    x10::lang::Complex __plus() {
        
        //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return (*this);
        
    }
    x10::lang::Complex __minus() {
        
        //#line 180 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return (*this)->x10::lang::Complex::isNaN() ? (x10::lang::Complex::_make(x10::lang::DoubleNatives::fromLongBits(0x7ff8000000000000LL),x10::lang::DoubleNatives::fromLongBits(0x7ff8000000000000LL)))
          : ((__extension__ ({
                 
                 //#line 180 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
                 x10::lang::Complex alloc56131 =  x10::lang::Complex::_alloc();
                 
                 //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
                 x10_double real56251 = (-((*this)->FMGL(re)));
                 
                 //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10LocalDecl_c
                 x10_double imaginary56252 = (-((*this)->
                                                  FMGL(im)));
                 
                 //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
                 alloc56131->FMGL(re) = real56251;
                 
                 //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": Eval of x10.ast.X10FieldAssign_c
                 alloc56131->FMGL(im) = imaginary56252;
                 alloc56131;
             }))
             );
        
    }
    x10_double abs();
    x10_boolean isNaN() {
        
        //#line 215 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return x10::lang::DoubleNatives::isNaN((*this)->FMGL(re)) ||
        x10::lang::DoubleNatives::isNaN((*this)->FMGL(im));
        
    }
    x10_boolean isInfinite() {
        
        //#line 223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return !((*this)->x10::lang::Complex::isNaN()) &&
        (x10::lang::DoubleNatives::isInfinite((*this)->FMGL(re)) ||
         x10::lang::DoubleNatives::isInfinite((*this)->FMGL(im)));
        
    }
    x10::lang::String* toString();
    x10::lang::String* typeName();
    x10_int hashCode();
    x10_boolean equals(x10::lang::Any* other);
    x10_boolean equals(x10::lang::Complex other) {
        
        //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return (x10aux::struct_equals((*this)->FMGL(re), other->
                                                           FMGL(re))) &&
        (x10aux::struct_equals((*this)->FMGL(im), other->
                                                    FMGL(im)));
        
    }
    x10_boolean _struct_equals(x10::lang::Any* other);
    x10_boolean _struct_equals(x10::lang::Complex other) {
        
        //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return (x10aux::struct_equals((*this)->FMGL(re), other->
                                                           FMGL(re))) &&
        (x10aux::struct_equals((*this)->FMGL(im), other->
                                                    FMGL(im)));
        
    }
    x10::lang::Complex x10__lang__Complex____this__x10__lang__Complex(
      ) {
        
        //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Complex.x10": x10.ast.X10Return_c
        return (*this);
        
    }
    void __fieldInitializers_x10_lang_Complex() {
     
    }
    
    static void _serialize(x10::lang::Complex this_, x10aux::serialization_buffer& buf);
    
    static x10::lang::Complex _deserialize(x10aux::deserialization_buffer& buf) {
        x10::lang::Complex this_;
        this_->_deserialize_body(buf);
        return this_;
    }
    
    void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_LANG_COMPLEX_H

namespace x10 { namespace lang { 
class Complex;
} } 

#ifndef X10_LANG_COMPLEX_H_NODEPS
#define X10_LANG_COMPLEX_H_NODEPS
#include <x10/lang/Any.h>
#include <x10/lang/Arithmetic.h>
#include <x10/lang/Double.h>
#include <x10/compiler/Native.h>
#include <x10/compiler/Inline.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Math.h>
#include <x10/lang/String.h>
#include <x10/compiler/NonEscaping.h>
#include <x10/lang/Int.h>
#ifndef X10_LANG_COMPLEX_H_GENERICS
#define X10_LANG_COMPLEX_H_GENERICS
#endif // X10_LANG_COMPLEX_H_GENERICS
#endif // __X10_LANG_COMPLEX_H_NODEPS
