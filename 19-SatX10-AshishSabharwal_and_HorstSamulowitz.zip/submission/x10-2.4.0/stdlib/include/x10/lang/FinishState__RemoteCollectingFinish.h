#ifndef __X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H
#define __X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H

#include <x10rt.h>


#define X10_LANG_FINISHSTATE__REMOTEFINISH_H_NODEPS
#include <x10/lang/FinishState__RemoteFinish.h>
#undef X10_LANG_FINISHSTATE__REMOTEFINISH_H_NODEPS
#define X10_LANG_FINISHSTATE__COLLECTINGFINISHSTATE_H_NODEPS
#include <x10/lang/FinishState__CollectingFinishState.h>
#undef X10_LANG_FINISHSTATE__COLLECTINGFINISHSTATE_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class FinishState__StatefulReducer;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRef;
} } 
namespace x10 { namespace lang { 
class FinishState;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Reducible;
} } 
namespace x10 { namespace util { namespace concurrent { 
class Lock;
} } } 
namespace x10 { namespace util { namespace concurrent { 
class AtomicInteger;
} } } 
namespace x10 { namespace lang { 
class MultipleExceptions;
} } 
namespace x10 { namespace lang { 
class FinishState__RemoteFinishSkeleton;
} } 
namespace x10 { namespace lang { 
class VoidFun_0_0;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace lang { 
class FinishState__RootFinish;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class FinishState__RootCollectingFinish;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace compiler { 
class RemoteInvocation;
} } 
namespace x10 { namespace util { 
template<class TPMGL(T), class TPMGL(U)> class Pair;
} } 
namespace x10 { namespace util { 
template<class TPMGL(T)> class GrowableRail;
} } 
namespace x10 { namespace lang { 
class Runtime__Profile;
} } 
namespace x10 { namespace lang { 
class FinishState__FinishStates;
} } 
namespace x10 { namespace lang { 

template<class TPMGL(T)> class FinishState__RemoteCollectingFinish;
template <> class FinishState__RemoteCollectingFinish<void>;
template<class TPMGL(T)> class FinishState__RemoteCollectingFinish : public x10::lang::FinishState__RemoteFinish
  {
    public:
    RTT_H_DECLS_CLASS
    
    static x10aux::itable_entry _itables[3];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::FinishState__CollectingFinishState<TPMGL(T)>::template itable<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> > _itable_1;
    
    x10::lang::FinishState__StatefulReducer<TPMGL(T)>* FMGL(sr);
    
    void _constructor(x10::lang::GlobalRef<x10::lang::FinishState* > ref,
                      x10::lang::Reducible<TPMGL(T)>* reducer);
    
    static x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>* _make(
             x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Reducible<TPMGL(T)>* reducer);
    
    virtual void accept(TPMGL(T) t, x10_int id);
    virtual void notifyActivityTermination();
    virtual x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>*
      x10__lang__FinishState__RemoteCollectingFinish____this__x10__lang__FinishState__RemoteCollectingFinish(
      );
    virtual void __fieldInitializers_x10_lang_FinishState_RemoteCollectingFinish(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::lang::FinishState__RemoteCollectingFinish<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::lang::FinishState__RemoteFinish>(), x10aux::getRTT<x10::lang::FinishState__CollectingFinishState<TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.lang.FinishState.RemoteCollectingFinish";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class FinishState__RemoteCollectingFinish<void> : public x10::lang::FinishState__RemoteFinish
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } 
#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H

namespace x10 { namespace lang { 
template<class TPMGL(T)> class FinishState__RemoteCollectingFinish;
} } 

#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_NODEPS
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_NODEPS
#include <x10/lang/FinishState__RemoteFinish.h>
#include <x10/lang/FinishState__CollectingFinishState.h>
#include <x10/lang/FinishState__StatefulReducer.h>
#include <x10/lang/GlobalRef.h>
#include <x10/lang/FinishState.h>
#include <x10/lang/Reducible.h>
#include <x10/lang/Int.h>
#include <x10/util/concurrent/Lock.h>
#include <x10/lang/Long.h>
#include <x10/lang/Boolean.h>
#include <x10/util/concurrent/AtomicInteger.h>
#include <x10/lang/MultipleExceptions.h>
#include <x10/lang/FinishState__RemoteFinishSkeleton.h>
#include <x10/lang/VoidFun_0_0.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Place.h>
#include <x10/lang/Unsafe.h>
#include <x10/lang/FinishState__RootFinish.h>
#include <x10/lang/FinishState__RootCollectingFinish.h>
#include <x10/lang/Exception.h>
#include <x10/compiler/RemoteInvocation.h>
#include <x10/util/Pair.h>
#include <x10/util/GrowableRail.h>
#include <x10/lang/Runtime__Profile.h>
#include <x10/lang/FinishState__FinishStates.h>
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_GENERICS
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_GENERICS
#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_GENERICS
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_IMPLEMENTATION
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_IMPLEMENTATION
#include <x10/lang/FinishState__RemoteCollectingFinish.h>

#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__25_CLOSURE
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__25_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_lang_FinishState__RemoteCollectingFinish__closure__25 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 847 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(x10::lang::FinishState::template deref<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* >(
                            ref))->notify(message, reinterpret_cast<x10::lang::Exception*>(t));
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::lang::FinishState* > ref;
    x10::lang::Rail<x10_int >* message;
    x10::lang::MultipleExceptions* t;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->ref);
        buf.write(this->message);
        buf.write(this->t);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >* storage = x10aux::alloc<x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::lang::FinishState* > that_ref = buf.read<x10::lang::GlobalRef<x10::lang::FinishState* > >();
        x10::lang::Rail<x10_int >* that_message = buf.read<x10::lang::Rail<x10_int >*>();
        x10::lang::MultipleExceptions* that_t = buf.read<x10::lang::MultipleExceptions*>();
        x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >* this_ = new (storage) x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >(that_ref, that_message, that_t);
        return this_;
    }
    
    x10_lang_FinishState__RemoteCollectingFinish__closure__25(x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Rail<x10_int >* message, x10::lang::MultipleExceptions* t) : ref(ref), message(message), t(t) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10:847";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) > >x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::__apply, &x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_GENERAL_ASYNC);

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__25_CLOSURE
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__26_CLOSURE
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__26_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_lang_FinishState__RemoteCollectingFinish__closure__26 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 849 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(x10::lang::FinishState::template deref<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* >(
                            ref))->notifyValue(message, result);
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::lang::FinishState* > ref;
    x10::lang::Rail<x10_int >* message;
    TPMGL(T) result;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->ref);
        buf.write(this->message);
        buf.write(this->result);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >* storage = x10aux::alloc<x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::lang::FinishState* > that_ref = buf.read<x10::lang::GlobalRef<x10::lang::FinishState* > >();
        x10::lang::Rail<x10_int >* that_message = buf.read<x10::lang::Rail<x10_int >*>();
        TPMGL(T) that_result = buf.read<TPMGL(T)>();
        x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >* this_ = new (storage) x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >(that_ref, that_message, that_result);
        return this_;
    }
    
    x10_lang_FinishState__RemoteCollectingFinish__closure__26(x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Rail<x10_int >* message, TPMGL(T) result) : ref(ref), message(message), result(result) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10:849";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) > >x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::__apply, &x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_GENERAL_ASYNC);

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__26_CLOSURE
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__27_CLOSURE
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__27_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_lang_FinishState__RemoteCollectingFinish__closure__27 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 857 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(x10::lang::FinishState::template deref<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* >(
                            ref))->notify(message, reinterpret_cast<x10::lang::Exception*>(t));
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::lang::FinishState* > ref;
    x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message;
    x10::lang::MultipleExceptions* t;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->ref);
        buf.write(this->message);
        buf.write(this->t);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >* storage = x10aux::alloc<x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::lang::FinishState* > that_ref = buf.read<x10::lang::GlobalRef<x10::lang::FinishState* > >();
        x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* that_message = buf.read<x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >*>();
        x10::lang::MultipleExceptions* that_t = buf.read<x10::lang::MultipleExceptions*>();
        x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >* this_ = new (storage) x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >(that_ref, that_message, that_t);
        return this_;
    }
    
    x10_lang_FinishState__RemoteCollectingFinish__closure__27(x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message, x10::lang::MultipleExceptions* t) : ref(ref), message(message), t(t) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10:857";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) > >x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::__apply, &x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_GENERAL_ASYNC);

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__27_CLOSURE
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__28_CLOSURE
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__28_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_lang_FinishState__RemoteCollectingFinish__closure__28 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 859 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(x10::lang::FinishState::template deref<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* >(
                            ref))->notifyValue(message, result);
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::lang::FinishState* > ref;
    x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message;
    TPMGL(T) result;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->ref);
        buf.write(this->message);
        buf.write(this->result);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >* storage = x10aux::alloc<x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::lang::FinishState* > that_ref = buf.read<x10::lang::GlobalRef<x10::lang::FinishState* > >();
        x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* that_message = buf.read<x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >*>();
        TPMGL(T) that_result = buf.read<TPMGL(T)>();
        x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >* this_ = new (storage) x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >(that_ref, that_message, that_result);
        return this_;
    }
    
    x10_lang_FinishState__RemoteCollectingFinish__closure__28(x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message, TPMGL(T) result) : ref(ref), message(message), result(result) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10:859";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) > >x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::__apply, &x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_GENERAL_ASYNC);

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__28_CLOSURE
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__29_CLOSURE
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__29_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_lang_FinishState__RemoteCollectingFinish__closure__29 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 868 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(x10::lang::FinishState::template deref<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* >(
                            ref))->notify(message, reinterpret_cast<x10::lang::Exception*>(t));
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::lang::FinishState* > ref;
    x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message;
    x10::lang::MultipleExceptions* t;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->ref);
        buf.write(this->message);
        buf.write(this->t);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >* storage = x10aux::alloc<x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::lang::FinishState* > that_ref = buf.read<x10::lang::GlobalRef<x10::lang::FinishState* > >();
        x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* that_message = buf.read<x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >*>();
        x10::lang::MultipleExceptions* that_t = buf.read<x10::lang::MultipleExceptions*>();
        x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >* this_ = new (storage) x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >(that_ref, that_message, that_t);
        return this_;
    }
    
    x10_lang_FinishState__RemoteCollectingFinish__closure__29(x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message, x10::lang::MultipleExceptions* t) : ref(ref), message(message), t(t) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10:868";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) > >x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::__apply, &x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_GENERAL_ASYNC);

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__29_CLOSURE
#ifndef X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__30_CLOSURE
#define X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__30_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_lang_FinishState__RemoteCollectingFinish__closure__30 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 870 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(x10::lang::FinishState::template deref<x10::lang::FinishState__RootCollectingFinish<TPMGL(T)>* >(
                            ref))->notifyValue(message, result);
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::lang::FinishState* > ref;
    x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message;
    TPMGL(T) result;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->ref);
        buf.write(this->message);
        buf.write(this->result);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >* storage = x10aux::alloc<x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::lang::FinishState* > that_ref = buf.read<x10::lang::GlobalRef<x10::lang::FinishState* > >();
        x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* that_message = buf.read<x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >*>();
        TPMGL(T) that_result = buf.read<TPMGL(T)>();
        x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >* this_ = new (storage) x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >(that_ref, that_message, that_result);
        return this_;
    }
    
    x10_lang_FinishState__RemoteCollectingFinish__closure__30(x10::lang::GlobalRef<x10::lang::FinishState* > ref, x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message, TPMGL(T) result) : ref(ref), message(message), result(result) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10:870";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) > >x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::__apply, &x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_GENERAL_ASYNC);

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH__CLOSURE__30_CLOSURE
template<class TPMGL(T)> typename x10::lang::FinishState__CollectingFinishState<TPMGL(T)>::template itable<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> >  x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_itable_0(&x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::accept, &x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> >  x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_itables[3] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::FinishState__CollectingFinishState<TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> >())};

//#line 820 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10FieldDecl_c

//#line 821 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_constructor(
                           x10::lang::GlobalRef<x10::lang::FinishState* > ref,
                           x10::lang::Reducible<TPMGL(T)>* reducer) {
    
    //#line 822 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::lang::FinishState__RemoteFinish::_constructor(
      ref);
    
    //#line 821 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.AssignPropertyCall_c
    
    //#line 819 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>* this58528 =
      this;
    
    //#line 823 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(sr) = (__extension__ ({
        
        //#line 823 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState__StatefulReducer<TPMGL(T)>* alloc55355 =
           ((new (memset(x10aux::alloc<x10::lang::FinishState__StatefulReducer<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__StatefulReducer<TPMGL(T)>))) x10::lang::FinishState__StatefulReducer<TPMGL(T)>()))
        ;
        
        //#line 823 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10ConstructorCall_c
        (alloc55355)->::x10::lang::FinishState__StatefulReducer<TPMGL(T)>::_constructor(
          reducer);
        alloc55355;
    }))
    ;
}
template<class TPMGL(T)> x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>* x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_make(
                           x10::lang::GlobalRef<x10::lang::FinishState* > ref,
                           x10::lang::Reducible<TPMGL(T)>* reducer)
{
    x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>))) x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>();
    this_->_constructor(ref, reducer);
    return this_;
}



//#line 825 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::accept(
  TPMGL(T) t, x10_int id) {
    
    //#line 826 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->accept(t, id);
}

//#line 828 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::notifyActivityTermination(
  ) {
    
    //#line 829 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(lock))->lock();
    
    //#line 830 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>* x58537 =
      this;
    
    //#line 830 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(x58537)->FMGL(count) = ((x10_int) ((x10aux::nullCheck(x58537)->
                                                            FMGL(count)) - (((x10_int)1))));
    
    //#line 831 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
    if (((((x10_long) (this->FMGL(local)->x10::util::concurrent::AtomicInteger::decrementAndGet()))) > (((x10_long)0ll))))
    {
        
        //#line 832 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(this->FMGL(lock))->unlock();
        
        //#line 833 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
        return;
    }
    
    //#line 835 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10::lang::MultipleExceptions* t = x10::lang::MultipleExceptions::make(
                                         this->FMGL(exceptions));
    
    //#line 836 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRef<x10::lang::FinishState* > ref = this->ref();
    
    //#line 837 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    x10::lang::VoidFun_0_0* closure;
    
    //#line 838 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->placeMerge();
    
    //#line 839 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) result = x10aux::nullCheck(this->FMGL(sr))->result();
    
    //#line 840 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(sr))->reset();
    
    //#line 841 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(this->FMGL(counts), reinterpret_cast<x10::lang::NullType*>(X10_NULL))) &&
        (!x10aux::struct_equals((x10_long)(x10aux::nullCheck(this->
                                                               FMGL(counts))->FMGL(size)),
                                ((x10_long)0ll)))) {
        
        //#line 842 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(this->FMGL(counts))->x10::lang::template Rail<x10_int >::__set(
          ((x10_long)x10aux::here), this->FMGL(count));
        
        //#line 843 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
        if (((((x10_long) ((((x10_long)2ll)) * (((x10_long) (this->
                                                               FMGL(length))))))) > (((x10_long)x10aux::num_hosts))))
        {
            
            //#line 844 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<x10_int >* message = x10::lang::Rail<x10_int >::_makeUnsafe((x10_long)(x10aux::nullCheck(this->
                                                                                                                       FMGL(counts))->FMGL(size)), false);
            
            //#line 845 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
            x10::lang::Rail<void >::template copy<x10_int >(
              this->FMGL(counts), ((x10_long)0ll), message,
              ((x10_long)0ll), (x10_long)(x10aux::nullCheck(this->
                                                              FMGL(counts))->FMGL(size)));
            
            //#line 846 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::NullType*>(X10_NULL),
                                        t))) {
                
                //#line 847 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
                closure = reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T)>)))x10_lang_FinishState__RemoteCollectingFinish__closure__25<TPMGL(T)>(ref, message, t)));
            } else {
                
                //#line 849 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
                closure = reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T)>)))x10_lang_FinishState__RemoteCollectingFinish__closure__26<TPMGL(T)>(ref, message, result)));
            }
            
        } else {
            
            //#line 852 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message =
              x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >::_makeUnsafe(((x10_long) (this->
                                                                                              FMGL(length))), false);
            
            //#line 853 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
            x10_long i55408max58532 = ((x10_long) ((((x10_long) (this->
                                                                   FMGL(length)))) - (((x10_long)1ll))));
            
            //#line 853 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": polyglot.ast.For_c
            {
                x10_long i58533;
                for (
                     //#line 853 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
                     i58533 = ((x10_long)0ll); ((i58533) <= (i55408max58532));
                     
                     //#line 853 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
                     i58533 = ((x10_long) ((i58533) + (((x10_long)1ll)))))
                {
                    
                    //#line 853 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
                    x10_long i58534 = i58533;
                    
                    //#line 854 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
                    message->x10::lang::template Rail<x10::util::Pair<x10_int, x10_int> >::__set(
                      i58534, (__extension__ ({
                          
                          //#line 854 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
                          x10::util::Pair<x10_int, x10_int> alloc58531 =
                             x10::util::Pair<x10_int, x10_int>::_alloc();
                          
                          //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": x10.ast.X10LocalDecl_c
                          x10_int first58529 = x10aux::nullCheck(this->
                                                                   FMGL(places))->x10::lang::template Rail<x10_int >::__apply(
                                                 i58534);
                          
                          //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": x10.ast.X10LocalDecl_c
                          x10_int second58530 = x10aux::nullCheck(this->
                                                                    FMGL(counts))->x10::lang::template Rail<x10_int >::__apply(
                                                  ((x10_long) (x10aux::nullCheck(this->
                                                                                   FMGL(places))->x10::lang::template Rail<x10_int >::__apply(
                                                                 i58534))));
                          
                          //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": Eval of x10.ast.X10FieldAssign_c
                          alloc58531->FMGL(first) = first58529;
                          
                          //#line 23 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": Eval of x10.ast.X10FieldAssign_c
                          alloc58531->FMGL(second) = second58530;
                          alloc58531;
                      }))
                      );
                }
            }
            
            //#line 856 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::NullType*>(X10_NULL),
                                        t))) {
                
                //#line 857 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
                closure = reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T)>)))x10_lang_FinishState__RemoteCollectingFinish__closure__27<TPMGL(T)>(ref, message, t)));
            } else {
                
                //#line 859 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
                closure = reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T)>)))x10_lang_FinishState__RemoteCollectingFinish__closure__28<TPMGL(T)>(ref, message, result)));
            }
            
        }
        
        //#line 862 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        x10aux::nullCheck(this->FMGL(counts))->x10::lang::template Rail<x10_int >::clear(
          ((x10_long)0ll), (x10_long)(x10aux::nullCheck(this->
                                                          FMGL(counts))->FMGL(size)));
        
        //#line 863 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(length) = ((x10_int)1);
    } else {
        
        //#line 865 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >* message =
          x10::lang::Rail<x10::util::Pair<x10_int, x10_int> >::_makeUnsafe(((x10_long)1ll), false);
        
        //#line 866 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
        message->x10::lang::template Rail<x10::util::Pair<x10_int, x10_int> >::__set(
          ((x10_long)0ll), (__extension__ ({
              
              //#line 866 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10LocalDecl_c
              x10::util::Pair<x10_int, x10_int> alloc55357 =
                 x10::util::Pair<x10_int, x10_int>::_alloc();
              
              //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": x10.ast.X10LocalDecl_c
              x10_int first58535 = x10aux::here;
              
              //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": x10.ast.X10LocalDecl_c
              x10_int second58536 = this->FMGL(count);
              
              //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": Eval of x10.ast.X10FieldAssign_c
              alloc55357->FMGL(first) = first58535;
              
              //#line 23 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/Pair.x10": Eval of x10.ast.X10FieldAssign_c
              alloc55357->FMGL(second) = second58536;
              alloc55357;
          }))
          );
        
        //#line 867 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10If_c
        if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::NullType*>(X10_NULL),
                                    t))) {
            
            //#line 868 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
            closure = reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T)>)))x10_lang_FinishState__RemoteCollectingFinish__closure__29<TPMGL(T)>(ref, message, t)));
        } else {
            
            //#line 870 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10LocalAssign_c
            closure = reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T)>)))x10_lang_FinishState__RemoteCollectingFinish__closure__30<TPMGL(T)>(ref, message, result)));
        }
        
    }
    
    //#line 873 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(count) = ((x10_int)0);
    
    //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(exceptions) = (x10aux::class_cast_unchecked<x10::util::GrowableRail<x10::lang::Exception*>*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 875 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this->FMGL(lock))->unlock();
    
    //#line 876 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::run_closure_at((x10_int)x10::lang::Place::place((ref)->location)->
                                      FMGL(id), closure, x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 877 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10aux::dealloc(closure);
    
    //#line 878 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": Eval of x10.ast.X10Call_c
    x10::lang::Runtime::FMGL(finishStates__get)()->remove(
      ref);
}

//#line 819 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>*
  x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::x10__lang__FinishState__RemoteCollectingFinish____this__x10__lang__FinishState__RemoteCollectingFinish(
  ) {
    
    //#line 819 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 819 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/FinishState.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::__fieldInitializers_x10_lang_FinishState_RemoteCollectingFinish(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::lang::FinishState__RemoteFinish::_serialize_body(buf);
    buf.write(this->FMGL(sr));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)> >(), 0, sizeof(x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>))) x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::lang::FinishState__RemoteCollectingFinish<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::lang::FinishState__RemoteFinish::_deserialize_body(buf);
    FMGL(sr) = buf.read<x10::lang::FinishState__StatefulReducer<TPMGL(T)>*>();
}

#endif // X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_IMPLEMENTATION
#endif // __X10_LANG_FINISHSTATE__REMOTECOLLECTINGFINISH_H_NODEPS
