#ifndef __X10_LANG_GLOBALRAIL_H
#define __X10_LANG_GLOBALRAIL_H

#include <x10rt.h>

#include "x10/lang/RemoteOps.h"

#define X10_LANG_ANY_H_NODEPS
#include <x10/lang/Any.h>
#undef X10_LANG_ANY_H_NODEPS
#define X10_LANG_ANY_H_NODEPS
#include <x10/lang/Any.h>
#undef X10_LANG_ANY_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_GLOBALREF_H_NODEPS
#include <x10/lang/GlobalRef.h>
#undef X10_LANG_GLOBALREF_H_NODEPS
#define X10_LANG_GLOBALREF_H_NODEPS
#include <x10/lang/GlobalRef.h>
#undef X10_LANG_GLOBALREF_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace compiler { 
class NonEscaping;
} } 
namespace x10 { namespace compiler { 
class NativeCPPInclude;
} } 
namespace x10 { namespace lang { 

template<class TPMGL(T)> class GlobalRail   {
    public:
    RTT_H_DECLS_STRUCT
    
    x10::lang::GlobalRail<TPMGL(T)>* operator->() { return this; }
    
    x10_long FMGL(size);
    
    x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > FMGL(rail);
    
    static x10aux::itable_entry _itables[2];
    
    x10aux::itable_entry* _getITables() { return _itables; }
    
    static x10::lang::Any::itable<x10::lang::GlobalRail<TPMGL(T)> > _itable_0;
    
    static x10aux::itable_entry _iboxitables[2];
    
    x10aux::itable_entry* _getIBoxITables() { return _iboxitables; }
    
    static x10::lang::GlobalRail<TPMGL(T)> _alloc(){x10::lang::GlobalRail<TPMGL(T)> t; return t; }
    
    x10::lang::Place home();
    void _constructor(x10::lang::Rail<TPMGL(T) >* a);
    
    static x10::lang::GlobalRail<TPMGL(T)> _make(x10::lang::Rail<TPMGL(T) >* a);
    
    void _constructor(x10_long size, x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > raw);
    
    static x10::lang::GlobalRail<TPMGL(T)> _make(x10_long size, x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > raw);
    
    TPMGL(T) __apply(x10_long index);
    TPMGL(T) __set(x10_long index, TPMGL(T) v);
    x10::lang::Rail<TPMGL(T) >* __apply();
    x10::lang::String* typeName();
    x10::lang::String* toString();
    x10_int hashCode();
    x10_boolean equals(x10::lang::Any* other);
    x10_boolean equals(x10::lang::GlobalRail<TPMGL(T)> other);
    x10_boolean _struct_equals(x10::lang::Any* other);
    x10_boolean _struct_equals(x10::lang::GlobalRail<TPMGL(T)> other);
    x10::lang::GlobalRail<TPMGL(T)> x10__lang__GlobalRail____this__x10__lang__GlobalRail(
      );
    void __fieldInitializers_x10_lang_GlobalRail();
    
    static void _serialize(x10::lang::GlobalRail<TPMGL(T)> this_, x10aux::serialization_buffer& buf);
    
    static x10::lang::GlobalRail<TPMGL(T)> _deserialize(x10aux::deserialization_buffer& buf) {
        x10::lang::GlobalRail<TPMGL(T)> this_;
        this_->_deserialize_body(buf);
        return this_;
    }
    
    void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::lang::GlobalRail<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::lang::GlobalRail<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::lang::GlobalRail<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::lang::Any>(), x10aux::getRTT<x10::lang::Any>()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.lang.GlobalRail";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::struct_kind, 2, parents, 1, params, variances);
}

template <> class GlobalRail<void> {
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } 
#endif // X10_LANG_GLOBALRAIL_H

namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRail;
} } 

#ifndef X10_LANG_GLOBALRAIL_H_NODEPS
#define X10_LANG_GLOBALRAIL_H_NODEPS
#include <x10/lang/Any.h>
#include <x10/lang/Long.h>
#include <x10/lang/GlobalRef.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Place.h>
#include <x10/lang/Runtime.h>
#include <x10/compiler/Native.h>
#include <x10/lang/ULong.h>
#include <x10/lang/String.h>
#include <x10/compiler/NonEscaping.h>
#include <x10/lang/Int.h>
#include <x10/lang/Boolean.h>
#include <x10/compiler/NativeCPPInclude.h>
#ifndef X10_LANG_GLOBALRAIL_H_GENERICS
#define X10_LANG_GLOBALRAIL_H_GENERICS
#endif // X10_LANG_GLOBALRAIL_H_GENERICS
#ifndef X10_LANG_GLOBALRAIL_H_IMPLEMENTATION
#define X10_LANG_GLOBALRAIL_H_IMPLEMENTATION
#include <x10/lang/GlobalRail.h>


//#line 33 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.PropertyDecl_c

//#line 37 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.PropertyDecl_c
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRail_ibox0 : public x10::lang::IBox<x10::lang::GlobalRail<TPMGL(T)> > {
public:
    static x10::lang::Any::itable<GlobalRail_ibox0<TPMGL(T)> > itable;
    x10_boolean equals(x10::lang::Any* arg0) {
        return this->value->equals(arg0);
    }
    x10_int hashCode() {
        return this->value->hashCode();
    }
    x10::lang::String* toString() {
        return this->value->toString();
    }
    x10::lang::String* typeName() {
        return this->value->typeName();
    }
    
};
template<class TPMGL(T)> x10::lang::Any::itable<GlobalRail_ibox0<TPMGL(T)> >  GlobalRail_ibox0<TPMGL(T)>::itable(&GlobalRail_ibox0<TPMGL(T)>::equals, &GlobalRail_ibox0<TPMGL(T)>::hashCode, &GlobalRail_ibox0<TPMGL(T)>::toString, &GlobalRail_ibox0<TPMGL(T)>::typeName);
} } 
template<class TPMGL(T)> x10::lang::Any::itable<x10::lang::GlobalRail<TPMGL(T)> >  x10::lang::GlobalRail<TPMGL(T)>::_itable_0(&x10::lang::GlobalRail<TPMGL(T)>::equals, &x10::lang::GlobalRail<TPMGL(T)>::hashCode, &x10::lang::GlobalRail<TPMGL(T)>::toString, &x10::lang::GlobalRail<TPMGL(T)>::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::lang::GlobalRail<TPMGL(T)>::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &x10::lang::GlobalRail<TPMGL(T)>::_itable_0), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::lang::GlobalRail<TPMGL(T)> >())};
template<class TPMGL(T)> x10aux::itable_entry x10::lang::GlobalRail<TPMGL(T)>::_iboxitables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &x10::lang::GlobalRail_ibox0<TPMGL(T)>::itable), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::lang::GlobalRail<TPMGL(T)> >())};

//#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Place x10::lang::GlobalRail<TPMGL(T)>::home(
  ) {
    
    //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return x10::lang::Place::place(((*this)->FMGL(rail))->location);
    
}

//#line 49 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::lang::GlobalRail<TPMGL(T)>::_constructor(
                           x10::lang::Rail<TPMGL(T) >* a) {
    
    //#line 50 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.AssignPropertyCall_c
    FMGL(size) = (x10_long)(x10aux::nullCheck(a)->FMGL(size));
    FMGL(rail) = x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* >::_make(a);
    
    //#line 28 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRail<TPMGL(T)> this58704 = (*this);
    
}
template<class TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)>::_make(
                           x10::lang::Rail<TPMGL(T) >* a) {
    x10::lang::GlobalRail<TPMGL(T)> this_; 
    this_->_constructor(a);
    return this_;
}



//#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::lang::GlobalRail<TPMGL(T)>::_constructor(
                           x10_long size, x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > raw) {
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.AssignPropertyCall_c
    FMGL(size) = size;
    FMGL(rail) = raw;
    
    //#line 28 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRail<TPMGL(T)> this58705 = (*this);
    
}
template<class TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)>::_make(
                           x10_long size, x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > raw)
{
    x10::lang::GlobalRail<TPMGL(T)> this_; 
    this_->_constructor(size, raw);
    return this_;
}



//#line 71 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::lang::GlobalRail<TPMGL(T)>::__apply(
  x10_long index) {
    
    //#line 72 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (*this)->x10::lang::template GlobalRail<TPMGL(T)>::__apply()->x10::lang::template Rail<TPMGL(T) >::__apply(
             index);
    
}

//#line 83 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::lang::GlobalRail<TPMGL(T)>::__set(
  x10_long index, TPMGL(T) v) {
    
    //#line 84 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (*this)->x10::lang::template GlobalRail<TPMGL(T)>::__apply()->x10::lang::template Rail<TPMGL(T) >::__set(
             index, v);
    
}

//#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::lang::GlobalRail<TPMGL(T)>::__apply(
  ) {
    
    //#line 91 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return ((*this)->FMGL(rail))->__apply();
    
}

//#line 97 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 101 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 109 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 117 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::lang::GlobalRail<TPMGL(T)>::typeName(
  ){
    return x10aux::type_name((*this));
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::lang::GlobalRail<TPMGL(T)>::toString(
  ) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("struct x10.lang.GlobalRail:"), x10aux::makeStringLit(" size=")), (*this)->
                                                                                                                                                                                                             FMGL(size)), x10aux::makeStringLit(" rail=")), (*this)->
                                                                                                                                                                                                                                                              FMGL(rail));
    
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_int x10::lang::GlobalRail<TPMGL(T)>::hashCode(
  ) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10LocalDecl_c
    x10_int result = ((x10_int)1);
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": Eval of x10.ast.X10LocalAssign_c
    result = ((x10_int) ((((x10_int) ((((x10_int)8191)) * (result)))) + (x10aux::hash_code((*this)->
                                                                                             FMGL(size)))));
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": Eval of x10.ast.X10LocalAssign_c
    result = ((x10_int) ((((x10_int) ((((x10_int)8191)) * (result)))) + (((*this)->
                                                                            FMGL(rail))->hashCode())));
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return result;
    
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_boolean x10::lang::GlobalRail<TPMGL(T)>::equals(
  x10::lang::Any* other) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10If_c
    if (!(x10aux::instanceof<x10::lang::GlobalRail<TPMGL(T)> >(other)))
    {
        
        //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
        return false;
        
    }
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (*this)->x10::lang::template GlobalRail<TPMGL(T)>::equals(
             x10aux::class_cast<x10::lang::GlobalRail<TPMGL(T)> >(other));
    
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_boolean x10::lang::GlobalRail<TPMGL(T)>::equals(
  x10::lang::GlobalRail<TPMGL(T)> other) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (x10aux::struct_equals((*this)->FMGL(size), other->
                                                         FMGL(size))) &&
    (x10aux::struct_equals((*this)->FMGL(rail), other->FMGL(rail)));
    
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_boolean x10::lang::GlobalRail<TPMGL(T)>::_struct_equals(
  x10::lang::Any* other) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10If_c
    if (!(x10aux::instanceof<x10::lang::GlobalRail<TPMGL(T)> >(other)))
    {
        
        //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
        return false;
        
    }
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (*this)->x10::lang::template GlobalRail<TPMGL(T)>::_struct_equals(
             x10aux::class_cast<x10::lang::GlobalRail<TPMGL(T)> >(other));
    
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_boolean x10::lang::GlobalRail<TPMGL(T)>::_struct_equals(
  x10::lang::GlobalRail<TPMGL(T)> other) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (x10aux::struct_equals((*this)->FMGL(size), other->
                                                         FMGL(size))) &&
    (x10aux::struct_equals((*this)->FMGL(rail), other->FMGL(rail)));
    
}

//#line 28 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)> x10::lang::GlobalRail<TPMGL(T)>::x10__lang__GlobalRail____this__x10__lang__GlobalRail(
  ) {
    
    //#line 28 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10Return_c
    return (*this);
    
}

//#line 28 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/GlobalRail.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::lang::GlobalRail<TPMGL(T)>::__fieldInitializers_x10_lang_GlobalRail(
  ) {
 
}
template<class TPMGL(T)> void x10::lang::GlobalRail<TPMGL(T)>::_serialize(x10::lang::GlobalRail<TPMGL(T)> this_, x10aux::serialization_buffer& buf) {
    buf.write(this_->FMGL(size));
    buf.write(this_->FMGL(rail));
    
}

template<class TPMGL(T)> void x10::lang::GlobalRail<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(size) = buf.read<x10_long>();
    FMGL(rail) = buf.read<x10::lang::GlobalRef<x10::lang::Rail<TPMGL(T) >* > >();
}


#endif // X10_LANG_GLOBALRAIL_H_IMPLEMENTATION
#endif // __X10_LANG_GLOBALRAIL_H_NODEPS
