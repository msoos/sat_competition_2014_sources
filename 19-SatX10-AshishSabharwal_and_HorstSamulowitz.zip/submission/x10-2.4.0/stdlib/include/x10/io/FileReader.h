#ifndef __X10_IO_FILEREADER_H
#define __X10_IO_FILEREADER_H

#include <x10rt.h>


#define X10_IO_INPUTSTREAMREADER_H_NODEPS
#include <x10/io/InputStreamReader.h>
#undef X10_IO_INPUTSTREAMREADER_H_NODEPS
namespace x10 { namespace io { 
class File;
} } 
namespace x10 { namespace io { 
class InputStreamReader__InputStream;
} } 
namespace x10 { namespace io { 
class FileReader__FileInputStream;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace io { 

class FileReader : public x10::io::InputStreamReader   {
    public:
    RTT_H_DECLS_CLASS
    
    x10::io::File* FMGL(file);
    
    void _constructor(x10::io::File* file);
    
    static x10::io::FileReader* _make(x10::io::File* file);
    
    virtual x10::io::FileReader* x10__io__FileReader____this__x10__io__FileReader(
      );
    virtual void __fieldInitializers_x10_io_FileReader();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } 
#endif // X10_IO_FILEREADER_H

namespace x10 { namespace io { 
class FileReader;
} } 

#ifndef X10_IO_FILEREADER_H_NODEPS
#define X10_IO_FILEREADER_H_NODEPS
#ifndef X10_IO_FILEREADER_H_GENERICS
#define X10_IO_FILEREADER_H_GENERICS
#endif // X10_IO_FILEREADER_H_GENERICS
#endif // __X10_IO_FILEREADER_H_NODEPS
