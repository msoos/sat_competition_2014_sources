#ifndef __X10_COMPILER_WS_COLLECTINGFINISH_H
#define __X10_COMPILER_WS_COLLECTINGFINISH_H

#include <x10rt.h>


#define X10_COMPILER_WS_FINISHFRAME_H_NODEPS
#include <x10/compiler/ws/FinishFrame.h>
#undef X10_COMPILER_WS_FINISHFRAME_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Reducible;
} } 
namespace x10 { namespace compiler { 
class Uninitialized;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class Ifdef;
} } 
namespace x10 { namespace compiler { namespace ws { 
class Frame;
} } } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace util { 
template<class TPMGL(T)> class GrowableRail;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace util { namespace concurrent { 
class Lock;
} } } 
namespace x10 { namespace lang { 
class CheckedThrowable;
} } 
namespace x10 { namespace compiler { 
class Finalization;
} } 
namespace x10 { namespace compiler { 
class Abort;
} } 
namespace x10 { namespace compiler { 
class CompilerFlags;
} } 
namespace x10 { namespace compiler { namespace ws { 
class Worker;
} } } 
namespace x10 { namespace compiler { namespace ws { 

template<class TPMGL(T)> class CollectingFinish;
template <> class CollectingFinish<void>;
template<class TPMGL(T)> class CollectingFinish : public x10::compiler::ws::FinishFrame
  {
    public:
    RTT_H_DECLS_CLASS
    
    x10::lang::Reducible<TPMGL(T)>* FMGL(reducer);
    
    x10::lang::Rail<TPMGL(T) >* FMGL(resultRail);
    
    TPMGL(T) FMGL(result);
    
    void _constructor(x10::compiler::ws::Frame* up, x10::lang::Reducible<TPMGL(T)>* rd);
    
    void _constructor(x10_int x, x10::compiler::ws::CollectingFinish<TPMGL(T)>* o);
    
    virtual x10::compiler::ws::Frame* realloc();
    virtual void accept(TPMGL(T) t, x10::compiler::ws::Worker* worker);
    virtual TPMGL(T) fastResult(x10::compiler::ws::Worker* worker);
    virtual TPMGL(T) result();
    virtual x10::compiler::ws::CollectingFinish<TPMGL(T)>* x10__compiler__ws__CollectingFinish____this__x10__compiler__ws__CollectingFinish(
      );
    virtual void __fieldInitializers_x10_compiler_ws_CollectingFinish(
      );
    
    // Serialization
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::compiler::ws::CollectingFinish<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::compiler::ws::CollectingFinish<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::compiler::ws::FinishFrame>()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.compiler.ws.CollectingFinish";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 1, parents, 1, params, variances);
}

template <> class CollectingFinish<void> : public x10::compiler::ws::FinishFrame
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } } 
#endif // X10_COMPILER_WS_COLLECTINGFINISH_H

namespace x10 { namespace compiler { namespace ws { 
template<class TPMGL(T)> class CollectingFinish;
} } } 

#ifndef X10_COMPILER_WS_COLLECTINGFINISH_H_NODEPS
#define X10_COMPILER_WS_COLLECTINGFINISH_H_NODEPS
#include <x10/compiler/ws/FinishFrame.h>
#include <x10/lang/Reducible.h>
#include <x10/compiler/Uninitialized.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/Ifdef.h>
#include <x10/compiler/ws/Frame.h>
#include <x10/lang/Int.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Unsafe.h>
#include <x10/lang/Long.h>
#include <x10/lang/Boolean.h>
#include <x10/util/GrowableRail.h>
#include <x10/lang/Exception.h>
#include <x10/util/concurrent/Lock.h>
#include <x10/lang/CheckedThrowable.h>
#include <x10/compiler/Finalization.h>
#include <x10/compiler/Abort.h>
#include <x10/compiler/CompilerFlags.h>
#include <x10/compiler/ws/Worker.h>
#ifndef X10_COMPILER_WS_COLLECTINGFINISH_H_GENERICS
#define X10_COMPILER_WS_COLLECTINGFINISH_H_GENERICS
#endif // X10_COMPILER_WS_COLLECTINGFINISH_H_GENERICS
#ifndef X10_COMPILER_WS_COLLECTINGFINISH_H_IMPLEMENTATION
#define X10_COMPILER_WS_COLLECTINGFINISH_H_IMPLEMENTATION
#include <x10/compiler/ws/CollectingFinish.h>


//#line 15 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10FieldDecl_c

//#line 16 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10FieldDecl_c

//#line 17 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10FieldDecl_c

//#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::_constructor(
                           x10::compiler::ws::Frame* up, x10::lang::Reducible<TPMGL(T)>* rd) {
    
    //#line 20 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::compiler::ws::FinishFrame::_constructor(up);
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.AssignPropertyCall_c
    
    //#line 14 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
    x10::compiler::ws::CollectingFinish<TPMGL(T)>* this51805 = this;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(reducer) = rd;
    {
        
        //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(result) = x10::lang::Reducible<TPMGL(T)>::zero(x10aux::nullCheck(rd));
    }
}


//#line 32 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::_constructor(
                           x10_int x, x10::compiler::ws::CollectingFinish<TPMGL(T)>* o) {
    
    //#line 34 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::compiler::ws::FinishFrame::_constructor(
      x, reinterpret_cast<x10::compiler::ws::FinishFrame*>(o));
    
    //#line 32 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.AssignPropertyCall_c
    
    //#line 14 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
    x10::compiler::ws::CollectingFinish<TPMGL(T)>* this51806 =
      this;
    
    //#line 36 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(reducer) = x10aux::nullCheck(o)->FMGL(reducer);
    
    //#line 37 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
    x10_int size = x10::lang::Runtime::FMGL(NTHREADS__get)();
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(resultRail) = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(((x10_long) (size)), false);
    
    //#line 39 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": polyglot.ast.For_c
    {
        x10_int i;
        for (
             //#line 39 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
             i = ((x10_int)0); ((i) < (size)); 
                                               //#line 39 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10LocalAssign_c
                                               i = ((x10_int) ((i) + (((x10_int)1)))))
        {
            
            //#line 40 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(this->FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__set(
              ((x10_long) (i)), x10::lang::Reducible<TPMGL(T)>::zero(x10aux::nullCheck(this->
                                                                                         FMGL(reducer))));
        }
    }
    
}


//#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::compiler::ws::Frame* x10::compiler::ws::CollectingFinish<TPMGL(T)>::realloc(
  ) {
    
    //#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::NullType*>(X10_NULL),
                                this->FMGL(redirect)))) {
        
        //#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10Return_c
        return reinterpret_cast<x10::compiler::ws::Frame*>(this->
                                                             FMGL(redirect));
        
    }
    
    //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
    x10::compiler::ws::FinishFrame* tmp = reinterpret_cast<x10::compiler::ws::FinishFrame*>(this->remap());
    
    //#line 48 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(tmp)->FMGL(redirect) = tmp;
    
    //#line 49 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::NullType*>(X10_NULL),
                                this->FMGL(exceptions))))
    {
        
        //#line 50 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
        x10aux::nullCheck(tmp)->FMGL(exceptions) = (__extension__ ({
            
            //#line 50 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
            x10::util::GrowableRail<x10::lang::Exception*>* alloc51675 =
               ((new (memset(x10aux::alloc<x10::util::GrowableRail<x10::lang::Exception*> >(), 0, sizeof(x10::util::GrowableRail<x10::lang::Exception*>))) x10::util::GrowableRail<x10::lang::Exception*>()))
            ;
            
            //#line 50 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/GrowableRail.x10": x10.ast.X10ConstructorCall_c
            (alloc51675)->::x10::util::GrowableRail<x10::lang::Exception*>::_constructor(
              ((x10_long)0ll));
            alloc51675;
        }))
        ;
        
        //#line 51 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::FMGL(atomicMonitor__get)()->lock();
        
        //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10While_c
        while (!((__extension__ ({
                   
                   //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
                   x10::util::GrowableRail<x10::lang::Exception*>* this51804 =
                     this->FMGL(exceptions);
                   (x10aux::struct_equals(x10aux::nullCheck(this51804)->
                                            FMGL(size), ((x10_long)0ll)));
               }))
               )) {
            
            //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(x10aux::nullCheck(tmp)->FMGL(exceptions))->x10::util::template GrowableRail<x10::lang::Exception*>::add(
              x10aux::nullCheck(this->FMGL(exceptions))->x10::util::template GrowableRail<x10::lang::Exception*>::removeLast());
        }
        
        //#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(exceptions) = (x10aux::class_cast_unchecked<x10::util::GrowableRail<x10::lang::Exception*>*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
        
        //#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::FMGL(atomicMonitor__get)()->unlock();
    }
    {
        
        //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
        x10::lang::CheckedThrowable* throwable51807 = x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
        
        //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": polyglot.ast.Try_c
        try {
            {
                
                //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
                x10::lang::Runtime::enterAtomic();
                {
                    
                    //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
                    this->FMGL(redirect) = tmp;
                }
            }
            
            //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
            x10::compiler::Finalization::plausibleThrow();
        }
        catch (x10::lang::CheckedThrowable* __exc201) {
            if (true) {
                x10::lang::CheckedThrowable* formal51808 =
                  static_cast<x10::lang::CheckedThrowable*>(__exc201);
                {
                    
                    //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10LocalAssign_c
                    throwable51807 = formal51808;
                }
            } else
            throw;
        }
        
        //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
        if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                    throwable51807))) {
            
            //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
            if (x10aux::instanceof<x10::compiler::Abort*>(throwable51807))
            {
                
                //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(throwable51807));
            }
            
        }
        
        //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
        if (true) {
            
            //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
            x10::lang::Runtime::exitAtomic();
        }
        
        //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
        if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                    throwable51807))) {
            
            //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
            if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable51807)))
            {
                
                //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(throwable51807));
            }
            
        }
        
    }
    
    //#line 58 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(reinterpret_cast<x10::compiler::ws::CollectingFinish<TPMGL(T)>* >(tmp))->
      FMGL(result) = this->FMGL(result);
    
    //#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10Return_c
    return reinterpret_cast<x10::compiler::ws::Frame*>(tmp);
    
}

//#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::accept(
  TPMGL(T) t, x10::compiler::ws::Worker* worker) {
    {
        
        //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10If_c
        if ((x10aux::struct_equals(this->FMGL(redirect), reinterpret_cast<x10::lang::NullType*>(X10_NULL))))
        {
            
            //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
            this->FMGL(result) = x10::lang::Reducible<TPMGL(T)>::__apply(x10aux::nullCheck(this->
                                                                                             FMGL(reducer)), 
                                   this->FMGL(result), t);
        } else {
            
            //#line 68 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
            x10_int id = x10aux::nullCheck(worker)->FMGL(id);
            
            //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* rr = x10aux::nullCheck(reinterpret_cast<x10::compiler::ws::CollectingFinish<TPMGL(T)>* >(this->
                                                                                                                                   FMGL(redirect)))->
                                               FMGL(resultRail);
            
            //#line 70 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(rr)->x10::lang::template Rail<TPMGL(T) >::__set(
              ((x10_long) (id)), x10::lang::Reducible<TPMGL(T)>::__apply(x10aux::nullCheck(this->
                                                                                             FMGL(reducer)), 
                                   x10aux::nullCheck(rr)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                     ((x10_long) (id))), t));
        }
        
    }
}

//#line 80 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::compiler::ws::CollectingFinish<TPMGL(T)>::fastResult(
  x10::compiler::ws::Worker* worker) {
    {
        
        //#line 82 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10Return_c
        return this->FMGL(result);
        
    }
}

//#line 92 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::compiler::ws::CollectingFinish<TPMGL(T)>::result(
  ) {
    {
        
        //#line 95 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
        x10_int size = x10::lang::Runtime::FMGL(NTHREADS__get)();
        
        //#line 96 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": polyglot.ast.For_c
        {
            x10_int i;
            for (
                 //#line 96 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10LocalDecl_c
                 i = ((x10_int)0); ((i) < (size)); 
                                                   //#line 96 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10LocalAssign_c
                                                   i = ((x10_int) ((i) + (((x10_int)1)))))
            {
                
                //#line 97 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10FieldAssign_c
                this->FMGL(result) = x10::lang::Reducible<TPMGL(T)>::__apply(x10aux::nullCheck(this->
                                                                                                 FMGL(reducer)), 
                                       this->FMGL(result),
                                       x10aux::nullCheck(this->
                                                           FMGL(resultRail))->x10::lang::template Rail<TPMGL(T) >::__apply(
                                         ((x10_long) (i))));
            }
        }
        
        //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": Eval of x10.ast.X10Call_c
        x10aux::dealloc(this->FMGL(resultRail));
        
        //#line 100 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10Return_c
        return this->FMGL(result);
        
    }
}

//#line 14 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::compiler::ws::CollectingFinish<TPMGL(T)>*
  x10::compiler::ws::CollectingFinish<TPMGL(T)>::x10__compiler__ws__CollectingFinish____this__x10__compiler__ws__CollectingFinish(
  ) {
    
    //#line 14 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 14 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/CollectingFinish.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::__fieldInitializers_x10_compiler_ws_CollectingFinish(
  ) {
 
}
template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::compiler::ws::FinishFrame::_serialize_body(buf);
    buf.write(this->FMGL(reducer));
    buf.write(this->FMGL(resultRail));
    buf.write(this->FMGL(result));
    
}

template<class TPMGL(T)> void x10::compiler::ws::CollectingFinish<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::compiler::ws::FinishFrame::_deserialize_body(buf);
    FMGL(reducer) = buf.read<x10::lang::Reducible<TPMGL(T)>*>();
    FMGL(resultRail) = buf.read<x10::lang::Rail<TPMGL(T) >*>();
    FMGL(result) = buf.read<TPMGL(T)>();
}

#endif // X10_COMPILER_WS_COLLECTINGFINISH_H_IMPLEMENTATION
#endif // __X10_COMPILER_WS_COLLECTINGFINISH_H_NODEPS
