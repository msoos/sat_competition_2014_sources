#ifndef __X10_COMPILER_WS_FRAME_H
#define __X10_COMPILER_WS_FRAME_H

#include <x10rt.h>


namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace compiler { 
class Uninitialized;
} } 
namespace x10 { namespace compiler { 
class Header;
} } 
namespace x10 { namespace compiler { 
class Ifdef;
} } 
namespace x10 { namespace compiler { namespace ws { 
class Worker;
} } } 
namespace x10 { namespace compiler { 
class Abort;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace compiler { namespace ws { 

class Frame : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    x10::compiler::ws::Frame* FMGL(up);
    
    void _constructor(x10::compiler::ws::Frame* up) {
        
        //#line 18 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/Frame.x10": x10.ast.AssignPropertyCall_c
        
        //#line 11 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/Frame.x10": x10.ast.X10LocalDecl_c
        x10::compiler::ws::Frame* this52546 = this;
        
        //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/Frame.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(up) = up;
    }
    virtual x10::compiler::ws::Frame* remap() = 0;
    virtual x10::compiler::ws::Frame* realloc();
    virtual void back(x10::compiler::ws::Worker* worker, x10::compiler::ws::Frame* frame);
    virtual void wrapBack(x10::compiler::ws::Worker* worker, x10::compiler::ws::Frame* frame);
    virtual void resume(x10::compiler::ws::Worker* worker);
    virtual void wrapResume(x10::compiler::ws::Worker* worker);
    virtual x10::compiler::ws::Frame* x10__compiler__ws__Frame____this__x10__compiler__ws__Frame(
      );
    virtual void __fieldInitializers_x10_compiler_ws_Frame();
    
    // Serialization
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } } 
#endif // X10_COMPILER_WS_FRAME_H

namespace x10 { namespace compiler { namespace ws { 
class Frame;
} } } 

#ifndef X10_COMPILER_WS_FRAME_H_NODEPS
#define X10_COMPILER_WS_FRAME_H_NODEPS
#include <x10/compiler/Native.h>
#include <x10/compiler/Uninitialized.h>
#include <x10/compiler/Header.h>
#include <x10/compiler/Ifdef.h>
#include <x10/compiler/ws/Worker.h>
#include <x10/compiler/Abort.h>
#include <x10/lang/Exception.h>
#ifndef X10_COMPILER_WS_FRAME_H_GENERICS
#define X10_COMPILER_WS_FRAME_H_GENERICS
#endif // X10_COMPILER_WS_FRAME_H_GENERICS
#endif // __X10_COMPILER_WS_FRAME_H_NODEPS
