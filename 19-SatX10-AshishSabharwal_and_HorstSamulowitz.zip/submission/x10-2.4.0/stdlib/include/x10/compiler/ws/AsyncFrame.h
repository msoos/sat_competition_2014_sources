#ifndef __X10_COMPILER_WS_ASYNCFRAME_H
#define __X10_COMPILER_WS_ASYNCFRAME_H

#include <x10rt.h>


#define X10_COMPILER_WS_FRAME_H_NODEPS
#include <x10/compiler/ws/Frame.h>
#undef X10_COMPILER_WS_FRAME_H_NODEPS
namespace x10 { namespace compiler { 
class Header;
} } 
namespace x10 { namespace compiler { namespace ws { 
class FinishFrame;
} } } 
namespace x10 { namespace compiler { 
class Ifdef;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace compiler { namespace ws { 
class Worker;
} } } 
namespace x10 { namespace lang { 
class Deque;
} } 
namespace x10 { namespace lang { 
class Any;
} } 
namespace x10 { namespace util { namespace concurrent { 
class Lock;
} } } 
namespace x10 { namespace util { 
template<class TPMGL(T)> class GrowableRail;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace compiler { 
class NoInline;
} } 
namespace x10 { namespace compiler { namespace ws { 

class AsyncFrame : public x10::compiler::ws::Frame   {
    public:
    RTT_H_DECLS_CLASS
    
    void _constructor(x10::compiler::ws::Frame* up) {
        
        //#line 10 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/AsyncFrame.x10": x10.ast.X10LocalDecl_c
        x10::compiler::ws::Frame* this51616 = this;
        
        //#line 18 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/Frame.x10": x10.ast.X10LocalDecl_c
        x10::compiler::ws::Frame* up51617 = up;
        
        //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/Frame.x10": Eval of x10.ast.X10FieldAssign_c
        x10aux::nullCheck(this51616)->FMGL(up) = up51617;
        
        //#line 9 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/AsyncFrame.x10": x10.ast.AssignPropertyCall_c
        
        //#line 8 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/compiler/ws/AsyncFrame.x10": x10.ast.X10LocalDecl_c
        x10::compiler::ws::AsyncFrame* this51615 = this;
        
    }
    void _constructor(x10_int id__40, x10::compiler::ws::AsyncFrame* o);
    
    virtual x10::compiler::ws::FinishFrame* ff();
    virtual void move(x10::compiler::ws::FinishFrame* ff) = 0;
    virtual void poll(x10::compiler::ws::Worker* worker);
    virtual void pollSlow(x10::compiler::ws::Worker* worker);
    virtual void caught(x10::lang::Exception* t);
    virtual x10::compiler::ws::AsyncFrame* x10__compiler__ws__AsyncFrame____this__x10__compiler__ws__AsyncFrame(
      );
    virtual void __fieldInitializers_x10_compiler_ws_AsyncFrame();
    
    // Serialization
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};


} } } 
#endif // X10_COMPILER_WS_ASYNCFRAME_H

namespace x10 { namespace compiler { namespace ws { 
class AsyncFrame;
} } } 

#ifndef X10_COMPILER_WS_ASYNCFRAME_H_NODEPS
#define X10_COMPILER_WS_ASYNCFRAME_H_NODEPS
#include <x10/compiler/ws/Frame.h>
#include <x10/compiler/Header.h>
#include <x10/lang/Int.h>
#include <x10/compiler/ws/FinishFrame.h>
#include <x10/compiler/Ifdef.h>
#include <x10/compiler/Inline.h>
#include <x10/compiler/ws/Worker.h>
#include <x10/lang/Deque.h>
#include <x10/lang/Any.h>
#include <x10/util/concurrent/Lock.h>
#include <x10/util/GrowableRail.h>
#include <x10/lang/Exception.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Boolean.h>
#include <x10/compiler/NoInline.h>
#ifndef X10_COMPILER_WS_ASYNCFRAME_H_GENERICS
#define X10_COMPILER_WS_ASYNCFRAME_H_GENERICS
#endif // X10_COMPILER_WS_ASYNCFRAME_H_GENERICS
#endif // __X10_COMPILER_WS_ASYNCFRAME_H_NODEPS
