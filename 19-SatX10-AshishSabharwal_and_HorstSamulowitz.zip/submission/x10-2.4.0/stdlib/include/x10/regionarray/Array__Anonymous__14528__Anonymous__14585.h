#ifndef __X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H
#define __X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H

#include <x10rt.h>


#define X10_LANG_ITERATOR_H_NODEPS
#include <x10/lang/Iterator.h>
#undef X10_LANG_ITERATOR_H_NODEPS
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array__Anonymous__14528;
} } 
namespace x10 { namespace lang { 
class Point;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array;
} } 
namespace x10 { namespace regionarray { 
class Region;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace regionarray { 

template<class TPMGL(T)> class Array__Anonymous__14528__Anonymous__14585;
template <> class Array__Anonymous__14528__Anonymous__14585<void>;
template<class TPMGL(T)> class Array__Anonymous__14528__Anonymous__14585 : public x10::lang::X10Class
  {
    public:
    RTT_H_DECLS_CLASS
    
    static x10aux::itable_entry _itables[3];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Iterator<TPMGL(T)>::template itable<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> > _itable_1;
    
    x10::regionarray::Array__Anonymous__14528<TPMGL(T)>* FMGL(out__);
    
    x10::lang::Iterator<x10::lang::Point*>* FMGL(regIt);
    
    virtual TPMGL(T) next();
    virtual x10_boolean hasNext();
    void _constructor(x10::regionarray::Array__Anonymous__14528<TPMGL(T)>* out__);
    
    static x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>* _make(
             x10::regionarray::Array__Anonymous__14528<TPMGL(T)>* out__);
    
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::lang::Iterator<TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.regionarray.Array.Anonymous.14528.Anonymous.14585";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 1, parents, 1, params, variances);
}

template <> class Array__Anonymous__14528__Anonymous__14585<void> : public x10::lang::X10Class
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } 
#endif // X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H

namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array__Anonymous__14528__Anonymous__14585;
} } 

#ifndef X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_NODEPS
#define X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_NODEPS
#include <x10/lang/Iterator.h>
#include <x10/regionarray/Array__Anonymous__14528.h>
#include <x10/lang/Point.h>
#include <x10/regionarray/Array.h>
#include <x10/lang/Boolean.h>
#include <x10/regionarray/Region.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Long.h>
#ifndef X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_GENERICS
#define X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_GENERICS
#endif // X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_GENERICS
#ifndef X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_IMPLEMENTATION
#define X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_IMPLEMENTATION
#include <x10/regionarray/Array__Anonymous__14528__Anonymous__14585.h>

template<class TPMGL(T)> typename x10::lang::Iterator<TPMGL(T)>::template itable<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> >  x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::hasNext, &x10::lang::X10Class::hashCode, &x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::next, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> >  x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_itables[3] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterator<TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> >())};

//#line 422 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c

//#line 424 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c

//#line 425 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::next(
  ) {
    
    //#line 425 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62679 = x10aux::nullCheck(this->
                                                                       FMGL(out__))->
                                                     FMGL(out__);
    
    //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Point* pt62680 = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(this->
                                                                                                 FMGL(regIt)));
    
    //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret62681;
    
    //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(x10aux::nullCheck(this62679)->FMGL(region)->contains(
                    pt62680))) {
        
        //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(pt62680);
    }
    
    //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    ret62681 = x10aux::nullCheck(this62679)->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                 (__extension__ ({
                     
                     //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                     x10::lang::Point* pt62677 = pt62680;
                     
                     //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                     x10_long ret62678;
                     
                     //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                     x10_long offset62676 = ((x10_long) ((x10aux::nullCheck(pt62677)->x10::lang::Point::__apply(
                                                            ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62679)->
                                                                                               FMGL(layout_min0))));
                     
                     //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                     if (((x10aux::nullCheck(pt62677)->FMGL(rank)) > (((x10_long)1ll))))
                     {
                         
                         //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                         offset62676 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62676) * (x10aux::nullCheck(this62679)->
                                                                                                   FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62677)->x10::lang::Point::__apply(
                                                                                                                                 ((x10_long)1ll)))))) - (x10aux::nullCheck(this62679)->
                                                                                                                                                           FMGL(layout_min1))));
                         
                         //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                         x10_long i61289max62673 = ((x10_long) ((x10aux::nullCheck(pt62677)->
                                                                   FMGL(rank)) - (((x10_long)1ll))));
                         
                         //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                         {
                             x10_long i62674;
                             for (
                                  //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                  i62674 = ((x10_long)2ll);
                                  ((i62674) <= (i61289max62673));
                                  
                                  //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                  i62674 = ((x10_long) ((i62674) + (((x10_long)1ll)))))
                             {
                                 
                                 //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                 x10_long i62675 = i62674;
                                 
                                 //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                 offset62676 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62676) * (x10aux::nullCheck(x10aux::nullCheck(this62679)->
                                                                                                                             FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                           ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62675) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62677)->x10::lang::Point::__apply(
                                                                                                                                                                                                      i62675))))) - (x10aux::nullCheck(x10aux::nullCheck(this62679)->
                                                                                                                                                                                                                                         FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                       ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62675) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                             }
                         }
                         
                     }
                     
                     //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                     ret62678 = offset62676;
                     ret62678;
                 }))
                 );
    
    //#line 425 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return ret62681;
    
}

//#line 426 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_boolean x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::hasNext(
  ) {
    
    //#line 426 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(this->
                                                                               FMGL(regIt)));
    
}

//#line 423 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_constructor(
                           x10::regionarray::Array__Anonymous__14528<TPMGL(T)>* out__) {
    
    //#line 422 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(out__) = out__;
    
    //#line 424 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(regIt) = (__extension__ ({
        
        //#line 424 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array<TPMGL(T)>* this62355 = x10aux::nullCheck(this->
                                                                           FMGL(out__))->
                                                         FMGL(out__);
        x10aux::nullCheck(this62355)->FMGL(region)->iterator();
    }))
    ;
}
template<class TPMGL(T)> x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>* x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_make(
                           x10::regionarray::Array__Anonymous__14528<TPMGL(T)>* out__)
{
    x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>))) x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>();
    this_->_constructor(out__);
    return this_;
}


template<class TPMGL(T)> const x10aux::serialization_id_t x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    buf.write(this->FMGL(regIt));
    buf.write(this->FMGL(out__));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>))) x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::regionarray::Array__Anonymous__14528__Anonymous__14585<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(regIt) = buf.read<x10::lang::Iterator<x10::lang::Point*>*>();
    FMGL(out__) = buf.read<x10::regionarray::Array__Anonymous__14528<TPMGL(T)>*>();
}

#endif // X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_IMPLEMENTATION
#endif // __X10_REGIONARRAY_ARRAY__ANONYMOUS__14528__ANONYMOUS__14585_H_NODEPS
