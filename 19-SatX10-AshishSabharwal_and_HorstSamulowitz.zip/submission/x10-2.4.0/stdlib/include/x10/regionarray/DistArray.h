#ifndef __X10_REGIONARRAY_DISTARRAY_H
#define __X10_REGIONARRAY_DISTARRAY_H

#include <x10rt.h>


#define X10_LANG_FUN_0_1_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#undef X10_LANG_FUN_0_1_H_NODEPS
namespace x10 { namespace lang { 
class Point;
} } 
#define X10_LANG_ITERABLE_H_NODEPS
#include <x10/lang/Iterable.h>
#undef X10_LANG_ITERABLE_H_NODEPS
#define X10_LANG_PLACELOCALHANDLE_H_NODEPS
#include <x10/lang/PlaceLocalHandle.h>
#undef X10_LANG_PLACELOCALHANDLE_H_NODEPS
#define X10_LANG_PLACELOCALHANDLE_H_NODEPS
#include <x10/lang/PlaceLocalHandle.h>
#undef X10_LANG_PLACELOCALHANDLE_H_NODEPS
namespace x10 { namespace regionarray { 
class Dist;
} } 
namespace x10 { namespace regionarray { 
class Region;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class DistArray__LocalState;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class TransientInitExpr;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class UnsupportedOperationException;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace lang { 
class Any;
} } 
namespace x10 { namespace compiler { 
class CompilerFlags;
} } 
namespace x10 { namespace lang { 
class FailedDynamicCheckException;
} } 
namespace x10 { namespace regionarray { 
class Array__LayoutHelper;
} } 
namespace x10 { namespace lang { 
class IllegalArgumentException;
} } 
namespace x10 { namespace lang { 
class PlaceGroup;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(U)> class Fun_0_0;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Iterator;
} } 
namespace x10 { namespace lang { 
class FinishState;
} } 
namespace x10 { namespace lang { 
class CheckedThrowable;
} } 
namespace x10 { namespace lang { 
class VoidFun_0_0;
} } 
namespace x10 { namespace lang { 
class Error;
} } 
namespace x10 { namespace lang { 
class Exception;
} } 
namespace x10 { namespace compiler { 
class AsyncClosure;
} } 
namespace x10 { namespace lang { 
class Runtime__Profile;
} } 
namespace x10 { namespace compiler { 
class Finalization;
} } 
namespace x10 { namespace compiler { 
class Abort;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(Z1), class TPMGL(Z2), class TPMGL(U)> class Fun_0_2;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(U), class TPMGL(T)> class DistArray__Anonymous__27635;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Reducible;
} } 
namespace x10 { namespace regionarray { 

template<class TPMGL(T)> class DistArray;
template <> class DistArray<void>;
template<class TPMGL(T)> class DistArray : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    x10::regionarray::Dist* FMGL(dist);
    
    static x10aux::itable_entry _itables[4];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::regionarray::DistArray<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::regionarray::DistArray<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::Iterable<x10::lang::Point*>::template itable<x10::regionarray::DistArray<TPMGL(T)> > _itable_2;
    
    x10::regionarray::Region* region();
    x10_long rank();
    x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>
      FMGL(localHandle);
    
    x10::lang::Rail<TPMGL(T) >* FMGL(raw);
    
    virtual x10::lang::Rail<TPMGL(T) >* getRawFromLocalHandle();
    virtual x10::lang::Rail<TPMGL(T) >* raw();
    virtual x10::regionarray::Array<TPMGL(T)>* getLocalPortion();
    void _constructor(x10::regionarray::Dist* dist);
    
    static x10::regionarray::DistArray<TPMGL(T)>* _make(x10::regionarray::Dist* dist);
    
    void _constructor(x10::regionarray::Dist* dist, x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init);
    
    static x10::regionarray::DistArray<TPMGL(T)>* _make(x10::regionarray::Dist* dist,
                                                        x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init);
    
    void _constructor(x10::regionarray::Dist* dist, TPMGL(T) init);
    
    static x10::regionarray::DistArray<TPMGL(T)>* _make(x10::regionarray::Dist* dist,
                                                        TPMGL(T) init);
    
    void _constructor(x10::regionarray::DistArray<TPMGL(T)>* a,
                      x10::regionarray::Dist* d);
    
    static x10::regionarray::DistArray<TPMGL(T)>* _make(x10::regionarray::DistArray<TPMGL(T)>* a,
                                                        x10::regionarray::Dist* d);
    
    void _constructor(x10::regionarray::Dist* d, x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> pls);
    
    static x10::regionarray::DistArray<TPMGL(T)>* _make(x10::regionarray::Dist* d,
                                                        x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> pls);
    
    virtual TPMGL(T) __apply(x10::lang::Point* pt);
    virtual TPMGL(T) __apply(x10_long i0);
    virtual TPMGL(T) __apply(x10_long i0, x10_long i1);
    virtual TPMGL(T) __apply(x10_long i0, x10_long i1, x10_long i2);
    virtual TPMGL(T) __apply(x10_long i0, x10_long i1, x10_long i2,
                             x10_long i3);
    virtual TPMGL(T) __set(x10::lang::Point* pt, TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, x10_long i1, TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, x10_long i1, x10_long i2,
                           TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, x10_long i1, x10_long i2,
                           x10_long i3, TPMGL(T) v);
    virtual x10::regionarray::DistArray<TPMGL(T)>* restriction(
      x10::regionarray::Dist* d);
    virtual x10::regionarray::DistArray<TPMGL(T)>* restriction(
      x10::regionarray::Region* r);
    virtual x10::regionarray::DistArray<TPMGL(T)>* restriction(
      x10::lang::Place p);
    virtual x10::regionarray::DistArray<TPMGL(T)>* __bar(
      x10::regionarray::Region* r);
    virtual x10::regionarray::DistArray<TPMGL(T)>* __bar(
      x10::lang::Place p);
    virtual void fill(TPMGL(T) v);
    template<class TPMGL(U)> x10::regionarray::DistArray<TPMGL(U)>*
      map(x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(U)> x10::regionarray::DistArray<TPMGL(U)>*
      map(x10::regionarray::DistArray<TPMGL(U)>* dst, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(U)> x10::regionarray::DistArray<TPMGL(U)>*
      map(x10::regionarray::DistArray<TPMGL(U)>* dst, x10::regionarray::Region* filter,
          x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::regionarray::DistArray<TPMGL(S)>*
      map(x10::regionarray::DistArray<TPMGL(U)>* src, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::regionarray::DistArray<TPMGL(S)>*
      map(x10::regionarray::DistArray<TPMGL(S)>* dst, x10::regionarray::DistArray<TPMGL(U)>* src,
          x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::regionarray::DistArray<TPMGL(S)>*
      map(x10::regionarray::DistArray<TPMGL(S)>* dst, x10::regionarray::DistArray<TPMGL(U)>* src,
          x10::regionarray::Region* filter, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op);
    virtual TPMGL(T) reduce(x10::lang::Fun_0_2<TPMGL(T), TPMGL(T), TPMGL(T)>* op,
                            TPMGL(T) unit);
    template<class TPMGL(U)> TPMGL(U) reduce(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* lop,
                                             x10::lang::Fun_0_2<TPMGL(U), TPMGL(U), TPMGL(U)>* gop,
                                             TPMGL(U) unit);
    virtual x10::lang::String* toString();
    virtual x10::lang::Iterator<x10::lang::Point*>* iterator(
      );
    virtual x10::regionarray::DistArray<TPMGL(T)>* x10__regionarray__DistArray____this__x10__regionarray__DistArray(
      );
    virtual void __fieldInitializers_x10_regionarray_DistArray(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::regionarray::DistArray<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::regionarray::DistArray<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >(), x10aux::getRTT<x10::lang::Iterable<x10::lang::Point*> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.regionarray.DistArray";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class DistArray<void> : public x10::lang::X10Class
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(T)> static x10::regionarray::DistArray<TPMGL(T)>*
      make(x10::regionarray::Dist* dist);
    
    template<class TPMGL(T)> static x10::regionarray::DistArray<TPMGL(T)>*
      make(x10::regionarray::Dist* dist, x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init);
    
    template<class TPMGL(T)> static x10::regionarray::DistArray<TPMGL(T)>*
      make(x10::regionarray::Dist* dist, TPMGL(T) init);
    
    
};

} } 
#endif // X10_REGIONARRAY_DISTARRAY_H

namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class DistArray;
} } 

#ifndef X10_REGIONARRAY_DISTARRAY_H_NODEPS
#define X10_REGIONARRAY_DISTARRAY_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/Point.h>
#include <x10/lang/Iterable.h>
#include <x10/lang/PlaceLocalHandle.h>
#include <x10/regionarray/Dist.h>
#include <x10/regionarray/Region.h>
#include <x10/lang/Long.h>
#include <x10/regionarray/DistArray__LocalState.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/TransientInitExpr.h>
#include <x10/regionarray/Array.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Place.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/UnsupportedOperationException.h>
#include <x10/lang/String.h>
#include <x10/lang/Any.h>
#include <x10/compiler/CompilerFlags.h>
#include <x10/lang/FailedDynamicCheckException.h>
#include <x10/regionarray/Array__LayoutHelper.h>
#include <x10/lang/IllegalArgumentException.h>
#include <x10/lang/PlaceGroup.h>
#include <x10/lang/Fun_0_0.h>
#include <x10/lang/Unsafe.h>
#include <x10/lang/Iterator.h>
#include <x10/lang/FinishState.h>
#include <x10/lang/CheckedThrowable.h>
#include <x10/lang/VoidFun_0_0.h>
#include <x10/lang/Error.h>
#include <x10/lang/Exception.h>
#include <x10/compiler/AsyncClosure.h>
#include <x10/lang/Runtime__Profile.h>
#include <x10/compiler/Finalization.h>
#include <x10/compiler/Abort.h>
#include <x10/lang/Fun_0_2.h>
#include <x10/regionarray/DistArray__Anonymous__27635.h>
#include <x10/lang/Reducible.h>
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__6_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__6_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T), class TPMGL(U)> class x10_regionarray_DistArray__closure__6 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*>::template itable <x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::regionarray::DistArray__LocalState<TPMGL(U)>* __apply() {
        
        //#line 516 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* srcRail = (__extension__ ({
            
            //#line 516 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::DistArray<TPMGL(T)>* this67054 = saved_this;
            x10aux::nullCheck(this67054)->FMGL(raw);
        }))
        ;
        
        //#line 517 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(U) >* newRail = x10::lang::Rail<TPMGL(U) >::_makeUnsafe(((x10_long) ((x10aux::nullCheck(saved_this->
                                                                                                                        FMGL(dist))->maxOffset()) + (((x10_long)1ll)))), false);
        
        //#line 518 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                            FMGL(dist))->get(
                                          x10::lang::Place::_make(x10aux::here));
        
        //#line 519 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* pt66972;
            for (
                 //#line 519 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 pt66972 = x10aux::nullCheck(reg)->iterator(); x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66972));
                 ) {
                
                //#line 519 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66972));
                
                //#line 520 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10_long offset = x10aux::nullCheck(saved_this->
                                                      FMGL(dist))->offset(
                                    pt);
                
                //#line 521 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                newRail->x10::lang::template Rail<TPMGL(U) >::__set(
                  offset, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
                    srcRail->x10::lang::template Rail<TPMGL(T) >::__apply(
                      offset)));
            }
        }
        
        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray__LocalState<TPMGL(U)>* alloc67092 =
           ((new (memset(x10aux::alloc<x10::regionarray::DistArray__LocalState<TPMGL(U)> >(), 0, sizeof(x10::regionarray::DistArray__LocalState<TPMGL(U)>))) x10::regionarray::DistArray__LocalState<TPMGL(U)>()))
        ;
        
        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67092)->::x10::regionarray::DistArray__LocalState<TPMGL(U)>::_constructor(
          saved_this->FMGL(dist), newRail);
        
        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
        return alloc67092;
        
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->op);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* that_op = buf.read<x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>*>();
        x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >(that_saved_this, that_op);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__6(x10::regionarray::DistArray<TPMGL(T)>* saved_this, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) : saved_this(saved_this), op(op) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:515-524";
    }

};

template<class TPMGL(T), class TPMGL(U)> typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*>::template itable <x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) > >x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*> >, &x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__6_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__7_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__7_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T), class TPMGL(U)> class x10_regionarray_DistArray__closure__7 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 541 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
        try {
            
            //#line 542 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                                FMGL(dist))->get(
                                              x10::lang::Place::_make(x10aux::here));
            
            //#line 543 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* srcRail = (__extension__ ({
                
                //#line 543 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::regionarray::DistArray<TPMGL(T)>* this67055 =
                  saved_this;
                x10aux::nullCheck(this67055)->FMGL(raw);
            }))
            ;
            
            //#line 544 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(U) >* dstRail = x10aux::nullCheck(dst)->
                                                    FMGL(raw);
            
            //#line 545 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
            {
                x10::lang::Iterator<x10::lang::Point*>* pt66974;
                for (
                     //#line 545 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                     pt66974 = x10aux::nullCheck(reg)->iterator();
                     x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66974));
                     ) {
                    
                    //#line 545 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66974));
                    
                    //#line 546 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10_long offset = x10aux::nullCheck(saved_this->
                                                          FMGL(dist))->offset(
                                        pt);
                    
                    //#line 547 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                    dstRail->x10::lang::template Rail<TPMGL(U) >::__set(
                      offset, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
                        srcRail->x10::lang::template Rail<TPMGL(T) >::__apply(
                          offset)));
                }
            }
            
        }
        catch (x10::lang::CheckedThrowable* __exc1603) {
            if (x10aux::instanceof<x10::lang::Error*>(__exc1603)) {
                x10::lang::Error* __lowerer__var__0__ = static_cast<x10::lang::Error*>(__exc1603);
                {
                    
                    //#line 541 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(__lowerer__var__0__));
                }
            } else
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__1__ =
                  static_cast<x10::lang::CheckedThrowable*>(__exc1603);
                {
                    
                    //#line 541 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::ensureException(
                                                               reinterpret_cast<x10::lang::CheckedThrowable*>(__lowerer__var__1__))));
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    x10::regionarray::DistArray<TPMGL(U)>* dst;
    x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->dst);
        buf.write(this->op);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10::regionarray::DistArray<TPMGL(U)>* that_dst = buf.read<x10::regionarray::DistArray<TPMGL(U)>*>();
        x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* that_op = buf.read<x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>*>();
        x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >(that_saved_this, that_dst, that_op);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__7(x10::regionarray::DistArray<TPMGL(T)>* saved_this, x10::regionarray::DistArray<TPMGL(U)>* dst, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) : saved_this(saved_this), dst(dst), op(op) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:541-549";
    }

};

template<class TPMGL(T), class TPMGL(U)> typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) > >x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_SIMPLE_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__7_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__8_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__8_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T), class TPMGL(U)> class x10_regionarray_DistArray__closure__8 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 570 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
        try {
            
            //#line 571 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                                FMGL(dist))->get(
                                              x10::lang::Place::_make(x10aux::here));
            
            //#line 572 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* freg = x10aux::nullCheck(reg)->__and(
                                               filter);
            
            //#line 573 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* srcRail = (__extension__ ({
                
                //#line 573 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::regionarray::DistArray<TPMGL(T)>* this67056 =
                  saved_this;
                x10aux::nullCheck(this67056)->FMGL(raw);
            }))
            ;
            
            //#line 574 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(U) >* dstRail = x10aux::nullCheck(dst)->
                                                    FMGL(raw);
            
            //#line 575 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
            {
                x10::lang::Iterator<x10::lang::Point*>* pt66978;
                for (
                     //#line 575 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                     pt66978 = x10aux::nullCheck(freg)->iterator();
                     x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66978));
                     ) {
                    
                    //#line 575 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66978));
                    
                    //#line 576 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10_long offset = x10aux::nullCheck(saved_this->
                                                          FMGL(dist))->offset(
                                        pt);
                    
                    //#line 577 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                    dstRail->x10::lang::template Rail<TPMGL(U) >::__set(
                      offset, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
                        srcRail->x10::lang::template Rail<TPMGL(T) >::__apply(
                          offset)));
                }
            }
            
        }
        catch (x10::lang::CheckedThrowable* __exc1607) {
            if (x10aux::instanceof<x10::lang::Error*>(__exc1607)) {
                x10::lang::Error* __lowerer__var__0__ = static_cast<x10::lang::Error*>(__exc1607);
                {
                    
                    //#line 570 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(__lowerer__var__0__));
                }
            } else
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__1__ =
                  static_cast<x10::lang::CheckedThrowable*>(__exc1607);
                {
                    
                    //#line 570 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::ensureException(
                                                               reinterpret_cast<x10::lang::CheckedThrowable*>(__lowerer__var__1__))));
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    x10::regionarray::Region* filter;
    x10::regionarray::DistArray<TPMGL(U)>* dst;
    x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->filter);
        buf.write(this->dst);
        buf.write(this->op);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10::regionarray::Region* that_filter = buf.read<x10::regionarray::Region*>();
        x10::regionarray::DistArray<TPMGL(U)>* that_dst = buf.read<x10::regionarray::DistArray<TPMGL(U)>*>();
        x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* that_op = buf.read<x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>*>();
        x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >(that_saved_this, that_filter, that_dst, that_op);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__8(x10::regionarray::DistArray<TPMGL(T)>* saved_this, x10::regionarray::Region* filter, x10::regionarray::DistArray<TPMGL(U)>* dst, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) : saved_this(saved_this), filter(filter), dst(dst), op(op) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:570-579";
    }

};

template<class TPMGL(T), class TPMGL(U)> typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) > >x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_SIMPLE_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__8_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__9_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__9_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> class x10_regionarray_DistArray__closure__9 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*>::template itable <x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::regionarray::DistArray__LocalState<TPMGL(S)>* __apply() {
        
        //#line 597 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* src1Rail = (__extension__ ({
            
            //#line 597 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::DistArray<TPMGL(T)>* this67057 = saved_this;
            x10aux::nullCheck(this67057)->FMGL(raw);
        }))
        ;
        
        //#line 598 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(U) >* src2Rail = x10aux::nullCheck(src)->FMGL(raw);
        
        //#line 599 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(S) >* newRail = x10::lang::Rail<TPMGL(S) >::_makeUnsafe(((x10_long) ((x10aux::nullCheck(saved_this->
                                                                                                                        FMGL(dist))->maxOffset()) + (((x10_long)1ll)))), false);
        
        //#line 600 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                            FMGL(dist))->get(
                                          x10::lang::Place::_make(x10aux::here));
        
        //#line 601 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* pt66982;
            for (
                 //#line 601 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 pt66982 = x10aux::nullCheck(reg)->iterator(); x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66982));
                 ) {
                
                //#line 601 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66982));
                
                //#line 602 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10_long offset = x10aux::nullCheck(saved_this->
                                                      FMGL(dist))->offset(
                                    pt);
                
                //#line 603 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                newRail->x10::lang::template Rail<TPMGL(S) >::__set(
                  offset, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op), 
                    src1Rail->x10::lang::template Rail<TPMGL(T) >::__apply(
                      offset), src2Rail->x10::lang::template Rail<TPMGL(U) >::__apply(
                                 offset)));
            }
        }
        
        //#line 605 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray__LocalState<TPMGL(S)>* alloc67094 =
           ((new (memset(x10aux::alloc<x10::regionarray::DistArray__LocalState<TPMGL(S)> >(), 0, sizeof(x10::regionarray::DistArray__LocalState<TPMGL(S)>))) x10::regionarray::DistArray__LocalState<TPMGL(S)>()))
        ;
        
        //#line 605 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67094)->::x10::regionarray::DistArray__LocalState<TPMGL(S)>::_constructor(
          saved_this->FMGL(dist), newRail);
        
        //#line 605 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
        return alloc67094;
        
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    x10::regionarray::DistArray<TPMGL(U)>* src;
    x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->src);
        buf.write(this->op);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10::regionarray::DistArray<TPMGL(U)>* that_src = buf.read<x10::regionarray::DistArray<TPMGL(U)>*>();
        x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* that_op = buf.read<x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>*>();
        x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >(that_saved_this, that_src, that_op);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__9(x10::regionarray::DistArray<TPMGL(T)>* saved_this, x10::regionarray::DistArray<TPMGL(U)>* src, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) : saved_this(saved_this), src(src), op(op) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:596-606";
    }

};

template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*>::template itable <x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) > >x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*> >, &x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__9_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__10_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__10_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> class x10_regionarray_DistArray__closure__10 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 624 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
        try {
            
            //#line 625 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                                FMGL(dist))->get(
                                              x10::lang::Place::_make(x10aux::here));
            
            //#line 626 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* src1Rail = (__extension__ ({
                
                //#line 626 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::regionarray::DistArray<TPMGL(T)>* this67058 =
                  saved_this;
                x10aux::nullCheck(this67058)->FMGL(raw);
            }))
            ;
            
            //#line 627 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(U) >* src2Rail = x10aux::nullCheck(src)->
                                                     FMGL(raw);
            
            //#line 628 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(S) >* dstRail = x10aux::nullCheck(dst)->
                                                    FMGL(raw);
            
            //#line 629 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
            {
                x10::lang::Iterator<x10::lang::Point*>* pt66984;
                for (
                     //#line 629 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                     pt66984 = x10aux::nullCheck(reg)->iterator();
                     x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66984));
                     ) {
                    
                    //#line 629 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66984));
                    
                    //#line 630 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10_long offset = x10aux::nullCheck(saved_this->
                                                          FMGL(dist))->offset(
                                        pt);
                    
                    //#line 631 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                    dstRail->x10::lang::template Rail<TPMGL(S) >::__set(
                      offset, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op), 
                        src1Rail->x10::lang::template Rail<TPMGL(T) >::__apply(
                          offset), src2Rail->x10::lang::template Rail<TPMGL(U) >::__apply(
                                     offset)));
                }
            }
            
        }
        catch (x10::lang::CheckedThrowable* __exc1612) {
            if (x10aux::instanceof<x10::lang::Error*>(__exc1612)) {
                x10::lang::Error* __lowerer__var__0__ = static_cast<x10::lang::Error*>(__exc1612);
                {
                    
                    //#line 624 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(__lowerer__var__0__));
                }
            } else
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__1__ =
                  static_cast<x10::lang::CheckedThrowable*>(__exc1612);
                {
                    
                    //#line 624 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::ensureException(
                                                               reinterpret_cast<x10::lang::CheckedThrowable*>(__lowerer__var__1__))));
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    x10::regionarray::DistArray<TPMGL(U)>* src;
    x10::regionarray::DistArray<TPMGL(S)>* dst;
    x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->src);
        buf.write(this->dst);
        buf.write(this->op);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10::regionarray::DistArray<TPMGL(U)>* that_src = buf.read<x10::regionarray::DistArray<TPMGL(U)>*>();
        x10::regionarray::DistArray<TPMGL(S)>* that_dst = buf.read<x10::regionarray::DistArray<TPMGL(S)>*>();
        x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* that_op = buf.read<x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>*>();
        x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >(that_saved_this, that_src, that_dst, that_op);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__10(x10::regionarray::DistArray<TPMGL(T)>* saved_this, x10::regionarray::DistArray<TPMGL(U)>* src, x10::regionarray::DistArray<TPMGL(S)>* dst, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) : saved_this(saved_this), src(src), dst(dst), op(op) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:624-633";
    }

};

template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) > >x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_SIMPLE_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__10_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__11_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__11_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> class x10_regionarray_DistArray__closure__11 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 654 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
        try {
            
            //#line 655 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                                FMGL(dist))->get(
                                              x10::lang::Place::_make(x10aux::here));
            
            //#line 656 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* freg = x10aux::nullCheck(reg)->__and(
                                               filter);
            
            //#line 657 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* src1Rail = (__extension__ ({
                
                //#line 657 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::regionarray::DistArray<TPMGL(T)>* this67059 =
                  saved_this;
                x10aux::nullCheck(this67059)->FMGL(raw);
            }))
            ;
            
            //#line 658 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(U) >* src2Rail = x10aux::nullCheck(src)->
                                                     FMGL(raw);
            
            //#line 659 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(S) >* dstRail = x10aux::nullCheck(dst)->
                                                    FMGL(raw);
            
            //#line 660 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
            {
                x10::lang::Iterator<x10::lang::Point*>* pt66988;
                for (
                     //#line 660 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                     pt66988 = x10aux::nullCheck(freg)->iterator();
                     x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66988));
                     ) {
                    
                    //#line 660 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66988));
                    
                    //#line 661 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10_long offset = x10aux::nullCheck(saved_this->
                                                          FMGL(dist))->offset(
                                        pt);
                    
                    //#line 662 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                    dstRail->x10::lang::template Rail<TPMGL(S) >::__set(
                      offset, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op), 
                        src1Rail->x10::lang::template Rail<TPMGL(T) >::__apply(
                          offset), src2Rail->x10::lang::template Rail<TPMGL(U) >::__apply(
                                     offset)));
                }
            }
            
        }
        catch (x10::lang::CheckedThrowable* __exc1616) {
            if (x10aux::instanceof<x10::lang::Error*>(__exc1616)) {
                x10::lang::Error* __lowerer__var__0__ = static_cast<x10::lang::Error*>(__exc1616);
                {
                    
                    //#line 654 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(__lowerer__var__0__));
                }
            } else
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__1__ =
                  static_cast<x10::lang::CheckedThrowable*>(__exc1616);
                {
                    
                    //#line 654 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::ensureException(
                                                               reinterpret_cast<x10::lang::CheckedThrowable*>(__lowerer__var__1__))));
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    x10::regionarray::Region* filter;
    x10::regionarray::DistArray<TPMGL(U)>* src;
    x10::regionarray::DistArray<TPMGL(S)>* dst;
    x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->filter);
        buf.write(this->src);
        buf.write(this->dst);
        buf.write(this->op);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10::regionarray::Region* that_filter = buf.read<x10::regionarray::Region*>();
        x10::regionarray::DistArray<TPMGL(U)>* that_src = buf.read<x10::regionarray::DistArray<TPMGL(U)>*>();
        x10::regionarray::DistArray<TPMGL(S)>* that_dst = buf.read<x10::regionarray::DistArray<TPMGL(S)>*>();
        x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* that_op = buf.read<x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>*>();
        x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >(that_saved_this, that_filter, that_src, that_dst, that_op);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__11(x10::regionarray::DistArray<TPMGL(T)>* saved_this, x10::regionarray::Region* filter, x10::regionarray::DistArray<TPMGL(U)>* src, x10::regionarray::DistArray<TPMGL(S)>* dst, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) : saved_this(saved_this), filter(filter), src(src), dst(dst), op(op) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:654-664";
    }

};

template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) > >x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(S), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_SIMPLE_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__11_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__12_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__12_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T), class TPMGL(U)> class x10_regionarray_DistArray__closure__12 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 704 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
        try {
            
            //#line 705 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                                FMGL(dist))->get(
                                              x10::lang::Place::_make(x10aux::here));
            
            //#line 706 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) localRes = unit;
            
            //#line 707 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* rail = (__extension__ ({
                
                //#line 707 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::regionarray::DistArray<TPMGL(T)>* this67064 =
                  saved_this;
                x10aux::nullCheck(this67064)->FMGL(raw);
            }))
            ;
            
            //#line 708 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
            {
                x10::lang::Iterator<x10::lang::Point*>* pt66992;
                for (
                     //#line 708 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                     pt66992 = x10aux::nullCheck(reg)->iterator();
                     x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66992));
                     ) {
                    
                    //#line 708 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66992));
                    
                    //#line 709 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                    localRes = x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(lop), 
                      localRes, rail->x10::lang::template Rail<TPMGL(T) >::__apply(
                                  x10aux::nullCheck(saved_this->
                                                      FMGL(dist))->offset(
                                    pt)));
                }
            }
            
            //#line 711 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
            x10::lang::Runtime::template makeOffer<TPMGL(U) >(
              localRes);
        }
        catch (x10::lang::CheckedThrowable* __exc1621) {
            if (x10aux::instanceof<x10::lang::Error*>(__exc1621)) {
                x10::lang::Error* __lowerer__var__0__ = static_cast<x10::lang::Error*>(__exc1621);
                {
                    
                    //#line 704 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(__lowerer__var__0__));
                }
            } else
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__1__ =
                  static_cast<x10::lang::CheckedThrowable*>(__exc1621);
                {
                    
                    //#line 704 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::ensureException(
                                                               reinterpret_cast<x10::lang::CheckedThrowable*>(__lowerer__var__1__))));
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    TPMGL(U) unit;
    x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* lop;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->unit);
        buf.write(this->lop);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        TPMGL(U) that_unit = buf.read<TPMGL(U)>();
        x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* that_lop = buf.read<x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>*>();
        x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >* this_ = new (storage) x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >(that_saved_this, that_unit, that_lop);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__12(x10::regionarray::DistArray<TPMGL(T)>* saved_this, TPMGL(U) unit, x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* lop) : saved_this(saved_this), unit(unit), lop(lop) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:704-712";
    }

};

template<class TPMGL(T), class TPMGL(U)> typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) > >x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::__apply, &x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T), class TPMGL(U)> x10aux::itable_entry x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T), class TPMGL(U)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_SIMPLE_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__12_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY_H_GENERICS
#define X10_REGIONARRAY_DISTARRAY_H_GENERICS
#ifndef X10_REGIONARRAY_DISTARRAY_H_map_1601
#define X10_REGIONARRAY_DISTARRAY_H_map_1601
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::DistArray<TPMGL(U)>*
  x10::regionarray::DistArray<TPMGL(T)>::map(x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    
    //#line 515 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(U)>*> plh =
      x10::lang::PlaceLocalHandle<void>::template make<x10::regionarray::DistArray__LocalState<TPMGL(U)>* >(
        x10aux::nullCheck(this->FMGL(dist))->places(), reinterpret_cast<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(U)>*> >(sizeof(x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U)>)))x10_regionarray_DistArray__closure__6<TPMGL(T),TPMGL(U)>(this, op))));
    
    //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(U)>* alloc67093 =  ((new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(U)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(U)>))) x10::regionarray::DistArray<TPMGL(U)>()))
    ;
    
    //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
    (alloc67093)->::x10::regionarray::DistArray<TPMGL(U)>::_constructor(
      this->FMGL(dist), plh);
    
    //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return alloc67093;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_map_1601
#ifndef X10_REGIONARRAY_DISTARRAY_H_map_1602
#define X10_REGIONARRAY_DISTARRAY_H_map_1602
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::DistArray<TPMGL(U)>*
  x10::regionarray::DistArray<TPMGL(T)>::map(x10::regionarray::DistArray<TPMGL(U)>* dst,
                                             x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    {
        
        //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::ensureNotInAtomic();
        
        //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState* x10____var12 = x10::lang::Runtime::startFinish();
        {
            
            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::CheckedThrowable* throwable67142 =
              x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
            
            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
            try {
                
                //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
                try {
                    {
                        
                        //#line 540 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
                        {
                            x10::lang::Iterator<x10::lang::Place>* where66976;
                            for (
                                 //#line 540 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                 where66976 = x10aux::nullCheck(x10aux::nullCheck(this->
                                                                                    FMGL(dist))->places())->iterator();
                                 x10::lang::Iterator<x10::lang::Place>::hasNext(x10aux::nullCheck(where66976));
                                 ) {
                                
                                //#line 540 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                x10::lang::Place where = x10::lang::Iterator<x10::lang::Place>::next(x10aux::nullCheck(where66976));
                                
                                //#line 541 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                                x10::lang::Runtime::runAsync(
                                  where, reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U)>)))x10_regionarray_DistArray__closure__7<TPMGL(T),TPMGL(U)>(this, dst, op))),
                                  x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
                            }
                        }
                        
                    }
                }
                catch (x10::lang::CheckedThrowable* __exc1604) {
                    if (true) {
                        x10::lang::CheckedThrowable* __lowerer__var__0__ =
                          static_cast<x10::lang::CheckedThrowable*>(__exc1604);
                        {
                            
                            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                            x10::lang::Runtime::pushException(
                              __lowerer__var__0__);
                            
                            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                            x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::_make()));
                        }
                    } else
                    throw;
                }
                
                //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::compiler::Finalization::plausibleThrow();
            }
            catch (x10::lang::CheckedThrowable* __exc1605) {
                if (true) {
                    x10::lang::CheckedThrowable* formal67143 =
                      static_cast<x10::lang::CheckedThrowable*>(__exc1605);
                    {
                        
                        //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                        throwable67142 = formal67143;
                    }
                } else
                throw;
            }
            
            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67142)))
            {
                
                //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (x10aux::instanceof<x10::compiler::Abort*>(throwable67142))
                {
                    
                    //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67142));
                }
                
            }
            
            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::lang::Runtime::stopFinish(x10____var12);
            }
            
            //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67142)))
            {
                
                //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable67142)))
                {
                    
                    //#line 539 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67142));
                }
                
            }
            
        }
    }
    
    //#line 552 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_map_1602
#ifndef X10_REGIONARRAY_DISTARRAY_H_map_1606
#define X10_REGIONARRAY_DISTARRAY_H_map_1606
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::DistArray<TPMGL(U)>*
  x10::regionarray::DistArray<TPMGL(T)>::map(x10::regionarray::DistArray<TPMGL(U)>* dst,
                                             x10::regionarray::Region* filter,
                                             x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    {
        
        //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::ensureNotInAtomic();
        
        //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState* x10____var13 = x10::lang::Runtime::startFinish();
        {
            
            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::CheckedThrowable* throwable67145 =
              x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
            
            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
            try {
                
                //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
                try {
                    {
                        
                        //#line 569 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
                        {
                            x10::lang::Iterator<x10::lang::Place>* where66980;
                            for (
                                 //#line 569 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                 where66980 = x10aux::nullCheck(x10aux::nullCheck(this->
                                                                                    FMGL(dist))->places())->iterator();
                                 x10::lang::Iterator<x10::lang::Place>::hasNext(x10aux::nullCheck(where66980));
                                 ) {
                                
                                //#line 569 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                x10::lang::Place where = x10::lang::Iterator<x10::lang::Place>::next(x10aux::nullCheck(where66980));
                                
                                //#line 570 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                                x10::lang::Runtime::runAsync(
                                  where, reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U)>)))x10_regionarray_DistArray__closure__8<TPMGL(T),TPMGL(U)>(this, filter, dst, op))),
                                  x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
                            }
                        }
                        
                    }
                }
                catch (x10::lang::CheckedThrowable* __exc1608) {
                    if (true) {
                        x10::lang::CheckedThrowable* __lowerer__var__0__ =
                          static_cast<x10::lang::CheckedThrowable*>(__exc1608);
                        {
                            
                            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                            x10::lang::Runtime::pushException(
                              __lowerer__var__0__);
                            
                            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                            x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::_make()));
                        }
                    } else
                    throw;
                }
                
                //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::compiler::Finalization::plausibleThrow();
            }
            catch (x10::lang::CheckedThrowable* __exc1609) {
                if (true) {
                    x10::lang::CheckedThrowable* formal67146 =
                      static_cast<x10::lang::CheckedThrowable*>(__exc1609);
                    {
                        
                        //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                        throwable67145 = formal67146;
                    }
                } else
                throw;
            }
            
            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67145)))
            {
                
                //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (x10aux::instanceof<x10::compiler::Abort*>(throwable67145))
                {
                    
                    //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67145));
                }
                
            }
            
            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::lang::Runtime::stopFinish(x10____var13);
            }
            
            //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67145)))
            {
                
                //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable67145)))
                {
                    
                    //#line 568 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67145));
                }
                
            }
            
        }
    }
    
    //#line 582 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_map_1606
#ifndef X10_REGIONARRAY_DISTARRAY_H_map_1610
#define X10_REGIONARRAY_DISTARRAY_H_map_1610
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::regionarray::DistArray<TPMGL(S)>* x10::regionarray::DistArray<TPMGL(T)>::map(
  x10::regionarray::DistArray<TPMGL(U)>* src, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) {
    
    //#line 596 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(S)>*> plh =
      x10::lang::PlaceLocalHandle<void>::template make<x10::regionarray::DistArray__LocalState<TPMGL(S)>* >(
        x10aux::nullCheck(this->FMGL(dist))->places(), reinterpret_cast<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(S)>*> >(sizeof(x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U)>)))x10_regionarray_DistArray__closure__9<TPMGL(T),TPMGL(S),TPMGL(U)>(this, src, op))));
    
    //#line 607 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(S)>* alloc67095 =  ((new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(S)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(S)>))) x10::regionarray::DistArray<TPMGL(S)>()))
    ;
    
    //#line 607 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
    (alloc67095)->::x10::regionarray::DistArray<TPMGL(S)>::_constructor(
      this->FMGL(dist), plh);
    
    //#line 607 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return alloc67095;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_map_1610
#ifndef X10_REGIONARRAY_DISTARRAY_H_map_1611
#define X10_REGIONARRAY_DISTARRAY_H_map_1611
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::regionarray::DistArray<TPMGL(S)>* x10::regionarray::DistArray<TPMGL(T)>::map(
  x10::regionarray::DistArray<TPMGL(S)>* dst, x10::regionarray::DistArray<TPMGL(U)>* src,
  x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) {
    {
        
        //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::ensureNotInAtomic();
        
        //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState* x10____var14 = x10::lang::Runtime::startFinish();
        {
            
            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::CheckedThrowable* throwable67148 =
              x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
            
            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
            try {
                
                //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
                try {
                    {
                        
                        //#line 623 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
                        {
                            x10::lang::Iterator<x10::lang::Place>* where66986;
                            for (
                                 //#line 623 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                 where66986 = x10aux::nullCheck(x10aux::nullCheck(this->
                                                                                    FMGL(dist))->places())->iterator();
                                 x10::lang::Iterator<x10::lang::Place>::hasNext(x10aux::nullCheck(where66986));
                                 ) {
                                
                                //#line 623 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                x10::lang::Place where = x10::lang::Iterator<x10::lang::Place>::next(x10aux::nullCheck(where66986));
                                
                                //#line 624 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                                x10::lang::Runtime::runAsync(
                                  where, reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U)>)))x10_regionarray_DistArray__closure__10<TPMGL(T),TPMGL(S),TPMGL(U)>(this, src, dst, op))),
                                  x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
                            }
                        }
                        
                    }
                }
                catch (x10::lang::CheckedThrowable* __exc1613) {
                    if (true) {
                        x10::lang::CheckedThrowable* __lowerer__var__0__ =
                          static_cast<x10::lang::CheckedThrowable*>(__exc1613);
                        {
                            
                            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                            x10::lang::Runtime::pushException(
                              __lowerer__var__0__);
                            
                            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                            x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::_make()));
                        }
                    } else
                    throw;
                }
                
                //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::compiler::Finalization::plausibleThrow();
            }
            catch (x10::lang::CheckedThrowable* __exc1614) {
                if (true) {
                    x10::lang::CheckedThrowable* formal67149 =
                      static_cast<x10::lang::CheckedThrowable*>(__exc1614);
                    {
                        
                        //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                        throwable67148 = formal67149;
                    }
                } else
                throw;
            }
            
            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67148)))
            {
                
                //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (x10aux::instanceof<x10::compiler::Abort*>(throwable67148))
                {
                    
                    //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67148));
                }
                
            }
            
            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::lang::Runtime::stopFinish(x10____var14);
            }
            
            //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67148)))
            {
                
                //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable67148)))
                {
                    
                    //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67148));
                }
                
            }
            
        }
    }
    
    //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_map_1611
#ifndef X10_REGIONARRAY_DISTARRAY_H_map_1615
#define X10_REGIONARRAY_DISTARRAY_H_map_1615
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::regionarray::DistArray<TPMGL(S)>* x10::regionarray::DistArray<TPMGL(T)>::map(
  x10::regionarray::DistArray<TPMGL(S)>* dst, x10::regionarray::DistArray<TPMGL(U)>* src,
  x10::regionarray::Region* filter, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) {
    {
        
        //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::ensureNotInAtomic();
        
        //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState* x10____var15 = x10::lang::Runtime::startFinish();
        {
            
            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::CheckedThrowable* throwable67151 =
              x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
            
            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
            try {
                
                //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
                try {
                    {
                        
                        //#line 653 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
                        {
                            x10::lang::Iterator<x10::lang::Place>* where66990;
                            for (
                                 //#line 653 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                 where66990 = x10aux::nullCheck(x10aux::nullCheck(this->
                                                                                    FMGL(dist))->places())->iterator();
                                 x10::lang::Iterator<x10::lang::Place>::hasNext(x10aux::nullCheck(where66990));
                                 ) {
                                
                                //#line 653 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                x10::lang::Place where = x10::lang::Iterator<x10::lang::Place>::next(x10aux::nullCheck(where66990));
                                
                                //#line 654 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                                x10::lang::Runtime::runAsync(
                                  where, reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U)>)))x10_regionarray_DistArray__closure__11<TPMGL(T),TPMGL(S),TPMGL(U)>(this, filter, src, dst, op))),
                                  x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
                            }
                        }
                        
                    }
                }
                catch (x10::lang::CheckedThrowable* __exc1617) {
                    if (true) {
                        x10::lang::CheckedThrowable* __lowerer__var__0__ =
                          static_cast<x10::lang::CheckedThrowable*>(__exc1617);
                        {
                            
                            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                            x10::lang::Runtime::pushException(
                              __lowerer__var__0__);
                            
                            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                            x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::_make()));
                        }
                    } else
                    throw;
                }
                
                //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::compiler::Finalization::plausibleThrow();
            }
            catch (x10::lang::CheckedThrowable* __exc1618) {
                if (true) {
                    x10::lang::CheckedThrowable* formal67152 =
                      static_cast<x10::lang::CheckedThrowable*>(__exc1618);
                    {
                        
                        //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                        throwable67151 = formal67152;
                    }
                } else
                throw;
            }
            
            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67151)))
            {
                
                //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (x10aux::instanceof<x10::compiler::Abort*>(throwable67151))
                {
                    
                    //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67151));
                }
                
            }
            
            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::lang::Runtime::stopFinish(x10____var15);
            }
            
            //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67151)))
            {
                
                //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable67151)))
                {
                    
                    //#line 652 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67151));
                }
                
            }
            
        }
    }
    
    //#line 667 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_map_1615
#ifndef X10_REGIONARRAY_DISTARRAY_H_reduce_1620
#define X10_REGIONARRAY_DISTARRAY_H_reduce_1620
template<class TPMGL(T)> template<class TPMGL(U)> TPMGL(U)
  x10::regionarray::DistArray<TPMGL(T)>::reduce(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* lop,
                                                x10::lang::Fun_0_2<TPMGL(U), TPMGL(U), TPMGL(U)>* gop,
                                                TPMGL(U) unit) {
    
    //#line 697 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray__Anonymous__27635<TPMGL(U), TPMGL(T)>* reducer =
       ((new (memset(x10aux::alloc<x10::regionarray::DistArray__Anonymous__27635<TPMGL(U), TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray__Anonymous__27635<TPMGL(U), TPMGL(T)>))) x10::regionarray::DistArray__Anonymous__27635<TPMGL(U), TPMGL(T)>()))
    ;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* out__67096 = this;
    
    //#line 696 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) unit67097 = unit;
    
    //#line 696 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::lang::Fun_0_2<TPMGL(U), TPMGL(U), TPMGL(U)>* gop67098 =
      gop;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    reducer->FMGL(out__) = out__67096;
    
    //#line 696 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    reducer->FMGL(unit) = unit67097;
    
    //#line 696 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    reducer->FMGL(gop) = gop67098;
    
    //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) result;
    {
        
        //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState* x10____var16 = x10aux::class_cast_unchecked<x10::lang::FinishState*>(x10::lang::Runtime::template startCollectingFinish<TPMGL(U) >(
                                                                                                       reinterpret_cast<x10::lang::Reducible<TPMGL(U)>*>(reducer)));
        {
            
            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::CheckedThrowable* throwable67154 =
              x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
            
            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
            try {
                
                //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
                try {
                    {
                        
                        //#line 703 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
                        {
                            x10::lang::Iterator<x10::lang::Place>* where66994;
                            for (
                                 //#line 703 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                 where66994 = x10aux::nullCheck(x10aux::nullCheck(this->
                                                                                    FMGL(dist))->places())->iterator();
                                 x10::lang::Iterator<x10::lang::Place>::hasNext(x10aux::nullCheck(where66994));
                                 ) {
                                
                                //#line 703 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                x10::lang::Place where = x10::lang::Iterator<x10::lang::Place>::next(x10aux::nullCheck(where66994));
                                
                                //#line 704 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                                x10::lang::Runtime::runAsync(
                                  where, reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U)>)))x10_regionarray_DistArray__closure__12<TPMGL(T),TPMGL(U)>(this, unit, lop))),
                                  x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
                            }
                        }
                        
                    }
                }
                catch (x10::lang::CheckedThrowable* __exc1622) {
                    if (true) {
                        x10::lang::CheckedThrowable* __lowerer__var__0__ =
                          static_cast<x10::lang::CheckedThrowable*>(__exc1622);
                        {
                            
                            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                            x10::lang::Runtime::pushException(
                              __lowerer__var__0__);
                            
                            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                            x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::_make()));
                        }
                    } else
                    throw;
                }
                
                //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::compiler::Finalization::plausibleThrow();
            }
            catch (x10::lang::CheckedThrowable* __exc1623) {
                if (true) {
                    x10::lang::CheckedThrowable* formal67155 =
                      static_cast<x10::lang::CheckedThrowable*>(__exc1623);
                    {
                        
                        //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                        throwable67154 = formal67155;
                    }
                } else
                throw;
            }
            
            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67154)))
            {
                
                //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (x10aux::instanceof<x10::compiler::Abort*>(throwable67154))
                {
                    
                    //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67154));
                }
                
            }
            
            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                result = x10::lang::Runtime::template stopCollectingFinish<TPMGL(U) >(
                           x10____var16);
            }
            
            //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67154)))
            {
                
                //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable67154)))
                {
                    
                    //#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67154));
                }
                
            }
            
        }
    }
    
    //#line 716 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return result;
    
}
#endif // X10_REGIONARRAY_DISTARRAY_H_reduce_1620
#endif // X10_REGIONARRAY_DISTARRAY_H_GENERICS
#ifndef X10_REGIONARRAY_DISTARRAY_H_IMPLEMENTATION
#define X10_REGIONARRAY_DISTARRAY_H_IMPLEMENTATION
#include <x10/regionarray/DistArray.h>

#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__1_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__1_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_DistArray__closure__1 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__1<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::regionarray::DistArray__LocalState<TPMGL(T)>* __apply() {
        
        //#line 122 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10_long size = ((x10_long) ((x10aux::nullCheck(dist)->maxOffset()) + (((x10_long)1ll))));
        
        //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* localRaw = x10::lang::Rail<TPMGL(T) >::_make(size);
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray__LocalState<TPMGL(T)>* alloc67079 =  ((new (memset(x10aux::alloc<x10::regionarray::DistArray__LocalState<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray__LocalState<TPMGL(T)>))) x10::regionarray::DistArray__LocalState<TPMGL(T)>()))
        ;
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67079)->::x10::regionarray::DistArray__LocalState<TPMGL(T)>::_constructor(
          dist, localRaw);
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
        return alloc67079;
        
    }
    
    // captured environment
    x10::regionarray::Dist* dist;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->dist);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__1<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__1<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::regionarray::Dist* that_dist = buf.read<x10::regionarray::Dist*>();
        x10_regionarray_DistArray__closure__1<TPMGL(T) >* this_ = new (storage) x10_regionarray_DistArray__closure__1<TPMGL(T) >(that_dist);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__1(x10::regionarray::Dist* dist) : dist(dist) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:121-125";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__1<TPMGL(T) > >x10_regionarray_DistArray__closure__1<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__1<TPMGL(T) >::__apply, &x10_regionarray_DistArray__closure__1<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_DistArray__closure__1<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >, &x10_regionarray_DistArray__closure__1<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__1<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__1<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__1_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__2_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__2_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_DistArray__closure__2 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__2<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::regionarray::DistArray__LocalState<TPMGL(T)>* __apply() {
        
        //#line 153 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* localRaw = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(((x10_long) ((x10aux::nullCheck(dist)->maxOffset()) + (((x10_long)1ll)))), false);
        
        //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* reg = x10aux::nullCheck(dist)->get(x10::lang::Place::_make(x10aux::here));
        
        //#line 155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* pt66964;
            for (
                 //#line 155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 pt66964 = x10aux::nullCheck(reg)->iterator(); x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66964));
                 ) {
                
                //#line 155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66964));
                
                //#line 156 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                localRaw->x10::lang::template Rail<TPMGL(T) >::__set(
                  x10aux::nullCheck(dist)->offset(pt), x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::__apply(x10aux::nullCheck(init), 
                    pt));
            }
        }
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray__LocalState<TPMGL(T)>* alloc67082 =
           ((new (memset(x10aux::alloc<x10::regionarray::DistArray__LocalState<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray__LocalState<TPMGL(T)>))) x10::regionarray::DistArray__LocalState<TPMGL(T)>()))
        ;
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67082)->::x10::regionarray::DistArray__LocalState<TPMGL(T)>::_constructor(
          dist, localRaw);
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
        return alloc67082;
        
    }
    
    // captured environment
    x10::regionarray::Dist* dist;
    x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->dist);
        buf.write(this->init);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__2<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__2<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::regionarray::Dist* that_dist = buf.read<x10::regionarray::Dist*>();
        x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* that_init = buf.read<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>*>();
        x10_regionarray_DistArray__closure__2<TPMGL(T) >* this_ = new (storage) x10_regionarray_DistArray__closure__2<TPMGL(T) >(that_dist, that_init);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__2(x10::regionarray::Dist* dist, x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init) : dist(dist), init(init) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:152-159";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__2<TPMGL(T) > >x10_regionarray_DistArray__closure__2<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__2<TPMGL(T) >::__apply, &x10_regionarray_DistArray__closure__2<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_DistArray__closure__2<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >, &x10_regionarray_DistArray__closure__2<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__2<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__2<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__2_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__3_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__3_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_DistArray__closure__3 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__3<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::regionarray::DistArray__LocalState<TPMGL(T)>* __apply() {
        
        //#line 181 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* localRaw = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(((x10_long) ((x10aux::nullCheck(dist)->maxOffset()) + (((x10_long)1ll)))), false);
        
        //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* reg = x10aux::nullCheck(dist)->get(x10::lang::Place::_make(x10aux::here));
        
        //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* pt66966;
            for (
                 //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 pt66966 = x10aux::nullCheck(reg)->iterator(); x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66966));
                 ) {
                
                //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66966));
                
                //#line 184 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                localRaw->x10::lang::template Rail<TPMGL(T) >::__set(
                  x10aux::nullCheck(dist)->offset(pt), init);
            }
        }
        
        //#line 186 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray__LocalState<TPMGL(T)>* alloc67085 =
           ((new (memset(x10aux::alloc<x10::regionarray::DistArray__LocalState<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray__LocalState<TPMGL(T)>))) x10::regionarray::DistArray__LocalState<TPMGL(T)>()))
        ;
        
        //#line 186 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67085)->::x10::regionarray::DistArray__LocalState<TPMGL(T)>::_constructor(
          dist, localRaw);
        
        //#line 186 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
        return alloc67085;
        
    }
    
    // captured environment
    x10::regionarray::Dist* dist;
    TPMGL(T) init;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->dist);
        buf.write(this->init);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__3<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__3<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::regionarray::Dist* that_dist = buf.read<x10::regionarray::Dist*>();
        TPMGL(T) that_init = buf.read<TPMGL(T)>();
        x10_regionarray_DistArray__closure__3<TPMGL(T) >* this_ = new (storage) x10_regionarray_DistArray__closure__3<TPMGL(T) >(that_dist, that_init);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__3(x10::regionarray::Dist* dist, TPMGL(T) init) : dist(dist), init(init) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:180-187";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__3<TPMGL(T) > >x10_regionarray_DistArray__closure__3<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__3<TPMGL(T) >::__apply, &x10_regionarray_DistArray__closure__3<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_DistArray__closure__3<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >, &x10_regionarray_DistArray__closure__3<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__3<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__3<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__3_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__4_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__4_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_DistArray__closure__4 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__4<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::regionarray::DistArray__LocalState<TPMGL(T)>* __apply() {
        
        //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray__LocalState<TPMGL(T)>* alloc67087 =  ((new (memset(x10aux::alloc<x10::regionarray::DistArray__LocalState<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray__LocalState<TPMGL(T)>))) x10::regionarray::DistArray__LocalState<TPMGL(T)>()))
        ;
        
        //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67087)->::x10::regionarray::DistArray__LocalState<TPMGL(T)>::_constructor(
          d, x10aux::nullCheck(x10aux::nullCheck(a)->FMGL(localHandle)->x10::lang::template PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::__apply())->
               FMGL(data));
        
        //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
        return alloc67087;
        
    }
    
    // captured environment
    x10::regionarray::Dist* d;
    x10::regionarray::DistArray<TPMGL(T)>* a;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->d);
        buf.write(this->a);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__4<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__4<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::regionarray::Dist* that_d = buf.read<x10::regionarray::Dist*>();
        x10::regionarray::DistArray<TPMGL(T)>* that_a = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        x10_regionarray_DistArray__closure__4<TPMGL(T) >* this_ = new (storage) x10_regionarray_DistArray__closure__4<TPMGL(T) >(that_d, that_a);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__4(x10::regionarray::Dist* d, x10::regionarray::DistArray<TPMGL(T)>* a) : d(d), a(a) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:205";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::template itable <x10_regionarray_DistArray__closure__4<TPMGL(T) > >x10_regionarray_DistArray__closure__4<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__4<TPMGL(T) >::__apply, &x10_regionarray_DistArray__closure__4<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_DistArray__closure__4<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >, &x10_regionarray_DistArray__closure__4<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__4<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__4<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__4_CLOSURE
#ifndef X10_REGIONARRAY_DISTARRAY__CLOSURE__5_CLOSURE
#define X10_REGIONARRAY_DISTARRAY__CLOSURE__5_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/VoidFun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_DistArray__closure__5 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__5<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    void __apply() {
        
        //#line 495 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
        try {
            
            //#line 496 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* reg = x10aux::nullCheck(saved_this->
                                                                FMGL(dist))->get(
                                              x10::lang::Place::_make(x10aux::here));
            
            //#line 497 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(T) >* rail = saved_this->FMGL(raw);
            
            //#line 498 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
            {
                x10::lang::Iterator<x10::lang::Point*>* pt66968;
                for (
                     //#line 498 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                     pt66968 = x10aux::nullCheck(reg)->iterator();
                     x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(pt66968));
                     ) {
                    
                    //#line 498 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                    x10::lang::Point* pt = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(pt66968));
                    
                    //#line 499 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                    rail->x10::lang::template Rail<TPMGL(T) >::__set(
                      x10aux::nullCheck(saved_this->FMGL(dist))->offset(
                        pt), v);
                }
            }
            
        }
        catch (x10::lang::CheckedThrowable* __exc1598) {
            if (x10aux::instanceof<x10::lang::Error*>(__exc1598)) {
                x10::lang::Error* __lowerer__var__0__ = static_cast<x10::lang::Error*>(__exc1598);
                {
                    
                    //#line 495 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(__lowerer__var__0__));
                }
            } else
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__1__ =
                  static_cast<x10::lang::CheckedThrowable*>(__exc1598);
                {
                    
                    //#line 495 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::ensureException(
                                                               reinterpret_cast<x10::lang::CheckedThrowable*>(__lowerer__var__1__))));
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::regionarray::DistArray<TPMGL(T)>* saved_this;
    TPMGL(T) v;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->saved_this);
        buf.write(this->v);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_DistArray__closure__5<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_DistArray__closure__5<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::regionarray::DistArray<TPMGL(T)>* that_saved_this = buf.read<x10::regionarray::DistArray<TPMGL(T)>*>();
        TPMGL(T) that_v = buf.read<TPMGL(T)>();
        x10_regionarray_DistArray__closure__5<TPMGL(T) >* this_ = new (storage) x10_regionarray_DistArray__closure__5<TPMGL(T) >(that_saved_this, that_v);
        return this_;
    }
    
    x10_regionarray_DistArray__closure__5(x10::regionarray::DistArray<TPMGL(T)>* saved_this, TPMGL(T) v) : saved_this(saved_this), v(v) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::VoidFun_0_0>(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10:495-501";
    }

};

template<class TPMGL(T)> typename x10::lang::VoidFun_0_0::template itable <x10_regionarray_DistArray__closure__5<TPMGL(T) > >x10_regionarray_DistArray__closure__5<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_DistArray__closure__5<TPMGL(T) >::__apply, &x10_regionarray_DistArray__closure__5<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_DistArray__closure__5<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::VoidFun_0_0>, &x10_regionarray_DistArray__closure__5<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_DistArray__closure__5<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_DistArray__closure__5<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_SIMPLE_ASYNC);

#endif // X10_REGIONARRAY_DISTARRAY__CLOSURE__5_CLOSURE

//#line 48 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.PropertyDecl_c
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::regionarray::DistArray<TPMGL(T)> >  x10::regionarray::DistArray<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::regionarray::DistArray<TPMGL(T)>::__apply, &x10::regionarray::DistArray<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::regionarray::DistArray<TPMGL(T)> >  x10::regionarray::DistArray<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::regionarray::DistArray<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Iterable<x10::lang::Point*>::template itable<x10::regionarray::DistArray<TPMGL(T)> >  x10::regionarray::DistArray<TPMGL(T)>::_itable_2(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::regionarray::DistArray<TPMGL(T)>::iterator, &x10::regionarray::DistArray<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::regionarray::DistArray<TPMGL(T)>::_itables[4] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterable<x10::lang::Point*> >, &_itable_2), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::regionarray::DistArray<TPMGL(T)> >())};

//#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::Region* x10::regionarray::DistArray<TPMGL(T)>::region(
  ) {
    
    //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return x10aux::nullCheck(this->FMGL(dist))->FMGL(region);
    
}

//#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::regionarray::DistArray<TPMGL(T)>::rank(
  ) {
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Dist* this67066 = this->FMGL(dist);
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return x10aux::nullCheck(x10aux::nullCheck(this67066)->FMGL(region))->
             FMGL(rank);
    
}

//#line 80 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10FieldDecl_c
/** The place-local state for the DistArray */

//#line 87 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10FieldDecl_c
/** 
     * The place-local backing storage for elements of the DistArray.
     */

//#line 88 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::regionarray::DistArray<TPMGL(T)>::getRawFromLocalHandle(
  ) {
    
    //#line 89 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray__LocalState<TPMGL(T)>* ls =
      this->FMGL(localHandle)->x10::lang::template PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>::__apply();
    
    //#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return (!x10aux::struct_equals(ls, reinterpret_cast<x10::lang::NullType*>(X10_NULL)))
      ? (x10aux::nullCheck(ls)->FMGL(data)) : (x10::lang::Rail<TPMGL(T) >::_make());
    
}

//#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::regionarray::DistArray<TPMGL(T)>::raw(
  ) {
    
    //#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw);
    
}

//#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::getLocalPortion(
  ) {
    
    //#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Region* regionForHere = x10aux::nullCheck(this->
                                                                  FMGL(dist))->get(
                                                x10::lang::Place::_make(x10aux::here));
    
    //#line 106 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
    if (!(x10aux::nullCheck(regionForHere)->FMGL(rect))) {
        
        //#line 106 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
        x10aux::throwException(x10aux::nullCheck(x10::lang::UnsupportedOperationException::_make(x10::lang::String::__plus(x10aux::type_name(this), x10aux::makeStringLit(".getLocalPortion(): local portion is not rectangular!")))));
    }
    
    //#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* alloc67076 =  ((new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>()))
    ;
    
    //#line 231 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Region* reg67074 = regionForHere;
    
    //#line 231 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* backingStore67075 = this->
                                                      FMGL(raw);
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(region) = (__extension__ ({
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__32__67068 =
          reg67074;
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret67069;
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__32__67068,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret67069 = __desugarer__var__32__67068;
        ret67069;
    }))
    ;
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(rank) = x10aux::nullCheck(reg67074)->
                               FMGL(rank);
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(rect) = x10aux::nullCheck(reg67074)->
                               FMGL(rect);
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(zeroBased) = x10aux::nullCheck(reg67074)->
                                    FMGL(zeroBased);
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(rail) = x10aux::nullCheck(reg67074)->
                               FMGL(rail);
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(size) = x10aux::nullCheck(reg67074)->size();
    
    //#line 235 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh67070 =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 235 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh67070)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg67074);
    
    //#line 236 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(layout_min0) = crh67070->FMGL(min0);
    
    //#line 237 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(layout_stride1) = crh67070->FMGL(stride1);
    
    //#line 238 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(layout_min1) = crh67070->FMGL(min1);
    
    //#line 239 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(layout) = crh67070->FMGL(layout);
    
    //#line 240 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n67071 = crh67070->FMGL(size);
    
    //#line 241 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (((n67071) > ((x10_long)(x10aux::nullCheck(backingStore67075)->FMGL(size)))))
    {
        
        //#line 242 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (true) {
            
            //#line 242 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
            x10aux::throwException(x10aux::nullCheck(x10::lang::IllegalArgumentException::_make(x10aux::makeStringLit("backingStore too small"))));
        }
        
    }
    
    //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc67076->FMGL(raw) = (__extension__ ({
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* __desugarer__var__33__67072 =
          backingStore67075;
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* ret67073;
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__33__67072,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.lang.Rail[T]{self!=null}"))));
            }
            
        }
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret67073 = __desugarer__var__33__67072;
        ret67073;
    }))
    ;
    
    //#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return alloc67076;
    
}

//#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 118 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_constructor(
                           x10::regionarray::Dist* dist) {
    
    //#line 119 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.AssignPropertyCall_c
    FMGL(dist) = dist;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* this67078 = this;
    
    //#line 127 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localHandle) = x10::lang::PlaceLocalHandle<void>::template makeFlat<x10::regionarray::DistArray__LocalState<TPMGL(T)>* >(
                                x10aux::nullCheck(dist)->places(),
                                reinterpret_cast<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(sizeof(x10_regionarray_DistArray__closure__1<TPMGL(T)>)))x10_regionarray_DistArray__closure__1<TPMGL(T)>(dist))));
    
    //#line 128 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = this->x10::regionarray::template DistArray<TPMGL(T)>::getRawFromLocalHandle();
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>* x10::regionarray::DistArray<TPMGL(T)>::_make(
                           x10::regionarray::Dist* dist) {
    x10::regionarray::DistArray<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>();
    this_->_constructor(dist);
    return this_;
}



//#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_constructor(
                           x10::regionarray::Dist* dist, x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init) {
    
    //#line 150 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.AssignPropertyCall_c
    FMGL(dist) = dist;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* this67081 = this;
    
    //#line 161 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localHandle) = x10::lang::PlaceLocalHandle<void>::template make<x10::regionarray::DistArray__LocalState<TPMGL(T)>* >(
                                x10aux::nullCheck(dist)->places(),
                                reinterpret_cast<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(sizeof(x10_regionarray_DistArray__closure__2<TPMGL(T)>)))x10_regionarray_DistArray__closure__2<TPMGL(T)>(dist, init))));
    
    //#line 162 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = this->x10::regionarray::template DistArray<TPMGL(T)>::getRawFromLocalHandle();
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>* x10::regionarray::DistArray<TPMGL(T)>::_make(
                           x10::regionarray::Dist* dist, x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init)
{
    x10::regionarray::DistArray<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>();
    this_->_constructor(dist, init);
    return this_;
}



//#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 177 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_constructor(
                           x10::regionarray::Dist* dist, TPMGL(T) init) {
    
    //#line 178 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.AssignPropertyCall_c
    FMGL(dist) = dist;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* this67084 = this;
    
    //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localHandle) = x10::lang::PlaceLocalHandle<void>::template makeFlat<x10::regionarray::DistArray__LocalState<TPMGL(T)>* >(
                                x10aux::nullCheck(dist)->places(),
                                reinterpret_cast<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(sizeof(x10_regionarray_DistArray__closure__3<TPMGL(T)>)))x10_regionarray_DistArray__closure__3<TPMGL(T)>(dist, init))));
    
    //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = this->x10::regionarray::template DistArray<TPMGL(T)>::getRawFromLocalHandle();
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>* x10::regionarray::DistArray<TPMGL(T)>::_make(
                           x10::regionarray::Dist* dist, TPMGL(T) init)
{
    x10::regionarray::DistArray<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>();
    this_->_constructor(dist, init);
    return this_;
}



//#line 202 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_constructor(
                           x10::regionarray::DistArray<TPMGL(T)>* a,
                           x10::regionarray::Dist* d) {
    
    //#line 203 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.AssignPropertyCall_c
    FMGL(dist) = d;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* this67086 = this;
    
    //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localHandle) = x10::lang::PlaceLocalHandle<void>::template makeFlat<x10::regionarray::DistArray__LocalState<TPMGL(T)>* >(
                                x10aux::nullCheck(d)->places(),
                                reinterpret_cast<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >(sizeof(x10_regionarray_DistArray__closure__4<TPMGL(T)>)))x10_regionarray_DistArray__closure__4<TPMGL(T)>(d, a))));
    
    //#line 207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = this->x10::regionarray::template DistArray<TPMGL(T)>::getRawFromLocalHandle();
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>* x10::regionarray::DistArray<TPMGL(T)>::_make(
                           x10::regionarray::DistArray<TPMGL(T)>* a,
                           x10::regionarray::Dist* d) {
    x10::regionarray::DistArray<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>();
    this_->_constructor(a, d);
    return this_;
}



//#line 215 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_constructor(
                           x10::regionarray::Dist* d, x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> pls) {
    
    //#line 216 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.AssignPropertyCall_c
    FMGL(dist) = d;
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* this67088 = this;
    
    //#line 217 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localHandle) = pls;
    
    //#line 218 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = this->x10::regionarray::template DistArray<TPMGL(T)>::getRawFromLocalHandle();
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>* x10::regionarray::DistArray<TPMGL(T)>::_make(
                           x10::regionarray::Dist* d, x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> pls)
{
    x10::regionarray::DistArray<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>();
    this_->_constructor(d, pls);
    return this_;
}



//#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__apply(
  x10::lang::Point* pt) {
    
    //#line 234 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        pt);
    
    //#line 235 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             offset);
    
}

//#line 250 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__apply(
  x10_long i0) {
    
    //#line 251 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0);
    
    //#line 252 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             offset);
    
}

//#line 268 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__apply(
  x10_long i0, x10_long i1) {
    
    //#line 269 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0, i1);
    
    //#line 270 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             offset);
    
}

//#line 287 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__apply(
  x10_long i0, x10_long i1, x10_long i2) {
    
    //#line 288 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0, i1, i2);
    
    //#line 289 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             offset);
    
}

//#line 307 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__apply(
  x10_long i0, x10_long i1, x10_long i2, x10_long i3) {
    
    //#line 308 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0, i1, i2, i3);
    
    //#line 309 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             offset);
    
}

//#line 326 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__set(
  x10::lang::Point* pt, TPMGL(T) v) {
    
    //#line 327 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        pt);
    
    //#line 328 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      offset, v);
    
    //#line 329 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 346 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__set(
  x10_long i0, TPMGL(T) v) {
    
    //#line 347 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0);
    
    //#line 348 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      offset, v);
    
    //#line 349 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 367 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__set(
  x10_long i0, x10_long i1, TPMGL(T) v) {
    
    //#line 368 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0, i1);
    
    //#line 369 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      offset, v);
    
    //#line 370 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 389 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__set(
  x10_long i0, x10_long i1, x10_long i2, TPMGL(T) v) {
    
    //#line 390 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0, i1, i2);
    
    //#line 391 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      offset, v);
    
    //#line 392 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 412 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::__set(
  x10_long i0, x10_long i1, x10_long i2, x10_long i3, TPMGL(T) v) {
    
    //#line 413 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long offset = x10aux::nullCheck(this->FMGL(dist))->offset(
                        i0, i1, i2, i3);
    
    //#line 414 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      offset, v);
    
    //#line 415 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 435 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::restriction(x10::regionarray::Dist* d) {
    
    //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* __desugarer__var__62__67089 =
      (__extension__ ({
        
        //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::DistArray<TPMGL(T)>* alloc67090 =
           ((new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>()))
        ;
        
        //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
        (alloc67090)->::x10::regionarray::DistArray<TPMGL(T)>::_constructor(
          this, d);
        alloc67090;
    }))
    ;
    
    //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* ret67091;
    
    //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
    if (!((x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(x10aux::nullCheck(__desugarer__var__62__67089)->
                                                                       FMGL(dist))->
                                                     FMGL(region))->
                                   FMGL(rank), x10aux::nullCheck(x10aux::nullCheck(x10aux::nullCheck(this)->
                                                                                     FMGL(dist))->
                                                                   FMGL(region))->
                                                 FMGL(rank)))))
    {
        
        //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
        if (true) {
            
            //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
            x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.DistArray[T]{self.dist.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}"))));
        }
        
    }
    
    //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
    ret67091 = __desugarer__var__62__67089;
    
    //#line 436 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return ret67091;
    
}

//#line 447 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::restriction(x10::regionarray::Region* r) {
    
    //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->x10::regionarray::template DistArray<TPMGL(T)>::restriction(
             (__extension__ ({
                 
                 //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Dist* __desugarer__var__63__67048 =
                   x10aux::nullCheck(this->FMGL(dist))->restriction(
                     r);
                 
                 //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Dist* ret67049;
                 
                 //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                 if (!((x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(__desugarer__var__63__67048)->
                                                                  FMGL(region))->
                                                FMGL(rank),
                                              x10aux::nullCheck(x10aux::nullCheck(x10aux::nullCheck(this)->
                                                                                    FMGL(dist))->
                                                                  FMGL(region))->
                                                FMGL(rank)))))
                 {
                     
                     //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                     if (true) {
                         
                         //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                         x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}"))));
                     }
                     
                 }
                 
                 //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                 ret67049 = __desugarer__var__63__67048;
                 ret67049;
             }))
             );
    
}

//#line 459 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::restriction(x10::lang::Place p) {
    
    //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->x10::regionarray::template DistArray<TPMGL(T)>::restriction(
             (__extension__ ({
                 
                 //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Dist* __desugarer__var__64__67051 =
                   x10aux::nullCheck(this->FMGL(dist))->restriction(
                     p);
                 
                 //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Dist* ret67052;
                 
                 //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                 if (!((x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(__desugarer__var__64__67051)->
                                                                  FMGL(region))->
                                                FMGL(rank),
                                              x10aux::nullCheck(x10aux::nullCheck(x10aux::nullCheck(this)->
                                                                                    FMGL(dist))->
                                                                  FMGL(region))->
                                                FMGL(rank)))))
                 {
                     
                     //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                     if (true) {
                         
                         //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                         x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}"))));
                     }
                     
                 }
                 
                 //#line 460 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                 ret67052 = __desugarer__var__64__67051;
                 ret67052;
             }))
             );
    
}

//#line 471 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::__bar(x10::regionarray::Region* r) {
    
    //#line 471 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->x10::regionarray::template DistArray<TPMGL(T)>::restriction(
             r);
    
}

//#line 481 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::__bar(x10::lang::Place p) {
    
    //#line 481 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->x10::regionarray::template DistArray<TPMGL(T)>::restriction(
             p);
    
}

//#line 493 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::fill(
  TPMGL(T) v) {
    {
        
        //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
        x10::lang::Runtime::ensureNotInAtomic();
        
        //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::FinishState* x10____var11 = x10::lang::Runtime::startFinish();
        {
            
            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
            x10::lang::CheckedThrowable* throwable67139 =
              x10aux::class_cast_unchecked<x10::lang::CheckedThrowable*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL));
            
            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
            try {
                
                //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Try_c
                try {
                    {
                        
                        //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.For_c
                        {
                            x10::lang::Iterator<x10::lang::Place>* where66970;
                            for (
                                 //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                 where66970 = x10aux::nullCheck(x10aux::nullCheck(this->
                                                                                    FMGL(dist))->places())->iterator();
                                 x10::lang::Iterator<x10::lang::Place>::hasNext(x10aux::nullCheck(where66970));
                                 ) {
                                
                                //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                x10::lang::Place where = x10::lang::Iterator<x10::lang::Place>::next(x10aux::nullCheck(where66970));
                                
                                //#line 495 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                                x10::lang::Runtime::runAsync(
                                  where, reinterpret_cast<x10::lang::VoidFun_0_0*>((new (x10aux::alloc<x10::lang::VoidFun_0_0>(sizeof(x10_regionarray_DistArray__closure__5<TPMGL(T)>)))x10_regionarray_DistArray__closure__5<TPMGL(T)>(this, v))),
                                  x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
                            }
                        }
                        
                    }
                }
                catch (x10::lang::CheckedThrowable* __exc1599) {
                    if (true) {
                        x10::lang::CheckedThrowable* __lowerer__var__0__ =
                          static_cast<x10::lang::CheckedThrowable*>(__exc1599);
                        {
                            
                            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                            x10::lang::Runtime::pushException(
                              __lowerer__var__0__);
                            
                            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                            x10aux::throwException(x10aux::nullCheck(x10::lang::Exception::_make()));
                        }
                    } else
                    throw;
                }
                
                //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::compiler::Finalization::plausibleThrow();
            }
            catch (x10::lang::CheckedThrowable* __exc1600) {
                if (true) {
                    x10::lang::CheckedThrowable* formal67140 =
                      static_cast<x10::lang::CheckedThrowable*>(__exc1600);
                    {
                        
                        //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10LocalAssign_c
                        throwable67139 = formal67140;
                    }
                } else
                throw;
            }
            
            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67139)))
            {
                
                //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (x10aux::instanceof<x10::compiler::Abort*>(throwable67139))
                {
                    
                    //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67139));
                }
                
            }
            
            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": Eval of x10.ast.X10Call_c
                x10::lang::Runtime::stopFinish(x10____var11);
            }
            
            //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
            if ((!x10aux::struct_equals(reinterpret_cast<x10::lang::CheckedThrowable*>(X10_NULL),
                                        throwable67139)))
            {
                
                //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10If_c
                if (!(x10aux::instanceof<x10::compiler::Finalization*>(throwable67139)))
                {
                    
                    //#line 494 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(throwable67139));
                }
                
            }
            
        }
    }
}

//#line 514 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 538 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 567 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 595 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 621 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 651 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 682 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::DistArray<TPMGL(T)>::reduce(
  x10::lang::Fun_0_2<TPMGL(T), TPMGL(T), TPMGL(T)>* op, TPMGL(T) unit) {
    
    //#line 682 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this->template reduce<TPMGL(T) >(op, op, unit);
    
}

//#line 696 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 720 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::regionarray::DistArray<TPMGL(T)>::toString(
  ) {
    
    //#line 721 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("DistArray("), this->
                                                                                                      FMGL(dist)), x10aux::makeStringLit(")"));
    
}

//#line 730 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Iterator<x10::lang::Point*>*
  x10::regionarray::DistArray<TPMGL(T)>::iterator() {
    
    //#line 730 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return x10aux::nullCheck((__extension__ ({
               
               //#line 730 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
               x10::regionarray::DistArray<TPMGL(T)>* this67065 =
                 this;
               x10aux::nullCheck(x10aux::nullCheck(this67065)->
                                   FMGL(dist))->FMGL(region);
           }))
           )->iterator();
    
}

//#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<TPMGL(T)>::x10__regionarray__DistArray____this__x10__regionarray__DistArray(
  ) {
    
    //#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 44 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::__fieldInitializers_x10_regionarray_DistArray(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::regionarray::DistArray<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::regionarray::DistArray<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    buf.write(this->FMGL(localHandle));
    buf.write(this->FMGL(dist));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::regionarray::DistArray<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::regionarray::DistArray<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::regionarray::DistArray<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(localHandle) = buf.read<x10::lang::PlaceLocalHandle<x10::regionarray::DistArray__LocalState<TPMGL(T)>*> >();
    FMGL(dist) = buf.read<x10::regionarray::Dist*>();
    /* fields with @TransientInitExpr annotations */
    FMGL(raw) = x10::regionarray::template DistArray<TPMGL(T)>::getRawFromLocalHandle();
    
}

template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<void>::make(x10::regionarray::Dist* dist)
{
    
    //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* alloc67077 =  ((new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>()))
    ;
    
    //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
    (alloc67077)->::x10::regionarray::DistArray<TPMGL(T)>::_constructor(
      dist);
    
    //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return alloc67077;
    
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<void>::make(x10::regionarray::Dist* dist,
                                          x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init)
{
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::DistArray<TPMGL(T)>* alloc67080 =  ((new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>()))
    ;
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
    (alloc67080)->::x10::regionarray::DistArray<TPMGL(T)>::_constructor(
      dist, init);
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
    return alloc67080;
    
}
template<class TPMGL(T)> x10::regionarray::DistArray<TPMGL(T)>*
  x10::regionarray::DistArray<void>::make(x10::regionarray::Dist* dist,
                                          TPMGL(T) init) {
                                                             
                                                             //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10LocalDecl_c
                                                             x10::regionarray::DistArray<TPMGL(T)>* alloc67083 =
                                                               
                                                             ((new (memset(x10aux::alloc<x10::regionarray::DistArray<TPMGL(T)> >(), 0, sizeof(x10::regionarray::DistArray<TPMGL(T)>))) x10::regionarray::DistArray<TPMGL(T)>()))
                                                             ;
                                                             
                                                             //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10ConstructorCall_c
                                                             (alloc67083)->::x10::regionarray::DistArray<TPMGL(T)>::_constructor(
                                                               dist,
                                                               init);
                                                             
                                                             //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/DistArray.x10": x10.ast.X10Return_c
                                                             return alloc67083;
                                                             
                                                         }
#endif // X10_REGIONARRAY_DISTARRAY_H_IMPLEMENTATION
#endif // __X10_REGIONARRAY_DISTARRAY_H_NODEPS
