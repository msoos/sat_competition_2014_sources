#ifndef __X10_REGIONARRAY_ARRAY_H
#define __X10_REGIONARRAY_ARRAY_H

#include <x10rt.h>


#define X10_LANG_FUN_0_1_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#undef X10_LANG_FUN_0_1_H_NODEPS
namespace x10 { namespace lang { 
class Point;
} } 
#define X10_LANG_ITERABLE_H_NODEPS
#include <x10/lang/Iterable.h>
#undef X10_LANG_ITERABLE_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_BOOLEAN_H_NODEPS
#include <x10/lang/Boolean.h>
#undef X10_LANG_BOOLEAN_H_NODEPS
#define X10_LANG_BOOLEAN_H_NODEPS
#include <x10/lang/Boolean.h>
#undef X10_LANG_BOOLEAN_H_NODEPS
namespace x10 { namespace regionarray { 
class Region;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace compiler { 
class CompilerFlags;
} } 
namespace x10 { namespace lang { 
class FailedDynamicCheckException;
} } 
namespace x10 { namespace regionarray { 
class Array__LayoutHelper;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Iterator;
} } 
namespace x10 { namespace lang { 
class IllegalArgumentException;
} } 
namespace x10 { namespace regionarray { 
class RectRegion1D;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class RemoteArray;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class GlobalRef;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace util { 
class StringBuilder;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array__Anonymous__14242;
} } 
namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array__Anonymous__14528;
} } 
namespace x10 { namespace compiler { 
class Native;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(Z1), class TPMGL(Z2), class TPMGL(U)> class Fun_0_2;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(U)> class Fun_0_0;
} } 
namespace x10 { namespace lang { 
class CheckedThrowable;
} } 
namespace x10 { namespace lang { 
class Runtime__Profile;
} } 
namespace x10 { namespace lang { 
class ArrayIndexOutOfBoundsException;
} } 
namespace x10 { namespace compiler { 
class NoInline;
} } 
namespace x10 { namespace compiler { 
class NoReturn;
} } 
namespace x10 { namespace regionarray { 

template<class TPMGL(T)> class Array;
template <> class Array<void>;
template<class TPMGL(T)> class Array : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    x10::regionarray::Region* FMGL(region);
    
    x10_long FMGL(rank);
    
    x10_boolean FMGL(rect);
    
    x10_boolean FMGL(zeroBased);
    
    x10_boolean FMGL(rail);
    
    x10_long FMGL(size);
    
    static x10aux::itable_entry _itables[4];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::regionarray::Array<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::regionarray::Array<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::Iterable<x10::lang::Point*>::template itable<x10::regionarray::Array<TPMGL(T)> > _itable_2;
    
    x10::lang::Rail<TPMGL(T) >* FMGL(raw);
    
    virtual x10::lang::Rail<TPMGL(T) >* raw();
    void _constructor(x10::regionarray::Region* reg);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::regionarray::Region* reg);
    
    void _constructor(x10_boolean zeroed, x10::regionarray::Region* reg);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10_boolean zeroed, x10::regionarray::Region* reg);
    
    void _constructor(x10::regionarray::Region* reg, x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::regionarray::Region* reg,
                                                    x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init);
    
    void _constructor(x10::regionarray::Region* reg, TPMGL(T) init);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::regionarray::Region* reg,
                                                    TPMGL(T) init);
    
    void _constructor(x10::regionarray::Region* reg, x10::lang::Rail<TPMGL(T) >* backingStore);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::regionarray::Region* reg,
                                                    x10::lang::Rail<TPMGL(T) >* backingStore);
    
    void _constructor(x10::lang::Rail<TPMGL(T) >* backingStore);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::lang::Rail<TPMGL(T) >* backingStore);
    
    void _constructor(x10_long size);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10_long size);
    
    void _constructor(x10_boolean zeroed, x10_long size);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10_boolean zeroed,
                                                    x10_long size);
    
    void _constructor(x10_long size, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10_long size,
                                                    x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init);
    
    void _constructor(x10_long size, TPMGL(T) init);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10_long size,
                                                    TPMGL(T) init);
    
    void _constructor(x10::regionarray::Array<TPMGL(T)>* init);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::regionarray::Array<TPMGL(T)>* init);
    
    void _constructor(x10::regionarray::RemoteArray<TPMGL(T)>* init);
    
    static x10::regionarray::Array<TPMGL(T)>* _make(x10::regionarray::RemoteArray<TPMGL(T)>* init);
    
    virtual x10::lang::String* toString();
    virtual x10::lang::Iterator<x10::lang::Point*>* iterator(
      );
    virtual x10::lang::Iterable<TPMGL(T)>* values();
    virtual TPMGL(T) __apply(x10_long i0);
    virtual TPMGL(T) __apply(x10_long i0, x10_long i1);
    virtual TPMGL(T) __apply(x10_long i0, x10_long i1, x10_long i2);
    virtual TPMGL(T) __apply(x10_long i0, x10_long i1, x10_long i2,
                             x10_long i3);
    virtual TPMGL(T) __apply(x10::lang::Point* pt);
    virtual TPMGL(T) __set(x10_long i0, TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, x10_long i1, TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, x10_long i1, x10_long i2,
                           TPMGL(T) v);
    virtual TPMGL(T) __set(x10_long i0, x10_long i1, x10_long i2,
                           x10_long i3, TPMGL(T) v);
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v);
    virtual void fill(TPMGL(T) v);
    virtual void clear();
    template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
      map(x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
      map(x10::regionarray::Array<TPMGL(U)>* dst, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
      map(x10::regionarray::Array<TPMGL(U)>* dst, x10::regionarray::Region* filter,
          x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::regionarray::Array<TPMGL(S)>*
      map(x10::regionarray::Array<TPMGL(U)>* src, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::regionarray::Array<TPMGL(S)>*
      map(x10::regionarray::Array<TPMGL(S)>* dst, x10::regionarray::Array<TPMGL(U)>* src,
          x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::regionarray::Array<TPMGL(S)>*
      map(x10::regionarray::Array<TPMGL(S)>* dst, x10::regionarray::Array<TPMGL(U)>* src,
          x10::regionarray::Region* filter, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op);
    template<class TPMGL(U)> TPMGL(U) reduce(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
                                             TPMGL(U) unit);
    template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
      scan(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
           TPMGL(U) unit);
    template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
      scan(x10::regionarray::Array<TPMGL(U)>* dst, x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
           TPMGL(U) unit);
    x10_long FMGL(layout_min0);
    
    x10_long FMGL(layout_stride1);
    
    x10_long FMGL(layout_min1);
    
    x10::lang::Rail<x10_long >* FMGL(layout);
    
    x10_long offset(x10_long i0);
    x10_long offset(x10_long i0, x10_long i1);
    x10_long offset(x10_long i0, x10_long i1, x10_long i2);
    x10_long offset(x10_long i0, x10_long i1, x10_long i2,
                    x10_long i3);
    x10_long offset(x10::lang::Point* pt);
    virtual x10::regionarray::Array<TPMGL(T)>* x10__regionarray__Array____this__x10__regionarray__Array(
      );
    virtual void __fieldInitializers_x10_regionarray_Array(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::regionarray::Array<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::regionarray::Array<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >(), x10aux::getRTT<x10::lang::Iterable<x10::lang::Point*> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.regionarray.Array";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class Array<void> : public x10::lang::X10Class
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(T)> static void asyncCopy(x10::regionarray::Array<TPMGL(T)>* src,
                                                   x10::regionarray::RemoteArray<TPMGL(T)>* dst);
    
    template<class TPMGL(T)> static void asyncCopy(x10::regionarray::Array<TPMGL(T)>* src,
                                                   x10::lang::Point* srcPoint,
                                                   x10::regionarray::RemoteArray<TPMGL(T)>* dst,
                                                   x10::lang::Point* dstPoint,
                                                   x10_long numElems);
    
    template<class TPMGL(T)> static void asyncCopy(x10::regionarray::Array<TPMGL(T)>* src,
                                                   x10_long srcIndex,
                                                   x10::regionarray::RemoteArray<TPMGL(T)>* dst,
                                                   x10_long dstIndex,
                                                   x10_long numElems);
    
    template<class TPMGL(T)> static void asyncCopy(x10::regionarray::RemoteArray<TPMGL(T)>* src,
                                                   x10::regionarray::Array<TPMGL(T)>* dst);
    
    template<class TPMGL(T)> static void asyncCopy(x10::regionarray::RemoteArray<TPMGL(T)>* src,
                                                   x10::lang::Point* srcPoint,
                                                   x10::regionarray::Array<TPMGL(T)>* dst,
                                                   x10::lang::Point* dstPoint,
                                                   x10_long numElems);
    
    template<class TPMGL(T)> static void asyncCopy(x10::regionarray::RemoteArray<TPMGL(T)>* src,
                                                   x10_long srcIndex,
                                                   x10::regionarray::Array<TPMGL(T)>* dst,
                                                   x10_long dstIndex,
                                                   x10_long numElems);
    
    template<class TPMGL(T)> static void copy(x10::regionarray::Array<TPMGL(T)>* src,
                                              x10::regionarray::Array<TPMGL(T)>* dst);
    
    template<class TPMGL(T)> static void copy(x10::regionarray::Array<TPMGL(T)>* src,
                                              x10::lang::Point* srcPoint,
                                              x10::regionarray::Array<TPMGL(T)>* dst,
                                              x10::lang::Point* dstPoint,
                                              x10_long numElems);
    
    template<class TPMGL(T)> static void copy(x10::regionarray::Array<TPMGL(T)>* src,
                                              x10_long srcIndex,
                                              x10::regionarray::Array<TPMGL(T)>* dst,
                                              x10_long dstIndex,
                                              x10_long numElems);
    
    static void raiseBoundsError(x10_long i0) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i0, x10_long i1) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i0, x10_long i1,
                                 x10_long i2) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i0, x10_long i1,
                                 x10_long i2, x10_long i3) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10::lang::Point* pt) X10_PRAGMA_NORETURN ;
    
    
};

} } 
#endif // X10_REGIONARRAY_ARRAY_H

namespace x10 { namespace regionarray { 
template<class TPMGL(T)> class Array;
} } 

#ifndef X10_REGIONARRAY_ARRAY_H_NODEPS
#define X10_REGIONARRAY_ARRAY_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/Point.h>
#include <x10/lang/Iterable.h>
#include <x10/lang/Long.h>
#include <x10/lang/Boolean.h>
#include <x10/regionarray/Region.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/Inline.h>
#include <x10/compiler/CompilerFlags.h>
#include <x10/lang/FailedDynamicCheckException.h>
#include <x10/regionarray/Array__LayoutHelper.h>
#include <x10/lang/Unsafe.h>
#include <x10/lang/Iterator.h>
#include <x10/lang/IllegalArgumentException.h>
#include <x10/regionarray/RectRegion1D.h>
#include <x10/regionarray/RemoteArray.h>
#include <x10/lang/GlobalRef.h>
#include <x10/lang/String.h>
#include <x10/util/StringBuilder.h>
#include <x10/regionarray/Array__Anonymous__14242.h>
#include <x10/regionarray/Array__Anonymous__14528.h>
#include <x10/compiler/Native.h>
#include <x10/lang/Fun_0_2.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Place.h>
#include <x10/lang/Fun_0_0.h>
#include <x10/lang/CheckedThrowable.h>
#include <x10/lang/Runtime__Profile.h>
#include <x10/lang/ArrayIndexOutOfBoundsException.h>
#include <x10/compiler/NoInline.h>
#include <x10/compiler/NoReturn.h>
#ifndef X10_REGIONARRAY_ARRAY_H_GENERICS
#define X10_REGIONARRAY_ARRAY_H_GENERICS
#ifndef X10_REGIONARRAY_ARRAY_H_map_1475
#define X10_REGIONARRAY_ARRAY_H_map_1475
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
  x10::regionarray::Array<TPMGL(T)>::map(x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    
    //#line 685 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(U)>* alloc62445 =  ((new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(U)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(U)>))) x10::regionarray::Array<TPMGL(U)>()))
    ;
    
    //#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Region* reg62444 = this->FMGL(region);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(region) = (__extension__ ({
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__30__62431 = reg62444;
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62432;
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__30__62431,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62432 = __desugarer__var__30__62431;
        ret62432;
    }))
    ;
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(rank) = x10aux::nullCheck(reg62444)->
                               FMGL(rank);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(rect) = x10aux::nullCheck(reg62444)->
                               FMGL(rect);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(zeroBased) = x10aux::nullCheck(reg62444)->
                                    FMGL(zeroBased);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(rail) = x10aux::nullCheck(reg62444)->
                               FMGL(rail);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(size) = x10aux::nullCheck(reg62444)->size();
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh62433 =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh62433)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg62444);
    
    //#line 176 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(layout_min0) = crh62433->FMGL(min0);
    
    //#line 177 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(layout_stride1) = crh62433->FMGL(stride1);
    
    //#line 178 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(layout_min1) = crh62433->FMGL(min1);
    
    //#line 179 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(layout) = crh62433->FMGL(layout);
    
    //#line 180 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n62434 = crh62433->FMGL(size);
    
    //#line 181 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(U) >* r62435 = x10::lang::Rail<TPMGL(U) >::_makeUnsafe(n62434, false);
    
    //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p62436;
        for (
             //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p62436 = x10aux::nullCheck(reg62444)->iterator();
             x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p62436));
             ) {
            
            //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62437 = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p62436));
            
            //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            r62435->x10::lang::template Rail<TPMGL(U) >::__set(
              (__extension__ ({
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62438 = p62437;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret62439;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62424 = ((x10_long) ((x10aux::nullCheck(pt62438)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (alloc62445->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt62438)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62424 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62424) * (alloc62445->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62438)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (alloc62445->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62421 = ((x10_long) ((x10aux::nullCheck(pt62438)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62422;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62422 = ((x10_long)2ll); ((i62422) <= (i61289max62421));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62422 = ((x10_long) ((i62422) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62423 = i62422;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62424 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62424) * (x10aux::nullCheck(alloc62445->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62423) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62438)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62423))))) - (x10aux::nullCheck(alloc62445->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62423) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62439 = offset62424;
                  ret62439;
              }))
              , (__extension__ ({
                  
                  //#line 685 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* p62440 = p62437;
                  x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
                    (__extension__ ({
                        
                        //#line 685 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        x10::regionarray::Array<TPMGL(T)>* this62441 =
                          this;
                        
                        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        x10::lang::Point* pt62442 = p62440;
                        
                        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        TPMGL(T) ret62443;
                        
                        //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                        if (true && !(x10aux::nullCheck(this62441)->
                                        FMGL(region)->contains(
                                        pt62442))) {
                            
                            //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                            x10::regionarray::Array<void>::raiseBoundsError(
                              pt62442);
                        }
                        
                        //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                        ret62443 = x10aux::nullCheck(this62441)->
                                     FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                     (__extension__ ({
                                         
                                         //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10::lang::Point* pt62429 =
                                           pt62442;
                                         
                                         //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10_long ret62430;
                                         
                                         //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10_long offset62428 =
                                           ((x10_long) ((x10aux::nullCheck(pt62429)->x10::lang::Point::__apply(
                                                           ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62441)->
                                                                                              FMGL(layout_min0))));
                                         
                                         //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                         if (((x10aux::nullCheck(pt62429)->
                                                 FMGL(rank)) > (((x10_long)1ll))))
                                         {
                                             
                                             //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                             offset62428 =
                                               ((x10_long) ((((x10_long) ((((x10_long) ((offset62428) * (x10aux::nullCheck(this62441)->
                                                                                                           FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62429)->x10::lang::Point::__apply(
                                                                                                                                         ((x10_long)1ll)))))) - (x10aux::nullCheck(this62441)->
                                                                                                                                                                   FMGL(layout_min1))));
                                             
                                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                             x10_long i61289max62425 =
                                               ((x10_long) ((x10aux::nullCheck(pt62429)->
                                                               FMGL(rank)) - (((x10_long)1ll))));
                                             
                                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                             {
                                                 x10_long i62426;
                                                 for (
                                                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                      i62426 =
                                                        ((x10_long)2ll);
                                                      ((i62426) <= (i61289max62425));
                                                      
                                                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                      i62426 =
                                                        ((x10_long) ((i62426) + (((x10_long)1ll)))))
                                                 {
                                                     
                                                     //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                     x10_long i62427 =
                                                       i62426;
                                                     
                                                     //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                     offset62428 =
                                                       ((x10_long) ((((x10_long) ((((x10_long) ((offset62428) * (x10aux::nullCheck(x10aux::nullCheck(this62441)->
                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                   ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62427) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62429)->x10::lang::Point::__apply(
                                                                                                                                                                                                              i62427))))) - (x10aux::nullCheck(x10aux::nullCheck(this62441)->
                                                                                                                                                                                                                                                 FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                               ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62427) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                                 }
                                             }
                                             
                                         }
                                         
                                         //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                         ret62430 = offset62428;
                                         ret62430;
                                     }))
                                     );
                        ret62443;
                    }))
                    );
              }))
              );
        }
    }
    
    //#line 185 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62445->FMGL(raw) = r62435;
    
    //#line 685 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return alloc62445;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_map_1475
#ifndef X10_REGIONARRAY_ARRAY_H_map_1476
#define X10_REGIONARRAY_ARRAY_H_map_1476
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
  x10::regionarray::Array<TPMGL(T)>::map(x10::regionarray::Array<TPMGL(U)>* dst,
                                         x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    
    //#line 704 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rect)) {
        
        //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* src62450 = this->FMGL(raw);
        
        //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(U) >* dst62451 = x10aux::nullCheck(dst)->
                                                 FMGL(raw);
        
        //#line 144 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op62452 =
          op;
        
        //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(U) >* ret62453;
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail62446 = src62450;
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10_long i48161max62447 = (x10_long)(x10aux::nullCheck(rail62446)->FMGL(size));
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": polyglot.ast.For_c
        {
            x10_long i62448;
            for (
                 //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
                 i62448 = ((x10_long)0ll); ((i62448) < (i48161max62447));
                 
                 //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
                 i62448 = ((x10_long) ((i62448) + (((x10_long)1ll)))))
            {
                
                //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
                x10_long i62449 = i62448;
                
                //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Call_c
                x10aux::nullCheck(dst62451)->x10::lang::template Rail<TPMGL(U) >::__set(
                  i62449, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op62452), 
                    x10aux::nullCheck(src62450)->x10::lang::template Rail<TPMGL(T) >::__apply(
                      i62449)));
            }
        }
        
        //#line 151 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
        ret62453 = dst62451;
        
        //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Local_c
        ret62453;
        
        //#line 709 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return dst;
        
    } else {
        
        //#line 711 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* p61277;
            for (
                 //#line 711 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 p61277 = this->FMGL(region)->iterator();
                 x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61277));
                 ) {
                
                //#line 711 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61277));
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p62466 = p;
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                TPMGL(U) v62467 = x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
                  (__extension__ ({
                      
                      //#line 712 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::regionarray::Array<TPMGL(T)>* this62468 =
                        this;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt62469 = p;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      TPMGL(T) ret62470;
                      
                      //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (true && !(x10aux::nullCheck(this62468)->
                                      FMGL(region)->contains(
                                      pt62469))) {
                          
                          //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                          x10::regionarray::Array<void>::raiseBoundsError(
                            pt62469);
                      }
                      
                      //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret62470 = x10aux::nullCheck(this62468)->
                                   FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                   (__extension__ ({
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10::lang::Point* pt62458 =
                                         pt62469;
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long ret62459;
                                       
                                       //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long offset62457 =
                                         ((x10_long) ((x10aux::nullCheck(pt62458)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62468)->
                                                                                            FMGL(layout_min0))));
                                       
                                       //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                       if (((x10aux::nullCheck(pt62458)->
                                               FMGL(rank)) > (((x10_long)1ll))))
                                       {
                                           
                                           //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                           offset62457 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62457) * (x10aux::nullCheck(this62468)->
                                                                                                                     FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62458)->x10::lang::Point::__apply(
                                                                                                                                                   ((x10_long)1ll)))))) - (x10aux::nullCheck(this62468)->
                                                                                                                                                                             FMGL(layout_min1))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                           x10_long i61289max62454 =
                                             ((x10_long) ((x10aux::nullCheck(pt62458)->
                                                             FMGL(rank)) - (((x10_long)1ll))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                           {
                                               x10_long i62455;
                                               for (
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                    i62455 =
                                                      ((x10_long)2ll);
                                                    ((i62455) <= (i61289max62454));
                                                    
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                    i62455 =
                                                      ((x10_long) ((i62455) + (((x10_long)1ll)))))
                                               {
                                                   
                                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                   x10_long i62456 =
                                                     i62455;
                                                   
                                                   //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                   offset62457 =
                                                     ((x10_long) ((((x10_long) ((((x10_long) ((offset62457) * (x10aux::nullCheck(x10aux::nullCheck(this62468)->
                                                                                                                                   FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                 ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62456) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62458)->x10::lang::Point::__apply(
                                                                                                                                                                                                            i62456))))) - (x10aux::nullCheck(x10aux::nullCheck(this62468)->
                                                                                                                                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                             ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62456) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                               }
                                           }
                                           
                                       }
                                       
                                       //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       ret62459 = offset62457;
                                       ret62459;
                                   }))
                                   );
                      ret62470;
                  }))
                  );
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                TPMGL(U) ret62471;
                
                //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                if (true && !(x10aux::nullCheck(dst)->FMGL(region)->contains(
                                p62466))) {
                    
                    //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                    x10::regionarray::Array<void>::raiseBoundsError(
                      p62466);
                }
                
                //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                x10aux::nullCheck(dst)->FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__set(
                  (__extension__ ({
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt62464 = p62466;
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long ret62465;
                      
                      //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long offset62463 = ((x10_long) ((x10aux::nullCheck(pt62464)->x10::lang::Point::__apply(
                                                             ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(dst)->
                                                                                                FMGL(layout_min0))));
                      
                      //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (((x10aux::nullCheck(pt62464)->FMGL(rank)) > (((x10_long)1ll))))
                      {
                          
                          //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                          offset62463 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62463) * (x10aux::nullCheck(dst)->
                                                                                                    FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62464)->x10::lang::Point::__apply(
                                                                                                                                  ((x10_long)1ll)))))) - (x10aux::nullCheck(dst)->
                                                                                                                                                            FMGL(layout_min1))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                          x10_long i61289max62460 = ((x10_long) ((x10aux::nullCheck(pt62464)->
                                                                    FMGL(rank)) - (((x10_long)1ll))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                          {
                              x10_long i62461;
                              for (
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   i62461 = ((x10_long)2ll);
                                   ((i62461) <= (i61289max62460));
                                   
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   i62461 = ((x10_long) ((i62461) + (((x10_long)1ll)))))
                              {
                                  
                                  //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                  x10_long i62462 = i62461;
                                  
                                  //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                  offset62463 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62463) * (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                            ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62462) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62464)->x10::lang::Point::__apply(
                                                                                                                                                                                                       i62462))))) - (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                        ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62462) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                              }
                          }
                          
                      }
                      
                      //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret62465 = offset62463;
                      ret62465;
                  }))
                  , v62467);
                
                //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                ret62471 = v62467;
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Local_c
                ret62471;
            }
        }
        
    }
    
    //#line 715 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_map_1476
#ifndef X10_REGIONARRAY_ARRAY_H_map_1477
#define X10_REGIONARRAY_ARRAY_H_map_1477
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
  x10::regionarray::Array<TPMGL(T)>::map(x10::regionarray::Array<TPMGL(U)>* dst,
                                         x10::regionarray::Region* filter,
                                         x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    
    //#line 734 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Region* fregion = this->FMGL(region)->__and(
                                          filter);
    
    //#line 735 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p61279;
        for (
             //#line 735 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p61279 = x10aux::nullCheck(fregion)->iterator();
             x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61279));
             ) {
            
            //#line 735 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61279));
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62484 = p;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) v62485 = x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
              (__extension__ ({
                  
                  //#line 736 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::regionarray::Array<TPMGL(T)>* this62486 =
                    this;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62487 = p;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  TPMGL(T) ret62488;
                  
                  //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (true && !(x10aux::nullCheck(this62486)->
                                  FMGL(region)->contains(
                                  pt62487))) {
                      
                      //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                      x10::regionarray::Array<void>::raiseBoundsError(
                        pt62487);
                  }
                  
                  //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62488 = x10aux::nullCheck(this62486)->
                               FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                               (__extension__ ({
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10::lang::Point* pt62476 =
                                     pt62487;
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long ret62477;
                                   
                                   //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long offset62475 =
                                     ((x10_long) ((x10aux::nullCheck(pt62476)->x10::lang::Point::__apply(
                                                     ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62486)->
                                                                                        FMGL(layout_min0))));
                                   
                                   //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                   if (((x10aux::nullCheck(pt62476)->
                                           FMGL(rank)) > (((x10_long)1ll))))
                                   {
                                       
                                       //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       offset62475 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62475) * (x10aux::nullCheck(this62486)->
                                                                                                                 FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62476)->x10::lang::Point::__apply(
                                                                                                                                               ((x10_long)1ll)))))) - (x10aux::nullCheck(this62486)->
                                                                                                                                                                         FMGL(layout_min1))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long i61289max62472 =
                                         ((x10_long) ((x10aux::nullCheck(pt62476)->
                                                         FMGL(rank)) - (((x10_long)1ll))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                       {
                                           x10_long i62473;
                                           for (
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                i62473 = ((x10_long)2ll);
                                                ((i62473) <= (i61289max62472));
                                                
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                i62473 = ((x10_long) ((i62473) + (((x10_long)1ll)))))
                                           {
                                               
                                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                               x10_long i62474 =
                                                 i62473;
                                               
                                               //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                               offset62475 =
                                                 ((x10_long) ((((x10_long) ((((x10_long) ((offset62475) * (x10aux::nullCheck(x10aux::nullCheck(this62486)->
                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                             ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62474) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62476)->x10::lang::Point::__apply(
                                                                                                                                                                                                        i62474))))) - (x10aux::nullCheck(x10aux::nullCheck(this62486)->
                                                                                                                                                                                                                                           FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                         ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62474) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                           }
                                       }
                                       
                                   }
                                   
                                   //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   ret62477 = offset62475;
                                   ret62477;
                               }))
                               );
                  ret62488;
              }))
              );
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) ret62489;
            
            //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true && !(x10aux::nullCheck(dst)->FMGL(region)->contains(
                            p62484))) {
                
                //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                x10::regionarray::Array<void>::raiseBoundsError(
                  p62484);
            }
            
            //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(dst)->FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__set(
              (__extension__ ({
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62482 = p62484;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret62483;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62481 = ((x10_long) ((x10aux::nullCheck(pt62482)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(dst)->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt62482)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62481 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62481) * (x10aux::nullCheck(dst)->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62482)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (x10aux::nullCheck(dst)->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62478 = ((x10_long) ((x10aux::nullCheck(pt62482)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62479;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62479 = ((x10_long)2ll); ((i62479) <= (i61289max62478));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62479 = ((x10_long) ((i62479) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62480 = i62479;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62481 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62481) * (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62480) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62482)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62480))))) - (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62480) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62483 = offset62481;
                  ret62483;
              }))
              , v62485);
            
            //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            ret62489 = v62485;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Local_c
            ret62489;
        }
    }
    
    //#line 738 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_map_1477
#ifndef X10_REGIONARRAY_ARRAY_H_map_1478
#define X10_REGIONARRAY_ARRAY_H_map_1478
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::regionarray::Array<TPMGL(S)>* x10::regionarray::Array<TPMGL(T)>::map(
  x10::regionarray::Array<TPMGL(U)>* src, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) {
    
    //#line 755 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(S)>* alloc62522 =  ((new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(S)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(S)>))) x10::regionarray::Array<TPMGL(S)>()))
    ;
    
    //#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Region* reg62521 = this->FMGL(region);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(region) = (__extension__ ({
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__30__62506 =
          reg62521;
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62507;
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__30__62506,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62507 = __desugarer__var__30__62506;
        ret62507;
    }))
    ;
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(rank) = x10aux::nullCheck(reg62521)->
                               FMGL(rank);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(rect) = x10aux::nullCheck(reg62521)->
                               FMGL(rect);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(zeroBased) = x10aux::nullCheck(reg62521)->
                                    FMGL(zeroBased);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(rail) = x10aux::nullCheck(reg62521)->
                               FMGL(rail);
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(size) = x10aux::nullCheck(reg62521)->size();
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh62508 =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh62508)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg62521);
    
    //#line 176 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(layout_min0) = crh62508->FMGL(min0);
    
    //#line 177 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(layout_stride1) = crh62508->FMGL(stride1);
    
    //#line 178 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(layout_min1) = crh62508->FMGL(min1);
    
    //#line 179 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(layout) = crh62508->FMGL(layout);
    
    //#line 180 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n62509 = crh62508->FMGL(size);
    
    //#line 181 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(S) >* r62510 = x10::lang::Rail<TPMGL(S) >::_makeUnsafe(n62509, false);
    
    //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p62511;
        for (
             //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p62511 = x10aux::nullCheck(reg62521)->iterator();
             x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p62511));
             ) {
            
            //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62512 = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p62511));
            
            //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            r62510->x10::lang::template Rail<TPMGL(S) >::__set(
              (__extension__ ({
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62513 = p62512;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret62514;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62493 = ((x10_long) ((x10aux::nullCheck(pt62513)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (alloc62522->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt62513)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62493 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62493) * (alloc62522->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62513)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (alloc62522->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62490 = ((x10_long) ((x10aux::nullCheck(pt62513)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62491;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62491 = ((x10_long)2ll); ((i62491) <= (i61289max62490));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62491 = ((x10_long) ((i62491) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62492 = i62491;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62493 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62493) * (x10aux::nullCheck(alloc62522->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62492) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62513)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62492))))) - (x10aux::nullCheck(alloc62522->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62492) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62514 = offset62493;
                  ret62514;
              }))
              , (__extension__ ({
                  
                  //#line 755 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* p62515 = p62512;
                  x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op), 
                    (__extension__ ({
                        
                        //#line 755 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        x10::regionarray::Array<TPMGL(T)>* this62516 =
                          this;
                        
                        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        x10::lang::Point* pt62517 = p62515;
                        
                        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        TPMGL(T) ret62518;
                        
                        //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                        if (true && !(x10aux::nullCheck(this62516)->
                                        FMGL(region)->contains(
                                        pt62517))) {
                            
                            //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                            x10::regionarray::Array<void>::raiseBoundsError(
                              pt62517);
                        }
                        
                        //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                        ret62518 = x10aux::nullCheck(this62516)->
                                     FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                     (__extension__ ({
                                         
                                         //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10::lang::Point* pt62498 =
                                           pt62517;
                                         
                                         //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10_long ret62499;
                                         
                                         //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10_long offset62497 =
                                           ((x10_long) ((x10aux::nullCheck(pt62498)->x10::lang::Point::__apply(
                                                           ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62516)->
                                                                                              FMGL(layout_min0))));
                                         
                                         //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                         if (((x10aux::nullCheck(pt62498)->
                                                 FMGL(rank)) > (((x10_long)1ll))))
                                         {
                                             
                                             //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                             offset62497 =
                                               ((x10_long) ((((x10_long) ((((x10_long) ((offset62497) * (x10aux::nullCheck(this62516)->
                                                                                                           FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62498)->x10::lang::Point::__apply(
                                                                                                                                         ((x10_long)1ll)))))) - (x10aux::nullCheck(this62516)->
                                                                                                                                                                   FMGL(layout_min1))));
                                             
                                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                             x10_long i61289max62494 =
                                               ((x10_long) ((x10aux::nullCheck(pt62498)->
                                                               FMGL(rank)) - (((x10_long)1ll))));
                                             
                                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                             {
                                                 x10_long i62495;
                                                 for (
                                                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                      i62495 =
                                                        ((x10_long)2ll);
                                                      ((i62495) <= (i61289max62494));
                                                      
                                                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                      i62495 =
                                                        ((x10_long) ((i62495) + (((x10_long)1ll)))))
                                                 {
                                                     
                                                     //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                     x10_long i62496 =
                                                       i62495;
                                                     
                                                     //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                     offset62497 =
                                                       ((x10_long) ((((x10_long) ((((x10_long) ((offset62497) * (x10aux::nullCheck(x10aux::nullCheck(this62516)->
                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                   ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62496) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62498)->x10::lang::Point::__apply(
                                                                                                                                                                                                              i62496))))) - (x10aux::nullCheck(x10aux::nullCheck(this62516)->
                                                                                                                                                                                                                                                 FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                               ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62496) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                                 }
                                             }
                                             
                                         }
                                         
                                         //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                         ret62499 = offset62497;
                                         ret62499;
                                     }))
                                     );
                        ret62518;
                    }))
                    , (__extension__ ({
                        
                        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        x10::lang::Point* pt62519 = p62515;
                        
                        //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                        TPMGL(U) ret62520;
                        
                        //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                        if (true && !(x10aux::nullCheck(src)->
                                        FMGL(region)->contains(
                                        pt62519))) {
                            
                            //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                            x10::regionarray::Array<void>::raiseBoundsError(
                              pt62519);
                        }
                        
                        //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                        ret62520 = x10aux::nullCheck(src)->
                                     FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__apply(
                                     (__extension__ ({
                                         
                                         //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10::lang::Point* pt62504 =
                                           pt62519;
                                         
                                         //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10_long ret62505;
                                         
                                         //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                         x10_long offset62503 =
                                           ((x10_long) ((x10aux::nullCheck(pt62504)->x10::lang::Point::__apply(
                                                           ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(src)->
                                                                                              FMGL(layout_min0))));
                                         
                                         //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                         if (((x10aux::nullCheck(pt62504)->
                                                 FMGL(rank)) > (((x10_long)1ll))))
                                         {
                                             
                                             //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                             offset62503 =
                                               ((x10_long) ((((x10_long) ((((x10_long) ((offset62503) * (x10aux::nullCheck(src)->
                                                                                                           FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62504)->x10::lang::Point::__apply(
                                                                                                                                         ((x10_long)1ll)))))) - (x10aux::nullCheck(src)->
                                                                                                                                                                   FMGL(layout_min1))));
                                             
                                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                             x10_long i61289max62500 =
                                               ((x10_long) ((x10aux::nullCheck(pt62504)->
                                                               FMGL(rank)) - (((x10_long)1ll))));
                                             
                                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                             {
                                                 x10_long i62501;
                                                 for (
                                                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                      i62501 =
                                                        ((x10_long)2ll);
                                                      ((i62501) <= (i61289max62500));
                                                      
                                                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                      i62501 =
                                                        ((x10_long) ((i62501) + (((x10_long)1ll)))))
                                                 {
                                                     
                                                     //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                     x10_long i62502 =
                                                       i62501;
                                                     
                                                     //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                     offset62503 =
                                                       ((x10_long) ((((x10_long) ((((x10_long) ((offset62503) * (x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                   ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62502) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62504)->x10::lang::Point::__apply(
                                                                                                                                                                                                              i62502))))) - (x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                                                                                                                                                                                 FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                               ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62502) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                                 }
                                             }
                                             
                                         }
                                         
                                         //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                         ret62505 = offset62503;
                                         ret62505;
                                     }))
                                     );
                        ret62520;
                    }))
                    );
              }))
              );
        }
    }
    
    //#line 185 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    alloc62522->FMGL(raw) = r62510;
    
    //#line 755 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return alloc62522;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_map_1478
#ifndef X10_REGIONARRAY_ARRAY_H_map_1479
#define X10_REGIONARRAY_ARRAY_H_map_1479
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::regionarray::Array<TPMGL(S)>* x10::regionarray::Array<TPMGL(T)>::map(
  x10::regionarray::Array<TPMGL(S)>* dst, x10::regionarray::Array<TPMGL(U)>* src,
  x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) {
    
    //#line 774 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rect) && (x10aux::struct_equals(this->
                                                     FMGL(size),
                                                   x10aux::nullCheck(src)->
                                                     FMGL(size))))
    {
        
        //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* src62527 = this->FMGL(raw);
        
        //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(U) >* src62528 = (__extension__ ({
            
            //#line 778 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(U) >* __desugarer__var__35__62529 =
              x10aux::nullCheck(src)->FMGL(raw);
            
            //#line 778 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Rail<TPMGL(U) >* ret62530;
            
            //#line 778 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (!((x10aux::struct_equals((x10_long)(x10aux::nullCheck(__desugarer__var__35__62529)->FMGL(size)),
                                         (x10_long)(x10aux::nullCheck(x10aux::nullCheck(this)->
                                                                        FMGL(raw))->FMGL(size))))))
            {
                
                //#line 778 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                if (true) {
                    
                    //#line 778 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.lang.Rail[U]{self.size==this(:x10.regionarray.Array).raw.size}"))));
                }
                
            }
            
            //#line 778 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            ret62530 = __desugarer__var__35__62529;
            ret62530;
        }))
        ;
        
        //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(S) >* dst62531 = x10aux::nullCheck(dst)->
                                                 FMGL(raw);
        
        //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op62532 =
          op;
        
        //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(S) >* ret62533;
        
        //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail62523 = src62527;
        
        //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10_long i48178max62524 = (x10_long)(x10aux::nullCheck(rail62523)->FMGL(size));
        
        //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": polyglot.ast.For_c
        {
            x10_long i62525;
            for (
                 //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
                 i62525 = ((x10_long)0ll); ((i62525) < (i48178max62524));
                 
                 //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
                 i62525 = ((x10_long) ((i62525) + (((x10_long)1ll)))))
            {
                
                //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
                x10_long i62526 = i62525;
                
                //#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Call_c
                x10aux::nullCheck(dst62531)->x10::lang::template Rail<TPMGL(S) >::__set(
                  i62526, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op62532), 
                    x10aux::nullCheck(src62527)->x10::lang::template Rail<TPMGL(T) >::__apply(
                      i62526), x10aux::nullCheck(src62528)->x10::lang::template Rail<TPMGL(U) >::__apply(
                                 i62526)));
            }
        }
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
        ret62533 = dst62531;
        
        //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Local_c
        ret62533;
        
        //#line 779 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return dst;
        
    } else {
        
        //#line 781 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* p61281;
            for (
                 //#line 781 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 p61281 = this->FMGL(region)->iterator();
                 x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61281));
                 ) {
                
                //#line 781 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61281));
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p62552 = p;
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                TPMGL(S) v62553 = x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op), 
                  (__extension__ ({
                      
                      //#line 782 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::regionarray::Array<TPMGL(T)>* this62554 =
                        this;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt62555 = p;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      TPMGL(T) ret62556;
                      
                      //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (true && !(x10aux::nullCheck(this62554)->
                                      FMGL(region)->contains(
                                      pt62555))) {
                          
                          //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                          x10::regionarray::Array<void>::raiseBoundsError(
                            pt62555);
                      }
                      
                      //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret62556 = x10aux::nullCheck(this62554)->
                                   FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                   (__extension__ ({
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10::lang::Point* pt62538 =
                                         pt62555;
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long ret62539;
                                       
                                       //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long offset62537 =
                                         ((x10_long) ((x10aux::nullCheck(pt62538)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62554)->
                                                                                            FMGL(layout_min0))));
                                       
                                       //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                       if (((x10aux::nullCheck(pt62538)->
                                               FMGL(rank)) > (((x10_long)1ll))))
                                       {
                                           
                                           //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                           offset62537 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62537) * (x10aux::nullCheck(this62554)->
                                                                                                                     FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62538)->x10::lang::Point::__apply(
                                                                                                                                                   ((x10_long)1ll)))))) - (x10aux::nullCheck(this62554)->
                                                                                                                                                                             FMGL(layout_min1))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                           x10_long i61289max62534 =
                                             ((x10_long) ((x10aux::nullCheck(pt62538)->
                                                             FMGL(rank)) - (((x10_long)1ll))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                           {
                                               x10_long i62535;
                                               for (
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                    i62535 =
                                                      ((x10_long)2ll);
                                                    ((i62535) <= (i61289max62534));
                                                    
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                    i62535 =
                                                      ((x10_long) ((i62535) + (((x10_long)1ll)))))
                                               {
                                                   
                                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                   x10_long i62536 =
                                                     i62535;
                                                   
                                                   //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                   offset62537 =
                                                     ((x10_long) ((((x10_long) ((((x10_long) ((offset62537) * (x10aux::nullCheck(x10aux::nullCheck(this62554)->
                                                                                                                                   FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                 ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62536) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62538)->x10::lang::Point::__apply(
                                                                                                                                                                                                            i62536))))) - (x10aux::nullCheck(x10aux::nullCheck(this62554)->
                                                                                                                                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                             ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62536) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                               }
                                           }
                                           
                                       }
                                       
                                       //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       ret62539 = offset62537;
                                       ret62539;
                                   }))
                                   );
                      ret62556;
                  }))
                  , (__extension__ ({
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt62557 = p;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      TPMGL(U) ret62558;
                      
                      //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (true && !(x10aux::nullCheck(src)->
                                      FMGL(region)->contains(
                                      pt62557))) {
                          
                          //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                          x10::regionarray::Array<void>::raiseBoundsError(
                            pt62557);
                      }
                      
                      //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret62558 = x10aux::nullCheck(src)->
                                   FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__apply(
                                   (__extension__ ({
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10::lang::Point* pt62544 =
                                         pt62557;
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long ret62545;
                                       
                                       //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long offset62543 =
                                         ((x10_long) ((x10aux::nullCheck(pt62544)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(src)->
                                                                                            FMGL(layout_min0))));
                                       
                                       //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                       if (((x10aux::nullCheck(pt62544)->
                                               FMGL(rank)) > (((x10_long)1ll))))
                                       {
                                           
                                           //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                           offset62543 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62543) * (x10aux::nullCheck(src)->
                                                                                                                     FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62544)->x10::lang::Point::__apply(
                                                                                                                                                   ((x10_long)1ll)))))) - (x10aux::nullCheck(src)->
                                                                                                                                                                             FMGL(layout_min1))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                           x10_long i61289max62540 =
                                             ((x10_long) ((x10aux::nullCheck(pt62544)->
                                                             FMGL(rank)) - (((x10_long)1ll))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                           {
                                               x10_long i62541;
                                               for (
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                    i62541 =
                                                      ((x10_long)2ll);
                                                    ((i62541) <= (i61289max62540));
                                                    
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                    i62541 =
                                                      ((x10_long) ((i62541) + (((x10_long)1ll)))))
                                               {
                                                   
                                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                   x10_long i62542 =
                                                     i62541;
                                                   
                                                   //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                   offset62543 =
                                                     ((x10_long) ((((x10_long) ((((x10_long) ((offset62543) * (x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                                                                   FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                 ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62542) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62544)->x10::lang::Point::__apply(
                                                                                                                                                                                                            i62542))))) - (x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                                                                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                             ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62542) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                               }
                                           }
                                           
                                       }
                                       
                                       //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       ret62545 = offset62543;
                                       ret62545;
                                   }))
                                   );
                      ret62558;
                  }))
                  );
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                TPMGL(S) ret62559;
                
                //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                if (true && !(x10aux::nullCheck(dst)->FMGL(region)->contains(
                                p62552))) {
                    
                    //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                    x10::regionarray::Array<void>::raiseBoundsError(
                      p62552);
                }
                
                //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                x10aux::nullCheck(dst)->FMGL(raw)->x10::lang::template Rail<TPMGL(S) >::__set(
                  (__extension__ ({
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt62550 = p62552;
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long ret62551;
                      
                      //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long offset62549 = ((x10_long) ((x10aux::nullCheck(pt62550)->x10::lang::Point::__apply(
                                                             ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(dst)->
                                                                                                FMGL(layout_min0))));
                      
                      //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (((x10aux::nullCheck(pt62550)->FMGL(rank)) > (((x10_long)1ll))))
                      {
                          
                          //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                          offset62549 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62549) * (x10aux::nullCheck(dst)->
                                                                                                    FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62550)->x10::lang::Point::__apply(
                                                                                                                                  ((x10_long)1ll)))))) - (x10aux::nullCheck(dst)->
                                                                                                                                                            FMGL(layout_min1))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                          x10_long i61289max62546 = ((x10_long) ((x10aux::nullCheck(pt62550)->
                                                                    FMGL(rank)) - (((x10_long)1ll))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                          {
                              x10_long i62547;
                              for (
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   i62547 = ((x10_long)2ll);
                                   ((i62547) <= (i61289max62546));
                                   
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   i62547 = ((x10_long) ((i62547) + (((x10_long)1ll)))))
                              {
                                  
                                  //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                  x10_long i62548 = i62547;
                                  
                                  //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                  offset62549 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62549) * (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                            ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62548) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62550)->x10::lang::Point::__apply(
                                                                                                                                                                                                       i62548))))) - (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                        ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62548) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                              }
                          }
                          
                      }
                      
                      //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret62551 = offset62549;
                      ret62551;
                  }))
                  , v62553);
                
                //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                ret62559 = v62553;
                
                //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Local_c
                ret62559;
            }
        }
        
    }
    
    //#line 785 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_map_1479
#ifndef X10_REGIONARRAY_ARRAY_H_map_1480
#define X10_REGIONARRAY_ARRAY_H_map_1480
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::regionarray::Array<TPMGL(S)>* x10::regionarray::Array<TPMGL(T)>::map(
  x10::regionarray::Array<TPMGL(S)>* dst, x10::regionarray::Array<TPMGL(U)>* src,
  x10::regionarray::Region* filter, x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>* op) {
    
    //#line 805 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Region* fregion = this->FMGL(region)->__and(
                                          filter);
    
    //#line 806 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p61283;
        for (
             //#line 806 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p61283 = x10aux::nullCheck(fregion)->iterator();
             x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61283));
             ) {
            
            //#line 806 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61283));
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62578 = p;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(S) v62579 = x10::lang::Fun_0_2<TPMGL(T), TPMGL(U), TPMGL(S)>::__apply(x10aux::nullCheck(op), 
              (__extension__ ({
                  
                  //#line 807 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::regionarray::Array<TPMGL(T)>* this62580 =
                    this;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62581 = p;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  TPMGL(T) ret62582;
                  
                  //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (true && !(x10aux::nullCheck(this62580)->
                                  FMGL(region)->contains(
                                  pt62581))) {
                      
                      //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                      x10::regionarray::Array<void>::raiseBoundsError(
                        pt62581);
                  }
                  
                  //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62582 = x10aux::nullCheck(this62580)->
                               FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                               (__extension__ ({
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10::lang::Point* pt62564 =
                                     pt62581;
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long ret62565;
                                   
                                   //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long offset62563 =
                                     ((x10_long) ((x10aux::nullCheck(pt62564)->x10::lang::Point::__apply(
                                                     ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62580)->
                                                                                        FMGL(layout_min0))));
                                   
                                   //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                   if (((x10aux::nullCheck(pt62564)->
                                           FMGL(rank)) > (((x10_long)1ll))))
                                   {
                                       
                                       //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       offset62563 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62563) * (x10aux::nullCheck(this62580)->
                                                                                                                 FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62564)->x10::lang::Point::__apply(
                                                                                                                                               ((x10_long)1ll)))))) - (x10aux::nullCheck(this62580)->
                                                                                                                                                                         FMGL(layout_min1))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long i61289max62560 =
                                         ((x10_long) ((x10aux::nullCheck(pt62564)->
                                                         FMGL(rank)) - (((x10_long)1ll))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                       {
                                           x10_long i62561;
                                           for (
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                i62561 = ((x10_long)2ll);
                                                ((i62561) <= (i61289max62560));
                                                
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                i62561 = ((x10_long) ((i62561) + (((x10_long)1ll)))))
                                           {
                                               
                                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                               x10_long i62562 =
                                                 i62561;
                                               
                                               //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                               offset62563 =
                                                 ((x10_long) ((((x10_long) ((((x10_long) ((offset62563) * (x10aux::nullCheck(x10aux::nullCheck(this62580)->
                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                             ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62562) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62564)->x10::lang::Point::__apply(
                                                                                                                                                                                                        i62562))))) - (x10aux::nullCheck(x10aux::nullCheck(this62580)->
                                                                                                                                                                                                                                           FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                         ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62562) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                           }
                                       }
                                       
                                   }
                                   
                                   //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   ret62565 = offset62563;
                                   ret62565;
                               }))
                               );
                  ret62582;
              }))
              , (__extension__ ({
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62583 = p;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  TPMGL(U) ret62584;
                  
                  //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (true && !(x10aux::nullCheck(src)->FMGL(region)->contains(
                                  pt62583))) {
                      
                      //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                      x10::regionarray::Array<void>::raiseBoundsError(
                        pt62583);
                  }
                  
                  //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62584 = x10aux::nullCheck(src)->FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__apply(
                               (__extension__ ({
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10::lang::Point* pt62570 =
                                     pt62583;
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long ret62571;
                                   
                                   //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long offset62569 =
                                     ((x10_long) ((x10aux::nullCheck(pt62570)->x10::lang::Point::__apply(
                                                     ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(src)->
                                                                                        FMGL(layout_min0))));
                                   
                                   //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                   if (((x10aux::nullCheck(pt62570)->
                                           FMGL(rank)) > (((x10_long)1ll))))
                                   {
                                       
                                       //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       offset62569 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62569) * (x10aux::nullCheck(src)->
                                                                                                                 FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62570)->x10::lang::Point::__apply(
                                                                                                                                               ((x10_long)1ll)))))) - (x10aux::nullCheck(src)->
                                                                                                                                                                         FMGL(layout_min1))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long i61289max62566 =
                                         ((x10_long) ((x10aux::nullCheck(pt62570)->
                                                         FMGL(rank)) - (((x10_long)1ll))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                       {
                                           x10_long i62567;
                                           for (
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                i62567 = ((x10_long)2ll);
                                                ((i62567) <= (i61289max62566));
                                                
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                i62567 = ((x10_long) ((i62567) + (((x10_long)1ll)))))
                                           {
                                               
                                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                               x10_long i62568 =
                                                 i62567;
                                               
                                               //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                               offset62569 =
                                                 ((x10_long) ((((x10_long) ((((x10_long) ((offset62569) * (x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                             ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62568) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62570)->x10::lang::Point::__apply(
                                                                                                                                                                                                        i62568))))) - (x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                                                                                                                                                                           FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                         ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62568) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                           }
                                       }
                                       
                                   }
                                   
                                   //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   ret62571 = offset62569;
                                   ret62571;
                               }))
                               );
                  ret62584;
              }))
              );
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(S) ret62585;
            
            //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true && !(x10aux::nullCheck(dst)->FMGL(region)->contains(
                            p62578))) {
                
                //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                x10::regionarray::Array<void>::raiseBoundsError(
                  p62578);
            }
            
            //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(dst)->FMGL(raw)->x10::lang::template Rail<TPMGL(S) >::__set(
              (__extension__ ({
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62576 = p62578;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret62577;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62575 = ((x10_long) ((x10aux::nullCheck(pt62576)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(dst)->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt62576)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62575 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62575) * (x10aux::nullCheck(dst)->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62576)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (x10aux::nullCheck(dst)->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62572 = ((x10_long) ((x10aux::nullCheck(pt62576)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62573;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62573 = ((x10_long)2ll); ((i62573) <= (i61289max62572));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62573 = ((x10_long) ((i62573) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62574 = i62573;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62575 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62575) * (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62574) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62576)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62574))))) - (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62574) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62577 = offset62575;
                  ret62577;
              }))
              , v62579);
            
            //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            ret62585 = v62579;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Local_c
            ret62585;
        }
    }
    
    //#line 809 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_map_1480
#ifndef X10_REGIONARRAY_ARRAY_H_reduce_1481
#define X10_REGIONARRAY_ARRAY_H_reduce_1481
template<class TPMGL(T)> template<class TPMGL(U)> TPMGL(U)
  x10::regionarray::Array<TPMGL(T)>::reduce(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
                                            TPMGL(U) unit) {
    
    //#line 826 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rect)) {
        
        //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* src62591 = this->FMGL(raw);
        
        //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op62592 =
          op;
        
        //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        TPMGL(U) unit62593 = unit;
        
        //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        TPMGL(U) ret62594;
        
        //#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        TPMGL(U) accum62590 = unit62593;
        
        //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail62586 = src62591;
        
        //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
        x10_long i48144max62587 = (x10_long)(x10aux::nullCheck(rail62586)->FMGL(size));
        
        //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": polyglot.ast.For_c
        {
            x10_long i62588;
            for (
                 //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
                 i62588 = ((x10_long)0ll); ((i62588) < (i48144max62587));
                 
                 //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
                 i62588 = ((x10_long) ((i62588) + (((x10_long)1ll)))))
            {
                
                //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
                x10_long i62589 = i62588;
                
                //#line 127 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
                accum62590 = x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op62592), 
                  accum62590, x10aux::nullCheck(src62591)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                i62589));
            }
        }
        
        //#line 129 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
        ret62594 = accum62590;
        
        //#line 830 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return ret62594;
        
    } else {
        
        //#line 832 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        TPMGL(U) accum = unit;
        
        //#line 833 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* p61285;
            for (
                 //#line 833 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 p61285 = this->FMGL(region)->iterator();
                 x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61285));
                 ) {
                
                //#line 833 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61285));
                
                //#line 834 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                accum = x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
                  accum, (__extension__ ({
                      
                      //#line 834 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::regionarray::Array<TPMGL(T)>* this62237 =
                        this;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt62236 = p;
                      
                      //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      TPMGL(T) ret62238;
                      
                      //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (true && !(x10aux::nullCheck(this62237)->
                                      FMGL(region)->contains(
                                      pt62236))) {
                          
                          //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                          x10::regionarray::Array<void>::raiseBoundsError(
                            pt62236);
                      }
                      
                      //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret62238 = x10aux::nullCheck(this62237)->
                                   FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                   (__extension__ ({
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10::lang::Point* pt62599 =
                                         pt62236;
                                       
                                       //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long ret62600;
                                       
                                       //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long offset62598 =
                                         ((x10_long) ((x10aux::nullCheck(pt62599)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62237)->
                                                                                            FMGL(layout_min0))));
                                       
                                       //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                       if (((x10aux::nullCheck(pt62599)->
                                               FMGL(rank)) > (((x10_long)1ll))))
                                       {
                                           
                                           //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                           offset62598 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62598) * (x10aux::nullCheck(this62237)->
                                                                                                                     FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62599)->x10::lang::Point::__apply(
                                                                                                                                                   ((x10_long)1ll)))))) - (x10aux::nullCheck(this62237)->
                                                                                                                                                                             FMGL(layout_min1))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                           x10_long i61289max62595 =
                                             ((x10_long) ((x10aux::nullCheck(pt62599)->
                                                             FMGL(rank)) - (((x10_long)1ll))));
                                           
                                           //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                           {
                                               x10_long i62596;
                                               for (
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                    i62596 =
                                                      ((x10_long)2ll);
                                                    ((i62596) <= (i61289max62595));
                                                    
                                                    //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                    i62596 =
                                                      ((x10_long) ((i62596) + (((x10_long)1ll)))))
                                               {
                                                   
                                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                   x10_long i62597 =
                                                     i62596;
                                                   
                                                   //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                   offset62598 =
                                                     ((x10_long) ((((x10_long) ((((x10_long) ((offset62598) * (x10aux::nullCheck(x10aux::nullCheck(this62237)->
                                                                                                                                   FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                 ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62597) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62599)->x10::lang::Point::__apply(
                                                                                                                                                                                                            i62597))))) - (x10aux::nullCheck(x10aux::nullCheck(this62237)->
                                                                                                                                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                             ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62597) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                               }
                                           }
                                           
                                       }
                                       
                                       //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       ret62600 = offset62598;
                                       ret62600;
                                   }))
                                   );
                      ret62238;
                  }))
                  );
            }
        }
        
        //#line 836 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return accum;
        
    }
    
}
#endif // X10_REGIONARRAY_ARRAY_H_reduce_1481
#ifndef X10_REGIONARRAY_ARRAY_H_scan_1482
#define X10_REGIONARRAY_ARRAY_H_scan_1482
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
  x10::regionarray::Array<TPMGL(T)>::scan(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
                                          TPMGL(U) unit) {
    
    //#line 855 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62626 = this;
    
    //#line 872 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(U)>* dst62627 = (__extension__ ({
        
        //#line 855 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array<TPMGL(U)>* alloc62628 =  ((new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(U)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(U)>))) x10::regionarray::Array<TPMGL(U)>()))
        ;
        
        //#line 140 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Empty_c
        ;
        
        //#line 140 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* reg62605 = this->FMGL(region);
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(region) = (__extension__ ({
            
            //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* __desugarer__var__29__62601 =
              reg62605;
            
            //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::regionarray::Region* ret62602;
            
            //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (!((!x10aux::struct_equals(__desugarer__var__29__62601,
                                          reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
            {
                
                //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                if (true) {
                    
                    //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                    x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
                }
                
            }
            
            //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            ret62602 = __desugarer__var__29__62601;
            ret62602;
        }))
        ;
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(rank) = x10aux::nullCheck(reg62605)->
                                   FMGL(rank);
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(rect) = x10aux::nullCheck(reg62605)->
                                   FMGL(rect);
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(zeroBased) = x10aux::nullCheck(reg62605)->
                                        FMGL(zeroBased);
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(rail) = x10aux::nullCheck(reg62605)->
                                   FMGL(rail);
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(size) = x10aux::nullCheck(reg62605)->size();
        
        //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array__LayoutHelper crh62603 = 
        x10::regionarray::Array__LayoutHelper::_alloc();
        
        //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
        (crh62603)->::x10::regionarray::Array__LayoutHelper::_constructor(
          reg62605);
        
        //#line 144 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(layout_min0) = crh62603->FMGL(min0);
        
        //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(layout_stride1) = crh62603->FMGL(stride1);
        
        //#line 146 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(layout_min1) = crh62603->FMGL(min1);
        
        //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(layout) = crh62603->FMGL(layout);
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10_long n62604 = crh62603->FMGL(size);
        
        //#line 152 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62628->FMGL(raw) = x10::lang::Rail<TPMGL(U) >::_makeUnsafe(n62604, false);
        alloc62628;
    }))
    ;
    
    //#line 872 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op62629 =
      op;
    
    //#line 872 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) unit62630 = unit;
    
    //#line 872 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(U)>* ret62631;
    
    //#line 873 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) accum62621 = unit62630;
    
    //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p62622;
        for (
             //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p62622 = x10aux::nullCheck(this62626)->FMGL(region)->iterator();
             x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p62622));
             ) {
            
            //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62623 = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p62622));
            
            //#line 875 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            accum62621 = x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op62629), 
              accum62621, (__extension__ ({
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62624 = p62623;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  TPMGL(T) ret62625;
                  
                  //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (true && !(x10aux::nullCheck(this62626)->
                                  FMGL(region)->contains(
                                  pt62624))) {
                      
                      //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                      x10::regionarray::Array<void>::raiseBoundsError(
                        pt62624);
                  }
                  
                  //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62625 = x10aux::nullCheck(this62626)->
                               FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                               (__extension__ ({
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10::lang::Point* pt62610 =
                                     pt62624;
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long ret62611;
                                   
                                   //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long offset62609 =
                                     ((x10_long) ((x10aux::nullCheck(pt62610)->x10::lang::Point::__apply(
                                                     ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62626)->
                                                                                        FMGL(layout_min0))));
                                   
                                   //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                   if (((x10aux::nullCheck(pt62610)->
                                           FMGL(rank)) > (((x10_long)1ll))))
                                   {
                                       
                                       //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       offset62609 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62609) * (x10aux::nullCheck(this62626)->
                                                                                                                 FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62610)->x10::lang::Point::__apply(
                                                                                                                                               ((x10_long)1ll)))))) - (x10aux::nullCheck(this62626)->
                                                                                                                                                                         FMGL(layout_min1))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long i61289max62606 =
                                         ((x10_long) ((x10aux::nullCheck(pt62610)->
                                                         FMGL(rank)) - (((x10_long)1ll))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                       {
                                           x10_long i62607;
                                           for (
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                i62607 = ((x10_long)2ll);
                                                ((i62607) <= (i61289max62606));
                                                
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                i62607 = ((x10_long) ((i62607) + (((x10_long)1ll)))))
                                           {
                                               
                                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                               x10_long i62608 =
                                                 i62607;
                                               
                                               //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                               offset62609 =
                                                 ((x10_long) ((((x10_long) ((((x10_long) ((offset62609) * (x10aux::nullCheck(x10aux::nullCheck(this62626)->
                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                             ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62608) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62610)->x10::lang::Point::__apply(
                                                                                                                                                                                                        i62608))))) - (x10aux::nullCheck(x10aux::nullCheck(this62626)->
                                                                                                                                                                                                                                           FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                         ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62608) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                           }
                                       }
                                       
                                   }
                                   
                                   //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   ret62611 = offset62609;
                                   ret62611;
                               }))
                               );
                  ret62625;
              }))
              );
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62618 = p62623;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) v62619 = accum62621;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) ret62620;
            
            //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true && !(dst62627->FMGL(region)->contains(
                            p62618))) {
                
                //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                x10::regionarray::Array<void>::raiseBoundsError(
                  p62618);
            }
            
            //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            dst62627->FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__set(
              (__extension__ ({
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62616 = p62618;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret62617;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62615 = ((x10_long) ((x10aux::nullCheck(pt62616)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (dst62627->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt62616)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62615 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62615) * (dst62627->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62616)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (dst62627->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62612 = ((x10_long) ((x10aux::nullCheck(pt62616)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62613;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62613 = ((x10_long)2ll); ((i62613) <= (i61289max62612));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62613 = ((x10_long) ((i62613) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62614 = i62613;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62615 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62615) * (x10aux::nullCheck(dst62627->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62614) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62616)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62614))))) - (x10aux::nullCheck(dst62627->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62614) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62617 = offset62615;
                  ret62617;
              }))
              , v62619);
            
            //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            ret62620 = v62619;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Local_c
            ret62620;
        }
    }
    
    //#line 878 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    ret62631 = dst62627;
    
    //#line 855 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return ret62631;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_scan_1482
#ifndef X10_REGIONARRAY_ARRAY_H_scan_1483
#define X10_REGIONARRAY_ARRAY_H_scan_1483
template<class TPMGL(T)> template<class TPMGL(U)> x10::regionarray::Array<TPMGL(U)>*
  x10::regionarray::Array<TPMGL(T)>::scan(x10::regionarray::Array<TPMGL(U)>* dst,
                                          x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
                                          TPMGL(U) unit) {
    
    //#line 873 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) accum = unit;
    
    //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p61287;
        for (
             //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p61287 = this->FMGL(region)->iterator(); x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61287));
             ) {
            
            //#line 874 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61287));
            
            //#line 875 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            accum = x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op), 
              accum, (__extension__ ({
                  
                  //#line 875 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::regionarray::Array<TPMGL(T)>* this62292 =
                    this;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62291 = p;
                  
                  //#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  TPMGL(T) ret62293;
                  
                  //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (true && !(x10aux::nullCheck(this62292)->
                                  FMGL(region)->contains(
                                  pt62291))) {
                      
                      //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                      x10::regionarray::Array<void>::raiseBoundsError(
                        pt62291);
                  }
                  
                  //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62293 = x10aux::nullCheck(this62292)->
                               FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                               (__extension__ ({
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10::lang::Point* pt62636 =
                                     pt62291;
                                   
                                   //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long ret62637;
                                   
                                   //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   x10_long offset62635 =
                                     ((x10_long) ((x10aux::nullCheck(pt62636)->x10::lang::Point::__apply(
                                                     ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this62292)->
                                                                                        FMGL(layout_min0))));
                                   
                                   //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                                   if (((x10aux::nullCheck(pt62636)->
                                           FMGL(rank)) > (((x10_long)1ll))))
                                   {
                                       
                                       //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                       offset62635 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62635) * (x10aux::nullCheck(this62292)->
                                                                                                                 FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62636)->x10::lang::Point::__apply(
                                                                                                                                               ((x10_long)1ll)))))) - (x10aux::nullCheck(this62292)->
                                                                                                                                                                         FMGL(layout_min1))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                       x10_long i61289max62632 =
                                         ((x10_long) ((x10aux::nullCheck(pt62636)->
                                                         FMGL(rank)) - (((x10_long)1ll))));
                                       
                                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                                       {
                                           x10_long i62633;
                                           for (
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                                i62633 = ((x10_long)2ll);
                                                ((i62633) <= (i61289max62632));
                                                
                                                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                                i62633 = ((x10_long) ((i62633) + (((x10_long)1ll)))))
                                           {
                                               
                                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                               x10_long i62634 =
                                                 i62633;
                                               
                                               //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                               offset62635 =
                                                 ((x10_long) ((((x10_long) ((((x10_long) ((offset62635) * (x10aux::nullCheck(x10aux::nullCheck(this62292)->
                                                                                                                               FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                             ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62634) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62636)->x10::lang::Point::__apply(
                                                                                                                                                                                                        i62634))))) - (x10aux::nullCheck(x10aux::nullCheck(this62292)->
                                                                                                                                                                                                                                           FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                         ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62634) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                                           }
                                       }
                                       
                                   }
                                   
                                   //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   ret62637 = offset62635;
                                   ret62637;
                               }))
                               );
                  ret62293;
              }))
              );
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p62644 = p;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) v62645 = accum;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            TPMGL(U) ret62646;
            
            //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true && !(x10aux::nullCheck(dst)->FMGL(region)->contains(
                            p62644))) {
                
                //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                x10::regionarray::Array<void>::raiseBoundsError(
                  p62644);
            }
            
            //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(dst)->FMGL(raw)->x10::lang::template Rail<TPMGL(U) >::__set(
              (__extension__ ({
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt62642 = p62644;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret62643;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62641 = ((x10_long) ((x10aux::nullCheck(pt62642)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(dst)->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt62642)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62641 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62641) * (x10aux::nullCheck(dst)->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt62642)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (x10aux::nullCheck(dst)->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62638 = ((x10_long) ((x10aux::nullCheck(pt62642)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62639;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62639 = ((x10_long)2ll); ((i62639) <= (i61289max62638));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62639 = ((x10_long) ((i62639) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62640 = i62639;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62641 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62641) * (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62640) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt62642)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62640))))) - (x10aux::nullCheck(x10aux::nullCheck(dst)->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62640) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret62643 = offset62641;
                  ret62643;
              }))
              , v62645);
            
            //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
            ret62646 = v62645;
            
            //#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Local_c
            ret62646;
        }
    }
    
    //#line 878 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_REGIONARRAY_ARRAY_H_scan_1483
#endif // X10_REGIONARRAY_ARRAY_H_GENERICS
#ifndef X10_REGIONARRAY_ARRAY_H_IMPLEMENTATION
#define X10_REGIONARRAY_ARRAY_H_IMPLEMENTATION
#include <x10/regionarray/Array.h>

#ifndef X10_REGIONARRAY_ARRAY__CLOSURE__1_CLOSURE
#define X10_REGIONARRAY_ARRAY__CLOSURE__1_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_Array__closure__1 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10_long>::template itable <x10_regionarray_Array__closure__1<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10_long __apply() {
        
        //#line 938 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Try_c
        try {
            
            //#line 938 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
            return x10aux::nullCheck((gra)->__apply())->FMGL(region)->indexOf(
                     dstPoint);
            
        }
        catch (x10::lang::CheckedThrowable* __exc1491) {
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__0__ = static_cast<x10::lang::CheckedThrowable*>(__exc1491);
                {
                    
                    //#line 938 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                    x10_long __lowerer__var__1__ = x10aux::class_cast_unchecked<x10_long>(x10::lang::Runtime::wrapAtChecked<x10_long >(
                                                                                            __lowerer__var__0__));
                    
                    //#line 938 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
                    return __lowerer__var__1__;
                    
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > gra;
    x10::lang::Point* dstPoint;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->gra);
        buf.write(this->dstPoint);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_Array__closure__1<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_Array__closure__1<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > that_gra = buf.read<x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > >();
        x10::lang::Point* that_dstPoint = buf.read<x10::lang::Point*>();
        x10_regionarray_Array__closure__1<TPMGL(T) >* this_ = new (storage) x10_regionarray_Array__closure__1<TPMGL(T) >(that_gra, that_dstPoint);
        return this_;
    }
    
    x10_regionarray_Array__closure__1(x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > gra, x10::lang::Point* dstPoint) : gra(gra), dstPoint(dstPoint) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10_long> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10_long> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10:938";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10_long>::template itable <x10_regionarray_Array__closure__1<TPMGL(T) > >x10_regionarray_Array__closure__1<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_Array__closure__1<TPMGL(T) >::__apply, &x10_regionarray_Array__closure__1<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_Array__closure__1<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10_long> >, &x10_regionarray_Array__closure__1<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_Array__closure__1<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_Array__closure__1<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_ARRAY__CLOSURE__1_CLOSURE
#ifndef X10_REGIONARRAY_ARRAY__CLOSURE__2_CLOSURE
#define X10_REGIONARRAY_ARRAY__CLOSURE__2_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_regionarray_Array__closure__2 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10_long>::template itable <x10_regionarray_Array__closure__2<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10_long __apply() {
        
        //#line 1041 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Try_c
        try {
            
            //#line 1041 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
            return x10aux::nullCheck((gra)->__apply())->FMGL(region)->indexOf(
                     srcPoint);
            
        }
        catch (x10::lang::CheckedThrowable* __exc1492) {
            if (true) {
                x10::lang::CheckedThrowable* __lowerer__var__0__ = static_cast<x10::lang::CheckedThrowable*>(__exc1492);
                {
                    
                    //#line 1041 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                    x10_long __lowerer__var__1__ = x10aux::class_cast_unchecked<x10_long>(x10::lang::Runtime::wrapAtChecked<x10_long >(
                                                                                            __lowerer__var__0__));
                    
                    //#line 1041 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
                    return __lowerer__var__1__;
                    
                }
            } else
            throw;
        }
    }
    
    // captured environment
    x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > gra;
    x10::lang::Point* srcPoint;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->gra);
        buf.write(this->srcPoint);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_regionarray_Array__closure__2<TPMGL(T) >* storage = x10aux::alloc<x10_regionarray_Array__closure__2<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > that_gra = buf.read<x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > >();
        x10::lang::Point* that_srcPoint = buf.read<x10::lang::Point*>();
        x10_regionarray_Array__closure__2<TPMGL(T) >* this_ = new (storage) x10_regionarray_Array__closure__2<TPMGL(T) >(that_gra, that_srcPoint);
        return this_;
    }
    
    x10_regionarray_Array__closure__2(x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > gra, x10::lang::Point* srcPoint) : gra(gra), srcPoint(srcPoint) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10_long> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10_long> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10:1041";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10_long>::template itable <x10_regionarray_Array__closure__2<TPMGL(T) > >x10_regionarray_Array__closure__2<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_regionarray_Array__closure__2<TPMGL(T) >::__apply, &x10_regionarray_Array__closure__2<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_regionarray_Array__closure__2<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10_long> >, &x10_regionarray_Array__closure__2<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_regionarray_Array__closure__2<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_regionarray_Array__closure__2<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_REGIONARRAY_ARRAY__CLOSURE__2_CLOSURE

//#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.PropertyDecl_c

//#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.PropertyDecl_c

//#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.PropertyDecl_c

//#line 74 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.PropertyDecl_c

//#line 79 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.PropertyDecl_c

//#line 85 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.PropertyDecl_c
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::regionarray::Array<TPMGL(T)> >  x10::regionarray::Array<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::regionarray::Array<TPMGL(T)>::__apply, &x10::regionarray::Array<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::regionarray::Array<TPMGL(T)> >  x10::regionarray::Array<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::regionarray::Array<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Iterable<x10::lang::Point*>::template itable<x10::regionarray::Array<TPMGL(T)> >  x10::regionarray::Array<TPMGL(T)>::_itable_2(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::regionarray::Array<TPMGL(T)>::iterator, &x10::regionarray::Array<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::regionarray::Array<TPMGL(T)>::_itables[4] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterable<x10::lang::Point*> >, &_itable_2), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::regionarray::Array<TPMGL(T)> >())};

//#line 97 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c
/**
     * The backing storage for the array's elements
     */

//#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::regionarray::Array<TPMGL(T)>::raw(
  ) {
    
    //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw);
    
}

//#line 122 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::regionarray::Region* reg) {
    
    //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = (__extension__ ({
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__28__62357 = reg;
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62358;
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__28__62357,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62358 = __desugarer__var__28__62357;
        ret62358;
    }))
    ;
    FMGL(rank) = x10aux::nullCheck(reg)->FMGL(rank);
    FMGL(rect) = x10aux::nullCheck(reg)->FMGL(rect);
    FMGL(zeroBased) = x10aux::nullCheck(reg)->FMGL(zeroBased);
    FMGL(rail) = x10aux::nullCheck(reg)->FMGL(rail);
    FMGL(size) = x10aux::nullCheck(reg)->size();
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62356 = this;
    
    //#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg);
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = crh->FMGL(min0);
    
    //#line 127 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_stride1) = crh->FMGL(stride1);
    
    //#line 128 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min1) = crh->FMGL(min1);
    
    //#line 129 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = crh->FMGL(layout);
    
    //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n = crh->FMGL(size);
    
    //#line 131 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = x10::lang::Rail<TPMGL(T) >::_make(n);
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::regionarray::Region* reg)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(reg);
    return this_;
}



//#line 140 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10_boolean zeroed, x10::regionarray::Region* reg) {
    
    //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = (__extension__ ({
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__29__62360 =
          reg;
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62361;
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__29__62360,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62361 = __desugarer__var__29__62360;
        ret62361;
    }))
    ;
    FMGL(rank) = x10aux::nullCheck(reg)->FMGL(rank);
    FMGL(rect) = x10aux::nullCheck(reg)->FMGL(rect);
    FMGL(zeroBased) = x10aux::nullCheck(reg)->FMGL(zeroBased);
    FMGL(rail) = x10aux::nullCheck(reg)->FMGL(rail);
    FMGL(size) = x10aux::nullCheck(reg)->size();
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62359 = this;
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg);
    
    //#line 144 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = crh->FMGL(min0);
    
    //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_stride1) = crh->FMGL(stride1);
    
    //#line 146 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min1) = crh->FMGL(min1);
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = crh->FMGL(layout);
    
    //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n = crh->FMGL(size);
    
    //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (zeroed) {
        
        //#line 150 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(raw) = x10::lang::Rail<TPMGL(T) >::_make(n);
    } else {
        
        //#line 152 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(raw) = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(n, false);
    }
    
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10_boolean zeroed, x10::regionarray::Region* reg)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(zeroed, reg);
    return this_;
}



//#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::regionarray::Region* reg,
                           x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init) {
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = (__extension__ ({
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__30__62367 =
          reg;
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62368;
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__30__62367,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62368 = __desugarer__var__30__62367;
        ret62368;
    }))
    ;
    FMGL(rank) = x10aux::nullCheck(reg)->FMGL(rank);
    FMGL(rect) = x10aux::nullCheck(reg)->FMGL(rect);
    FMGL(zeroBased) = x10aux::nullCheck(reg)->FMGL(zeroBased);
    FMGL(rail) = x10aux::nullCheck(reg)->FMGL(rail);
    FMGL(size) = x10aux::nullCheck(reg)->size();
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62362 = this;
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg);
    
    //#line 176 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = crh->FMGL(min0);
    
    //#line 177 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_stride1) = crh->FMGL(stride1);
    
    //#line 178 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min1) = crh->FMGL(min1);
    
    //#line 179 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = crh->FMGL(layout);
    
    //#line 180 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n = crh->FMGL(size);
    
    //#line 181 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(n, false);
    
    //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10::lang::Iterator<x10::lang::Point*>* p61206;
        for (
             //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             p61206 = x10aux::nullCheck(reg)->iterator();
             x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61206));
             ) {
            
            //#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61206));
            
            //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            r->x10::lang::template Rail<TPMGL(T) >::__set(
              (__extension__ ({
                  
                  //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::regionarray::Array<TPMGL(T)>* this61512 =
                    this;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10::lang::Point* pt61506 = p;
                  
                  //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long ret61513;
                  
                  //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                  x10_long offset62366 = ((x10_long) ((x10aux::nullCheck(pt61506)->x10::lang::Point::__apply(
                                                         ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this61512)->
                                                                                            FMGL(layout_min0))));
                  
                  //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                  if (((x10aux::nullCheck(pt61506)->FMGL(rank)) > (((x10_long)1ll))))
                  {
                      
                      //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62366 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62366) * (x10aux::nullCheck(this61512)->
                                                                                                FMGL(layout_stride1))))) + (x10aux::nullCheck(pt61506)->x10::lang::Point::__apply(
                                                                                                                              ((x10_long)1ll)))))) - (x10aux::nullCheck(this61512)->
                                                                                                                                                        FMGL(layout_min1))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i61289max62363 = ((x10_long) ((x10aux::nullCheck(pt61506)->
                                                                FMGL(rank)) - (((x10_long)1ll))));
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                      {
                          x10_long i62364;
                          for (
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                               i62364 = ((x10_long)2ll); ((i62364) <= (i61289max62363));
                               
                               //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                               i62364 = ((x10_long) ((i62364) + (((x10_long)1ll)))))
                          {
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              x10_long i62365 = i62364;
                              
                              //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              offset62366 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62366) * (x10aux::nullCheck(x10aux::nullCheck(this61512)->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62365) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt61506)->x10::lang::Point::__apply(
                                                                                                                                                                                                   i62365))))) - (x10aux::nullCheck(x10aux::nullCheck(this61512)->
                                                                                                                                                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                    ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62365) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                          }
                      }
                      
                  }
                  
                  //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                  ret61513 = offset62366;
                  ret61513;
              }))
              , x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::__apply(x10aux::nullCheck(init), 
                p));
        }
    }
    
    //#line 185 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = r;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::regionarray::Region* reg,
                           x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>* init)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(reg, init);
    return this_;
}



//#line 195 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::regionarray::Region* reg,
                           TPMGL(T) init) {
    
    //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = (__extension__ ({
        
        //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__31__62378 =
          reg;
        
        //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62379;
        
        //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__31__62378,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62379 = __desugarer__var__31__62378;
        ret62379;
    }))
    ;
    FMGL(rank) = x10aux::nullCheck(reg)->FMGL(rank);
    FMGL(rect) = x10aux::nullCheck(reg)->FMGL(rect);
    FMGL(zeroBased) = x10aux::nullCheck(reg)->FMGL(zeroBased);
    FMGL(rail) = x10aux::nullCheck(reg)->FMGL(rail);
    FMGL(size) = x10aux::nullCheck(reg)->size();
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62369 = this;
    
    //#line 199 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 199 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg);
    
    //#line 200 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = crh->FMGL(min0);
    
    //#line 201 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_stride1) = crh->FMGL(stride1);
    
    //#line 202 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min1) = crh->FMGL(min1);
    
    //#line 203 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = crh->FMGL(layout);
    
    //#line 204 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n = crh->FMGL(size);
    
    //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(n, false);
    
    //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (x10aux::nullCheck(reg)->FMGL(rect)) {
        
        //#line 209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail62370 = r;
        
        //#line 209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10_long i61208max62371 = (x10_long)(x10aux::nullCheck(rail62370)->FMGL(size));
        
        //#line 209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10_long i62372;
            for (
                 //#line 209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 i62372 = ((x10_long)0ll); ((i62372) < (i61208max62371));
                 
                 //#line 209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 i62372 = ((x10_long) ((i62372) + (((x10_long)1ll)))))
            {
                
                //#line 209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10_long i62373 = i62372;
                
                //#line 210 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                r->x10::lang::template Rail<TPMGL(T) >::__set(
                  i62373, init);
            }
        }
        
    } else {
        
        //#line 213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* p61225;
            for (
                 //#line 213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 p61225 = x10aux::nullCheck(reg)->iterator();
                 x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61225));
                 ) {
                
                //#line 213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61225));
                
                //#line 214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                r->x10::lang::template Rail<TPMGL(T) >::__set(
                  (__extension__ ({
                      
                      //#line 214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::regionarray::Array<TPMGL(T)>* this61527 =
                        this;
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt61521 = p;
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long ret61528;
                      
                      //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long offset62377 = ((x10_long) ((x10aux::nullCheck(pt61521)->x10::lang::Point::__apply(
                                                             ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this61527)->
                                                                                                FMGL(layout_min0))));
                      
                      //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (((x10aux::nullCheck(pt61521)->FMGL(rank)) > (((x10_long)1ll))))
                      {
                          
                          //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                          offset62377 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62377) * (x10aux::nullCheck(this61527)->
                                                                                                    FMGL(layout_stride1))))) + (x10aux::nullCheck(pt61521)->x10::lang::Point::__apply(
                                                                                                                                  ((x10_long)1ll)))))) - (x10aux::nullCheck(this61527)->
                                                                                                                                                            FMGL(layout_min1))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                          x10_long i61289max62374 = ((x10_long) ((x10aux::nullCheck(pt61521)->
                                                                    FMGL(rank)) - (((x10_long)1ll))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                          {
                              x10_long i62375;
                              for (
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   i62375 = ((x10_long)2ll);
                                   ((i62375) <= (i61289max62374));
                                   
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   i62375 = ((x10_long) ((i62375) + (((x10_long)1ll)))))
                              {
                                  
                                  //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                  x10_long i62376 = i62375;
                                  
                                  //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                  offset62377 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62377) * (x10aux::nullCheck(x10aux::nullCheck(this61527)->
                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                            ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62376) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt61521)->x10::lang::Point::__apply(
                                                                                                                                                                                                       i62376))))) - (x10aux::nullCheck(x10aux::nullCheck(this61527)->
                                                                                                                                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                        ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62376) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                              }
                          }
                          
                      }
                      
                      //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret61528 = offset62377;
                      ret61528;
                  }))
                  , init);
            }
        }
        
    }
    
    //#line 217 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = r;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::regionarray::Region* reg,
                           TPMGL(T) init) {
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(reg, init);
    return this_;
}



//#line 231 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::regionarray::Region* reg,
                           x10::lang::Rail<TPMGL(T) >* backingStore) {
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = (__extension__ ({
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* __desugarer__var__32__62381 =
          reg;
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Region* ret62382;
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__32__62381,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.regionarray.Region{self!=null}"))));
            }
            
        }
        
        //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret62382 = __desugarer__var__32__62381;
        ret62382;
    }))
    ;
    FMGL(rank) = x10aux::nullCheck(reg)->FMGL(rank);
    FMGL(rect) = x10aux::nullCheck(reg)->FMGL(rect);
    FMGL(zeroBased) = x10aux::nullCheck(reg)->FMGL(zeroBased);
    FMGL(rail) = x10aux::nullCheck(reg)->FMGL(rail);
    FMGL(size) = x10aux::nullCheck(reg)->size();
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62380 = this;
    
    //#line 235 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array__LayoutHelper crh =  x10::regionarray::Array__LayoutHelper::_alloc();
    
    //#line 235 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (crh)->::x10::regionarray::Array__LayoutHelper::_constructor(
      reg);
    
    //#line 236 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = crh->FMGL(min0);
    
    //#line 237 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_stride1) = crh->FMGL(stride1);
    
    //#line 238 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min1) = crh->FMGL(min1);
    
    //#line 239 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = crh->FMGL(layout);
    
    //#line 240 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long n = crh->FMGL(size);
    
    //#line 241 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (((n) > ((x10_long)(x10aux::nullCheck(backingStore)->FMGL(size)))))
    {
        
        //#line 242 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
        x10aux::throwException(x10aux::nullCheck(x10::lang::IllegalArgumentException::_make(x10aux::makeStringLit("backingStore too small"))));
    }
    
    //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = (__extension__ ({
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* __desugarer__var__33__61536 =
          backingStore;
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* ret61537;
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__33__61536,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.lang.Rail[T]{self!=null}"))));
            }
            
        }
        
        //#line 244 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret61537 = __desugarer__var__33__61536;
        ret61537;
    }))
    ;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::regionarray::Region* reg,
                           x10::lang::Rail<TPMGL(T) >* backingStore)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(reg, backingStore);
    return this_;
}



//#line 253 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::lang::Rail<TPMGL(T) >* backingStore) {
    
    //#line 255 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long s = ((x10_long) (((x10_long)(x10aux::nullCheck(backingStore)->FMGL(size))) - (((x10_long)1ll))));
    
    //#line 256 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RectRegion1D* myReg =  ((new (memset(x10aux::alloc<x10::regionarray::RectRegion1D>(), 0, sizeof(x10::regionarray::RectRegion1D))) x10::regionarray::RectRegion1D()))
    ;
    
    //#line 256 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (myReg)->::x10::regionarray::RectRegion1D::_constructor(
      s);
    
    //#line 257 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = reinterpret_cast<x10::regionarray::Region*>(myReg);
    FMGL(rank) = ((x10_long)1ll);
    FMGL(rect) = true;
    FMGL(zeroBased) = true;
    FMGL(rail) = true;
    FMGL(size) = s;
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62383 = this;
    
    //#line 259 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = this->FMGL(layout_stride1) =
      this->FMGL(layout_min1) = ((x10_long)0ll);
    
    //#line 260 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = (x10aux::class_cast_unchecked<x10::lang::Rail<x10_long >*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = (__extension__ ({
        
        //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* __desugarer__var__34__61883 =
          backingStore;
        
        //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* ret61884;
        
        //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (!((!x10aux::struct_equals(__desugarer__var__34__61883,
                                      reinterpret_cast<x10::lang::NullType*>(X10_NULL)))))
        {
            
            //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
            if (true) {
                
                //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.Throw_c
                x10aux::throwException(x10aux::nullCheck(x10::lang::FailedDynamicCheckException::_make(x10aux::makeStringLit("x10.lang.Rail[T]{self!=null}"))));
            }
            
        }
        
        //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        ret61884 = __desugarer__var__34__61883;
        ret61884;
    }))
    ;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::lang::Rail<TPMGL(T) >* backingStore)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(backingStore);
    return this_;
}



//#line 268 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10_long size) {
    
    //#line 270 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RectRegion1D* myReg =  ((new (memset(x10aux::alloc<x10::regionarray::RectRegion1D>(), 0, sizeof(x10::regionarray::RectRegion1D))) x10::regionarray::RectRegion1D()))
    ;
    
    //#line 270 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (myReg)->::x10::regionarray::RectRegion1D::_constructor(
      ((x10_long) ((size) - (((x10_long)1ll)))));
    
    //#line 271 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = reinterpret_cast<x10::regionarray::Region*>(myReg);
    FMGL(rank) = ((x10_long)1ll);
    FMGL(rect) = true;
    FMGL(zeroBased) = true;
    FMGL(rail) = true;
    FMGL(size) = size;
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62384 = this;
    
    //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = this->FMGL(layout_stride1) =
      this->FMGL(layout_min1) = ((x10_long)0ll);
    
    //#line 274 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = (x10aux::class_cast_unchecked<x10::lang::Rail<x10_long >*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 275 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = x10::lang::Rail<TPMGL(T) >::_make(size);
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10_long size) {
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(size);
    return this_;
}



//#line 282 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10_boolean zeroed, x10_long size) {
    
    //#line 284 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RectRegion1D* myReg =  ((new (memset(x10aux::alloc<x10::regionarray::RectRegion1D>(), 0, sizeof(x10::regionarray::RectRegion1D))) x10::regionarray::RectRegion1D()))
    ;
    
    //#line 284 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (myReg)->::x10::regionarray::RectRegion1D::_constructor(
      ((x10_long) ((size) - (((x10_long)1ll)))));
    
    //#line 285 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = reinterpret_cast<x10::regionarray::Region*>(myReg);
    FMGL(rank) = ((x10_long)1ll);
    FMGL(rect) = true;
    FMGL(zeroBased) = true;
    FMGL(rail) = true;
    FMGL(size) = size;
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62385 = this;
    
    //#line 287 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = this->FMGL(layout_stride1) =
      this->FMGL(layout_min1) = ((x10_long)0ll);
    
    //#line 288 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = (x10aux::class_cast_unchecked<x10::lang::Rail<x10_long >*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 289 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (zeroed) {
        
        //#line 290 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(raw) = x10::lang::Rail<TPMGL(T) >::_make(size);
    } else {
        
        //#line 292 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        this->FMGL(raw) = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(size, false);
    }
    
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10_boolean zeroed, x10_long size)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(zeroed, size);
    return this_;
}



//#line 312 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10_long size, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init) {
    
    //#line 314 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RectRegion1D* myReg =  ((new (memset(x10aux::alloc<x10::regionarray::RectRegion1D>(), 0, sizeof(x10::regionarray::RectRegion1D))) x10::regionarray::RectRegion1D()))
    ;
    
    //#line 314 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (myReg)->::x10::regionarray::RectRegion1D::_constructor(
      ((x10_long) ((size) - (((x10_long)1ll)))));
    
    //#line 315 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = reinterpret_cast<x10::regionarray::Region*>(myReg);
    FMGL(rank) = ((x10_long)1ll);
    FMGL(rect) = true;
    FMGL(zeroBased) = true;
    FMGL(rail) = true;
    FMGL(size) = size;
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62386 = this;
    
    //#line 317 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = this->FMGL(layout_stride1) =
      this->FMGL(layout_min1) = ((x10_long)0ll);
    
    //#line 318 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = (x10aux::class_cast_unchecked<x10::lang::Rail<x10_long >*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 319 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(size, false);
    
    //#line 320 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long i61227max62387 = ((x10_long) ((size) - (((x10_long)1ll))));
    
    //#line 320 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10_long i62388;
        for (
             //#line 320 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             i62388 = ((x10_long)0ll); ((i62388) <= (i61227max62387));
             
             //#line 320 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
             i62388 = ((x10_long) ((i62388) + (((x10_long)1ll)))))
        {
            
            //#line 320 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10_long i62389 = i62388;
            
            //#line 321 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            r->x10::lang::template Rail<TPMGL(T) >::__set(
              i62389, x10::lang::Fun_0_1<x10_long, TPMGL(T)>::__apply(x10aux::nullCheck(init), 
                i62389));
        }
    }
    
    //#line 323 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = r;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10_long size, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(size, init);
    return this_;
}



//#line 333 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10_long size, TPMGL(T) init) {
    
    //#line 335 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RectRegion1D* myReg =  ((new (memset(x10aux::alloc<x10::regionarray::RectRegion1D>(), 0, sizeof(x10::regionarray::RectRegion1D))) x10::regionarray::RectRegion1D()))
    ;
    
    //#line 335 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
    (myReg)->::x10::regionarray::RectRegion1D::_constructor(
      ((x10_long) ((size) - (((x10_long)1ll)))));
    
    //#line 336 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = reinterpret_cast<x10::regionarray::Region*>(myReg);
    FMGL(rank) = ((x10_long)1ll);
    FMGL(rect) = true;
    FMGL(zeroBased) = true;
    FMGL(rail) = true;
    FMGL(size) = size;
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62390 = this;
    
    //#line 338 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = this->FMGL(layout_stride1) =
      this->FMGL(layout_min1) = ((x10_long)0ll);
    
    //#line 339 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = (x10aux::class_cast_unchecked<x10::lang::Rail<x10_long >*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 340 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r = x10::lang::Rail<TPMGL(T) >::_makeUnsafe(size, false);
    
    //#line 341 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long i61243max62391 = ((x10_long) ((size) - (((x10_long)1ll))));
    
    //#line 341 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
    {
        x10_long i62392;
        for (
             //#line 341 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
             i62392 = ((x10_long)0ll); ((i62392) <= (i61243max62391));
             
             //#line 341 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
             i62392 = ((x10_long) ((i62392) + (((x10_long)1ll)))))
        {
            
            //#line 341 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
            x10_long i62393 = i62392;
            
            //#line 342 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            r->x10::lang::template Rail<TPMGL(T) >::__set(
              i62393, init);
        }
    }
    
    //#line 344 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = r;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10_long size, TPMGL(T) init) {
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(size, init);
    return this_;
}



//#line 353 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::regionarray::Array<TPMGL(T)>* init) {
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(region) = x10aux::nullCheck(init)->FMGL(region);
    FMGL(rank) = x10aux::nullCheck(init)->FMGL(rank);
    FMGL(rect) = x10aux::nullCheck(init)->FMGL(rect);
    FMGL(zeroBased) = x10aux::nullCheck(init)->FMGL(zeroBased);
    FMGL(rail) = x10aux::nullCheck(init)->FMGL(rail);
    FMGL(size) = x10aux::nullCheck(init)->FMGL(size);
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62394 = this;
    
    //#line 356 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min0) = x10aux::nullCheck(init)->FMGL(layout_min0);
    
    //#line 357 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_stride1) = x10aux::nullCheck(init)->
                                   FMGL(layout_stride1);
    
    //#line 358 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout_min1) = x10aux::nullCheck(init)->FMGL(layout_min1);
    
    //#line 359 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(layout) = x10aux::nullCheck(init)->FMGL(layout);
    
    //#line 360 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r = x10::lang::Rail<TPMGL(T) >::_makeUnsafe((x10_long)(x10aux::nullCheck(x10aux::nullCheck(init)->
                                                                                                           FMGL(raw))->FMGL(size)), false);
    
    //#line 361 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(init)->
                                                       FMGL(raw),
                                                     ((x10_long)0ll),
                                                     r, ((x10_long)0ll),
                                                     (x10_long)(x10aux::nullCheck(r)->FMGL(size)));
    
    //#line 362 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = r;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::regionarray::Array<TPMGL(T)>* init)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(init);
    return this_;
}



//#line 371 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_constructor(
                           x10::regionarray::RemoteArray<TPMGL(T)>* init) {
    
    //#line 373 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* this62396 = this;
    
    //#line 353 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* init62397 = (x10aux::nullCheck(init)->
                                                      FMGL(array))->__apply();
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(region) = x10aux::nullCheck(init62397)->
                                                   FMGL(region);
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(rank) = x10aux::nullCheck(init62397)->
                                                 FMGL(rank);
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(rect) = x10aux::nullCheck(init62397)->
                                                 FMGL(rect);
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(zeroBased) = x10aux::nullCheck(init62397)->
                                                      FMGL(zeroBased);
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(rail) = x10aux::nullCheck(init62397)->
                                                 FMGL(rail);
    
    //#line 355 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(size) = x10aux::nullCheck(init62397)->
                                                 FMGL(size);
    
    //#line 356 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(layout_min0) = x10aux::nullCheck(init62397)->
                                                        FMGL(layout_min0);
    
    //#line 357 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(layout_stride1) = x10aux::nullCheck(init62397)->
                                                           FMGL(layout_stride1);
    
    //#line 358 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(layout_min1) = x10aux::nullCheck(init62397)->
                                                        FMGL(layout_min1);
    
    //#line 359 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(layout) = x10aux::nullCheck(init62397)->
                                                   FMGL(layout);
    
    //#line 360 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r62395 = x10::lang::Rail<TPMGL(T) >::_makeUnsafe((x10_long)(x10aux::nullCheck(x10aux::nullCheck(init62397)->
                                                                                                                FMGL(raw))->FMGL(size)), false);
    
    //#line 361 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(init62397)->
                                                       FMGL(raw),
                                                     ((x10_long)0ll),
                                                     r62395,
                                                     ((x10_long)0ll),
                                                     (x10_long)(x10aux::nullCheck(r62395)->FMGL(size)));
    
    //#line 362 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this62396)->FMGL(raw) = r62395;
}
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::_make(
                           x10::regionarray::RemoteArray<TPMGL(T)>* init)
{
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    this_->_constructor(init);
    return this_;
}



//#line 381 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::regionarray::Array<TPMGL(T)>::toString(
  ) {
    
    //#line 382 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rail)) {
        
        //#line 383 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::util::StringBuilder* sb =  ((new (memset(x10aux::alloc<x10::util::StringBuilder>(), 0, sizeof(x10::util::StringBuilder))) x10::util::StringBuilder()))
        ;
        
        //#line 383 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10ConstructorCall_c
        (sb)->::x10::util::StringBuilder::_constructor();
        
        //#line 384 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        sb->add(x10aux::makeStringLit("["));
        
        //#line 385 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10_long sz = (__extension__ ({
            
            //#line 364 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Math.x10": x10.ast.X10LocalDecl_c
            x10_long a61907 = this->FMGL(size);
            
            //#line 364 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/lang/Math.x10": polyglot.ast.Empty_c
            ;
            ((a61907) < (((x10_long)10ll))) ? (a61907) : (((x10_long)10ll));
        }))
        ;
        
        //#line 386 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10_long i61259max62398 = ((x10_long) ((sz) - (((x10_long)1ll))));
        
        //#line 386 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10_long i62399;
            for (
                 //#line 386 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 i62399 = ((x10_long)0ll); ((i62399) <= (i61259max62398));
                 
                 //#line 386 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 i62399 = ((x10_long) ((i62399) + (((x10_long)1ll)))))
            {
                
                //#line 386 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10_long i62400 = i62399;
                
                //#line 387 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                if (((i62400) > (((x10_long)0ll)))) {
                    
                    //#line 387 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                    sb->add(x10aux::makeStringLit(","));
                }
                
                //#line 388 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                sb->add(x10::lang::String::__plus(x10aux::makeStringLit(""), this->
                                                                               FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                                                                               i62400)));
            }
        }
        
        //#line 390 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (((sz) < (this->FMGL(size)))) {
            
            //#line 390 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            sb->add(x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("...(omitted "), ((x10_long) ((this->
                                                                                                                               FMGL(size)) - (sz)))), x10aux::makeStringLit(" elements)")));
        }
        
        //#line 391 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        sb->add(x10aux::makeStringLit("]"));
        
        //#line 392 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return sb->toString();
        
    } else {
        
        //#line 394 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("Array("), this->
                                                                                                      FMGL(region)), x10aux::makeStringLit(")"));
        
    }
    
}

//#line 404 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Iterator<x10::lang::Point*>*
  x10::regionarray::Array<TPMGL(T)>::iterator() {
    
    //#line 404 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this->FMGL(region)->iterator();
    
}

//#line 412 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Iterable<TPMGL(T)>* x10::regionarray::Array<TPMGL(T)>::values(
  ) {
    
    //#line 413 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rect)) {
        
        //#line 414 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array__Anonymous__14242<TPMGL(T)>* alloc62402 =
           ((new (memset(x10aux::alloc<x10::regionarray::Array__Anonymous__14242<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array__Anonymous__14242<TPMGL(T)>))) x10::regionarray::Array__Anonymous__14242<TPMGL(T)>()))
        ;
        
        //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array<TPMGL(T)>* out__62401 = this;
        
        //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62402->FMGL(out__) = out__62401;
        
        //#line 414 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return reinterpret_cast<x10::lang::Iterable<TPMGL(T)>*>(alloc62402);
        
    } else {
        
        //#line 422 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array__Anonymous__14528<TPMGL(T)>* alloc62404 =
           ((new (memset(x10aux::alloc<x10::regionarray::Array__Anonymous__14528<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array__Anonymous__14528<TPMGL(T)>))) x10::regionarray::Array__Anonymous__14528<TPMGL(T)>()))
        ;
        
        //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10::regionarray::Array<TPMGL(T)>* out__62403 = this;
        
        //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10FieldAssign_c
        alloc62404->FMGL(out__) = out__62403;
        
        //#line 422 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return reinterpret_cast<x10::lang::Iterable<TPMGL(T)>*>(alloc62404);
        
    }
    
}

//#line 442 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__apply(
  x10_long i0) {
    
    //#line 444 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rail)) {
        
        //#line 446 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                 i0);
        
    } else {
        
        //#line 448 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (true && !(this->FMGL(region)->contains(i0))) {
            
            //#line 449 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            x10::regionarray::Array<void>::raiseBoundsError(
              i0);
        }
        
        //#line 451 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
        return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                 ((x10_long) ((i0) - (this->FMGL(layout_min0)))));
        
    }
    
}

//#line 466 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__apply(
  x10_long i0, x10_long i1) {
    
    //#line 467 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(i0, i1))) {
        
        //#line 468 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(i0,
                                                        i1);
    }
    
    //#line 470 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long offset = ((x10_long) ((i0) - (this->FMGL(layout_min0))));
    
    //#line 471 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (this->
                                                                    FMGL(layout_stride1))))) + (i1)))) - (this->
                                                                                                            FMGL(layout_min1))));
    
    //#line 472 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             offset);
    
}

//#line 487 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__apply(
  x10_long i0, x10_long i1, x10_long i2) {
    
    //#line 488 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(i0, i1, i2)))
    {
        
        //#line 489 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(i0,
                                                        i1,
                                                        i2);
    }
    
    //#line 491 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             (__extension__ ({
                 
                 //#line 491 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Array<TPMGL(T)>* this61917 =
                   this;
                 
                 //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61913 = i0;
                 
                 //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61914 = i1;
                 
                 //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61915 = i2;
                 
                 //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long ret61918;
                 
                 //#line 1207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long offset62405 = ((x10_long) ((i61913) - (x10aux::nullCheck(this61917)->
                                                                   FMGL(layout_min0))));
                 
                 //#line 1208 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 offset62405 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62405) * (x10aux::nullCheck(this61917)->
                                                                                           FMGL(layout_stride1))))) + (i61914)))) - (x10aux::nullCheck(this61917)->
                                                                                                                                       FMGL(layout_min1))));
                 
                 //#line 1209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 offset62405 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62405) * (x10aux::nullCheck(x10aux::nullCheck(this61917)->
                                                                                                             FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                           ((x10_long)0ll)))))) + (i61915)))) - (x10aux::nullCheck(x10aux::nullCheck(this61917)->
                                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                   ((x10_long)1ll)))));
                 
                 //#line 1210 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 ret61918 = offset62405;
                 ret61918;
             }))
             );
    
}

//#line 507 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__apply(
  x10_long i0, x10_long i1, x10_long i2, x10_long i3) {
    
    //#line 508 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(i0, i1, i2,
                                               i3))) {
        
        //#line 509 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(i0,
                                                        i1,
                                                        i2,
                                                        i3);
    }
    
    //#line 511 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             (__extension__ ({
                 
                 //#line 511 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Array<TPMGL(T)>* this61925 =
                   this;
                 
                 //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61920 = i0;
                 
                 //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61921 = i1;
                 
                 //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61922 = i2;
                 
                 //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long i61923 = i3;
                 
                 //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long ret61926;
                 
                 //#line 1214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long offset62406 = ((x10_long) ((i61920) - (x10aux::nullCheck(this61925)->
                                                                   FMGL(layout_min0))));
                 
                 //#line 1215 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 offset62406 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62406) * (x10aux::nullCheck(this61925)->
                                                                                           FMGL(layout_stride1))))) + (i61921)))) - (x10aux::nullCheck(this61925)->
                                                                                                                                       FMGL(layout_min1))));
                 
                 //#line 1216 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 offset62406 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62406) * (x10aux::nullCheck(x10aux::nullCheck(this61925)->
                                                                                                             FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                           ((x10_long)0ll)))))) + (i61922)))) - (x10aux::nullCheck(x10aux::nullCheck(this61925)->
                                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                   ((x10_long)1ll)))));
                 
                 //#line 1217 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 offset62406 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62406) * (x10aux::nullCheck(x10aux::nullCheck(this61925)->
                                                                                                             FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                           ((x10_long)2ll)))))) + (i61923)))) - (x10aux::nullCheck(x10aux::nullCheck(this61925)->
                                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                   ((x10_long)3ll)))));
                 
                 //#line 1218 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 ret61926 = offset62406;
                 ret61926;
             }))
             );
    
}

//#line 523 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__apply(
  x10::lang::Point* pt) {
    
    //#line 524 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(pt))) {
        
        //#line 525 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(pt);
    }
    
    //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             (__extension__ ({
                 
                 //#line 527 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10::regionarray::Array<TPMGL(T)>* this61934 =
                   this;
                 
                 //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10::lang::Point* pt61928 = pt;
                 
                 //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long ret61935;
                 
                 //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 x10_long offset62410 = ((x10_long) ((x10aux::nullCheck(pt61928)->x10::lang::Point::__apply(
                                                        ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this61934)->
                                                                                           FMGL(layout_min0))));
                 
                 //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                 if (((x10aux::nullCheck(pt61928)->FMGL(rank)) > (((x10_long)1ll))))
                 {
                     
                     //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                     offset62410 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62410) * (x10aux::nullCheck(this61934)->
                                                                                               FMGL(layout_stride1))))) + (x10aux::nullCheck(pt61928)->x10::lang::Point::__apply(
                                                                                                                             ((x10_long)1ll)))))) - (x10aux::nullCheck(this61934)->
                                                                                                                                                       FMGL(layout_min1))));
                     
                     //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                     x10_long i61289max62407 = ((x10_long) ((x10aux::nullCheck(pt61928)->
                                                               FMGL(rank)) - (((x10_long)1ll))));
                     
                     //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                     {
                         x10_long i62408;
                         for (
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                              i62408 = ((x10_long)2ll); ((i62408) <= (i61289max62407));
                              
                              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                              i62408 = ((x10_long) ((i62408) + (((x10_long)1ll)))))
                         {
                             
                             //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                             x10_long i62409 = i62408;
                             
                             //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                             offset62410 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62410) * (x10aux::nullCheck(x10aux::nullCheck(this61934)->
                                                                                                                         FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                       ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62409) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt61928)->x10::lang::Point::__apply(
                                                                                                                                                                                                  i62409))))) - (x10aux::nullCheck(x10aux::nullCheck(this61934)->
                                                                                                                                                                                                                                     FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                   ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62409) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                         }
                     }
                     
                 }
                 
                 //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 ret61935 = offset62410;
                 ret61935;
             }))
             );
    
}

//#line 543 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__set(
  x10_long i0, TPMGL(T) v) {
    
    //#line 545 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rail)) {
        
        //#line 547 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
          i0, v);
    } else {
        
        //#line 549 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
        if (true && !(this->FMGL(region)->contains(i0))) {
            
            //#line 550 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
            x10::regionarray::Array<void>::raiseBoundsError(
              i0);
        }
        
        //#line 552 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
          ((x10_long) ((i0) - (this->FMGL(layout_min0)))),
          v);
    }
    
    //#line 554 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 570 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__set(
  x10_long i0, x10_long i1, TPMGL(T) v) {
    
    //#line 571 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(i0, i1))) {
        
        //#line 572 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(i0,
                                                        i1);
    }
    
    //#line 574 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long offset = ((x10_long) ((i0) - (this->FMGL(layout_min0))));
    
    //#line 575 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (this->
                                                                    FMGL(layout_stride1))))) + (i1)))) - (this->
                                                                                                            FMGL(layout_min1))));
    
    //#line 576 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      offset, v);
    
    //#line 577 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 594 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__set(
  x10_long i0, x10_long i1, x10_long i2, TPMGL(T) v) {
    
    //#line 595 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(i0, i1, i2)))
    {
        
        //#line 596 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(i0,
                                                        i1,
                                                        i2);
    }
    
    //#line 598 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      (__extension__ ({
          
          //#line 598 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10::regionarray::Array<TPMGL(T)>* this61941 = this;
          
          //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61937 = i0;
          
          //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61938 = i1;
          
          //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61939 = i2;
          
          //#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long ret61942;
          
          //#line 1207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long offset62411 = ((x10_long) ((i61937) - (x10aux::nullCheck(this61941)->
                                                            FMGL(layout_min0))));
          
          //#line 1208 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          offset62411 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62411) * (x10aux::nullCheck(this61941)->
                                                                                    FMGL(layout_stride1))))) + (i61938)))) - (x10aux::nullCheck(this61941)->
                                                                                                                                FMGL(layout_min1))));
          
          //#line 1209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          offset62411 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62411) * (x10aux::nullCheck(x10aux::nullCheck(this61941)->
                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                    ((x10_long)0ll)))))) + (i61939)))) - (x10aux::nullCheck(x10aux::nullCheck(this61941)->
                                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                            ((x10_long)1ll)))));
          
          //#line 1210 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          ret61942 = offset62411;
          ret61942;
      }))
      , v);
    
    //#line 599 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 617 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__set(
  x10_long i0, x10_long i1, x10_long i2, x10_long i3, TPMGL(T) v) {
    
    //#line 618 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(i0, i1, i2,
                                               i3))) {
        
        //#line 619 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(i0,
                                                        i1,
                                                        i2,
                                                        i3);
    }
    
    //#line 621 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      (__extension__ ({
          
          //#line 621 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10::regionarray::Array<TPMGL(T)>* this61949 = this;
          
          //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61944 = i0;
          
          //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61945 = i1;
          
          //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61946 = i2;
          
          //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long i61947 = i3;
          
          //#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long ret61950;
          
          //#line 1214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long offset62412 = ((x10_long) ((i61944) - (x10aux::nullCheck(this61949)->
                                                            FMGL(layout_min0))));
          
          //#line 1215 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          offset62412 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62412) * (x10aux::nullCheck(this61949)->
                                                                                    FMGL(layout_stride1))))) + (i61945)))) - (x10aux::nullCheck(this61949)->
                                                                                                                                FMGL(layout_min1))));
          
          //#line 1216 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          offset62412 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62412) * (x10aux::nullCheck(x10aux::nullCheck(this61949)->
                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                    ((x10_long)0ll)))))) + (i61946)))) - (x10aux::nullCheck(x10aux::nullCheck(this61949)->
                                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                            ((x10_long)1ll)))));
          
          //#line 1217 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          offset62412 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62412) * (x10aux::nullCheck(x10aux::nullCheck(this61949)->
                                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                    ((x10_long)2ll)))))) + (i61947)))) - (x10aux::nullCheck(x10aux::nullCheck(this61949)->
                                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                            ((x10_long)3ll)))));
          
          //#line 1218 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          ret61950 = offset62412;
          ret61950;
      }))
      , v);
    
    //#line 622 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 636 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::regionarray::Array<TPMGL(T)>::__set(
  x10::lang::Point* p, TPMGL(T) v) {
    
    //#line 637 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (true && !(this->FMGL(region)->contains(p))) {
        
        //#line 638 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        x10::regionarray::Array<void>::raiseBoundsError(p);
    }
    
    //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      (__extension__ ({
          
          //#line 640 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10::regionarray::Array<TPMGL(T)>* this61958 = this;
          
          //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10::lang::Point* pt61952 = p;
          
          //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long ret61959;
          
          //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
          x10_long offset62416 = ((x10_long) ((x10aux::nullCheck(pt61952)->x10::lang::Point::__apply(
                                                 ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this61958)->
                                                                                    FMGL(layout_min0))));
          
          //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
          if (((x10aux::nullCheck(pt61952)->FMGL(rank)) > (((x10_long)1ll))))
          {
              
              //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
              offset62416 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62416) * (x10aux::nullCheck(this61958)->
                                                                                        FMGL(layout_stride1))))) + (x10aux::nullCheck(pt61952)->x10::lang::Point::__apply(
                                                                                                                      ((x10_long)1ll)))))) - (x10aux::nullCheck(this61958)->
                                                                                                                                                FMGL(layout_min1))));
              
              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
              x10_long i61289max62413 = ((x10_long) ((x10aux::nullCheck(pt61952)->
                                                        FMGL(rank)) - (((x10_long)1ll))));
              
              //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
              {
                  x10_long i62414;
                  for (
                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                       i62414 = ((x10_long)2ll); ((i62414) <= (i61289max62413));
                       
                       //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                       i62414 = ((x10_long) ((i62414) + (((x10_long)1ll)))))
                  {
                      
                      //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long i62415 = i62414;
                      
                      //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      offset62416 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62416) * (x10aux::nullCheck(x10aux::nullCheck(this61958)->
                                                                                                                  FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62415) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt61952)->x10::lang::Point::__apply(
                                                                                                                                                                                           i62415))))) - (x10aux::nullCheck(x10aux::nullCheck(this61958)->
                                                                                                                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                            ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62415) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                  }
              }
              
          }
          
          //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
          ret61959 = offset62416;
          ret61959;
      }))
      , v);
    
    //#line 641 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 650 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::fill(
  TPMGL(T) v) {
    
    //#line 651 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (this->FMGL(rect)) {
        
        //#line 654 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
        this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::fill(
          v);
    } else {
        
        //#line 656 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10::lang::Iterator<x10::lang::Point*>* p61275;
            for (
                 //#line 656 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 p61275 = this->FMGL(region)->iterator();
                 x10::lang::Iterator<x10::lang::Point*>::hasNext(x10aux::nullCheck(p61275));
                 ) {
                
                //#line 656 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10::lang::Point* p = x10::lang::Iterator<x10::lang::Point*>::next(x10aux::nullCheck(p61275));
                
                //#line 657 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
                this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
                  (__extension__ ({
                      
                      //#line 657 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::regionarray::Array<TPMGL(T)>* this61967 =
                        this;
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10::lang::Point* pt61961 = p;
                      
                      //#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long ret61968;
                      
                      //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                      x10_long offset62420 = ((x10_long) ((x10aux::nullCheck(pt61961)->x10::lang::Point::__apply(
                                                             ((x10_long) (((x10_int)0))))) - (x10aux::nullCheck(this61967)->
                                                                                                FMGL(layout_min0))));
                      
                      //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
                      if (((x10aux::nullCheck(pt61961)->FMGL(rank)) > (((x10_long)1ll))))
                      {
                          
                          //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                          offset62420 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62420) * (x10aux::nullCheck(this61967)->
                                                                                                    FMGL(layout_stride1))))) + (x10aux::nullCheck(pt61961)->x10::lang::Point::__apply(
                                                                                                                                  ((x10_long)1ll)))))) - (x10aux::nullCheck(this61967)->
                                                                                                                                                            FMGL(layout_min1))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                          x10_long i61289max62417 = ((x10_long) ((x10aux::nullCheck(pt61961)->
                                                                    FMGL(rank)) - (((x10_long)1ll))));
                          
                          //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
                          {
                              x10_long i62418;
                              for (
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                   i62418 = ((x10_long)2ll);
                                   ((i62418) <= (i61289max62417));
                                   
                                   //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                   i62418 = ((x10_long) ((i62418) + (((x10_long)1ll)))))
                              {
                                  
                                  //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                                  x10_long i62419 = i62418;
                                  
                                  //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                                  offset62420 = ((x10_long) ((((x10_long) ((((x10_long) ((offset62420) * (x10aux::nullCheck(x10aux::nullCheck(this61967)->
                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                            ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62419) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt61961)->x10::lang::Point::__apply(
                                                                                                                                                                                                       i62419))))) - (x10aux::nullCheck(x10aux::nullCheck(this61967)->
                                                                                                                                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                                                        ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62419) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
                              }
                          }
                          
                      }
                      
                      //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                      ret61968 = offset62420;
                      ret61968;
                  }))
                  , v);
            }
        }
        
    }
    
}

//#line 667 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::clear(
  ) {
    
    //#line 668 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::clear(
      ((x10_long)0ll), (x10_long)(x10aux::nullCheck(this->
                                                      FMGL(raw))->FMGL(size)));
}

//#line 684 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 702 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 733 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 754 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 772 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 804 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 825 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 854 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 872 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 903 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 934 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 978 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1006 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1037 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1081 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1099 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1161 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1164 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1167 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1173 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c

//#line 1184 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c

//#line 1185 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c

//#line 1186 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c

//#line 1194 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10FieldDecl_c

//#line 1197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::regionarray::Array<TPMGL(T)>::offset(
  x10_long i0) {
    
    //#line 1197 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return ((x10_long) ((i0) - (this->FMGL(layout_min0))));
    
}

//#line 1200 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::regionarray::Array<TPMGL(T)>::offset(
  x10_long i0, x10_long i1) {
    
    //#line 1201 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long offset = ((x10_long) ((i0) - (this->FMGL(layout_min0))));
    
    //#line 1202 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (this->
                                                                    FMGL(layout_stride1))))) + (i1)))) - (this->
                                                                                                            FMGL(layout_min1))));
    
    //#line 1203 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return offset;
    
}

//#line 1206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::regionarray::Array<TPMGL(T)>::offset(
  x10_long i0, x10_long i1, x10_long i2) {
    
    //#line 1207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long offset = ((x10_long) ((i0) - (this->FMGL(layout_min0))));
    
    //#line 1208 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (this->
                                                                    FMGL(layout_stride1))))) + (i1)))) - (this->
                                                                                                            FMGL(layout_min1))));
    
    //#line 1209 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (x10aux::nullCheck(this->
                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                    ((x10_long)0ll)))))) + (i2)))) - (x10aux::nullCheck(this->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long)1ll)))));
    
    //#line 1210 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return offset;
    
}

//#line 1213 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::regionarray::Array<TPMGL(T)>::offset(
  x10_long i0, x10_long i1, x10_long i2, x10_long i3) {
    
    //#line 1214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long offset = ((x10_long) ((i0) - (this->FMGL(layout_min0))));
    
    //#line 1215 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (this->
                                                                    FMGL(layout_stride1))))) + (i1)))) - (this->
                                                                                                            FMGL(layout_min1))));
    
    //#line 1216 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (x10aux::nullCheck(this->
                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                    ((x10_long)0ll)))))) + (i2)))) - (x10aux::nullCheck(this->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long)1ll)))));
    
    //#line 1217 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
    offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (x10aux::nullCheck(this->
                                                                                      FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                    ((x10_long)2ll)))))) + (i3)))) - (x10aux::nullCheck(this->
                                                                                                                          FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                        ((x10_long)3ll)))));
    
    //#line 1218 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return offset;
    
}

//#line 1221 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::regionarray::Array<TPMGL(T)>::offset(
  x10::lang::Point* pt) {
    
    //#line 1222 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long offset = ((x10_long) ((x10aux::nullCheck(pt)->x10::lang::Point::__apply(
                                      ((x10_long) (((x10_int)0))))) - (this->
                                                                         FMGL(layout_min0))));
    
    //#line 1223 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10If_c
    if (((x10aux::nullCheck(pt)->FMGL(rank)) > (((x10_long)1ll))))
    {
        
        //#line 1224 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
        offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (this->
                                                                        FMGL(layout_stride1))))) + (x10aux::nullCheck(pt)->x10::lang::Point::__apply(
                                                                                                      ((x10_long)1ll)))))) - (this->
                                                                                                                                FMGL(layout_min1))));
        
        //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
        x10_long i61289max62662 = ((x10_long) ((x10aux::nullCheck(pt)->
                                                  FMGL(rank)) - (((x10_long)1ll))));
        
        //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": polyglot.ast.For_c
        {
            x10_long i62663;
            for (
                 //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                 i62663 = ((x10_long)2ll); ((i62663) <= (i61289max62662));
                 
                 //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                 i62663 = ((x10_long) ((i62663) + (((x10_long)1ll)))))
            {
                
                //#line 1225 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
                x10_long i62664 = i62663;
                
                //#line 1226 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10LocalAssign_c
                offset = ((x10_long) ((((x10_long) ((((x10_long) ((offset) * (x10aux::nullCheck(this->
                                                                                                  FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                ((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62664) - (((x10_long)2ll)))))))))))) + (x10aux::nullCheck(pt)->x10::lang::Point::__apply(
                                                                                                                                                                           i62664))))) - (x10aux::nullCheck(this->
                                                                                                                                                                                                              FMGL(layout))->x10::lang::template Rail<x10_long >::__apply(
                                                                                                                                                                                            ((x10_long) ((((x10_long) ((((x10_long)2ll)) * (((x10_long) ((i62664) - (((x10_long)2ll)))))))) + (((x10_long)1ll))))))));
            }
        }
        
    }
    
    //#line 1229 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return offset;
    
}

//#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::regionarray::Array<TPMGL(T)>*
  x10::regionarray::Array<TPMGL(T)>::x10__regionarray__Array____this__x10__regionarray__Array(
  ) {
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::__fieldInitializers_x10_regionarray_Array(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::regionarray::Array<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::regionarray::Array<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    buf.write(this->FMGL(raw));
    buf.write(this->FMGL(layout_min0));
    buf.write(this->FMGL(layout_stride1));
    buf.write(this->FMGL(layout_min1));
    buf.write(this->FMGL(layout));
    buf.write(this->FMGL(region));
    buf.write(this->FMGL(rank));
    buf.write(this->FMGL(rect));
    buf.write(this->FMGL(zeroBased));
    buf.write(this->FMGL(rail));
    buf.write(this->FMGL(size));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::regionarray::Array<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::regionarray::Array<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::regionarray::Array<TPMGL(T)> >(), 0, sizeof(x10::regionarray::Array<TPMGL(T)>))) x10::regionarray::Array<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::regionarray::Array<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(raw) = buf.read<x10::lang::Rail<TPMGL(T) >*>();
    FMGL(layout_min0) = buf.read<x10_long>();
    FMGL(layout_stride1) = buf.read<x10_long>();
    FMGL(layout_min1) = buf.read<x10_long>();
    FMGL(layout) = buf.read<x10::lang::Rail<x10_long >*>();
    FMGL(region) = buf.read<x10::regionarray::Region*>();
    FMGL(rank) = buf.read<x10_long>();
    FMGL(rect) = buf.read<x10_boolean>();
    FMGL(zeroBased) = buf.read<x10_boolean>();
    FMGL(rail) = buf.read<x10_boolean>();
    FMGL(size) = buf.read<x10_long>();
}

template<class TPMGL(T)> void x10::regionarray::Array<void>::asyncCopy(x10::regionarray::Array<TPMGL(T)>* src,
                                                                       x10::regionarray::RemoteArray<TPMGL(T)>* dst)
{
    
    //#line 904 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template asyncCopy<TPMGL(T) >(
      x10aux::nullCheck(src)->FMGL(raw), ((x10_long)0ll),
      x10aux::nullCheck(dst)->FMGL(rawData), ((x10_long)0ll),
      (x10_long)(x10aux::nullCheck(x10aux::nullCheck(src)->
                                     FMGL(raw))->FMGL(size)));
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::asyncCopy(x10::regionarray::Array<TPMGL(T)>* src,
                                                                       x10::lang::Point* srcPoint,
                                                                       x10::regionarray::RemoteArray<TPMGL(T)>* dst,
                                                                       x10::lang::Point* dstPoint,
                                                                       x10_long numElems)
{
    
    //#line 937 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > gra =
      x10aux::nullCheck(dst)->FMGL(array);
    
    //#line 938 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long dstIndex = x10::lang::Runtime::template evalAt<x10_long >(
                          x10::lang::Place::place(((x10_long)((gra)->location))),
                          reinterpret_cast<x10::lang::Fun_0_0<x10_long>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10_long> >(sizeof(x10_regionarray_Array__closure__1<TPMGL(T)>)))x10_regionarray_Array__closure__1<TPMGL(T)>(gra, dstPoint))),
                          x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 978 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* src62647 = src;
    
    //#line 978 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long srcIndex62648 = x10aux::nullCheck(src)->FMGL(region)->indexOf(
                               srcPoint);
    
    //#line 979 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RemoteArray<TPMGL(T)>* dst62649 = dst;
    
    //#line 979 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long dstIndex62650 = dstIndex;
    
    //#line 980 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long numElems62651 = numElems;
    
    //#line 981 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template asyncCopy<TPMGL(T) >(
      x10aux::nullCheck(src62647)->FMGL(raw), srcIndex62648,
      x10aux::nullCheck(dst62649)->FMGL(rawData), dstIndex62650,
      numElems62651);
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::asyncCopy(x10::regionarray::Array<TPMGL(T)>* src,
                                                                       x10_long srcIndex,
                                                                       x10::regionarray::RemoteArray<TPMGL(T)>* dst,
                                                                       x10_long dstIndex,
                                                                       x10_long numElems)
{
    
    //#line 981 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template asyncCopy<TPMGL(T) >(
      x10aux::nullCheck(src)->FMGL(raw), srcIndex, x10aux::nullCheck(dst)->
                                                     FMGL(rawData),
      dstIndex, numElems);
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::asyncCopy(x10::regionarray::RemoteArray<TPMGL(T)>* src,
                                                                       x10::regionarray::Array<TPMGL(T)>* dst)
{
    
    //#line 1007 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template asyncCopy<TPMGL(T) >(
      x10aux::nullCheck(src)->FMGL(rawData), ((x10_long)0ll),
      x10aux::nullCheck(dst)->FMGL(raw), ((x10_long)0ll),
      (x10_long)(x10aux::nullCheck(x10aux::nullCheck(dst)->
                                     FMGL(raw))->FMGL(size)));
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::asyncCopy(x10::regionarray::RemoteArray<TPMGL(T)>* src,
                                                                       x10::lang::Point* srcPoint,
                                                                       x10::regionarray::Array<TPMGL(T)>* dst,
                                                                       x10::lang::Point* dstPoint,
                                                                       x10_long numElems)
{
    
    //#line 1040 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::GlobalRef<x10::regionarray::Array<TPMGL(T)>* > gra =
      x10aux::nullCheck(src)->FMGL(array);
    
    //#line 1041 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long srcIndex = x10::lang::Runtime::template evalAt<x10_long >(
                          x10::lang::Place::place(((x10_long)((gra)->location))),
                          reinterpret_cast<x10::lang::Fun_0_0<x10_long>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10_long> >(sizeof(x10_regionarray_Array__closure__2<TPMGL(T)>)))x10_regionarray_Array__closure__2<TPMGL(T)>(gra, srcPoint))),
                          x10aux::class_cast_unchecked<x10::lang::Runtime__Profile*>(reinterpret_cast<x10::lang::NullType*>(X10_NULL)));
    
    //#line 1081 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::RemoteArray<TPMGL(T)>* src62652 = src;
    
    //#line 1081 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long srcIndex62653 = srcIndex;
    
    //#line 1082 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* dst62654 = dst;
    
    //#line 1082 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long dstIndex62655 = x10aux::nullCheck(dst)->FMGL(region)->indexOf(
                               dstPoint);
    
    //#line 1083 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long numElems62656 = numElems;
    
    //#line 1084 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template asyncCopy<TPMGL(T) >(
      x10aux::nullCheck(src62652)->FMGL(rawData), srcIndex62653,
      x10aux::nullCheck(dst62654)->FMGL(raw), dstIndex62655,
      numElems62656);
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::asyncCopy(x10::regionarray::RemoteArray<TPMGL(T)>* src,
                                                                       x10_long srcIndex,
                                                                       x10::regionarray::Array<TPMGL(T)>* dst,
                                                                       x10_long dstIndex,
                                                                       x10_long numElems)
{
    
    //#line 1084 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template asyncCopy<TPMGL(T) >(
      x10aux::nullCheck(src)->FMGL(rawData), srcIndex, x10aux::nullCheck(dst)->
                                                         FMGL(raw),
      dstIndex, numElems);
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::copy(x10::regionarray::Array<TPMGL(T)>* src,
                                                                  x10::regionarray::Array<TPMGL(T)>* dst)
{
    
    //#line 1100 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(src)->
                                                       FMGL(raw),
                                                     ((x10_long)0ll),
                                                     x10aux::nullCheck(dst)->
                                                       FMGL(raw),
                                                     ((x10_long)0ll),
                                                     (x10_long)(x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                    FMGL(raw))->FMGL(size)));
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::copy(x10::regionarray::Array<TPMGL(T)>* src,
                                                                  x10::lang::Point* srcPoint,
                                                                  x10::regionarray::Array<TPMGL(T)>* dst,
                                                                  x10::lang::Point* dstPoint,
                                                                  x10_long numElems)
{
    
    //#line 1154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* src62657 = src;
    
    //#line 1154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long srcIndex62658 = x10aux::nullCheck(src)->FMGL(region)->indexOf(
                               srcPoint);
    
    //#line 1155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10::regionarray::Array<TPMGL(T)>* dst62659 = dst;
    
    //#line 1155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long dstIndex62660 = x10aux::nullCheck(dst)->FMGL(region)->indexOf(
                               dstPoint);
    
    //#line 1156 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": x10.ast.X10LocalDecl_c
    x10_long numElems62661 = numElems;
    
    //#line 1157 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(src62657)->
                                                       FMGL(raw),
                                                     srcIndex62658,
                                                     x10aux::nullCheck(dst62659)->
                                                       FMGL(raw),
                                                     dstIndex62660,
                                                     numElems62661);
}
template<class TPMGL(T)> void x10::regionarray::Array<void>::copy(x10::regionarray::Array<TPMGL(T)>* src,
                                                                  x10_long srcIndex,
                                                                  x10::regionarray::Array<TPMGL(T)>* dst,
                                                                  x10_long dstIndex,
                                                                  x10_long numElems)
{
    
    //#line 1157 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/regionarray/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(src)->
                                                       FMGL(raw),
                                                     srcIndex,
                                                     x10aux::nullCheck(dst)->
                                                       FMGL(raw),
                                                     dstIndex,
                                                     numElems);
}
#endif // X10_REGIONARRAY_ARRAY_H_IMPLEMENTATION
#endif // __X10_REGIONARRAY_ARRAY_H_NODEPS
