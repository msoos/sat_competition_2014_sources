#ifndef __X10_ARRAY_DISTARRAY_UNIQUE_H
#define __X10_ARRAY_DISTARRAY_UNIQUE_H

#include <x10rt.h>


#define X10_ARRAY_DISTARRAY_H_NODEPS
#include <x10/array/DistArray.h>
#undef X10_ARRAY_DISTARRAY_H_NODEPS
#define X10_LANG_FUN_0_1_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#undef X10_LANG_FUN_0_1_H_NODEPS
namespace x10 { namespace lang { 
class PlaceGroup;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(U)> class Fun_0_0;
} } 
namespace x10 { namespace array { 
template<class TPMGL(S)> class LocalState;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace array { 
class DenseIterationSpace_1;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class Point;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace array { 

template<class TPMGL(T)> class DistArray_Unique;
template <> class DistArray_Unique<void>;
template<class TPMGL(T)> class DistArray_Unique : public x10::array::DistArray<TPMGL(T)>
  {
    public:
    RTT_H_DECLS_CLASS
    
    static x10aux::itable_entry _itables[4];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Iterable<x10::lang::Point*>::template itable<x10::array::DistArray_Unique<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::array::DistArray_Unique<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::Fun_0_1<x10_long, TPMGL(T)>::template itable<x10::array::DistArray_Unique<TPMGL(T)> > _itable_2;
    
    x10_long rank();
    void _constructor();
    
    static x10::array::DistArray_Unique<TPMGL(T)>* _make();
    
    void _constructor(x10::lang::Fun_0_0<TPMGL(T)>* init);
    
    static x10::array::DistArray_Unique<TPMGL(T)>* _make(x10::lang::Fun_0_0<TPMGL(T)>* init);
    
    void _constructor(x10::lang::PlaceGroup* pg, x10::lang::Fun_0_0<TPMGL(T)>* init);
    
    static x10::array::DistArray_Unique<TPMGL(T)>* _make(x10::lang::PlaceGroup* pg,
                                                         x10::lang::Fun_0_0<TPMGL(T)>* init);
    
    virtual x10::array::IterationSpace* globalIndices();
    virtual x10::array::IterationSpace* localIndices();
    virtual x10::lang::Place place(x10_long i);
    virtual x10::lang::Place place(x10::lang::Point* p);
    virtual TPMGL(T) __apply(x10_long i);
    virtual TPMGL(T) __apply(x10::lang::Point* p);
    virtual TPMGL(T) __set(x10_long i, TPMGL(T) v);
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v);
    void validateIndex(x10_long i);
    virtual x10::array::DistArray_Unique<TPMGL(T)>* x10__array__DistArray_Unique____this__x10__array__DistArray_Unique(
      );
    virtual void __fieldInitializers_x10_array_DistArray_Unique(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::array::DistArray_Unique<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::DistArray_Unique<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::array::DistArray<TPMGL(T)> >(), x10aux::getRTT<x10::lang::Fun_0_1<x10_long, TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.DistArray_Unique";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class DistArray_Unique<void> : public x10::array::DistArray<void>
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    
};

} } 
#endif // X10_ARRAY_DISTARRAY_UNIQUE_H

namespace x10 { namespace array { 
template<class TPMGL(T)> class DistArray_Unique;
} } 

#ifndef X10_ARRAY_DISTARRAY_UNIQUE_H_NODEPS
#define X10_ARRAY_DISTARRAY_UNIQUE_H_NODEPS
#include <x10/array/DistArray.h>
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/Long.h>
#include <x10/lang/PlaceGroup.h>
#include <x10/lang/Fun_0_0.h>
#include <x10/array/LocalState.h>
#include <x10/lang/Rail.h>
#include <x10/array/DenseIterationSpace_1.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Place.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Point.h>
#include <x10/compiler/Inline.h>
#ifndef X10_ARRAY_DISTARRAY_UNIQUE_H_GENERICS
#define X10_ARRAY_DISTARRAY_UNIQUE_H_GENERICS
#endif // X10_ARRAY_DISTARRAY_UNIQUE_H_GENERICS
#ifndef X10_ARRAY_DISTARRAY_UNIQUE_H_IMPLEMENTATION
#define X10_ARRAY_DISTARRAY_UNIQUE_H_IMPLEMENTATION
#include <x10/array/DistArray_Unique.h>

#ifndef X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__1_CLOSURE
#define X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__1_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_array_DistArray_Unique__closure__1 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>::template itable <x10_array_DistArray_Unique__closure__1<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::array::LocalState<TPMGL(T)>* __apply() {
        
        //#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
        x10::array::LocalState<TPMGL(T)>* alloc50891 =  ((new (memset(x10aux::alloc<x10::array::LocalState<TPMGL(T)> >(), 0, sizeof(x10::array::LocalState<TPMGL(T)>))) x10::array::LocalState<TPMGL(T)>()))
        ;
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::PlaceGroup* pg50887 = reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                    FMGL(WORLD__get)());
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail50888 = x10::lang::Rail<TPMGL(T) >::_make(((x10_long)1ll));
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10_long size50889 = (__extension__ ({
            
            //#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
            x10::lang::PlaceGroup* this50890 = reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                          FMGL(WORLD__get)());
            x10aux::nullCheck(this50890)->numPlaces();
        }))
        ;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50891->FMGL(pg) = pg50887;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50891->FMGL(rail) = rail50888;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50891->FMGL(size) = size50889;
        
        //#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
        return alloc50891;
        
    }
    
    // captured environment
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_array_DistArray_Unique__closure__1<TPMGL(T) >* storage = x10aux::alloc<x10_array_DistArray_Unique__closure__1<TPMGL(T) > >();
        buf.record_reference(storage);
        x10_array_DistArray_Unique__closure__1<TPMGL(T) >* this_ = new (storage) x10_array_DistArray_Unique__closure__1<TPMGL(T) >();
        return this_;
    }
    
    x10_array_DistArray_Unique__closure__1() { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10:30";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>::template itable <x10_array_DistArray_Unique__closure__1<TPMGL(T) > >x10_array_DistArray_Unique__closure__1<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_array_DistArray_Unique__closure__1<TPMGL(T) >::__apply, &x10_array_DistArray_Unique__closure__1<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_array_DistArray_Unique__closure__1<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >, &x10_array_DistArray_Unique__closure__1<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_array_DistArray_Unique__closure__1<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_array_DistArray_Unique__closure__1<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__1_CLOSURE
#ifndef X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__2_CLOSURE
#define X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__2_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_array_DistArray_Unique__closure__2 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>::template itable <x10_array_DistArray_Unique__closure__2<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::array::LocalState<TPMGL(T)>* __apply() {
        
        //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
        x10::array::LocalState<TPMGL(T)>* alloc50897 =  ((new (memset(x10aux::alloc<x10::array::LocalState<TPMGL(T)> >(), 0, sizeof(x10::array::LocalState<TPMGL(T)>))) x10::array::LocalState<TPMGL(T)>()))
        ;
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::PlaceGroup* pg50893 = reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                    FMGL(WORLD__get)());
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail50894 = x10::lang::Rail<TPMGL(T) >::_make(((x10_long)1ll),
                                                                                  x10::lang::Fun_0_0<TPMGL(T)>::__apply(x10aux::nullCheck(init)));
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10_long size50895 = (__extension__ ({
            
            //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
            x10::lang::PlaceGroup* this50896 = reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                          FMGL(WORLD__get)());
            x10aux::nullCheck(this50896)->numPlaces();
        }))
        ;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50897->FMGL(pg) = pg50893;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50897->FMGL(rail) = rail50894;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50897->FMGL(size) = size50895;
        
        //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
        return alloc50897;
        
    }
    
    // captured environment
    x10::lang::Fun_0_0<TPMGL(T)>* init;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->init);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_array_DistArray_Unique__closure__2<TPMGL(T) >* storage = x10aux::alloc<x10_array_DistArray_Unique__closure__2<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::Fun_0_0<TPMGL(T)>* that_init = buf.read<x10::lang::Fun_0_0<TPMGL(T)>*>();
        x10_array_DistArray_Unique__closure__2<TPMGL(T) >* this_ = new (storage) x10_array_DistArray_Unique__closure__2<TPMGL(T) >(that_init);
        return this_;
    }
    
    x10_array_DistArray_Unique__closure__2(x10::lang::Fun_0_0<TPMGL(T)>* init) : init(init) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10:38";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>::template itable <x10_array_DistArray_Unique__closure__2<TPMGL(T) > >x10_array_DistArray_Unique__closure__2<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_array_DistArray_Unique__closure__2<TPMGL(T) >::__apply, &x10_array_DistArray_Unique__closure__2<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_array_DistArray_Unique__closure__2<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >, &x10_array_DistArray_Unique__closure__2<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_array_DistArray_Unique__closure__2<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_array_DistArray_Unique__closure__2<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__2_CLOSURE
#ifndef X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__3_CLOSURE
#define X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__3_CLOSURE
#include <x10/lang/Closure.h>
#include <x10/lang/Fun_0_0.h>
template<class TPMGL(T)> class x10_array_DistArray_Unique__closure__3 : public x10::lang::Closure {
    public:
    
    static typename x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>::template itable <x10_array_DistArray_Unique__closure__3<TPMGL(T) > > _itable;
    static x10aux::itable_entry _itables[2];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    // closure body
    x10::array::LocalState<TPMGL(T)>* __apply() {
        
        //#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
        x10::array::LocalState<TPMGL(T)>* alloc50902 =  ((new (memset(x10aux::alloc<x10::array::LocalState<TPMGL(T)> >(), 0, sizeof(x10::array::LocalState<TPMGL(T)>))) x10::array::LocalState<TPMGL(T)>()))
        ;
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::PlaceGroup* pg50899 = pg;
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10::lang::Rail<TPMGL(T) >* rail50900 = x10::lang::Rail<TPMGL(T) >::_make(((x10_long)1ll),
                                                                                  x10::lang::Fun_0_0<TPMGL(T)>::__apply(x10aux::nullCheck(init)));
        
        //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
        x10_long size50901 = pg->numPlaces();
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50902->FMGL(pg) = pg50899;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50902->FMGL(rail) = rail50900;
        
        //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
        alloc50902->FMGL(size) = size50901;
        
        //#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
        return alloc50902;
        
    }
    
    // captured environment
    x10::lang::PlaceGroup* pg;
    x10::lang::Fun_0_0<TPMGL(T)>* init;
    
    x10aux::serialization_id_t _get_serialization_id() {
        return _serialization_id;
    }
    
    void _serialize_body(x10aux::serialization_buffer &buf) {
        buf.write(this->pg);
        buf.write(this->init);
    }
    
    template<class __T> static __T* _deserialize(x10aux::deserialization_buffer &buf) {
        x10_array_DistArray_Unique__closure__3<TPMGL(T) >* storage = x10aux::alloc<x10_array_DistArray_Unique__closure__3<TPMGL(T) > >();
        buf.record_reference(storage);
        x10::lang::PlaceGroup* that_pg = buf.read<x10::lang::PlaceGroup*>();
        x10::lang::Fun_0_0<TPMGL(T)>* that_init = buf.read<x10::lang::Fun_0_0<TPMGL(T)>*>();
        x10_array_DistArray_Unique__closure__3<TPMGL(T) >* this_ = new (storage) x10_array_DistArray_Unique__closure__3<TPMGL(T) >(that_pg, that_init);
        return this_;
    }
    
    x10_array_DistArray_Unique__closure__3(x10::lang::PlaceGroup* pg, x10::lang::Fun_0_0<TPMGL(T)>* init) : pg(pg), init(init) { }
    
    static const x10aux::serialization_id_t _serialization_id;
    
    static const x10aux::RuntimeType* getRTT() { return x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(); }
    virtual const x10aux::RuntimeType *_type() const { return x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(); }
    
    const char* toNativeString() {
        return "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10:46";
    }

};

template<class TPMGL(T)> typename x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>::template itable <x10_array_DistArray_Unique__closure__3<TPMGL(T) > >x10_array_DistArray_Unique__closure__3<TPMGL(T) >::_itable(&x10::lang::Reference::equals, &x10::lang::Closure::hashCode, &x10_array_DistArray_Unique__closure__3<TPMGL(T) >::__apply, &x10_array_DistArray_Unique__closure__3<TPMGL(T) >::toString, &x10::lang::Closure::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10_array_DistArray_Unique__closure__3<TPMGL(T) >::_itables[2] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >, &x10_array_DistArray_Unique__closure__3<TPMGL(T) >::_itable),x10aux::itable_entry(NULL, NULL)};

template<class TPMGL(T)> const x10aux::serialization_id_t x10_array_DistArray_Unique__closure__3<TPMGL(T) >::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10_array_DistArray_Unique__closure__3<TPMGL(T) >::template _deserialize<x10::lang::Reference>,x10aux::CLOSURE_KIND_NOT_ASYNC);

#endif // X10_ARRAY_DISTARRAY_UNIQUE__CLOSURE__3_CLOSURE
template<class TPMGL(T)> typename x10::lang::Iterable<x10::lang::Point*>::template itable<x10::array::DistArray_Unique<TPMGL(T)> >  x10::array::DistArray_Unique<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::DistArray<TPMGL(T)>::iterator, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::array::DistArray_Unique<TPMGL(T)> >  x10::array::DistArray_Unique<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10_long, TPMGL(T)>::template itable<x10::array::DistArray_Unique<TPMGL(T)> >  x10::array::DistArray_Unique<TPMGL(T)>::_itable_2(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::DistArray_Unique<TPMGL(T)>::__apply, &x10::lang::X10Class::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::array::DistArray_Unique<TPMGL(T)>::_itables[4] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterable<x10::lang::Point*> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10_long, TPMGL(T)> >, &_itable_2), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::array::DistArray_Unique<TPMGL(T)> >())};

//#line 24 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::array::DistArray_Unique<TPMGL(T)>::rank(
  ) {
    
    //#line 24 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return ((x10_long)1ll);
    
}

//#line 29 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::_constructor(
                           ) {
    
    //#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::DistArray<TPMGL(T)>::_constructor(reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                                       FMGL(WORLD__get)()),
                                                            reinterpret_cast<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(sizeof(x10_array_DistArray_Unique__closure__1<TPMGL(T)>)))x10_array_DistArray_Unique__closure__1<TPMGL(T)>())),
                                                            (__extension__ ({
                                                                
                                                                //#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
                                                                x10::lang::PlaceGroup* this50833 =
                                                                  reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                                             FMGL(WORLD__get)());
                                                                x10aux::nullCheck(this50833)->numPlaces();
                                                            }))
                                                            );
    
    //#line 29 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.AssignPropertyCall_c
    
    //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50892 = this;
    
}
template<class TPMGL(T)> x10::array::DistArray_Unique<TPMGL(T)>* x10::array::DistArray_Unique<TPMGL(T)>::_make(
                           ) {
    x10::array::DistArray_Unique<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::DistArray_Unique<TPMGL(T)> >(), 0, sizeof(x10::array::DistArray_Unique<TPMGL(T)>))) x10::array::DistArray_Unique<TPMGL(T)>();
    this_->_constructor();
    return this_;
}



//#line 37 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::_constructor(
                           x10::lang::Fun_0_0<TPMGL(T)>* init) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::DistArray<TPMGL(T)>::_constructor(
      reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                 FMGL(WORLD__get)()),
      reinterpret_cast<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(sizeof(x10_array_DistArray_Unique__closure__2<TPMGL(T)>)))x10_array_DistArray_Unique__closure__2<TPMGL(T)>(init))),
      (__extension__ ({
          
          //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
          x10::lang::PlaceGroup* this50844 = reinterpret_cast<x10::lang::PlaceGroup*>(x10::lang::PlaceGroup::
                                                                                        FMGL(WORLD__get)());
          x10aux::nullCheck(this50844)->numPlaces();
      }))
      );
    
    //#line 37 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.AssignPropertyCall_c
    
    //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50898 = this;
    
}
template<class TPMGL(T)> x10::array::DistArray_Unique<TPMGL(T)>* x10::array::DistArray_Unique<TPMGL(T)>::_make(
                           x10::lang::Fun_0_0<TPMGL(T)>* init)
{
    x10::array::DistArray_Unique<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::DistArray_Unique<TPMGL(T)> >(), 0, sizeof(x10::array::DistArray_Unique<TPMGL(T)>))) x10::array::DistArray_Unique<TPMGL(T)>();
    this_->_constructor(init);
    return this_;
}



//#line 45 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::_constructor(
                           x10::lang::PlaceGroup* pg, x10::lang::Fun_0_0<TPMGL(T)>* init) {
    
    //#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::DistArray<TPMGL(T)>::_constructor(
      pg, reinterpret_cast<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>*>((new (x10aux::alloc<x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*> >(sizeof(x10_array_DistArray_Unique__closure__3<TPMGL(T)>)))x10_array_DistArray_Unique__closure__3<TPMGL(T)>(pg, init))),
      pg->numPlaces());
    
    //#line 45 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.AssignPropertyCall_c
    
    //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50903 = this;
    
}
template<class TPMGL(T)> x10::array::DistArray_Unique<TPMGL(T)>* x10::array::DistArray_Unique<TPMGL(T)>::_make(
                           x10::lang::PlaceGroup* pg, x10::lang::Fun_0_0<TPMGL(T)>* init)
{
    x10::array::DistArray_Unique<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::DistArray_Unique<TPMGL(T)> >(), 0, sizeof(x10::array::DistArray_Unique<TPMGL(T)>))) x10::array::DistArray_Unique<TPMGL(T)>();
    this_->_constructor(pg, init);
    return this_;
}



//#line 54 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::IterationSpace* x10::array::DistArray_Unique<TPMGL(T)>::globalIndices(
  ) {
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_1* alloc50904 =  ((new (memset(x10aux::alloc<x10::array::DenseIterationSpace_1>(), 0, sizeof(x10::array::DenseIterationSpace_1))) x10::array::DenseIterationSpace_1()))
    ;
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorCall_c
    (alloc50904)->::x10::array::DenseIterationSpace_1::_constructor(
      ((x10_long)0ll), ((x10_long) (((__extension__ ({
          
          //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
          x10::lang::PlaceGroup* this50905 = this->FMGL(placeGroup);
          x10aux::nullCheck(this50905)->numPlaces();
      }))
      ) - (((x10_long)1ll)))));
    
    //#line 55 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return reinterpret_cast<x10::array::IterationSpace*>(alloc50904);
    
}

//#line 63 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::IterationSpace* x10::array::DistArray_Unique<TPMGL(T)>::localIndices(
  ) {
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long idx = x10aux::nullCheck(this->FMGL(placeGroup))->indexOf(
                     x10::lang::Place::_make(x10aux::here));
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_1* alloc50906 =  ((new (memset(x10aux::alloc<x10::array::DenseIterationSpace_1>(), 0, sizeof(x10::array::DenseIterationSpace_1))) x10::array::DenseIterationSpace_1()))
    ;
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10ConstructorCall_c
    (alloc50906)->::x10::array::DenseIterationSpace_1::_constructor(
      idx, idx);
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return reinterpret_cast<x10::array::IterationSpace*>(alloc50906);
    
}

//#line 77 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Place x10::array::DistArray_Unique<TPMGL(T)>::place(
  x10_long i) {
    
    //#line 77 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return ((i) >= (((x10_long)0ll))) && ((i) < ((__extension__ ({
        
        //#line 77 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
        x10::lang::PlaceGroup* this50858 = this->FMGL(placeGroup);
        x10aux::nullCheck(this50858)->numPlaces();
    }))
    )) ? (x10aux::nullCheck(this->FMGL(placeGroup))->__apply(
            i)) : (x10::lang::Place::FMGL(INVALID_PLACE__get)());
    
}

//#line 89 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Place x10::array::DistArray_Unique<TPMGL(T)>::place(
  x10::lang::Point* p) {
    
    //#line 89 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return this->x10::array::template DistArray_Unique<TPMGL(T)>::place(
             x10aux::nullCheck(p)->x10::lang::Point::__apply(
               ((x10_long)0ll)));
    
}

//#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::DistArray_Unique<TPMGL(T)>::__apply(
  x10_long i) {
    
    //#line 100 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50908 = this;
    
    //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long i50909 = i;
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(this50908)->
                                                    FMGL(placeGroup))->indexOf(
                                  x10::lang::Place::_make(x10aux::here)),
                                i50909))) {
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
        if (true && (((i50909) < (((x10_long)0ll))) || ((i50909) >= ((__extension__ ({
                         
                         //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
                         x10::lang::PlaceGroup* this50907 =
                           x10aux::nullCheck(this50908)->
                             FMGL(placeGroup);
                         x10aux::nullCheck(this50907)->numPlaces();
                     }))
                     )))) {
            
            //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
            x10::array::DistArray<void>::raiseBoundsError(
              i50909);
        }
        
        //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
        x10::array::DistArray<void>::raisePlaceError(i50909);
    }
    
    //#line 101 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             ((x10_long)0ll));
    
}

//#line 111 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::DistArray_Unique<TPMGL(T)>::__apply(
  x10::lang::Point* p) {
    
    //#line 111 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50912 = this;
    
    //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long i50913 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret50914;
    
    //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long i50911 = i50913;
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(this50912)->
                                                    FMGL(placeGroup))->indexOf(
                                  x10::lang::Place::_make(x10aux::here)),
                                i50911))) {
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
        if (true && (((i50911) < (((x10_long)0ll))) || ((i50911) >= ((__extension__ ({
                         
                         //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
                         x10::lang::PlaceGroup* this50910 =
                           x10aux::nullCheck(this50912)->
                             FMGL(placeGroup);
                         x10aux::nullCheck(this50910)->numPlaces();
                     }))
                     )))) {
            
            //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
            x10::array::DistArray<void>::raiseBoundsError(
              i50911);
        }
        
        //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
        x10::array::DistArray<void>::raisePlaceError(i50911);
    }
    
    //#line 101 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10LocalAssign_c
    ret50914 = x10aux::nullCheck(this50912)->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
                 ((x10_long)0ll));
    
    //#line 111 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return ret50914;
    
}

//#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::DistArray_Unique<TPMGL(T)>::__set(
  x10_long i, TPMGL(T) v) {
    
    //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50916 = this;
    
    //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long i50917 = i;
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(this50916)->
                                                    FMGL(placeGroup))->indexOf(
                                  x10::lang::Place::_make(x10aux::here)),
                                i50917))) {
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
        if (true && (((i50917) < (((x10_long)0ll))) || ((i50917) >= ((__extension__ ({
                         
                         //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
                         x10::lang::PlaceGroup* this50915 =
                           x10aux::nullCheck(this50916)->
                             FMGL(placeGroup);
                         x10aux::nullCheck(this50915)->numPlaces();
                     }))
                     )))) {
            
            //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
            x10::array::DistArray<void>::raiseBoundsError(
              i50917);
        }
        
        //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
        x10::array::DistArray<void>::raisePlaceError(i50917);
    }
    
    //#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      ((x10_long)0ll), v);
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::DistArray_Unique<TPMGL(T)>::__set(
  x10::lang::Point* p, TPMGL(T) v) {
    
    //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray_Unique<TPMGL(T)>* this50920 = this;
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long i50921 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) v50922 = v;
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret50923;
    
    //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
    x10_long i50919 = i50921;
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(x10aux::nullCheck(x10aux::nullCheck(this50920)->
                                                    FMGL(placeGroup))->indexOf(
                                  x10::lang::Place::_make(x10aux::here)),
                                i50919))) {
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
        if (true && (((i50919) < (((x10_long)0ll))) || ((i50919) >= ((__extension__ ({
                         
                         //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
                         x10::lang::PlaceGroup* this50918 =
                           x10aux::nullCheck(this50920)->
                             FMGL(placeGroup);
                         x10aux::nullCheck(this50918)->numPlaces();
                     }))
                     )))) {
            
            //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
            x10::array::DistArray<void>::raiseBoundsError(
              i50919);
        }
        
        //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
        x10::array::DistArray<void>::raisePlaceError(i50919);
    }
    
    //#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this50920)->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      ((x10_long)0ll), v50922);
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10LocalAssign_c
    ret50923 = v50922;
    
    //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return ret50923;
    
}

//#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::validateIndex(
  x10_long i) {
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(x10aux::nullCheck(this->FMGL(placeGroup))->indexOf(
                                  x10::lang::Place::_make(x10aux::here)),
                                i))) {
        
        //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10If_c
        if (true && (((i) < (((x10_long)0ll))) || ((i) >= ((__extension__ ({
                         
                         //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10LocalDecl_c
                         x10::lang::PlaceGroup* this50924 =
                           this->FMGL(placeGroup);
                         x10aux::nullCheck(this50924)->numPlaces();
                     }))
                     )))) {
            
            //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
            x10::array::DistArray<void>::raiseBoundsError(
              i);
        }
        
        //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": Eval of x10.ast.X10Call_c
        x10::array::DistArray<void>::raisePlaceError(i);
    }
    
}

//#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::DistArray_Unique<TPMGL(T)>*
  x10::array::DistArray_Unique<TPMGL(T)>::x10__array__DistArray_Unique____this__x10__array__DistArray_Unique(
  ) {
    
    //#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 22 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_Unique.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::__fieldInitializers_x10_array_DistArray_Unique(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::array::DistArray_Unique<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::array::DistArray_Unique<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::array::DistArray<TPMGL(T)>::_serialize_body(buf);
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::array::DistArray_Unique<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::array::DistArray_Unique<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::DistArray_Unique<TPMGL(T)> >(), 0, sizeof(x10::array::DistArray_Unique<TPMGL(T)>))) x10::array::DistArray_Unique<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::array::DistArray_Unique<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::array::DistArray<TPMGL(T)>::_deserialize_body(buf);
    
}

#endif // X10_ARRAY_DISTARRAY_UNIQUE_H_IMPLEMENTATION
#endif // __X10_ARRAY_DISTARRAY_UNIQUE_H_NODEPS
