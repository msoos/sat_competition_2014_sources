#ifndef __X10_ARRAY_LOCALSTATE_BB2_H
#define __X10_ARRAY_LOCALSTATE_BB2_H

#include <x10rt.h>


#define X10_ARRAY_LOCALSTATE_H_NODEPS
#include <x10/array/LocalState.h>
#undef X10_ARRAY_LOCALSTATE_H_NODEPS
namespace x10 { namespace array { 
class DenseIterationSpace_2;
} } 
namespace x10 { namespace lang { 
class PlaceGroup;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(Z1), class TPMGL(Z2), class TPMGL(U)> class Fun_0_2;
} } 
namespace x10 { namespace array { 
class BlockingUtils;
} } 
namespace x10 { namespace array { 
class IterationSpace;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace array { 

template<class TPMGL(S)> class LocalState_BB2;
template <> class LocalState_BB2<void>;
template<class TPMGL(S)> class LocalState_BB2 : public x10::array::LocalState<TPMGL(S)>
  {
    public:
    RTT_H_DECLS_CLASS
    
    x10::array::DenseIterationSpace_2* FMGL(globalIndices);
    
    x10::array::DenseIterationSpace_2* FMGL(localIndices);
    
    void _constructor(x10::lang::PlaceGroup* pg, x10::lang::Rail<TPMGL(S) >* data,
                      x10_long size, x10::array::DenseIterationSpace_2* gs,
                      x10::array::DenseIterationSpace_2* ls);
    
    static x10::array::LocalState_BB2<TPMGL(S)>* _make(x10::lang::PlaceGroup* pg,
                                                       x10::lang::Rail<TPMGL(S) >* data,
                                                       x10_long size,
                                                       x10::array::DenseIterationSpace_2* gs,
                                                       x10::array::DenseIterationSpace_2* ls);
    
    virtual x10::array::LocalState_BB2<TPMGL(S)>* x10__array__LocalState_BB2____this__x10__array__LocalState_BB2(
      );
    virtual void __fieldInitializers_x10_array_LocalState_BB2(
      );
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: virtual x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(S)> x10aux::RuntimeType x10::array::LocalState_BB2<TPMGL(S)>::rtt;
template<class TPMGL(S)> void x10::array::LocalState_BB2<TPMGL(S)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::LocalState_BB2<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::array::LocalState<TPMGL(S)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(S)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.LocalState_BB2";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 1, parents, 1, params, variances);
}

template <> class LocalState_BB2<void> : public x10::array::LocalState<void>
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(S)> static x10::array::LocalState_BB2<TPMGL(S)>*
      make(x10::lang::PlaceGroup* pg, x10_long m, x10_long n,
           x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(S)>* init);
    
    
};

} } 
#endif // X10_ARRAY_LOCALSTATE_BB2_H

namespace x10 { namespace array { 
template<class TPMGL(S)> class LocalState_BB2;
} } 

#ifndef X10_ARRAY_LOCALSTATE_BB2_H_NODEPS
#define X10_ARRAY_LOCALSTATE_BB2_H_NODEPS
#include <x10/array/LocalState.h>
#include <x10/array/DenseIterationSpace_2.h>
#include <x10/lang/PlaceGroup.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Long.h>
#include <x10/lang/Fun_0_2.h>
#include <x10/array/BlockingUtils.h>
#include <x10/array/IterationSpace.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/Place.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Unsafe.h>
#ifndef X10_ARRAY_LOCALSTATE_BB2_H_GENERICS
#define X10_ARRAY_LOCALSTATE_BB2_H_GENERICS
#endif // X10_ARRAY_LOCALSTATE_BB2_H_GENERICS
#ifndef X10_ARRAY_LOCALSTATE_BB2_H_IMPLEMENTATION
#define X10_ARRAY_LOCALSTATE_BB2_H_IMPLEMENTATION
#include <x10/array/LocalState_BB2.h>


//#line 247 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10FieldDecl_c

//#line 248 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10FieldDecl_c

//#line 250 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(S)> void x10::array::LocalState_BB2<TPMGL(S)>::_constructor(
                           x10::lang::PlaceGroup* pg, x10::lang::Rail<TPMGL(S) >* data,
                           x10_long size, x10::array::DenseIterationSpace_2* gs,
                           x10::array::DenseIterationSpace_2* ls) {
    
    //#line 252 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
    x10::array::LocalState<TPMGL(S)>* this50777 = this;
    
    //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::lang::PlaceGroup* pg50778 = pg;
    
    //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(S) >* rail50779 = data;
    
    //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10_long size50780 = size;
    
    //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this50777)->FMGL(pg) = pg50778;
    
    //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this50777)->FMGL(rail) = rail50779;
    
    //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this50777)->FMGL(size) = size50780;
    
    //#line 250 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.AssignPropertyCall_c
    
    //#line 246 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
    x10::array::LocalState_BB2<TPMGL(S)>* this50776 = this;
    
    //#line 253 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(globalIndices) = gs;
    
    //#line 254 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localIndices) = ls;
}
template<class TPMGL(S)> x10::array::LocalState_BB2<TPMGL(S)>* x10::array::LocalState_BB2<TPMGL(S)>::_make(
                           x10::lang::PlaceGroup* pg, x10::lang::Rail<TPMGL(S) >* data,
                           x10_long size, x10::array::DenseIterationSpace_2* gs,
                           x10::array::DenseIterationSpace_2* ls)
{
    x10::array::LocalState_BB2<TPMGL(S)>* this_ = new (memset(x10aux::alloc<x10::array::LocalState_BB2<TPMGL(S)> >(), 0, sizeof(x10::array::LocalState_BB2<TPMGL(S)>))) x10::array::LocalState_BB2<TPMGL(S)>();
    this_->_constructor(pg, data, size, gs, ls);
    return this_;
}



//#line 257 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10MethodDecl_c

//#line 246 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(S)> x10::array::LocalState_BB2<TPMGL(S)>*
  x10::array::LocalState_BB2<TPMGL(S)>::x10__array__LocalState_BB2____this__x10__array__LocalState_BB2(
  ) {
    
    //#line 246 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 246 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(S)> void x10::array::LocalState_BB2<TPMGL(S)>::__fieldInitializers_x10_array_LocalState_BB2(
  ) {
 
}
template<class TPMGL(S)> const x10aux::serialization_id_t x10::array::LocalState_BB2<TPMGL(S)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::array::LocalState_BB2<TPMGL(S)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(S)> void x10::array::LocalState_BB2<TPMGL(S)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::array::LocalState<TPMGL(S)>::_serialize_body(buf);
    buf.write(this->FMGL(globalIndices));
    buf.write(this->FMGL(localIndices));
    
}

template<class TPMGL(S)> x10::lang::Reference* x10::array::LocalState_BB2<TPMGL(S)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::array::LocalState_BB2<TPMGL(S)>* this_ = new (memset(x10aux::alloc<x10::array::LocalState_BB2<TPMGL(S)> >(), 0, sizeof(x10::array::LocalState_BB2<TPMGL(S)>))) x10::array::LocalState_BB2<TPMGL(S)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(S)> void x10::array::LocalState_BB2<TPMGL(S)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::array::LocalState<TPMGL(S)>::_deserialize_body(buf);
    FMGL(globalIndices) = buf.read<x10::array::DenseIterationSpace_2*>();
    FMGL(localIndices) = buf.read<x10::array::DenseIterationSpace_2*>();
}

template<class TPMGL(S)> x10::array::LocalState_BB2<TPMGL(S)>*
  x10::array::LocalState_BB2<void>::make(x10::lang::PlaceGroup* pg,
                                         x10_long m, x10_long n,
                                         x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(S)>* init)
{
    
    //#line 258 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_2* globalSpace =  ((new (memset(x10aux::alloc<x10::array::DenseIterationSpace_2>(), 0, sizeof(x10::array::DenseIterationSpace_2))) x10::array::DenseIterationSpace_2()))
    ;
    
    //#line 258 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10ConstructorCall_c
    (globalSpace)->::x10::array::DenseIterationSpace_2::_constructor(
      ((x10_long)0ll), ((x10_long)0ll), ((x10_long) ((m) - (((x10_long)1ll)))),
      ((x10_long) ((n) - (((x10_long)1ll)))));
    
    //#line 259 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_2* localSpace = x10::array::BlockingUtils::partitionBlockBlock(
                                                      reinterpret_cast<x10::array::IterationSpace*>(globalSpace),
                                                      pg->numPlaces(),
                                                      pg->indexOf(
                                                        x10::lang::Place::_make(x10aux::here)));
    
    //#line 260 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(S) >* data;
    
    //#line 261 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10If_c
    if (localSpace->x10::array::DenseIterationSpace_2::isEmpty())
    {
        
        //#line 262 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10LocalAssign_c
        data = x10::lang::Rail<TPMGL(S) >::_make();
    } else {
        
        //#line 264 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long low1 = localSpace->x10::array::DenseIterationSpace_2::min(
                          ((x10_long)0ll));
        
        //#line 265 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long hi1 = localSpace->x10::array::DenseIterationSpace_2::max(
                         ((x10_long)0ll));
        
        //#line 266 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long low2 = localSpace->x10::array::DenseIterationSpace_2::min(
                          ((x10_long)1ll));
        
        //#line 267 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long hi2 = localSpace->x10::array::DenseIterationSpace_2::max(
                         ((x10_long)1ll));
        
        //#line 268 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long localSize1 = ((x10_long) ((((x10_long) ((hi1) - (low1)))) + (((x10_long)1ll))));
        
        //#line 269 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long localSize2 = ((x10_long) ((((x10_long) ((hi2) - (low2)))) + (((x10_long)1ll))));
        
        //#line 270 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long dataSize = ((x10_long) ((localSize1) * (localSize2)));
        
        //#line 271 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10LocalAssign_c
        data = x10::lang::Rail<TPMGL(S) >::_makeUnsafe(dataSize, false);
        
        //#line 272 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long i50706min50786 = low1;
        
        //#line 272 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
        x10_long i50706max50787 = hi1;
        
        //#line 272 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": polyglot.ast.For_c
        {
            x10_long i50788;
            for (
                 //#line 272 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                 i50788 = i50706min50786; ((i50788) <= (i50706max50787));
                 
                 //#line 272 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10LocalAssign_c
                 i50788 = ((x10_long) ((i50788) + (((x10_long)1ll)))))
            {
                
                //#line 272 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                x10_long i50789 = i50788;
                
                //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                x10_long i50690min50782 = low2;
                
                //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                x10_long i50690max50783 = hi2;
                
                //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": polyglot.ast.For_c
                {
                    x10_long i50784;
                    for (
                         //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                         i50784 = i50690min50782; ((i50784) <= (i50690max50783));
                         
                         //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10LocalAssign_c
                         i50784 = ((x10_long) ((i50784) + (((x10_long)1ll)))))
                    {
                        
                        //#line 273 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                        x10_long j50785 = i50784;
                        
                        //#line 274 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
                        x10_long offset50781 = ((x10_long) ((((x10_long) ((j50785) - (low2)))) + (((x10_long) ((((x10_long) ((i50789) - (low1)))) * (localSize2))))));
                        
                        //#line 275 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": Eval of x10.ast.X10Call_c
                        data->x10::lang::template Rail<TPMGL(S) >::__set(
                          offset50781, x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(S)>::__apply(x10aux::nullCheck(init), 
                            i50789, j50785));
                    }
                }
                
            }
        }
        
    }
    
    //#line 279 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10LocalDecl_c
    x10::array::LocalState_BB2<TPMGL(S)>* alloc50790 =  ((new (memset(x10aux::alloc<x10::array::LocalState_BB2<TPMGL(S)> >(), 0, sizeof(x10::array::LocalState_BB2<TPMGL(S)>))) x10::array::LocalState_BB2<TPMGL(S)>()))
    ;
    
    //#line 279 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10ConstructorCall_c
    (alloc50790)->::x10::array::LocalState_BB2<TPMGL(S)>::_constructor(
      pg, data, ((x10_long) ((m) * (n))), globalSpace, localSpace);
    
    //#line 279 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray_BlockBlock_2.x10": x10.ast.X10Return_c
    return alloc50790;
    
}
#endif // X10_ARRAY_LOCALSTATE_BB2_H_IMPLEMENTATION
#endif // __X10_ARRAY_LOCALSTATE_BB2_H_NODEPS
