#ifndef __X10_ARRAY_ARRAY_H
#define __X10_ARRAY_ARRAY_H

#include <x10rt.h>


#define X10_LANG_ITERABLE_H_NODEPS
#include <x10/lang/Iterable.h>
#undef X10_LANG_ITERABLE_H_NODEPS
#define X10_LANG_FUN_0_1_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#undef X10_LANG_FUN_0_1_H_NODEPS
namespace x10 { namespace lang { 
class Point;
} } 
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Iterator;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(Z1), class TPMGL(Z2), class TPMGL(U)> class Fun_0_2;
} } 
namespace x10 { namespace array { 
class IterationSpace;
} } 
namespace x10 { namespace lang { 
class ArrayIndexOutOfBoundsException;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace compiler { 
class NoInline;
} } 
namespace x10 { namespace compiler { 
class NoReturn;
} } 
namespace x10 { namespace lang { 
class NegativeArraySizeException;
} } 
namespace x10 { namespace array { 

template<class TPMGL(T)> class Array;
template <> class Array<void>;
template<class TPMGL(T)> class Array : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    x10_long FMGL(size);
    
    x10_long rank();
    x10::lang::Rail<TPMGL(T) >* FMGL(raw);
    
    void _constructor(x10_long s, x10_boolean zero);
    
    void _constructor(x10::lang::Rail<TPMGL(T) >* r);
    
    virtual x10::lang::Rail<TPMGL(T) >* raw();
    virtual x10::lang::Iterator<TPMGL(T)>* iterator();
    virtual void fill(TPMGL(T) v);
    virtual void clear();
    template<class TPMGL(U)> TPMGL(U) reduce(x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op,
                                             TPMGL(U) unit);
    template<class TPMGL(U)> x10::array::Array<TPMGL(U)>* map(x10::array::Array<TPMGL(U)>* dst,
                                                              x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op);
    template<class TPMGL(S), class TPMGL(U)> x10::array::Array<TPMGL(U)>*
      map(x10::array::Array<TPMGL(S)>* src2, x10::array::Array<TPMGL(U)>* dst,
          x10::lang::Fun_0_2<TPMGL(T), TPMGL(S), TPMGL(U)>* op);
    virtual x10::array::IterationSpace* indices() = 0;
    virtual TPMGL(T) __apply(x10::lang::Point* p) = 0;
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v) = 0;
    virtual x10::array::Array<TPMGL(T)>* x10__array__Array____this__x10__array__Array(
      );
    virtual void __fieldInitializers_x10_array_Array();
    
    // Serialization
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::array::Array<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::Array<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::lang::Iterable<TPMGL(T)> >(), x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.Array";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class Array<void> : public x10::lang::X10Class
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(T)> static void copy(x10::array::Array<TPMGL(T)>* src,
                                              x10::array::Array<TPMGL(T)>* dst);
    
    template<class TPMGL(T)> static void copy(x10::array::Array<TPMGL(T)>* src,
                                              x10_long srcIndex,
                                              x10::array::Array<TPMGL(T)>* dst,
                                              x10_long dstIndex,
                                              x10_long numElems);
    
    static void raiseBoundsError(x10_long i) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i, x10_long j) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i, x10_long j, x10_long k) X10_PRAGMA_NORETURN ;
    
    static void raiseNegativeArraySizeException() X10_PRAGMA_NORETURN ;
    
    
};

} } 
#endif // X10_ARRAY_ARRAY_H

namespace x10 { namespace array { 
template<class TPMGL(T)> class Array;
} } 

#ifndef X10_ARRAY_ARRAY_H_NODEPS
#define X10_ARRAY_ARRAY_H_NODEPS
#include <x10/lang/Iterable.h>
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/Point.h>
#include <x10/lang/Long.h>
#include <x10/lang/Rail.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Unsafe.h>
#include <x10/compiler/Inline.h>
#include <x10/lang/Iterator.h>
#include <x10/lang/Fun_0_2.h>
#include <x10/array/IterationSpace.h>
#include <x10/lang/ArrayIndexOutOfBoundsException.h>
#include <x10/lang/String.h>
#include <x10/compiler/NoInline.h>
#include <x10/compiler/NoReturn.h>
#include <x10/lang/NegativeArraySizeException.h>
#ifndef X10_ARRAY_ARRAY_H_GENERICS
#define X10_ARRAY_ARRAY_H_GENERICS
#ifndef X10_ARRAY_ARRAY_H_reduce_34
#define X10_ARRAY_ARRAY_H_reduce_34
template<class TPMGL(T)> template<class TPMGL(U)> TPMGL(U) x10::array::Array<TPMGL(T)>::reduce(
  x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op, TPMGL(U) unit) {
    
    //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* src48233 = this->FMGL(raw);
    
    //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>* op48234 = op;
    
    //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) unit48235 = unit;
    
    //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) ret48236;
    
    //#line 125 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    TPMGL(U) accum48232 = unit48235;
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* rail48228 = src48233;
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10_long i48144max48229 = (x10_long)(x10aux::nullCheck(rail48228)->FMGL(size));
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": polyglot.ast.For_c
    {
        x10_long i48230;
        for (
             //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
             i48230 = ((x10_long)0ll); ((i48230) < (i48144max48229));
             
             //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
             i48230 = ((x10_long) ((i48230) + (((x10_long)1ll)))))
        {
            
            //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
            x10_long i48231 = i48230;
            
            //#line 127 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
            accum48232 = x10::lang::Fun_0_2<TPMGL(U), TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op48234), 
              accum48232, x10aux::nullCheck(src48233)->x10::lang::template Rail<TPMGL(T) >::__apply(
                            i48231));
        }
    }
    
    //#line 129 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
    ret48236 = accum48232;
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10Return_c
    return ret48236;
    
}
#endif // X10_ARRAY_ARRAY_H_reduce_34
#ifndef X10_ARRAY_ARRAY_H_map_35
#define X10_ARRAY_ARRAY_H_map_35
template<class TPMGL(T)> template<class TPMGL(U)> x10::array::Array<TPMGL(U)>*
  x10::array::Array<TPMGL(T)>::map(x10::array::Array<TPMGL(U)>* dst,
                                   x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op) {
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* src48241 = this->FMGL(raw);
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(U) >* dst48242 = x10aux::nullCheck(dst)->
                                             FMGL(raw);
    
    //#line 144 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>* op48243 = op;
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(U) >* ret48244;
    
    //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* rail48237 = src48241;
    
    //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10_long i48161max48238 = (x10_long)(x10aux::nullCheck(rail48237)->FMGL(size));
    
    //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": polyglot.ast.For_c
    {
        x10_long i48239;
        for (
             //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
             i48239 = ((x10_long)0ll); ((i48239) < (i48161max48238));
             
             //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
             i48239 = ((x10_long) ((i48239) + (((x10_long)1ll)))))
        {
            
            //#line 148 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
            x10_long i48240 = i48239;
            
            //#line 149 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(dst48242)->x10::lang::template Rail<TPMGL(U) >::__set(
              i48240, x10::lang::Fun_0_1<TPMGL(T), TPMGL(U)>::__apply(x10aux::nullCheck(op48243), 
                x10aux::nullCheck(src48241)->x10::lang::template Rail<TPMGL(T) >::__apply(
                  i48240)));
        }
    }
    
    //#line 151 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
    ret48244 = dst48242;
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Local_c
    ret48244;
    
    //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_ARRAY_ARRAY_H_map_35
#ifndef X10_ARRAY_ARRAY_H_map_36
#define X10_ARRAY_ARRAY_H_map_36
template<class TPMGL(T)> template<class TPMGL(S), class TPMGL(U)>
x10::array::Array<TPMGL(U)>* x10::array::Array<TPMGL(T)>::map(
  x10::array::Array<TPMGL(S)>* src2, x10::array::Array<TPMGL(U)>* dst,
  x10::lang::Fun_0_2<TPMGL(T), TPMGL(S), TPMGL(U)>* op) {
    
    //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* src48249 = this->FMGL(raw);
    
    //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(S) >* src48250 = x10aux::nullCheck(src2)->
                                             FMGL(raw);
    
    //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(U) >* dst48251 = x10aux::nullCheck(dst)->
                                             FMGL(raw);
    
    //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Fun_0_2<TPMGL(T), TPMGL(S), TPMGL(U)>* op48252 =
      op;
    
    //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(U) >* ret48253;
    
    //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* rail48245 = src48249;
    
    //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
    x10_long i48178max48246 = (x10_long)(x10aux::nullCheck(rail48245)->FMGL(size));
    
    //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": polyglot.ast.For_c
    {
        x10_long i48247;
        for (
             //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
             i48247 = ((x10_long)0ll); ((i48247) < (i48178max48246));
             
             //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
             i48247 = ((x10_long) ((i48247) + (((x10_long)1ll)))))
        {
            
            //#line 171 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": x10.ast.X10LocalDecl_c
            x10_long i48248 = i48247;
            
            //#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Call_c
            x10aux::nullCheck(dst48251)->x10::lang::template Rail<TPMGL(U) >::__set(
              i48248, x10::lang::Fun_0_2<TPMGL(T), TPMGL(S), TPMGL(U)>::__apply(x10aux::nullCheck(op48252), 
                x10aux::nullCheck(src48249)->x10::lang::template Rail<TPMGL(T) >::__apply(
                  i48248), x10aux::nullCheck(src48250)->x10::lang::template Rail<TPMGL(S) >::__apply(
                             i48248)));
        }
    }
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10LocalAssign_c
    ret48253 = dst48251;
    
    //#line 166 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/util/RailUtils.x10": Eval of x10.ast.X10Local_c
    ret48253;
    
    //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10Return_c
    return dst;
    
}
#endif // X10_ARRAY_ARRAY_H_map_36
#endif // X10_ARRAY_ARRAY_H_GENERICS
#ifndef X10_ARRAY_ARRAY_H_IMPLEMENTATION
#define X10_ARRAY_ARRAY_H_IMPLEMENTATION
#include <x10/array/Array.h>


//#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.PropertyDecl_c

//#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 57 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10FieldDecl_c
/**
     * The backing storage for the array's elements
     */

//#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::_constructor(x10_long s,
                                                                        x10_boolean zero) {
    
    //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(size) = s;
    
    //#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this48226 = this;
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = zero ? (x10::lang::Rail<TPMGL(T) >::_makeUnsafe(s, true))
      : (x10::lang::Rail<TPMGL(T) >::_makeUnsafe(s, false));
}


//#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::_constructor(
                           x10::lang::Rail<TPMGL(T) >* r) {
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.AssignPropertyCall_c
    FMGL(size) = (x10_long)(x10aux::nullCheck(r)->FMGL(size));
    
    //#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this48227 = this;
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = r;
}


//#line 81 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::array::Array<TPMGL(T)>::raw(
  ) {
    
    //#line 81 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw);
    
}

//#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Iterator<TPMGL(T)>* x10::array::Array<TPMGL(T)>::iterator(
  ) {
    
    //#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::iterator();
    
}

//#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::fill(
  TPMGL(T) v) {
    
    //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::fill(
      v);
}

//#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::clear(
  ) {
    
    //#line 108 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::clear();
}

//#line 122 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 167 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 179 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 203 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 214 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 231 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 237 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 240 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 243 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 247 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c

//#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::Array<TPMGL(T)>* x10::array::Array<TPMGL(T)>::x10__array__Array____this__x10__array__Array(
  ) {
    
    //#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::__fieldInitializers_x10_array_Array(
  ) {
 
}
template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    buf.write(this->FMGL(raw));
    buf.write(this->FMGL(size));
    
}

template<class TPMGL(T)> void x10::array::Array<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(raw) = buf.read<x10::lang::Rail<TPMGL(T) >*>();
    FMGL(size) = buf.read<x10_long>();
}

template<class TPMGL(T)> void x10::array::Array<void>::copy(x10::array::Array<TPMGL(T)>* src,
                                                            x10::array::Array<TPMGL(T)>* dst)
{
    
    //#line 215 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(src)->
                                                       FMGL(raw),
                                                     ((x10_long)0ll),
                                                     x10aux::nullCheck(dst)->
                                                       FMGL(raw),
                                                     ((x10_long)0ll),
                                                     (x10_long)(x10aux::nullCheck(x10aux::nullCheck(src)->
                                                                                    FMGL(raw))->FMGL(size)));
}
template<class TPMGL(T)> void x10::array::Array<void>::copy(x10::array::Array<TPMGL(T)>* src,
                                                            x10_long srcIndex,
                                                            x10::array::Array<TPMGL(T)>* dst,
                                                            x10_long dstIndex,
                                                            x10_long numElems)
{
    
    //#line 233 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10Call_c
    x10::lang::Rail<void >::template copy<TPMGL(T) >(x10aux::nullCheck(src)->
                                                       FMGL(raw),
                                                     srcIndex,
                                                     x10aux::nullCheck(dst)->
                                                       FMGL(raw),
                                                     dstIndex,
                                                     numElems);
}
#endif // X10_ARRAY_ARRAY_H_IMPLEMENTATION
#endif // __X10_ARRAY_ARRAY_H_NODEPS
