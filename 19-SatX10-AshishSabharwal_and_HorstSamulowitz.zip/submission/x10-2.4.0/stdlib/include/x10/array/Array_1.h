#ifndef __X10_ARRAY_ARRAY_1_H
#define __X10_ARRAY_ARRAY_1_H

#include <x10rt.h>


#define X10_ARRAY_ARRAY_H_NODEPS
#include <x10/array/Array.h>
#undef X10_ARRAY_ARRAY_H_NODEPS
#define X10_LANG_FUN_0_1_H_NODEPS
#include <x10/lang/Fun_0_1.h>
#undef X10_LANG_FUN_0_1_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace array { 
class DenseIterationSpace_1;
} } 
namespace x10 { namespace lang { 
class Point;
} } 
namespace x10 { namespace array { 

template<class TPMGL(T)> class Array_1;
template <> class Array_1<void>;
template<class TPMGL(T)> class Array_1 : public x10::array::Array<TPMGL(T)>
  {
    public:
    RTT_H_DECLS_CLASS
    
    static x10aux::itable_entry _itables[5];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Iterable<TPMGL(T)>::template itable<x10::array::Array_1<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::array::Array_1<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::array::Array_1<TPMGL(T)> > _itable_2;
    
    static typename x10::lang::Fun_0_1<x10_long, TPMGL(T)>::template itable<x10::array::Array_1<TPMGL(T)> > _itable_3;
    
    x10_long rank();
    void _constructor(x10_long n);
    
    static x10::array::Array_1<TPMGL(T)>* _make(x10_long n);
    
    void _constructor(x10_long n, TPMGL(T) init);
    
    static x10::array::Array_1<TPMGL(T)>* _make(x10_long n, TPMGL(T) init);
    
    void _constructor(x10_long n, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init);
    
    static x10::array::Array_1<TPMGL(T)>* _make(x10_long n, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init);
    
    void _constructor(x10::array::Array_1<TPMGL(T)>* src);
    
    static x10::array::Array_1<TPMGL(T)>* _make(x10::array::Array_1<TPMGL(T)>* src);
    
    void _constructor(x10::lang::Rail<TPMGL(T) >* r);
    
    static x10::array::Array_1<TPMGL(T)>* _make(x10::lang::Rail<TPMGL(T) >* r);
    
    virtual x10::lang::String* toString();
    virtual x10::array::IterationSpace* indices();
    virtual TPMGL(T) __apply(x10_long i);
    virtual TPMGL(T) __apply(x10::lang::Point* p);
    virtual TPMGL(T) __set(x10_long i, TPMGL(T) v);
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v);
    virtual x10::array::Array_1<TPMGL(T)>* x10__array__Array_1____this__x10__array__Array_1(
      );
    virtual void __fieldInitializers_x10_array_Array_1();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::array::Array_1<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::Array_1<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::array::Array<TPMGL(T)> >(), x10aux::getRTT<x10::lang::Fun_0_1<x10_long, TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.Array_1";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class Array_1<void> : public x10::array::Array<void> {
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(T)> static x10::array::Array_1<TPMGL(T)>*
      makeView(x10::lang::Rail<TPMGL(T) >* r);
    
    static x10_long validateSize(x10_long n);
    
    
};

} } 
#endif // X10_ARRAY_ARRAY_1_H

namespace x10 { namespace array { 
template<class TPMGL(T)> class Array_1;
} } 

#ifndef X10_ARRAY_ARRAY_1_H_NODEPS
#define X10_ARRAY_ARRAY_1_H_NODEPS
#include <x10/array/Array.h>
#include <x10/lang/Fun_0_1.h>
#include <x10/lang/Long.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/Inline.h>
#include <x10/lang/String.h>
#include <x10/array/DenseIterationSpace_1.h>
#include <x10/lang/Point.h>
#ifndef X10_ARRAY_ARRAY_1_H_GENERICS
#define X10_ARRAY_ARRAY_1_H_GENERICS
#endif // X10_ARRAY_ARRAY_1_H_GENERICS
#ifndef X10_ARRAY_ARRAY_1_H_IMPLEMENTATION
#define X10_ARRAY_ARRAY_1_H_IMPLEMENTATION
#include <x10/array/Array_1.h>

template<class TPMGL(T)> typename x10::lang::Iterable<TPMGL(T)>::template itable<x10::array::Array_1<TPMGL(T)> >  x10::array::Array_1<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array<TPMGL(T)>::iterator, &x10::array::Array_1<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::array::Array_1<TPMGL(T)> >  x10::array::Array_1<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_1<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::array::Array_1<TPMGL(T)> >  x10::array::Array_1<TPMGL(T)>::_itable_2(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_1<TPMGL(T)>::__apply, &x10::array::Array_1<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10_long, TPMGL(T)>::template itable<x10::array::Array_1<TPMGL(T)> >  x10::array::Array_1<TPMGL(T)>::_itable_3(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_1<TPMGL(T)>::__apply, &x10::array::Array_1<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::array::Array_1<TPMGL(T)>::_itables[5] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterable<TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >, &_itable_2), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10_long, TPMGL(T)> >, &_itable_3), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::array::Array_1<TPMGL(T)> >())};

//#line 24 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::array::Array_1<TPMGL(T)>::rank() {
    
    //#line 24 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return ((x10_long)1ll);
    
}

//#line 29 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_constructor(
                           x10_long n) {
    
    //#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n45676 =
                                                              n;
                                                            
                                                            //#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret45677;
                                                            
                                                            //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10If_c
                                                            if (((n45676) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 139 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret45677 =
                                                              n45676;
                                                            ret45677;
                                                        }))
                                                        , true);
    
    //#line 29 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.AssignPropertyCall_c
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46647 = this;
    
}
template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<TPMGL(T)>::_make(
                           x10_long n) {
    x10::array::Array_1<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>();
    this_->_constructor(n);
    return this_;
}



//#line 36 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_constructor(
                           x10_long n, TPMGL(T) init) {
    
    //#line 37 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n45964 =
                                                              n;
                                                            
                                                            //#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret45965;
                                                            
                                                            //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10If_c
                                                            if (((n45964) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 139 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret45965 =
                                                              n45964;
                                                            ret45965;
                                                        }))
                                                        ,
                                                        false);
    
    //#line 36 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.AssignPropertyCall_c
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46648 = this;
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::fill(
      init);
}
template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<TPMGL(T)>::_make(
                           x10_long n, TPMGL(T) init) {
    x10::array::Array_1<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>();
    this_->_constructor(n, init);
    return this_;
}



//#line 45 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_constructor(
                           x10_long n, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init) {
    
    //#line 46 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n45970 =
                                                              n;
                                                            
                                                            //#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret45971;
                                                            
                                                            //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10If_c
                                                            if (((n45970) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 138 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 139 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret45971 =
                                                              n45970;
                                                            ret45971;
                                                        }))
                                                        ,
                                                        false);
    
    //#line 45 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.AssignPropertyCall_c
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46649 = this;
    
    //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* rail46650 = this->FMGL(raw);
    
    //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10_long i45660max46651 = (x10_long)(x10aux::nullCheck(rail46650)->FMGL(size));
    
    //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": polyglot.ast.For_c
    {
        x10_long i46652;
        for (
             //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
             i46652 = ((x10_long)0ll); ((i46652) < (i45660max46651));
             
             //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10LocalAssign_c
             i46652 = ((x10_long) ((i46652) + (((x10_long)1ll)))))
        {
            
            //#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
            x10_long i46653 = i46652;
            
            //#line 48 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
            this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
              i46653, x10::lang::Fun_0_1<x10_long, TPMGL(T)>::__apply(x10aux::nullCheck(init), 
                i46653));
        }
    }
    
}
template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<TPMGL(T)>::_make(
                           x10_long n, x10::lang::Fun_0_1<x10_long, TPMGL(T)>* init)
{
    x10::array::Array_1<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>();
    this_->_constructor(n, init);
    return this_;
}



//#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_constructor(
                           x10::array::Array_1<TPMGL(T)>* src) {
    
    //#line 57 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this46655 = this;
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r46656 = x10::lang::Rail<TPMGL(T) >::_make(x10aux::nullCheck(src)->
                                                                             FMGL(raw));
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this46655)->FMGL(size) = (x10_long)(x10aux::nullCheck(r46656)->FMGL(size));
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this46655)->FMGL(raw) = r46656;
    
    //#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.AssignPropertyCall_c
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46654 = this;
    
}
template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<TPMGL(T)>::_make(
                           x10::array::Array_1<TPMGL(T)>* src)
{
    x10::array::Array_1<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>();
    this_->_constructor(src);
    return this_;
}



//#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_constructor(
                           x10::lang::Rail<TPMGL(T) >* r) {
    
    //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this46658 = this;
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r46659 = r;
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this46658)->FMGL(size) = (x10_long)(x10aux::nullCheck(r46659)->FMGL(size));
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this46658)->FMGL(raw) = r46659;
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.AssignPropertyCall_c
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46657 = this;
    
}
template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<TPMGL(T)>::_make(
                           x10::lang::Rail<TPMGL(T) >* r)
{
    x10::array::Array_1<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>();
    this_->_constructor(r);
    return this_;
}



//#line 68 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c

//#line 78 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::array::Array_1<TPMGL(T)>::toString(
  ) {
    
    //#line 78 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::toString();
    
}

//#line 84 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::IterationSpace* x10::array::Array_1<TPMGL(T)>::indices(
  ) {
    
    //#line 85 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_1* alloc46661 =  ((new (memset(x10aux::alloc<x10::array::DenseIterationSpace_1>(), 0, sizeof(x10::array::DenseIterationSpace_1))) x10::array::DenseIterationSpace_1()))
    ;
    
    //#line 85 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorCall_c
    (alloc46661)->::x10::array::DenseIterationSpace_1::_constructor(
      ((x10_long)0ll), ((x10_long) ((this->FMGL(size)) - (((x10_long)1ll)))));
    
    //#line 85 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return reinterpret_cast<x10::array::IterationSpace*>(alloc46661);
    
}

//#line 95 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_1<TPMGL(T)>::__apply(
  x10_long i) {
    
    //#line 97 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             i);
    
}

//#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_1<TPMGL(T)>::__apply(
  x10::lang::Point* p) {
    
    //#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46662 = this;
    
    //#line 95 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10_long i46663 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return x10aux::nullCheck(this46662)->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__apply(
             i46663);
    
}

//#line 119 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_1<TPMGL(T)>::__set(
  x10_long i, TPMGL(T) v) {
    
    //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      i, v);
    
    //#line 122 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_1<TPMGL(T)>::__set(
  x10::lang::Point* p, TPMGL(T) v) {
    
    //#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* this46664 = this;
    
    //#line 119 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10_long i46665 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 119 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) v46666 = v;
    
    //#line 119 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret46667;
    
    //#line 121 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10Call_c
    x10aux::nullCheck(this46664)->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
      i46665, v46666);
    
    //#line 122 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": Eval of x10.ast.X10LocalAssign_c
    ret46667 = v46666;
    
    //#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return ret46667;
    
}

//#line 137 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c

//#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<TPMGL(T)>::x10__array__Array_1____this__x10__array__Array_1(
  ) {
    
    //#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 19 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::__fieldInitializers_x10_array_Array_1(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::array::Array_1<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::array::Array_1<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::array::Array<TPMGL(T)>::_serialize_body(buf);
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::array::Array_1<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::array::Array_1<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::array::Array_1<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::array::Array<TPMGL(T)>::_deserialize_body(buf);
    
}

template<class TPMGL(T)> x10::array::Array_1<TPMGL(T)>* x10::array::Array_1<void>::makeView(x10::lang::Rail<TPMGL(T) >* r)
{
    
    //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_1<TPMGL(T)>* alloc46660 =  ((new (memset(x10aux::alloc<x10::array::Array_1<TPMGL(T)> >(), 0, sizeof(x10::array::Array_1<TPMGL(T)>))) x10::array::Array_1<TPMGL(T)>()))
    ;
    
    //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10ConstructorCall_c
    (alloc46660)->::x10::array::Array_1<TPMGL(T)>::_constructor(
      r);
    
    //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_1.x10": x10.ast.X10Return_c
    return alloc46660;
    
}
#endif // X10_ARRAY_ARRAY_1_H_IMPLEMENTATION
#endif // __X10_ARRAY_ARRAY_1_H_NODEPS
