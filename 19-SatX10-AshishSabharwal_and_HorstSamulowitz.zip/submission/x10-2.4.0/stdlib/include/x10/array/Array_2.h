#ifndef __X10_ARRAY_ARRAY_2_H
#define __X10_ARRAY_ARRAY_2_H

#include <x10rt.h>


#define X10_ARRAY_ARRAY_H_NODEPS
#include <x10/array/Array.h>
#undef X10_ARRAY_ARRAY_H_NODEPS
#define X10_LANG_FUN_0_2_H_NODEPS
#include <x10/lang/Fun_0_2.h>
#undef X10_LANG_FUN_0_2_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace lang { 
class IllegalOperationException;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace util { 
class StringBuilder;
} } 
namespace x10 { namespace lang { 
class Any;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace array { 
class DenseIterationSpace_2;
} } 
namespace x10 { namespace lang { 
class Point;
} } 
namespace x10 { namespace array { 

template<class TPMGL(T)> class Array_2;
template <> class Array_2<void>;
template<class TPMGL(T)> class Array_2 : public x10::array::Array<TPMGL(T)>
  {
    public:
    RTT_H_DECLS_CLASS
    
    x10_long FMGL(numElems_1);
    
    x10_long FMGL(numElems_2);
    
    static x10aux::itable_entry _itables[5];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Iterable<TPMGL(T)>::template itable<x10::array::Array_2<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::array::Array_2<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::array::Array_2<TPMGL(T)> > _itable_2;
    
    static typename x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>::template itable<x10::array::Array_2<TPMGL(T)> > _itable_3;
    
    x10_long rank();
    void _constructor(x10_long m, x10_long n);
    
    static x10::array::Array_2<TPMGL(T)>* _make(x10_long m, x10_long n);
    
    void _constructor(x10_long m, x10_long n, TPMGL(T) init);
    
    static x10::array::Array_2<TPMGL(T)>* _make(x10_long m, x10_long n, TPMGL(T) init);
    
    void _constructor(x10_long m, x10_long n, x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>* init);
    
    static x10::array::Array_2<TPMGL(T)>* _make(x10_long m, x10_long n, x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>* init);
    
    void _constructor(x10::array::Array_2<TPMGL(T)>* src);
    
    static x10::array::Array_2<TPMGL(T)>* _make(x10::array::Array_2<TPMGL(T)>* src);
    
    void _constructor(x10::lang::Rail<TPMGL(T) >* r, x10_long m, x10_long n);
    
    static x10::array::Array_2<TPMGL(T)>* _make(x10::lang::Rail<TPMGL(T) >* r,
                                                x10_long m, x10_long n);
    
    virtual x10::lang::String* toString();
    virtual x10::array::IterationSpace* indices();
    virtual x10_long offset(x10_long i, x10_long j);
    virtual TPMGL(T) __apply(x10_long i, x10_long j);
    virtual TPMGL(T) __apply(x10::lang::Point* p);
    virtual TPMGL(T) __set(x10_long i, x10_long j, TPMGL(T) v);
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v);
    virtual x10::array::Array_2<TPMGL(T)>* x10__array__Array_2____this__x10__array__Array_2(
      );
    virtual void __fieldInitializers_x10_array_Array_2();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::array::Array_2<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::Array_2<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::array::Array<TPMGL(T)> >(), x10aux::getRTT<x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.Array_2";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class Array_2<void> : public x10::array::Array<void> {
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(T)> static x10::array::Array_2<TPMGL(T)>*
      makeView(x10::lang::Rail<TPMGL(T) >* r, x10_long m, x10_long n);
    
    static x10_long validateSize(x10_long m, x10_long n);
    
    
};

} } 
#endif // X10_ARRAY_ARRAY_2_H

namespace x10 { namespace array { 
template<class TPMGL(T)> class Array_2;
} } 

#ifndef X10_ARRAY_ARRAY_2_H_NODEPS
#define X10_ARRAY_ARRAY_2_H_NODEPS
#include <x10/array/Array.h>
#include <x10/lang/Fun_0_2.h>
#include <x10/lang/Long.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/Inline.h>
#include <x10/lang/IllegalOperationException.h>
#include <x10/lang/String.h>
#include <x10/util/StringBuilder.h>
#include <x10/lang/Any.h>
#include <x10/lang/Unsafe.h>
#include <x10/array/DenseIterationSpace_2.h>
#include <x10/lang/Point.h>
#ifndef X10_ARRAY_ARRAY_2_H_GENERICS
#define X10_ARRAY_ARRAY_2_H_GENERICS
#endif // X10_ARRAY_ARRAY_2_H_GENERICS
#ifndef X10_ARRAY_ARRAY_2_H_IMPLEMENTATION
#define X10_ARRAY_ARRAY_2_H_IMPLEMENTATION
#include <x10/array/Array_2.h>


//#line 25 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.PropertyDecl_c

//#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.PropertyDecl_c
template<class TPMGL(T)> typename x10::lang::Iterable<TPMGL(T)>::template itable<x10::array::Array_2<TPMGL(T)> >  x10::array::Array_2<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array<TPMGL(T)>::iterator, &x10::array::Array_2<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::array::Array_2<TPMGL(T)> >  x10::array::Array_2<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_2<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::array::Array_2<TPMGL(T)> >  x10::array::Array_2<TPMGL(T)>::_itable_2(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_2<TPMGL(T)>::__apply, &x10::array::Array_2<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>::template itable<x10::array::Array_2<TPMGL(T)> >  x10::array::Array_2<TPMGL(T)>::_itable_3(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_2<TPMGL(T)>::__apply, &x10::array::Array_2<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::array::Array_2<TPMGL(T)>::_itables[5] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterable<TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >, &_itable_2), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)> >, &_itable_3), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::array::Array_2<TPMGL(T)> >())};

//#line 36 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::array::Array_2<TPMGL(T)>::rank() {
    
    //#line 36 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return ((x10_long)2ll);
    
}

//#line 41 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_constructor(
                           x10_long m, x10_long n) {
    
    //#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long m47032 =
                                                              m;
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n47033 =
                                                              n;
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret47034;
                                                            
                                                            //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
                                                            if (((m47032) < (((x10_long)0ll))) ||
                                                                ((n47033) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret47034 =
                                                              ((x10_long) ((m47032) * (n47033)));
                                                            ret47034;
                                                        }))
                                                        ,
                                                        true);
    
    //#line 43 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47219 = this;
    
}
template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<TPMGL(T)>::_make(
                           x10_long m, x10_long n) {
    x10::array::Array_2<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>();
    this_->_constructor(m, n);
    return this_;
}



//#line 49 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_constructor(
                           x10_long m, x10_long n, TPMGL(T) init) {
    
    //#line 50 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long m47039 =
                                                              m;
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n47040 =
                                                              n;
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret47041;
                                                            
                                                            //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
                                                            if (((m47039) < (((x10_long)0ll))) ||
                                                                ((n47040) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret47041 =
                                                              ((x10_long) ((m47039) * (n47040)));
                                                            ret47041;
                                                        }))
                                                        ,
                                                        false);
    
    //#line 51 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47220 = this;
    
    //#line 52 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::fill(
      init);
}
template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<TPMGL(T)>::_make(
                           x10_long m, x10_long n, TPMGL(T) init)
{
    x10::array::Array_2<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>();
    this_->_constructor(m, n, init);
    return this_;
}



//#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_constructor(
                           x10_long m, x10_long n, x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>* init) {
    
    //#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long m47046 =
                                                              m;
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n47047 =
                                                              n;
                                                            
                                                            //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret47048;
                                                            
                                                            //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
                                                            if (((m47046) < (((x10_long)0ll))) ||
                                                                ((n47047) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 191 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret47048 =
                                                              ((x10_long) ((m47046) * (n47047)));
                                                            ret47048;
                                                        }))
                                                        ,
                                                        false);
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47221 = this;
    
    //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long i46985max47228 = ((x10_long) ((m) - (((x10_long)1ll))));
    
    //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.For_c
    {
        x10_long i47229;
        for (
             //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
             i47229 = ((x10_long)0ll); ((i47229) <= (i46985max47228));
             
             //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
             i47229 = ((x10_long) ((i47229) + (((x10_long)1ll)))))
        {
            
            //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
            x10_long i47230 = i47229;
            
            //#line 63 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
            x10_long i46969max47225 = ((x10_long) ((n) - (((x10_long)1ll))));
            
            //#line 63 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.For_c
            {
                x10_long i47226;
                for (
                     //#line 63 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                     i47226 = ((x10_long)0ll); ((i47226) <= (i46969max47225));
                     
                     //#line 63 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
                     i47226 = ((x10_long) ((i47226) + (((x10_long)1ll)))))
                {
                    
                    //#line 63 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                    x10_long j47227 = i47226;
                    
                    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
                      (__extension__ ({
                          
                          //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                          x10::array::Array_2<TPMGL(T)>* this47222 =
                            this;
                          
                          //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                          x10_long i47223 = i47230;
                          
                          //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                          x10_long j47224 = j47227;
                          ((x10_long) ((j47224) + (((x10_long) ((i47223) * (x10aux::nullCheck(this47222)->
                                                                              FMGL(numElems_2)))))));
                      }))
                      , x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>::__apply(x10aux::nullCheck(init), 
                        i47230, j47227));
                }
            }
            
        }
    }
    
}
template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<TPMGL(T)>::_make(
                           x10_long m, x10_long n, x10::lang::Fun_0_2<x10_long, x10_long, TPMGL(T)>* init)
{
    x10::array::Array_2<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>();
    this_->_constructor(m, n, init);
    return this_;
}



//#line 73 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_constructor(
                           x10::array::Array_2<TPMGL(T)>* src) {
    
    //#line 74 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this47232 = this;
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r47233 = x10::lang::Rail<TPMGL(T) >::_make(x10aux::nullCheck(src)->
                                                                             FMGL(raw));
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47232)->FMGL(size) = (x10_long)(x10aux::nullCheck(r47233)->FMGL(size));
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47232)->FMGL(raw) = r47233;
    
    //#line 75 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = x10aux::nullCheck(src)->FMGL(numElems_1);
    FMGL(numElems_2) = x10aux::nullCheck(src)->FMGL(numElems_2);
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47231 = this;
    
}
template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<TPMGL(T)>::_make(
                           x10::array::Array_2<TPMGL(T)>* src)
{
    x10::array::Array_2<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>();
    this_->_constructor(src);
    return this_;
}



//#line 79 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_constructor(
                           x10::lang::Rail<TPMGL(T) >* r,
                           x10_long m, x10_long n) {
    
    //#line 80 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this47235 = this;
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r47236 = r;
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47235)->FMGL(size) = (x10_long)(x10aux::nullCheck(r47236)->FMGL(size));
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47235)->FMGL(raw) = r47236;
    
    //#line 81 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47234 = this;
    
}
template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<TPMGL(T)>::_make(
                           x10::lang::Rail<TPMGL(T) >* r,
                           x10_long m, x10_long n) {
    x10::array::Array_2<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>();
    this_->_constructor(r, m, n);
    return this_;
}



//#line 87 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c

//#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::array::Array_2<TPMGL(T)>::toString(
  ) {
    
    //#line 100 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::util::StringBuilder* sb =  ((new (memset(x10aux::alloc<x10::util::StringBuilder>(), 0, sizeof(x10::util::StringBuilder))) x10::util::StringBuilder()))
    ;
    
    //#line 100 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorCall_c
    (sb)->::x10::util::StringBuilder::_constructor();
    
    //#line 101 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
    sb->add(x10aux::makeStringLit("["));
    
    //#line 103 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long printed = ((x10_long)0ll);
    
    //#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long i47017max47247 = ((x10_long) ((this->FMGL(numElems_1)) - (((x10_long)1ll))));
    
    //#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.Labeled_c
    goto outer47248; outer47248: 
    //#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.For_c
    {
        x10_long i47249;
        for (
             //#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
             i47249 = ((x10_long)0ll); ((i47249) <= (i47017max47247));
             
             //#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
             i47249 = ((x10_long) ((i47249) + (((x10_long)1ll)))))
        {
        {
            
            //#line 104 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
            x10_long i47250 = i47249;
            
            //#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
            x10_long i47001max47244 = ((x10_long) ((this->
                                                      FMGL(numElems_2)) - (((x10_long)1ll))));
            
            //#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.For_c
            {
                x10_long i47245;
                for (
                     //#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                     i47245 = ((x10_long)0ll); ((i47245) <= (i47001max47244));
                     
                     //#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
                     i47245 = ((x10_long) ((i47245) + (((x10_long)1ll)))))
                {
                    
                    //#line 105 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                    x10_long j47246 = i47245;
                    
                    //#line 106 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
                    if ((!x10aux::struct_equals(j47246, ((x10_long)0ll))))
                    {
                        
                        //#line 106 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                        sb->add(x10aux::makeStringLit(", "));
                    }
                    
                    //#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                    reinterpret_cast<x10::util::StringBuilder*>(sb->add(
                                                                  x10aux::class_cast_unchecked<x10::lang::Any*>((__extension__ ({
                                                                      
                                                                      //#line 107 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                                      x10::array::Array_2<TPMGL(T)>* this47240 =
                                                                        this;
                                                                      
                                                                      //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                                      x10_long i47241 =
                                                                        i47250;
                                                                      
                                                                      //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                                      x10_long j47242 =
                                                                        j47246;
                                                                      
                                                                      //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                                      TPMGL(T) ret47243;
                                                                      
                                                                      //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
                                                                      if (true &&
                                                                          (((i47241) < (((x10_long)0ll))) ||
                                                                           ((i47241) >= (x10aux::nullCheck(this47240)->
                                                                                           FMGL(numElems_1))) ||
                                                                           ((j47242) < (((x10_long)0ll))) ||
                                                                           ((j47242) >= (x10aux::nullCheck(this47240)->
                                                                                           FMGL(numElems_2)))))
                                                                      {
                                                                          
                                                                          //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
                                                                          x10::array::Array<void>::raiseBoundsError(
                                                                            i47241,
                                                                            j47242);
                                                                      }
                                                                      
                                                                      //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
                                                                      ret47243 =
                                                                        (x10aux::nullCheck(this47240)->
                                                                           FMGL(raw))->unchecked_apply((__extension__ ({
                                                                          
                                                                          //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                                          x10_long i47238 =
                                                                            i47241;
                                                                          
                                                                          //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
                                                                          x10_long j47239 =
                                                                            j47242;
                                                                          ((x10_long) ((j47239) + (((x10_long) ((i47238) * (x10aux::nullCheck(this47240)->
                                                                                                                              FMGL(numElems_2)))))));
                                                                      }))
                                                                      );
                                                                      ret47243;
                                                                  }))
                                                                  )));
                    
                    //#line 108 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
                    if (((printed = ((x10_long) ((printed) + (((x10_long)1ll))))) > (((x10_long)10ll))))
                    {
                        
                        //#line 108 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.Branch_c
                        goto outer47248_end_;
                    }
                    
                }
            }
            
            //#line 110 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
            sb->add(x10aux::makeStringLit("; "));
        }
        goto outer47248_next_; outer47248_next_: ;
        }
        goto outer47248_end_; outer47248_end_: ;
    }
    
    //#line 112 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
    if (((((x10_long)10ll)) < (this->FMGL(size)))) {
        
        //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
        sb->add(x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("...(omitted "), ((x10_long) ((this->
                                                                                                                           FMGL(size)) - (((x10_long)10ll))))), x10aux::makeStringLit(" elements)")));
    }
    
    //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
    sb->add(x10aux::makeStringLit("]"));
    
    //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return sb->toString();
    
}

//#line 122 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::IterationSpace* x10::array::Array_2<TPMGL(T)>::indices(
  ) {
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_2* alloc47251 =  ((new (memset(x10aux::alloc<x10::array::DenseIterationSpace_2>(), 0, sizeof(x10::array::DenseIterationSpace_2))) x10::array::DenseIterationSpace_2()))
    ;
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorCall_c
    (alloc47251)->::x10::array::DenseIterationSpace_2::_constructor(
      ((x10_long)0ll), ((x10_long)0ll), ((x10_long) ((this->
                                                        FMGL(numElems_1)) - (((x10_long)1ll)))),
      ((x10_long) ((this->FMGL(numElems_2)) - (((x10_long)1ll)))));
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return reinterpret_cast<x10::array::IterationSpace*>(alloc47251);
    
}

//#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::array::Array_2<TPMGL(T)>::offset(
  x10_long i, x10_long j) {
    
    //#line 131 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return ((x10_long) ((j) + (((x10_long) ((i) * (this->
                                                     FMGL(numElems_2)))))));
    
}

//#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_2<TPMGL(T)>::__apply(
  x10_long i, x10_long j) {
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
    if (true && (((i) < (((x10_long)0ll))) || ((i) >= (this->
                                                         FMGL(numElems_1))) ||
                 ((j) < (((x10_long)0ll))) || ((j) >= (this->
                                                         FMGL(numElems_2)))))
    {
        
        //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i, j);
    }
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return (this->FMGL(raw))->unchecked_apply((__extension__ ({
        
        //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10::array::Array_2<TPMGL(T)>* this47200 = this;
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long i47198 = i;
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long j47199 = j;
        ((x10_long) ((j47199) + (((x10_long) ((i47198) * (x10aux::nullCheck(this47200)->
                                                            FMGL(numElems_2)))))));
    }))
    );
    
}

//#line 157 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_2<TPMGL(T)>::__apply(
  x10::lang::Point* p) {
    
    //#line 157 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47254 = this;
    
    //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long i47255 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long j47256 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)1ll));
    
    //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret47257;
    
    //#line 143 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
    if (true && (((i47255) < (((x10_long)0ll))) || ((i47255) >= (x10aux::nullCheck(this47254)->
                                                                   FMGL(numElems_1))) ||
                 ((j47256) < (((x10_long)0ll))) || ((j47256) >= (x10aux::nullCheck(this47254)->
                                                                   FMGL(numElems_2)))))
    {
        
        //#line 145 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i47255,
                                                  j47256);
    }
    
    //#line 147 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
    ret47257 = (x10aux::nullCheck(this47254)->FMGL(raw))->unchecked_apply((__extension__ ({
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long i47252 = i47255;
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long j47253 = j47256;
        ((x10_long) ((j47253) + (((x10_long) ((i47252) * (x10aux::nullCheck(this47254)->
                                                            FMGL(numElems_2)))))));
    }))
    );
    
    //#line 157 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return ret47257;
    
}

//#line 169 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_2<TPMGL(T)>::__set(
  x10_long i, x10_long j, TPMGL(T) v) {
    
    //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
    if (true && (((i) < (((x10_long)0ll))) || ((i) >= (this->
                                                         FMGL(numElems_1))) ||
                 ((j) < (((x10_long)0ll))) || ((j) >= (this->
                                                         FMGL(numElems_2)))))
    {
        
        //#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i, j);
    }
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
    (this->FMGL(raw))->unchecked_set((__extension__ ({
        
        //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10::array::Array_2<TPMGL(T)>* this47210 = this;
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long i47208 = i;
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long j47209 = j;
        ((x10_long) ((j47209) + (((x10_long) ((i47208) * (x10aux::nullCheck(this47210)->
                                                            FMGL(numElems_2)))))));
    }))
    , v);
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 187 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_2<TPMGL(T)>::__set(
  x10::lang::Point* p, TPMGL(T) v) {
    
    //#line 187 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* this47260 = this;
    
    //#line 169 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long i47261 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 169 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long j47262 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)1ll));
    
    //#line 169 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) v47263 = v;
    
    //#line 169 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret47264;
    
    //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
    if (true && (((i47261) < (((x10_long)0ll))) || ((i47261) >= (x10aux::nullCheck(this47260)->
                                                                   FMGL(numElems_1))) ||
                 ((j47262) < (((x10_long)0ll))) || ((j47262) >= (x10aux::nullCheck(this47260)->
                                                                   FMGL(numElems_2)))))
    {
        
        //#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i47261,
                                                  j47262);
    }
    
    //#line 174 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10Call_c
    (x10aux::nullCheck(this47260)->FMGL(raw))->unchecked_set((__extension__ ({
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long i47258 = i47261;
        
        //#line 130 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
        x10_long j47259 = j47262;
        ((x10_long) ((j47259) + (((x10_long) ((i47258) * (x10aux::nullCheck(this47260)->
                                                            FMGL(numElems_2)))))));
    }))
    , v47263);
    
    //#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": Eval of x10.ast.X10LocalAssign_c
    ret47264 = v47263;
    
    //#line 187 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return ret47264;
    
}

//#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c

//#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<TPMGL(T)>::x10__array__Array_2____this__x10__array__Array_2(
  ) {
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::__fieldInitializers_x10_array_Array_2(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::array::Array_2<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::array::Array_2<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::array::Array<TPMGL(T)>::_serialize_body(buf);
    buf.write(this->FMGL(numElems_1));
    buf.write(this->FMGL(numElems_2));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::array::Array_2<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::array::Array_2<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::array::Array_2<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::array::Array<TPMGL(T)>::_deserialize_body(buf);
    FMGL(numElems_1) = buf.read<x10_long>();
    FMGL(numElems_2) = buf.read<x10_long>();
}

template<class TPMGL(T)> x10::array::Array_2<TPMGL(T)>* x10::array::Array_2<void>::makeView(x10::lang::Rail<TPMGL(T) >* r,
                                                                                            x10_long m,
                                                                                            x10_long n)
{
    
    //#line 88 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10_long size = ((x10_long) ((m) * (n)));
    
    //#line 89 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(size, (x10_long)(x10aux::nullCheck(r)->FMGL(size)))))
    {
        
        //#line 89 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": polyglot.ast.Throw_c
        x10aux::throwException(x10aux::nullCheck(x10::lang::IllegalOperationException::_make(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("size mismatch: "), m), x10aux::makeStringLit(" * ")), n), x10aux::makeStringLit(" != ")), (x10_long)(x10aux::nullCheck(r)->FMGL(size))))));
    }
    
    //#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_2<TPMGL(T)>* alloc47237 =  ((new (memset(x10aux::alloc<x10::array::Array_2<TPMGL(T)> >(), 0, sizeof(x10::array::Array_2<TPMGL(T)>))) x10::array::Array_2<TPMGL(T)>()))
    ;
    
    //#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10ConstructorCall_c
    (alloc47237)->::x10::array::Array_2<TPMGL(T)>::_constructor(
      r, m, n);
    
    //#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_2.x10": x10.ast.X10Return_c
    return alloc47237;
    
}
#endif // X10_ARRAY_ARRAY_2_H_IMPLEMENTATION
#endif // __X10_ARRAY_ARRAY_2_H_NODEPS
