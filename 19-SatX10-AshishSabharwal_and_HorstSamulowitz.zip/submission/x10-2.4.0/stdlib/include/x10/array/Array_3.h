#ifndef __X10_ARRAY_ARRAY_3_H
#define __X10_ARRAY_ARRAY_3_H

#include <x10rt.h>


#define X10_ARRAY_ARRAY_H_NODEPS
#include <x10/array/Array.h>
#undef X10_ARRAY_ARRAY_H_NODEPS
#define X10_LANG_FUN_0_3_H_NODEPS
#include <x10/lang/Fun_0_3.h>
#undef X10_LANG_FUN_0_3_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace lang { 
class IllegalOperationException;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace util { 
class StringBuilder;
} } 
namespace x10 { namespace lang { 
class Any;
} } 
namespace x10 { namespace lang { 
class Unsafe;
} } 
namespace x10 { namespace array { 
class DenseIterationSpace_3;
} } 
namespace x10 { namespace lang { 
class Point;
} } 
namespace x10 { namespace array { 

template<class TPMGL(T)> class Array_3;
template <> class Array_3<void>;
template<class TPMGL(T)> class Array_3 : public x10::array::Array<TPMGL(T)>
  {
    public:
    RTT_H_DECLS_CLASS
    
    x10_long FMGL(numElems_1);
    
    x10_long FMGL(numElems_2);
    
    x10_long FMGL(numElems_3);
    
    static x10aux::itable_entry _itables[5];
    
    virtual x10aux::itable_entry* _getITables() { return _itables; }
    
    static typename x10::lang::Iterable<TPMGL(T)>::template itable<x10::array::Array_3<TPMGL(T)> > _itable_0;
    
    static x10::lang::Any::itable<x10::array::Array_3<TPMGL(T)> > _itable_1;
    
    static typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::array::Array_3<TPMGL(T)> > _itable_2;
    
    static typename x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>::template itable<x10::array::Array_3<TPMGL(T)> > _itable_3;
    
    x10_long rank();
    void _constructor(x10_long m, x10_long n, x10_long p);
    
    static x10::array::Array_3<TPMGL(T)>* _make(x10_long m, x10_long n, x10_long p);
    
    void _constructor(x10_long m, x10_long n, x10_long p, TPMGL(T) init);
    
    static x10::array::Array_3<TPMGL(T)>* _make(x10_long m, x10_long n, x10_long p,
                                                TPMGL(T) init);
    
    void _constructor(x10_long m, x10_long n, x10_long p, x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>* init);
    
    static x10::array::Array_3<TPMGL(T)>* _make(x10_long m, x10_long n,
                                                x10_long p, x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>* init);
    
    void _constructor(x10::array::Array_3<TPMGL(T)>* src);
    
    static x10::array::Array_3<TPMGL(T)>* _make(x10::array::Array_3<TPMGL(T)>* src);
    
    void _constructor(x10::lang::Rail<TPMGL(T) >* r, x10_long m, x10_long n,
                      x10_long p);
    
    static x10::array::Array_3<TPMGL(T)>* _make(x10::lang::Rail<TPMGL(T) >* r,
                                                x10_long m, x10_long n,
                                                x10_long p);
    
    virtual x10::lang::String* toString();
    virtual x10::array::IterationSpace* indices();
    virtual x10_long offset(x10_long i, x10_long j, x10_long k);
    virtual TPMGL(T) __apply(x10_long i, x10_long j, x10_long k);
    virtual TPMGL(T) __apply(x10::lang::Point* p);
    virtual TPMGL(T) __set(x10_long i, x10_long j, x10_long k, TPMGL(T) v);
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v);
    virtual x10::array::Array_3<TPMGL(T)>* x10__array__Array_3____this__x10__array__Array_3(
      );
    virtual void __fieldInitializers_x10_array_Array_3();
    
    // Serialization
    public: static const x10aux::serialization_id_t _serialization_id;
    
    public: x10aux::serialization_id_t _get_serialization_id() {
         return _serialization_id;
    }
    
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: static x10::lang::Reference* _deserializer(x10aux::deserialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::array::Array_3<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::Array_3<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[2] = { x10aux::getRTT<x10::array::Array<TPMGL(T)> >(), x10aux::getRTT<x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.Array_3";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 2, parents, 1, params, variances);
}

template <> class Array_3<void> : public x10::array::Array<void>
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    template<class TPMGL(T)> static x10::array::Array_3<TPMGL(T)>*
      makeView(x10::lang::Rail<TPMGL(T) >* r, x10_long m,
               x10_long n, x10_long p);
    
    static x10_long validateSize(x10_long m, x10_long n, x10_long p);
    
    
};

} } 
#endif // X10_ARRAY_ARRAY_3_H

namespace x10 { namespace array { 
template<class TPMGL(T)> class Array_3;
} } 

#ifndef X10_ARRAY_ARRAY_3_H_NODEPS
#define X10_ARRAY_ARRAY_3_H_NODEPS
#include <x10/array/Array.h>
#include <x10/lang/Fun_0_3.h>
#include <x10/lang/Long.h>
#include <x10/lang/Boolean.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/Inline.h>
#include <x10/lang/IllegalOperationException.h>
#include <x10/lang/String.h>
#include <x10/util/StringBuilder.h>
#include <x10/lang/Any.h>
#include <x10/lang/Unsafe.h>
#include <x10/array/DenseIterationSpace_3.h>
#include <x10/lang/Point.h>
#ifndef X10_ARRAY_ARRAY_3_H_GENERICS
#define X10_ARRAY_ARRAY_3_H_GENERICS
#endif // X10_ARRAY_ARRAY_3_H_GENERICS
#ifndef X10_ARRAY_ARRAY_3_H_IMPLEMENTATION
#define X10_ARRAY_ARRAY_3_H_IMPLEMENTATION
#include <x10/array/Array_3.h>


//#line 25 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.PropertyDecl_c

//#line 30 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.PropertyDecl_c

//#line 35 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.PropertyDecl_c
template<class TPMGL(T)> typename x10::lang::Iterable<TPMGL(T)>::template itable<x10::array::Array_3<TPMGL(T)> >  x10::array::Array_3<TPMGL(T)>::_itable_0(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array<TPMGL(T)>::iterator, &x10::array::Array_3<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10::lang::Any::itable<x10::array::Array_3<TPMGL(T)> >  x10::array::Array_3<TPMGL(T)>::_itable_1(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_3<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)>::template itable<x10::array::Array_3<TPMGL(T)> >  x10::array::Array_3<TPMGL(T)>::_itable_2(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_3<TPMGL(T)>::__apply, &x10::array::Array_3<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> typename x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>::template itable<x10::array::Array_3<TPMGL(T)> >  x10::array::Array_3<TPMGL(T)>::_itable_3(&x10::lang::X10Class::equals, &x10::lang::X10Class::hashCode, &x10::array::Array_3<TPMGL(T)>::__apply, &x10::array::Array_3<TPMGL(T)>::toString, &x10::lang::X10Class::typeName);
template<class TPMGL(T)> x10aux::itable_entry x10::array::Array_3<TPMGL(T)>::_itables[5] = {x10aux::itable_entry(&x10aux::getRTT<x10::lang::Iterable<TPMGL(T)> >, &_itable_0), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Any>, &_itable_1), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_1<x10::lang::Point*, TPMGL(T)> >, &_itable_2), x10aux::itable_entry(&x10aux::getRTT<x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)> >, &_itable_3), x10aux::itable_entry(NULL, (void*)x10aux::getRTT<x10::array::Array_3<TPMGL(T)> >())};

//#line 41 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::array::Array_3<TPMGL(T)>::rank() {
    
    //#line 41 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return ((x10_long)3ll);
    
}

//#line 47 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_constructor(
                           x10_long m, x10_long n, x10_long p) {
    
    //#line 48 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long m47790 =
                                                              m;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n47791 =
                                                              n;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long p47792 =
                                                              p;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret47793;
                                                            
                                                            //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
                                                            if (((m47790) < (((x10_long)0ll))) ||
                                                                ((n47791) < (((x10_long)0ll))) ||
                                                                ((p47792) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret47793 =
                                                              ((x10_long) ((((x10_long) ((m47790) * (n47791)))) * (p47792)));
                                                            ret47793;
                                                        }))
                                                        ,
                                                        true);
    
    //#line 49 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    FMGL(numElems_3) = p;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this47952 = this;
    
}
template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<TPMGL(T)>::_make(
                           x10_long m, x10_long n, x10_long p)
{
    x10::array::Array_3<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>();
    this_->_constructor(m, n, p);
    return this_;
}



//#line 56 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_constructor(
                           x10_long m, x10_long n, x10_long p,
                           TPMGL(T) init) {
    
    //#line 57 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long m47798 =
                                                              m;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n47799 =
                                                              n;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long p47800 =
                                                              p;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret47801;
                                                            
                                                            //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
                                                            if (((m47798) < (((x10_long)0ll))) ||
                                                                ((n47799) < (((x10_long)0ll))) ||
                                                                ((p47800) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret47801 =
                                                              ((x10_long) ((((x10_long) ((m47798) * (n47799)))) * (p47800)));
                                                            ret47801;
                                                        }))
                                                        ,
                                                        false);
    
    //#line 58 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    FMGL(numElems_3) = p;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this47953 = this;
    
    //#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
    this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::fill(
      init);
}
template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<TPMGL(T)>::_make(
                           x10_long m, x10_long n, x10_long p,
                           TPMGL(T) init) {
    x10::array::Array_3<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>();
    this_->_constructor(m, n, p, init);
    return this_;
}



//#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_constructor(
                           x10_long m, x10_long n, x10_long p,
                           x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>* init) {
    
    //#line 67 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorCall_c
    (this)->::x10::array::Array<TPMGL(T)>::_constructor((__extension__ ({
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long m47806 =
                                                              m;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long n47807 =
                                                              n;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long p47808 =
                                                              p;
                                                            
                                                            //#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                            x10_long ret47809;
                                                            
                                                            //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
                                                            if (((m47806) < (((x10_long)0ll))) ||
                                                                ((n47807) < (((x10_long)0ll))) ||
                                                                ((p47808) < (((x10_long)0ll))))
                                                            {
                                                                
                                                                //#line 206 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                                                                x10::array::Array<void>::raiseNegativeArraySizeException();
                                                            }
                                                            
                                                            //#line 207 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                                                            ret47809 =
                                                              ((x10_long) ((((x10_long) ((m47806) * (n47807)))) * (p47808)));
                                                            ret47809;
                                                        }))
                                                        ,
                                                        false);
    
    //#line 68 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    FMGL(numElems_3) = p;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this47954 = this;
    
    //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long i47727max47965 = ((x10_long) ((m) - (((x10_long)1ll))));
    
    //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.For_c
    {
        x10_long i47966;
        for (
             //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
             i47966 = ((x10_long)0ll); ((i47966) <= (i47727max47965));
             
             //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
             i47966 = ((x10_long) ((i47966) + (((x10_long)1ll)))))
        {
            
            //#line 69 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
            x10_long i47967 = i47966;
            
            //#line 70 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
            x10_long i47711max47962 = ((x10_long) ((n) - (((x10_long)1ll))));
            
            //#line 70 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.For_c
            {
                x10_long i47963;
                for (
                     //#line 70 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                     i47963 = ((x10_long)0ll); ((i47963) <= (i47711max47962));
                     
                     //#line 70 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                     i47963 = ((x10_long) ((i47963) + (((x10_long)1ll)))))
                {
                    
                    //#line 70 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                    x10_long j47964 = i47963;
                    
                    //#line 71 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                    x10_long i47695max47959 = ((x10_long) ((p) - (((x10_long)1ll))));
                    
                    //#line 71 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.For_c
                    {
                        x10_long i47960;
                        for (
                             //#line 71 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                             i47960 = ((x10_long)0ll); ((i47960) <= (i47695max47959));
                             
                             //#line 71 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                             i47960 = ((x10_long) ((i47960) + (((x10_long)1ll)))))
                        {
                            
                            //#line 71 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                            x10_long k47961 = i47960;
                            
                            //#line 72 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                            this->FMGL(raw)->x10::lang::template Rail<TPMGL(T) >::__set(
                              (__extension__ ({
                                  
                                  //#line 72 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                  x10::array::Array_3<TPMGL(T)>* this47955 =
                                    this;
                                  
                                  //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                  x10_long i47956 = i47967;
                                  
                                  //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                  x10_long j47957 = j47964;
                                  
                                  //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                  x10_long k47958 = k47961;
                                  ((x10_long) ((k47958) + (((x10_long) ((x10aux::nullCheck(this47955)->
                                                                           FMGL(numElems_3)) * (((x10_long) ((j47957) + (((x10_long) ((i47956) * (x10aux::nullCheck(this47955)->
                                                                                                                                                    FMGL(numElems_2)))))))))))));
                              }))
                              , x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>::__apply(x10aux::nullCheck(init), 
                                i47967, j47964, k47961));
                        }
                    }
                    
                }
            }
            
        }
    }
    
}
template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<TPMGL(T)>::_make(
                           x10_long m, x10_long n, x10_long p,
                           x10::lang::Fun_0_3<x10_long, x10_long, x10_long, TPMGL(T)>* init)
{
    x10::array::Array_3<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>();
    this_->_constructor(m, n, p, init);
    return this_;
}



//#line 82 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_constructor(
                           x10::array::Array_3<TPMGL(T)>* src) {
    
    //#line 83 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this47969 = this;
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r47970 = x10::lang::Rail<TPMGL(T) >::_make(x10aux::nullCheck(src)->
                                                                             FMGL(raw));
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47969)->FMGL(size) = (x10_long)(x10aux::nullCheck(r47970)->FMGL(size));
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47969)->FMGL(raw) = r47970;
    
    //#line 84 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = x10aux::nullCheck(src)->FMGL(numElems_1);
    FMGL(numElems_2) = x10aux::nullCheck(src)->FMGL(numElems_2);
    FMGL(numElems_3) = x10aux::nullCheck(src)->FMGL(numElems_3);
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this47968 = this;
    
}
template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<TPMGL(T)>::_make(
                           x10::array::Array_3<TPMGL(T)>* src)
{
    x10::array::Array_3<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>();
    this_->_constructor(src);
    return this_;
}



//#line 88 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_constructor(
                           x10::lang::Rail<TPMGL(T) >* r,
                           x10_long m, x10_long n, x10_long p) {
    
    //#line 89 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array<TPMGL(T)>* this47972 = this;
    
    //#line 64 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": x10.ast.X10LocalDecl_c
    x10::lang::Rail<TPMGL(T) >* r47973 = r;
    
    //#line 65 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47972)->FMGL(size) = (x10_long)(x10aux::nullCheck(r47973)->FMGL(size));
    
    //#line 66 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array.x10": Eval of x10.ast.X10FieldAssign_c
    x10aux::nullCheck(this47972)->FMGL(raw) = r47973;
    
    //#line 90 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.AssignPropertyCall_c
    FMGL(numElems_1) = m;
    FMGL(numElems_2) = n;
    FMGL(numElems_3) = p;
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this47971 = this;
    
}
template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<TPMGL(T)>::_make(
                           x10::lang::Rail<TPMGL(T) >* r,
                           x10_long m, x10_long n, x10_long p)
{
    x10::array::Array_3<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>();
    this_->_constructor(r, m, n, p);
    return this_;
}



//#line 96 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c

//#line 108 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::String* x10::array::Array_3<TPMGL(T)>::toString(
  ) {
    
    //#line 109 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::util::StringBuilder* sb =  ((new (memset(x10aux::alloc<x10::util::StringBuilder>(), 0, sizeof(x10::util::StringBuilder))) x10::util::StringBuilder()))
    ;
    
    //#line 109 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorCall_c
    (sb)->::x10::util::StringBuilder::_constructor();
    
    //#line 110 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
    sb->add(x10aux::makeStringLit("["));
    
    //#line 112 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long printed = ((x10_long)0ll);
    
    //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long i47775max47989 = ((x10_long) ((this->FMGL(numElems_1)) - (((x10_long)1ll))));
    
    //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.Labeled_c
    goto outer47990; outer47990: 
    //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.For_c
    {
        x10_long i47991;
        for (
             //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
             i47991 = ((x10_long)0ll); ((i47991) <= (i47775max47989));
             
             //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
             i47991 = ((x10_long) ((i47991) + (((x10_long)1ll)))))
        {
        {
            
            //#line 113 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
            x10_long i47992 = i47991;
            
            //#line 114 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
            x10_long i47759max47986 = ((x10_long) ((this->
                                                      FMGL(numElems_2)) - (((x10_long)1ll))));
            
            //#line 114 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.For_c
            {
                x10_long i47987;
                for (
                     //#line 114 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                     i47987 = ((x10_long)0ll); ((i47987) <= (i47759max47986));
                     
                     //#line 114 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                     i47987 = ((x10_long) ((i47987) + (((x10_long)1ll)))))
                {
                    
                    //#line 114 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                    x10_long j47988 = i47987;
                    
                    //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                    x10_long i47743max47983 = ((x10_long) ((this->
                                                              FMGL(numElems_3)) - (((x10_long)1ll))));
                    
                    //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.For_c
                    {
                        x10_long i47984;
                        for (
                             //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                             i47984 = ((x10_long)0ll); ((i47984) <= (i47743max47983));
                             
                             //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                             i47984 = ((x10_long) ((i47984) + (((x10_long)1ll)))))
                        {
                            
                            //#line 115 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                            x10_long k47985 = i47984;
                            
                            //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
                            if ((!x10aux::struct_equals(k47985,
                                                        ((x10_long)0ll))))
                            {
                                
                                //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                                sb->add(x10aux::makeStringLit(", "));
                            }
                            
                            //#line 117 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                            reinterpret_cast<x10::util::StringBuilder*>(sb->add(
                                                                          x10aux::class_cast_unchecked<x10::lang::Any*>((__extension__ ({
                                                                              
                                                                              //#line 117 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                              x10::array::Array_3<TPMGL(T)>* this47978 =
                                                                                this;
                                                                              
                                                                              //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                              x10_long i47979 =
                                                                                i47992;
                                                                              
                                                                              //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                              x10_long j47980 =
                                                                                j47988;
                                                                              
                                                                              //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                              x10_long k47981 =
                                                                                k47985;
                                                                              
                                                                              //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                              TPMGL(T) ret47982;
                                                                              
                                                                              //#line 155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
                                                                              if (true &&
                                                                                  (((i47979) < (((x10_long)0ll))) ||
                                                                                   ((i47979) >= (x10aux::nullCheck(this47978)->
                                                                                                   FMGL(numElems_1))) ||
                                                                                   ((j47980) < (((x10_long)0ll))) ||
                                                                                   ((j47980) >= (x10aux::nullCheck(this47978)->
                                                                                                   FMGL(numElems_2))) ||
                                                                                   ((k47981) < (((x10_long)0ll))) ||
                                                                                   ((k47981) >= (x10aux::nullCheck(this47978)->
                                                                                                   FMGL(numElems_3)))))
                                                                              {
                                                                                  
                                                                                  //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                                                                                  x10::array::Array<void>::raiseBoundsError(
                                                                                    i47979,
                                                                                    j47980,
                                                                                    k47981);
                                                                              }
                                                                              
                                                                              //#line 160 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
                                                                              ret47982 =
                                                                                (x10aux::nullCheck(this47978)->
                                                                                   FMGL(raw))->unchecked_apply((__extension__ ({
                                                                                  
                                                                                  //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                                  x10_long i47975 =
                                                                                    i47979;
                                                                                  
                                                                                  //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                                  x10_long j47976 =
                                                                                    j47980;
                                                                                  
                                                                                  //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
                                                                                  x10_long k47977 =
                                                                                    k47981;
                                                                                  ((x10_long) ((k47977) + (((x10_long) ((x10aux::nullCheck(this47978)->
                                                                                                                           FMGL(numElems_3)) * (((x10_long) ((j47976) + (((x10_long) ((i47975) * (x10aux::nullCheck(this47978)->
                                                                                                                                                                                                    FMGL(numElems_2)))))))))))));
                                                                              }))
                                                                              );
                                                                              ret47982;
                                                                          }))
                                                                          )));
                            
                            //#line 118 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
                            if (((printed = ((x10_long) ((printed) + (((x10_long)1ll))))) > (((x10_long)10ll))))
                            {
                                
                                //#line 118 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.Branch_c
                                goto outer47990_end_;
                            }
                            
                        }
                    }
                    
                    //#line 120 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
                    sb->add((x10aux::struct_equals(j47988,
                                                   ((x10_long) ((this->
                                                                   FMGL(numElems_2)) - (((x10_long)1ll))))))
                              ? (x10aux::makeStringLit(";; "))
                              : (x10aux::makeStringLit("; ")));
                }
            }
            
        }
        goto outer47990_next_; outer47990_next_: ;
        }
        goto outer47990_end_; outer47990_end_: ;
    }
    
    //#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
    if (((((x10_long)10ll)) < (this->FMGL(size)))) {
        
        //#line 124 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
        sb->add(x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("...(omitted "), ((x10_long) ((this->
                                                                                                                           FMGL(size)) - (((x10_long)10ll))))), x10aux::makeStringLit(" elements)")));
    }
    
    //#line 126 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
    sb->add(x10aux::makeStringLit("]"));
    
    //#line 127 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return sb->toString();
    
}

//#line 133 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::IterationSpace* x10::array::Array_3<TPMGL(T)>::indices(
  ) {
    
    //#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::DenseIterationSpace_3* alloc47993 =  ((new (memset(x10aux::alloc<x10::array::DenseIterationSpace_3>(), 0, sizeof(x10::array::DenseIterationSpace_3))) x10::array::DenseIterationSpace_3()))
    ;
    
    //#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorCall_c
    (alloc47993)->::x10::array::DenseIterationSpace_3::_constructor(
      ((x10_long)0ll), ((x10_long)0ll), ((x10_long)0ll), ((x10_long) ((this->
                                                                         FMGL(numElems_1)) - (((x10_long)1ll)))),
      ((x10_long) ((this->FMGL(numElems_2)) - (((x10_long)1ll)))),
      ((x10_long) ((this->FMGL(numElems_3)) - (((x10_long)1ll)))));
    
    //#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return reinterpret_cast<x10::array::IterationSpace*>(alloc47993);
    
}

//#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10_long x10::array::Array_3<TPMGL(T)>::offset(
  x10_long i, x10_long j, x10_long k) {
    
    //#line 142 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return ((x10_long) ((k) + (((x10_long) ((this->FMGL(numElems_3)) * (((x10_long) ((j) + (((x10_long) ((i) * (this->
                                                                                                                  FMGL(numElems_2)))))))))))));
    
}

//#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_3<TPMGL(T)>::__apply(
  x10_long i, x10_long j, x10_long k) {
    
    //#line 155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
    if (true && (((i) < (((x10_long)0ll))) || ((i) >= (this->
                                                         FMGL(numElems_1))) ||
                 ((j) < (((x10_long)0ll))) || ((j) >= (this->
                                                         FMGL(numElems_2))) ||
                 ((k) < (((x10_long)0ll))) || ((k) >= (this->
                                                         FMGL(numElems_3)))))
    {
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i, j, k);
    }
    
    //#line 160 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return (this->FMGL(raw))->unchecked_apply((__extension__ ({
        
        //#line 160 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10::array::Array_3<TPMGL(T)>* this47928 = this;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long i47925 = i;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long j47926 = j;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long k47927 = k;
        ((x10_long) ((k47927) + (((x10_long) ((x10aux::nullCheck(this47928)->
                                                 FMGL(numElems_3)) * (((x10_long) ((j47926) + (((x10_long) ((i47925) * (x10aux::nullCheck(this47928)->
                                                                                                                          FMGL(numElems_2)))))))))))));
    }))
    );
    
}

//#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_3<TPMGL(T)>::__apply(
  x10::lang::Point* p) {
    
    //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this47997 = this;
    
    //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long i47998 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long j47999 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)1ll));
    
    //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long k48000 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)2ll));
    
    //#line 154 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret48001;
    
    //#line 155 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
    if (true && (((i47998) < (((x10_long)0ll))) || ((i47998) >= (x10aux::nullCheck(this47997)->
                                                                   FMGL(numElems_1))) ||
                 ((j47999) < (((x10_long)0ll))) || ((j47999) >= (x10aux::nullCheck(this47997)->
                                                                   FMGL(numElems_2))) ||
                 ((k48000) < (((x10_long)0ll))) || ((k48000) >= (x10aux::nullCheck(this47997)->
                                                                   FMGL(numElems_3)))))
    {
        
        //#line 158 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i47998,
                                                  j47999,
                                                  k48000);
    }
    
    //#line 160 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
    ret48001 = (x10aux::nullCheck(this47997)->FMGL(raw))->unchecked_apply((__extension__ ({
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long i47994 = i47998;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long j47995 = j47999;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long k47996 = k48000;
        ((x10_long) ((k47996) + (((x10_long) ((x10aux::nullCheck(this47997)->
                                                 FMGL(numElems_3)) * (((x10_long) ((j47995) + (((x10_long) ((i47994) * (x10aux::nullCheck(this47997)->
                                                                                                                          FMGL(numElems_2)))))))))))));
    }))
    );
    
    //#line 170 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return ret48001;
    
}

//#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_3<TPMGL(T)>::__set(
  x10_long i, x10_long j, x10_long k, TPMGL(T) v) {
    
    //#line 184 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
    if (true && (((i) < (((x10_long)0ll))) || ((i) >= (this->
                                                         FMGL(numElems_1))) ||
                 ((j) < (((x10_long)0ll))) || ((j) >= (this->
                                                         FMGL(numElems_2))) ||
                 ((k) < (((x10_long)0ll))) || ((k) >= (this->
                                                         FMGL(numElems_3)))))
    {
        
        //#line 187 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i, j, k);
    }
    
    //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
    (this->FMGL(raw))->unchecked_set((__extension__ ({
        
        //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10::array::Array_3<TPMGL(T)>* this47941 = this;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long i47938 = i;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long j47939 = j;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long k47940 = k;
        ((x10_long) ((k47940) + (((x10_long) ((x10aux::nullCheck(this47941)->
                                                 FMGL(numElems_3)) * (((x10_long) ((j47939) + (((x10_long) ((i47938) * (x10aux::nullCheck(this47941)->
                                                                                                                          FMGL(numElems_2)))))))))))));
    }))
    , v);
    
    //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return v;
    
}

//#line 202 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> TPMGL(T) x10::array::Array_3<TPMGL(T)>::__set(
  x10::lang::Point* p, TPMGL(T) v) {
    
    //#line 202 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* this48005 = this;
    
    //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long i48006 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)0ll));
    
    //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long j48007 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)1ll));
    
    //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long k48008 = x10aux::nullCheck(p)->x10::lang::Point::__apply(
                        ((x10_long)2ll));
    
    //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) v48009 = v;
    
    //#line 183 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    TPMGL(T) ret48010;
    
    //#line 184 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
    if (true && (((i48006) < (((x10_long)0ll))) || ((i48006) >= (x10aux::nullCheck(this48005)->
                                                                   FMGL(numElems_1))) ||
                 ((j48007) < (((x10_long)0ll))) || ((j48007) >= (x10aux::nullCheck(this48005)->
                                                                   FMGL(numElems_2))) ||
                 ((k48008) < (((x10_long)0ll))) || ((k48008) >= (x10aux::nullCheck(this48005)->
                                                                   FMGL(numElems_3)))))
    {
        
        //#line 187 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
        x10::array::Array<void>::raiseBoundsError(i48006,
                                                  j48007,
                                                  k48008);
    }
    
    //#line 189 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10Call_c
    (x10aux::nullCheck(this48005)->FMGL(raw))->unchecked_set((__extension__ ({
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long i48002 = i48006;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long j48003 = j48007;
        
        //#line 141 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
        x10_long k48004 = k48008;
        ((x10_long) ((k48004) + (((x10_long) ((x10aux::nullCheck(this48005)->
                                                 FMGL(numElems_3)) * (((x10_long) ((j48003) + (((x10_long) ((i48002) * (x10aux::nullCheck(this48005)->
                                                                                                                          FMGL(numElems_2)))))))))))));
    }))
    , v48009);
    
    //#line 190 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": Eval of x10.ast.X10LocalAssign_c
    ret48010 = v48009;
    
    //#line 202 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return ret48010;
    
}

//#line 205 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c

//#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<TPMGL(T)>::x10__array__Array_3____this__x10__array__Array_3(
  ) {
    
    //#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 21 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::__fieldInitializers_x10_array_Array_3(
  ) {
 
}
template<class TPMGL(T)> const x10aux::serialization_id_t x10::array::Array_3<TPMGL(T)>::_serialization_id = 
    x10aux::DeserializationDispatcher::addDeserializer(x10::array::Array_3<TPMGL(T)>::_deserializer, x10aux::CLOSURE_KIND_NOT_ASYNC);

template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    x10::array::Array<TPMGL(T)>::_serialize_body(buf);
    buf.write(this->FMGL(numElems_1));
    buf.write(this->FMGL(numElems_2));
    buf.write(this->FMGL(numElems_3));
    
}

template<class TPMGL(T)> x10::lang::Reference* x10::array::Array_3<TPMGL(T)>::_deserializer(x10aux::deserialization_buffer& buf) {
    x10::array::Array_3<TPMGL(T)>* this_ = new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>();
    buf.record_reference(this_);
    this_->_deserialize_body(buf);
    return this_;
}

template<class TPMGL(T)> void x10::array::Array_3<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    x10::array::Array<TPMGL(T)>::_deserialize_body(buf);
    FMGL(numElems_1) = buf.read<x10_long>();
    FMGL(numElems_2) = buf.read<x10_long>();
    FMGL(numElems_3) = buf.read<x10_long>();
}

template<class TPMGL(T)> x10::array::Array_3<TPMGL(T)>* x10::array::Array_3<void>::makeView(x10::lang::Rail<TPMGL(T) >* r,
                                                                                            x10_long m,
                                                                                            x10_long n,
                                                                                            x10_long p)
{
    
    //#line 97 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10_long size = ((x10_long) ((((x10_long) ((n) * (m)))) * (p)));
    
    //#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10If_c
    if ((!x10aux::struct_equals(size, (x10_long)(x10aux::nullCheck(r)->FMGL(size)))))
    {
        
        //#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": polyglot.ast.Throw_c
        x10aux::throwException(x10aux::nullCheck(x10::lang::IllegalOperationException::_make(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10::lang::String::__plus(x10aux::makeStringLit("size mismatch: "), m), x10aux::makeStringLit(" * ")), n), x10aux::makeStringLit(" * ")), p), x10aux::makeStringLit(" != ")), (x10_long)(x10aux::nullCheck(r)->FMGL(size))))));
    }
    
    //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10LocalDecl_c
    x10::array::Array_3<TPMGL(T)>* alloc47974 =  ((new (memset(x10aux::alloc<x10::array::Array_3<TPMGL(T)> >(), 0, sizeof(x10::array::Array_3<TPMGL(T)>))) x10::array::Array_3<TPMGL(T)>()))
    ;
    
    //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10ConstructorCall_c
    (alloc47974)->::x10::array::Array_3<TPMGL(T)>::_constructor(
      r, m, n, p);
    
    //#line 99 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/Array_3.x10": x10.ast.X10Return_c
    return alloc47974;
    
}
#endif // X10_ARRAY_ARRAY_3_H_IMPLEMENTATION
#endif // __X10_ARRAY_ARRAY_3_H_NODEPS
