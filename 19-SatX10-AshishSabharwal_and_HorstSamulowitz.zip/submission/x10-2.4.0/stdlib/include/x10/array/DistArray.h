#ifndef __X10_ARRAY_DISTARRAY_H
#define __X10_ARRAY_DISTARRAY_H

#include <x10rt.h>


#define X10_LANG_ITERABLE_H_NODEPS
#include <x10/lang/Iterable.h>
#undef X10_LANG_ITERABLE_H_NODEPS
namespace x10 { namespace lang { 
class Point;
} } 
#define X10_LANG_PLACELOCALHANDLE_H_NODEPS
#include <x10/lang/PlaceLocalHandle.h>
#undef X10_LANG_PLACELOCALHANDLE_H_NODEPS
#define X10_LANG_PLACELOCALHANDLE_H_NODEPS
#include <x10/lang/PlaceLocalHandle.h>
#undef X10_LANG_PLACELOCALHANDLE_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
#define X10_LANG_LONG_H_NODEPS
#include <x10/lang/Long.h>
#undef X10_LANG_LONG_H_NODEPS
namespace x10 { namespace array { 
template<class TPMGL(S)> class LocalState;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Rail;
} } 
namespace x10 { namespace compiler { 
class TransientInitExpr;
} } 
namespace x10 { namespace compiler { 
class NonEscaping;
} } 
namespace x10 { namespace lang { 
class PlaceGroup;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(U)> class Fun_0_0;
} } 
namespace x10 { namespace compiler { 
class Inline;
} } 
namespace x10 { namespace array { 
class IterationSpace;
} } 
namespace x10 { namespace lang { 
template<class TPMGL(T)> class Iterator;
} } 
namespace x10 { namespace lang { 
class Place;
} } 
namespace x10 { namespace lang { 
class ArrayIndexOutOfBoundsException;
} } 
namespace x10 { namespace lang { 
class String;
} } 
namespace x10 { namespace compiler { 
class NoInline;
} } 
namespace x10 { namespace compiler { 
class NoReturn;
} } 
namespace x10 { namespace lang { 
class BadPlaceException;
} } 
namespace x10 { namespace lang { 
class Runtime;
} } 
namespace x10 { namespace lang { 
class NegativeArraySizeException;
} } 
namespace x10 { namespace array { 

template<class TPMGL(T)> class DistArray;
template <> class DistArray<void>;
template<class TPMGL(T)> class DistArray : public x10::lang::X10Class   {
    public:
    RTT_H_DECLS_CLASS
    
    x10_long FMGL(size);
    
    x10_long rank();
    x10::lang::PlaceLocalHandle<x10::array::LocalState<TPMGL(T)>*> FMGL(localHandle);
    
    x10::lang::Rail<TPMGL(T) >* FMGL(raw);
    
    virtual x10::lang::Rail<TPMGL(T) >* getRailFromLocalHandle();
    x10::lang::PlaceGroup* FMGL(placeGroup);
    
    void _constructor(x10::lang::PlaceGroup* pg, x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>* init,
                      x10_long sz);
    
    virtual x10::lang::Rail<TPMGL(T) >* raw();
    virtual x10::lang::PlaceGroup* placeGroup();
    virtual x10::array::IterationSpace* globalIndices() = 0;
    virtual x10::lang::Iterator<x10::lang::Point*>* iterator();
    virtual x10::array::IterationSpace* localIndices() = 0;
    virtual x10::lang::Place place(x10::lang::Point* p) = 0;
    virtual TPMGL(T) __apply(x10::lang::Point* p) = 0;
    virtual TPMGL(T) __set(x10::lang::Point* p, TPMGL(T) v) = 0;
    virtual x10::array::DistArray<TPMGL(T)>* x10__array__DistArray____this__x10__array__DistArray(
      );
    virtual void __fieldInitializers_x10_array_DistArray(
      );
    
    // Serialization
    public: virtual void _serialize_body(x10aux::serialization_buffer& buf);
    
    public: void _deserialize_body(x10aux::deserialization_buffer& buf);
    
};

template<class TPMGL(T)> x10aux::RuntimeType x10::array::DistArray<TPMGL(T)>::rtt;
template<class TPMGL(T)> void x10::array::DistArray<TPMGL(T)>::_initRTT() {
    const x10aux::RuntimeType *canonical = x10aux::getRTT<x10::array::DistArray<void> >();
    if (rtt.initStageOne(canonical)) return;
    const x10aux::RuntimeType* parents[1] = { x10aux::getRTT<x10::lang::Iterable<x10::lang::Point*> >()};
    const x10aux::RuntimeType* params[1] = { x10aux::getRTT<TPMGL(T)>()};
    x10aux::RuntimeType::Variance variances[1] = { x10aux::RuntimeType::invariant};
    const char *baseName = "x10.array.DistArray";
    rtt.initStageTwo(baseName, x10aux::RuntimeType::class_kind, 1, parents, 1, params, variances);
}

template <> class DistArray<void> : public x10::lang::X10Class
{
    public:
    static x10aux::RuntimeType rtt;
    static const x10aux::RuntimeType* getRTT() { return & rtt; }
    static void raiseBoundsError(x10_long i) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i, x10_long j) X10_PRAGMA_NORETURN ;
    
    static void raiseBoundsError(x10_long i, x10_long j, x10_long k) X10_PRAGMA_NORETURN ;
    
    static void raisePlaceError(x10_long i) X10_PRAGMA_NORETURN ;
    
    static void raisePlaceError(x10_long i, x10_long j) X10_PRAGMA_NORETURN ;
    
    static void raisePlaceError(x10_long i, x10_long j, x10_long k) X10_PRAGMA_NORETURN ;
    
    static void raiseNegativeArraySizeException() X10_PRAGMA_NORETURN ;
    
    
};

} } 
#endif // X10_ARRAY_DISTARRAY_H

namespace x10 { namespace array { 
template<class TPMGL(T)> class DistArray;
} } 

#ifndef X10_ARRAY_DISTARRAY_H_NODEPS
#define X10_ARRAY_DISTARRAY_H_NODEPS
#include <x10/lang/Iterable.h>
#include <x10/lang/Point.h>
#include <x10/lang/PlaceLocalHandle.h>
#include <x10/lang/Long.h>
#include <x10/array/LocalState.h>
#include <x10/lang/Rail.h>
#include <x10/compiler/TransientInitExpr.h>
#include <x10/compiler/NonEscaping.h>
#include <x10/lang/PlaceGroup.h>
#include <x10/lang/Fun_0_0.h>
#include <x10/compiler/Inline.h>
#include <x10/array/IterationSpace.h>
#include <x10/lang/Iterator.h>
#include <x10/lang/Place.h>
#include <x10/lang/ArrayIndexOutOfBoundsException.h>
#include <x10/lang/String.h>
#include <x10/compiler/NoInline.h>
#include <x10/compiler/NoReturn.h>
#include <x10/lang/BadPlaceException.h>
#include <x10/lang/Runtime.h>
#include <x10/lang/NegativeArraySizeException.h>
#ifndef X10_ARRAY_DISTARRAY_H_GENERICS
#define X10_ARRAY_DISTARRAY_H_GENERICS
#endif // X10_ARRAY_DISTARRAY_H_GENERICS
#ifndef X10_ARRAY_DISTARRAY_H_IMPLEMENTATION
#define X10_ARRAY_DISTARRAY_H_IMPLEMENTATION
#include <x10/array/DistArray.h>


//#line 42 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.PropertyDecl_c

//#line 48 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 53 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10FieldDecl_c
/** 
     * The place-local state for the DistArray 
     */

//#line 59 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10FieldDecl_c
/**
     * The place-local backing storage for elements of the DistArray.
     */

//#line 60 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::array::DistArray<TPMGL(T)>::getRailFromLocalHandle(
  ) {
    
    //#line 61 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::array::LocalState<TPMGL(T)>* ls = this->FMGL(localHandle)->x10::lang::template PlaceLocalHandle<x10::array::LocalState<TPMGL(T)>*>::__apply();
    
    //#line 62 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10Return_c
    return (!x10aux::struct_equals(ls, reinterpret_cast<x10::lang::NullType*>(X10_NULL)))
      ? (x10aux::nullCheck(ls)->FMGL(rail)) : (x10::lang::Rail<TPMGL(T) >::_make());
    
}

//#line 68 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10FieldDecl_c
/**
     * The PlaceGroup over which this DistArray is defined.
     */

//#line 77 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10ConstructorDecl_c
template<class TPMGL(T)> void x10::array::DistArray<TPMGL(T)>::_constructor(
                           x10::lang::PlaceGroup* pg, x10::lang::Fun_0_0<x10::array::LocalState<TPMGL(T)>*>* init,
                           x10_long sz) {
    
    //#line 78 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.AssignPropertyCall_c
    FMGL(size) = sz;
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::array::DistArray<TPMGL(T)>* this50931 = this;
    
    //#line 79 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::lang::PlaceLocalHandle<x10::array::LocalState<TPMGL(T)>*> plh =
      x10::lang::PlaceLocalHandle<void>::template makeFlat<x10::array::LocalState<TPMGL(T)>* >(
        pg, init);
    
    //#line 80 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10LocalDecl_c
    x10::array::LocalState<TPMGL(T)>* ls = plh->x10::lang::template PlaceLocalHandle<x10::array::LocalState<TPMGL(T)>*>::__apply();
    
    //#line 81 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(localHandle) = plh;
    
    //#line 82 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(placeGroup) = pg;
    
    //#line 83 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": Eval of x10.ast.X10FieldAssign_c
    this->FMGL(raw) = this->x10::array::template DistArray<TPMGL(T)>::getRailFromLocalHandle();
}


//#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Rail<TPMGL(T) >* x10::array::DistArray<TPMGL(T)>::raw(
  ) {
    
    //#line 98 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(raw);
    
}

//#line 103 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::PlaceGroup* x10::array::DistArray<TPMGL(T)>::placeGroup(
  ) {
    
    //#line 103 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10Return_c
    return this->FMGL(placeGroup);
    
}

//#line 110 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::lang::Iterator<x10::lang::Point*>*
  x10::array::DistArray<TPMGL(T)>::iterator() {
    
    //#line 116 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10Return_c
    return this->globalIndices()->iterator();
    
}

//#line 123 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 134 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 146 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 160 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 162 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 165 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 168 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 172 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 175 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 178 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 182 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> x10::array::DistArray<TPMGL(T)>*
  x10::array::DistArray<TPMGL(T)>::x10__array__DistArray____this__x10__array__DistArray(
  ) {
    
    //#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10Return_c
    return this;
    
}

//#line 38 "/tmp/x10-rc-dgrove/x10-2.4.0/x10.runtime/src-x10/x10/array/DistArray.x10": x10.ast.X10MethodDecl_c
template<class TPMGL(T)> void x10::array::DistArray<TPMGL(T)>::__fieldInitializers_x10_array_DistArray(
  ) {
 
}
template<class TPMGL(T)> void x10::array::DistArray<TPMGL(T)>::_serialize_body(x10aux::serialization_buffer& buf) {
    buf.write(this->FMGL(localHandle));
    buf.write(this->FMGL(placeGroup));
    buf.write(this->FMGL(size));
    
}

template<class TPMGL(T)> void x10::array::DistArray<TPMGL(T)>::_deserialize_body(x10aux::deserialization_buffer& buf) {
    FMGL(localHandle) = buf.read<x10::lang::PlaceLocalHandle<x10::array::LocalState<TPMGL(T)>*> >();
    FMGL(placeGroup) = buf.read<x10::lang::PlaceGroup*>();
    FMGL(size) = buf.read<x10_long>();
    /* fields with @TransientInitExpr annotations */
    FMGL(raw) = x10::array::template DistArray<TPMGL(T)>::getRailFromLocalHandle();
    
}

#endif // X10_ARRAY_DISTARRAY_H_IMPLEMENTATION
#endif // __X10_ARRAY_DISTARRAY_H_NODEPS
