(c) IBM Corporation

This program is controlled by the Eclipse Public Licence v1.0.

This is a distribution of the X10 Programming Language.
http://x10-lang.org/

Please see INSTALL.txt for basic usage instructions.

Please see x10-lang.org for more detailed instructions
on how to build from source and for general infromation
about X10.
