This directory and its sub-directories contain a collection of small
sample programs illustrating various aspects of the X10 programming
language.

Additional larger X10 benchmarks can be found online either from the
main X10 web site at http://x10-lang.org or in the benchmarks section
of the X10 subversion repository at
https://svn.code.sf.net/p/x10/code/benchmarks/trunk.
