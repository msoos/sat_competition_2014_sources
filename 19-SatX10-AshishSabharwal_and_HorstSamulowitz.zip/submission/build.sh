#!/bin/sh

ROOT=$PWD

X10_VERSION='2.4.0'
#X10_ROOT=/usr/local/x10           # X10 installation folder
X10_ROOT=$ROOT/x10-$X10_VERSION    # X10 installation folder

# Check X10 installation
echo ============== Checking X10 $X10_VERSION ==============
if [ ! -d $X10_ROOT ]; then
  echo "ERROR: X10 installation folder not found: $X10_ROOT"
  exit 1
else
  export PATH=$X10_ROOT/bin:$PATH
  x10_ver=`x10c++ -version | cut -d' ' -f3`
  if [ $x10_ver != $X10_VERSION ]; then
    echo "ERROR: X10 installation has version $x10_ver; need $X10_VERSION"
    exit 1
  fi
  echo "  using $X10_ROOT/bin/x10c++"
fi

# Compile Glucose
echo ============== Compiling Glucose ==============
cd $ROOT/code/src_others/Glucose/core
#make clean
make rs
cp glucose_static $ROOT/code/pySatX10/

# Compile Satelite
echo ============== Compiling SatELite ==============
cd $ROOT/code/src_others/SatELite_2005_nomap
#./clean.sh
./build.sh
cp SatELite_2005_nomap $ROOT/code/pySatX10/

# Compile SatX10
echo ============== Compiling GlucoseX10 ==============
cd $ROOT/code
#make clean-all
make
cp SatX10 $ROOT/code/pySatX10/
cp $X10_ROOT/stdlib/lib/libx10.so $ROOT/code/pySatX10/
cp $X10_ROOT/lib/libx10rt_sockets.so $ROOT/code/pySatX10/
cp $X10_ROOT/lib/libgc.so.1 $ROOT/code/pySatX10/

echo ============== Creating 'binary' folder ==============
cd $ROOT
rm -fr binary
mkdir binary
cd binary
mkdir WORKING-DIR
cp $ROOT/code/pySatX10/* .

