#!/bin/sh

ROOT=$PWD

set -x   # echo commands as they are executed

# Clean Glucose
cd $ROOT/code/src_others/Glucose/core
make clean

# Clean Satelite
cd $ROOT/code/src_others/SatELite_2005_nomap
./clean.sh

# Clean SatX10
cd $ROOT/code
make clean-all
cd pySatX10
rm -f glucose_static
rm -f SatELite_2005_nomap
rm -f SatX10
rm -f libx10.so libx10rt_sockets.so libgc.so.1

# Remove 'binary' folder
cd $ROOT
rm -fr binary

set +x

