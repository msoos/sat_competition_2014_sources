SATX10 based on 2-core solvers

Requires X10 language installed!
- Version 2.4.0
- Precomiled library available here: http://x10-lang.org/software/download-x10/latest-release.html
- X10 library 2.4.0 is sufficient; if you really need to install from source, downloads and instructions are available here:
http://sourceforge.net/projects/x10/files/x10/2.4.0/x10-2.4.0-src.tar.bz2/download
 Complete instructions are here: http://x10-lang.org/x10-development/building-x10-from-source.html
 
2-Core Solver:
- This version of SatX10 only uses Glucose and Circuit Minisat.
- If parallel execution fails, it falls back to Glucose on a single core


USAGE EXAMPLES:

Very simple:
  python runSatX10.py --x10ppconfig=ppconfigs/example.ppconfig --x10nplaces=2 example-easy.cnf

No solution printing:
  python runSatX10.py --x10ppconfig=ppconfigs/Glucose21.ppconfig --x10nplaces=4 --nosolution example-sat.cnf

Use (variable number preserving) SatELite to preprocess before calling SatX10:
  python runSatX10.py --x10ppconfig=ppconfigs/Glucose21.ppconfig --x10nplaces=4 --x10usepre example-sat.cnf

