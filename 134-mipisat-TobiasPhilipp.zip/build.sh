cd code
make rs
cd ..
mkdir binary
cp code/minisat binary/mipisat

