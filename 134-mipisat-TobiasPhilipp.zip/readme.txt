MiPiSAT - Probing as Inprocessing in MiniSAT
Version 1.0

Author
Tobias Philipp
Knowledge Representation and Reasoning Group
Technische Universität Dresden, Germany
<tobias.philipp@tu-dresden.de>


MiPiSAT is a modification of MiniSAT 2.2.
It can be used as the usual.

Run ./build.sh
You find the executable in binary/mipisat


