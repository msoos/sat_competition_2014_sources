stamp=f.cnf
i="0"
j="0"

while [ $i -lt 100 ]; do
 
 # read -p "Press [ENTER] to generate next CNF"

 # Execute runner.sh
 # If error:
 # ./cnfdd f.cnf bug.cnf ./runner.sh

 ./cnfuzz > $stamp
 #ulimit -t 10
 
 ./minisat_debug -rnd-freq=1.0 f.cnf > satline
 status=$?
 #echo !!!!!!!!!!!!!!!!!!!!!!!!!!! $status !!!!!!!!!!!!!!!!!!!!1

 

 if [ $status -ne 20 ]; then
   #echo Formula is satisfiable
   # continue 
  python /home/tp/sat2013/check-solver-solution.py
  tail satline
 ficase 
done