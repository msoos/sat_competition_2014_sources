==================
==== SWDiA5BY ====
==================

Chanseok Oh (chanseok@cs.nyu.edu)
New York University
NY, USA


HOW TO BUILD
------------
To build, `cd' into where `build.sh' is located.

   $ ./build.sh

This will generate an executable `SWDiA5BY_static' and place it
inside `./binary'.



EXECUTION
---------

    $ cd binary
    $ ./SWDiA5BY_static <CNF>

The usage is exactly same as that of the original Glucose 2.3.
