#!/bin/sh
# Norbert Manthey, 2014
#
# script to build the SAT solver Riss
#

# setup binary directory
rm -rf binary
mkdir -p binary

cd code;
# build Riss with DRAT support
make clean
make rissRS ARGS="-DDRATPROOF -DTOOLVERSION=427"
cp riss ../binary/rissDRAT

# copy the call scripts
cp scripts/*.sh ../binary/

# return to calling directory
cd ..
