mkdir binary
cd ./code
chmod 755 configure
./configure
make
cd ..
cp ./code/cryptominisat ./binary/ntusat
chmod 755 ./binary/ntusat 
