name:   ntusat
version: 1.0
author: Hsiao-Lun, Wang and Jie Hong, Roland Jiang

compile:

sh build.sh


execute:

./ntusat   xxx.cnf