#!/bin/bash

mkdir binary
cd code/core/
make 
cp pglucose ../../binary/pglucose

 
