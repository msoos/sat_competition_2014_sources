#include "core/SharedBase.h"
#include <iostream>

using namespace Glucose;

SharedBase::SharedBase(int threads_) : 
  threads (threads_){
  Lists = new ListLearn[threads_];
  for(int i=0; i<threads_; i++ ) {
    Lists[i].head = 0;
    Lists[i].tail = 0;
    Lists[i].sidx = new SelfishIdx[threads];
    Lists[i].rmfrqc = 0;
    Lists[i].nba = 0;
    Lists[i].nbs = 0;
    Lists[i].nbptr=0;
  }
}

SharedBase::~SharedBase()  {

  for(int i=0; i<threads; i++){
 
    elearn *cur = Lists[i].head;

    while(cur != 0){
      elearn *nxt= cur->next;
      delete cur; 
      cur=nxt;
    }
    
    delete[] Lists[i].sidx;
  }

  delete[] Lists;
}

// List Primitive 
void SharedBase::append(elearn *e, ListLearn *l)
{ 
  if (l->tail) 
    l->tail->next = e;
  else 
    l->head = e;
  l->tail = e;
}

void SharedBase::clean(ListLearn *l) {
  
  elearn *cur = l->head;
 
  if (!cur) return;

  while(cur != 0 && cur->cref == 0){
    elearn *nxt= cur->next;
    delete cur;
    l->nbs++;
    cur=nxt;
  }

  if(!cur)
    l->tail=0;

  l->head = cur;
}


void SharedBase::push(vec<Lit>& learn, int nblev, pSolver *solver) {

  ListLearn &l = Lists[solver->id];
  elearn *e = new elearn(learn,nblev,threads-2);
  append(e, &l);
  l.nba++;  

  /* the reduce of the DB */
  if(solver->conflicts >=
     (uint64_t)solver->curRestart* 
     solver->nbclausesbeforereduce)
    clean(&Lists[solver->id]);
}


void SharedBase::update(pSolver * solver)
{
   
  int id = solver->id;
  elearn* j,*nxt;

  for (int i=1; i<threads; i++) {
       
    if (id == i)
       continue;
      
    ListLearn& l = Lists[i];
 
    if (!l.sidx[id].ptr) 
      j= l.sidx[id].ptr = l.head;
    else {
      j = l.sidx[id].ptr->next;
      if(j)
	__sync_sub_and_fetch(&(l.sidx[id].ptr->cref),1);
    }
    
    while(j) { 
      vec<Lit>& learn = j->learn;
      
      if (learn.size() == 1){
	if (solver->value(learn[0]) == l_Undef)
	  solver->uncheckedEnqueue(learn[0]);
      }
      else {
	CRef cr = solver->ca.alloc(learn, true);
	solver->ca[cr].setLBD(j->nblevels); 
	solver->learnts.push(cr);
	solver->attachClause(cr);
	solver->claBumpActivity(solver->ca[cr]);	
      } 
      solver->varDecayActivity();
      solver->claDecayActivity();
      
      l.sidx[id].ptr = j;
      nxt=j->next;
      
      if(nxt) 
	__sync_sub_and_fetch(&(j->cref),1);
      
      j=nxt;     
      
   }	
 } 
}
