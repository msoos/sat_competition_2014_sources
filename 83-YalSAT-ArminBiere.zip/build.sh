#!/bin/sh
cd code
./configure.sh -O
make yalsat
cd ..
mkdir binary
cp code/yalsat binary
