#if defined(__linux__)

#include <cstdlib>
#include <fstream>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>

#elif defined(_MSC_VER) || defined(__MINGW32__)

#include <time.h>

#endif

#include "System.h"

using namespace std;

System::System()
{
}

double System::get_cpu_time()
{
#if defined(__linux__)

	struct rusage ru;
	getrusage(RUSAGE_SELF, &ru);
	return static_cast<double>(ru.ru_utime.tv_sec) + static_cast<double>(ru.ru_utime.tv_usec) / 1e6;

#elif defined(_MSC_VER) || defined(__MINGW32__)

	return static_cast<double>(clock());

#endif
}

double System::get_wall_time()
{
#if defined(__linux__)

	struct timeval tv;
	gettimeofday(&tv, NULL);
	return static_cast<double>(tv.tv_sec) + static_cast<double>(tv.tv_usec)/1e6;

#elif defined(_MSC_VER) || defined(__MINGW32__)

	return (double)clock();

#endif
}

double System::get_memory_usage()
{
#if defined(__linux__)

	ifstream in("/proc/self/statm", ios_base::in);

	int VmSize_index = 0;
	int size = 0;

	for (int i = 0; i <= VmSize_index; i++)
	{
		in >> size;
	}

	in.close();

	return (double) size * getpagesize() / (1024 * 1024);

#endif
}

double System::get_max_memory_usage()
{
#if defined(__linux__)

	ifstream in("/proc/self/status", ios_base::in);

	const char* VmPeak_Key = "VmPeak:";
	const int Buffer_Size = 100;
	char line_buffer[Buffer_Size];
	int peak_kb = 0;

	int i = 0;
	bool flag = true;

	while (!in.eof())
	{
		in.getline(line_buffer, Buffer_Size);
		i = 0;
		flag = true;
		while (VmPeak_Key[i] != '\0')
		{
			if (line_buffer[i] != VmPeak_Key[i])
			{
				flag = false;
				break;
			}
			i++;
		}
		if (flag)
		{
			peak_kb = atoi(&line_buffer[i]);
			break;
		}
	}

	in.close();

	return (double) peak_kb / 1024;

#endif
}
