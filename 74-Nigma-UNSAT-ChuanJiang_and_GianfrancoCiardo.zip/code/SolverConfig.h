#ifndef _SOLVERCONFIG_HEADER
#define _SOLVERCONFIG_HEADER

typedef struct SolverConfig
{
	struct Preprocessing
	{
		struct Elimination
		{
			int timeout;
		} elimination;

		struct Probing
		{
			int timeout;
		} probing;
	} preprocessing;

	struct PartialBacktracking
	{
		bool enabled;
		unsigned int ignore_distance;
	} partial_backtracking;

	struct Restart
	{
		bool reuse_trail;
	} restart;

	struct ClauseDeletion
	{
		double delete_factor;
		int first_learnt_upper_bound;
		int increment;
	} clause_deletion;

	struct VarActivity
	{
		double upper_bound;
		double rescale_factor;
		double decay_factor;
	} var_activity;

	struct ClauseActivity
	{
		double upper_bound;
		double rescale_factor;
		double decay_factor;
	} clause_activity;

	struct GarbageCollect
	{
		double garbage_ratio;
	} garbage_collect;

	struct StatusOutput
	{
		bool enabled;
		int first_conflict_upper_bound;
		double conflict_growth_factor;
	} status_output;

	struct AssignmentOutput
	{
		bool enabled;
	} assignment_output;

	struct DRUPOutput
	{
		bool enabled;
		const char* dir;
	} drup_output;

	SolverConfig()
	{
		preprocessing.elimination.timeout=0;
		preprocessing.probing.timeout=0;

		partial_backtracking.enabled=false;
		partial_backtracking.ignore_distance=10;

		restart.reuse_trail=false;

		clause_deletion.delete_factor=0.5;
		clause_deletion.first_learnt_upper_bound=4000;
		clause_deletion.increment=2000;

		var_activity.upper_bound=1e100;
		var_activity.rescale_factor=1e-100;
		var_activity.decay_factor=0.95;

		clause_activity.upper_bound=1e20;
		clause_activity.rescale_factor=1e-20;
		clause_activity.decay_factor=0.999;

		garbage_collect.garbage_ratio=0.2;

		status_output.enabled=false;
		status_output.first_conflict_upper_bound=100;
		status_output.conflict_growth_factor=2.5;

		assignment_output.enabled=false;

		drup_output.enabled=false;
		drup_output.dir="/tmp";
	}
}SolverConfig;

#endif
