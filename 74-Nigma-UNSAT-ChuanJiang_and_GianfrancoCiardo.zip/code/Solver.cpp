#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <set>
#include <algorithm>
#include <cassert>
#include <unistd.h>

#include "System.h"
#include "ClauseDistributor.h"
#include "Solver.h"

using namespace std;

volatile sig_atomic_t Solver::sig_timeout=1;
volatile sig_atomic_t Solver::sig_output_status=0;

const char* Solver::DRUP_FILE="/DRUP";

void Solver::signal_timeout_handler(int signum)
{
	assert(signum==SIGALRM);
	Solver::sig_timeout=1;
}

void Solver::signal_output_status_handler(int signum)
{
	assert(signum==SIGALRM);
	Solver::sig_output_status=1;
}

Solver::Solver(const SolverConfig& config)
	: _config(config), _glue_queue(30), _trail_queue(5000), _heap(VariableOrderLt(_activities)),
	  _dlevel(TOP_DLEVEL), _top_level_var_count(0), _assigned(0), _mark(0),
	  _result(UNKNOWN), _executable(true), _output_interval(1), _output_count(1)
{
	_assignment_stack.push_back(vector<Literal> ());

//	if(_config.drup_output.enabled){
//		char* file=new char[strlen(_config.drup_output.dir)+strlen(DRUP_FILE)+1];
//		strcpy(file, _config.drup_output.dir);
//		strcat(file, DRUP_FILE);
//		drup_out.open(file, ios::out);
//		delete[] file;
//	}
}

Solver::~Solver()
{
}

void Solver::set_variable_size(int var_size)
{
	// The index 0 is reserved
	_values.resize(var_size+1, V_UNASSIGNED);
	_reasons.resize(var_size+1);
	_activities.resize(var_size+1, 0);
	_prev_values.resize(var_size+1, V_FALSE);
	_mark_dlevels.resize(var_size+1, 0);
	_mark=0;

	_binary_watchers.set_variable_size(var_size);
	_watchers.set_variable_size(var_size);

	// The index 0 is reserved
	_eliminated.resize(var_size + 1, false);
	_seen.resize(var_size + 1, false);

	_heap.set_variable_size(var_size);
}

//
// Sort literals
// Remove duplicate literals and false literals
// Return FALSE if the clause is satisfied
//
bool Solver::prepare_clause(vector<Literal>& literals)
{
	assert(_dlevel==TOP_DLEVEL);

	std::sort(literals.begin(), literals.end());

	Literal last(Literal::UNDEF);
	size_t i, j;
	for (i=0, j=0; i<literals.size(); i++){
		if (literals[i]!=last){
			if (is_true(literals[i]) || literals[i]==-last){
				return false;
			}
			else if(!is_false(literals[i])){
				last=literals[j++]=literals[i];
			}
		}
	}
	literals.resize(j);

	return true;
}

void Solver::attach_clause(ClausePtr clause_ptr)
{
	Clause& clause = ClausePool::get(clause_ptr);
	assert(clause.size()>=2);

	if(clause.size()==2){
		_binary_watchers[clause[0]].push_back({clause_ptr, clause[1]});
		_binary_watchers[clause[1]].push_back({clause_ptr, clause[0]});
	}
	else{
		_watchers[clause[0]].push_back({clause_ptr, clause[1]});
		_watchers[clause[1]].push_back({clause_ptr, clause[0]});
	}

	if(clause.is_learnt()){
		_stat.literal.learnt+=clause.size();
	}
}

void Solver::detach_clause(ClausePtr clause_ptr)
{
	Clause& clause = ClausePool::get(clause_ptr);

	for(int i=0; i<2; i++){
		vector<Watcher>& watchers=((clause.size()==2) ? _binary_watchers : _watchers)[clause[i]];
		for(vector<Watcher>::iterator itr=watchers.begin(); itr!=watchers.end(); itr++){
			if(itr->clause_ptr==clause_ptr){
				*itr=watchers.back();
				break;
			}
		}
		watchers.pop_back();
	}

	if(clause.is_learnt()){
		_stat.clause.deleted_learnt++;

		_stat.literal.learnt-=clause.size();
		_stat.literal.deleted_learnt+=clause.size();
	}
}

ClausePtr Solver::add_clause(vector<int>& literals)
{
	if(!_executable){
		return ClausePool::CLS_NULL;
	}

	assert(_dlevel==TOP_DLEVEL);

	vector<Literal> lits;
	lits.reserve(literals.size());
	for(vector<int>::iterator itr=literals.begin(); itr!=literals.end(); itr++){
		assert(*itr!=0);
		lits.push_back(Literal(abs(*itr), *itr > 0 ? P_POSITIVE : P_NEGATIVE));
	}

	vector<Literal> lits_backup(lits);

	if(!prepare_clause(lits)){
		// The clause is satisfied
		return ClausePool::CLS_NULL;
	}

	if(_config.drup_output.enabled && lits_backup.size()>lits.size()){
		output_drup_clause(lits.begin(), lits.end(), false);
		output_drup_clause(lits_backup.begin(), lits_backup.end(), true);
	}

	if(lits.empty()){
		_executable=false;
		_result=UNSAT;
		return ClausePool::CLS_NULL;
	}
	else if(lits.size()==1){
		set_var_value(lits[0], TOP_DLEVEL);
		if(!deduce()){
			_executable=false;
			_result=UNSAT;
		}
		return ClausePool::CLS_NULL;
	}
	else{
		ClausePtr clause_ptr = ClausePool::create(lits, false);
		_clauses.push_back(clause_ptr);
		attach_clause(clause_ptr);
		return clause_ptr;
	}
}

void Solver::delete_clause(ClausePtr clause_ptr)
{
	if(_config.drup_output.enabled){
		output_drup_clause(clause_ptr, true);
	}

	detach_clause(clause_ptr);
	ClausePool::free(clause_ptr);
}

void Solver::clean_clauses()
{
	// Keep original relative order
	size_t i, j;
	size_t size=_clauses.size();
	for(i=0, j=0; i<size; i++){
		Clause& clause=ClausePool::get(_clauses[i]);
		if(!clause.is_deleted()){
			_clauses[j++]=_clauses[i];
		}
	}
	_clauses.resize(j);
}

//
// Return FALSE if a conflict occurs
//
bool Solver::backward_subsumption(ClausePtr clause_ptr, deque<ClausePtr>& touched)
{
	Clause& clause=ClausePool::get(clause_ptr);
	if(clause.is_deleted()){
		return true;
	}

	assert(clause.is_touched());
	clause.untouch();

	// Find the literal with the minimum occurrence
	Literal min_occur=clause[0];
	size_t occur_size=_occurrences[min_occur].size()+_occurrences[-min_occur].size();
	for(Clause::iterator itr=clause.begin()+1; itr!=clause.end(); itr++){
		if(occur_size>_occurrences[*itr].size()+_occurrences[-*itr].size()){
			min_occur=*itr;
			occur_size=_occurrences[min_occur].size()+_occurrences[-min_occur].size();
		}
	}

	Literal literal(Literal::UNDEF);
	size_t i, j;

	vector<ClausePtr>& occurs1=_occurrences[min_occur];
	for(i=0, j=0; i<occurs1.size(); i++){
		if(occurs1[i]==clause_ptr){
			occurs1[j++]=occurs1[i];
			continue;
		}

		Clause& clause1=ClausePool::get(occurs1[i]);
		if(clause1.is_deleted()){
			continue;
		}

		switch(check_subsumption(clause, clause1, literal)){
		case Subsumed:
			if(_config.drup_output.enabled){
				output_drup_clause(occurs1[i], true);
			}

			// Do not update occurrences
			ClausePool::free(occurs1[i]);

			_stat.preprocessing.elimination.subsumed_clauses++;

			break;
		case Strengthened:
			assert(literal.var()!=min_occur.var());

			if(_config.drup_output.enabled){
				vector<Literal> literals;
				for(Clause::iterator itr=clause1.begin(); itr!=clause1.end(); itr++){
					if(*itr!=literal){
						literals.push_back(*itr);
					}
				}

				output_drup_clause(literals.begin(), literals.end(), false);

				literals.push_back(literal);
				output_drup_clause(literals.begin(), literals.end(), true);
			}

			if(!strengthen(occurs1[i], literal, true)){
				// Unsatisfiable
				return false;
			}

			if(!clause1.is_touched()){
				clause1.touch();
				touched.push_back(occurs1[i]);
			}
			occurs1[j++]=occurs1[i];

			_stat.preprocessing.elimination.strengthened_clauses++;

			break;
		default:
			occurs1[j++]=occurs1[i];
			break;
		}
	}
	occurs1.resize(j);

	vector<ClausePtr>& occurs2=_occurrences[-min_occur];
	for(i=0, j=0; i<occurs2.size(); i++){
		Clause& clause2=ClausePool::get(occurs2[i]);
		if(clause2.is_deleted()){
			continue;
		}

		switch(check_subsumption(clause, clause2, literal)){
		// Impossible to be Subsumed
		case Strengthened:
			assert(literal==-min_occur);

			if(_config.drup_output.enabled){
				vector<Literal> literals;
				for(Clause::iterator itr=clause2.begin(); itr!=clause2.end(); itr++){
					if(*itr!=literal){
						literals.push_back(*itr);
					}
				}

				output_drup_clause(literals.begin(), literals.end(), false);

				literals.push_back(literal);
				output_drup_clause(literals.begin(), literals.end(), true);
			}

			if(!strengthen(occurs2[i], literal, false)){
				// Unsatisfiable
				return false;
			}

			if(!clause2.is_touched()){
				clause2.touch();
				touched.push_back(occurs2[i]);
			}

			_stat.preprocessing.elimination.strengthened_clauses++;

			break;
		default:
			occurs2[j++]=occurs2[i];
			break;
		}
	}
	occurs2.resize(j);

	return true;
}

//
// Return Subsumed if left subsumes right
// Return Strengthened if left strengthen right by literal
//
Solver::Subsumption Solver::check_subsumption(Clause& left, Clause& right, Literal& literal)
{
	if(left.size()>right.size() || (left.signature() | right.signature())!=right.signature()){
		return None;
	}

	// WARNING: _mark<MAX(unsigned long)/2
	_mark++;

	// Mark all literals in right
	for(Clause::iterator itr=right.begin(); itr!=right.end(); itr++){
		_mark_dlevels[itr->var()]=((_mark<<1) | (itr->phase()==P_POSITIVE ? 0ul : 1ul));
	}

	bool strengthened=false;
	// right is consumed by left if all the literals in left have been marked
	for(Clause::iterator itr=left.begin(); itr!=left.end(); itr++){
		unsigned long temp=((_mark<<1) | (itr->phase()==P_POSITIVE ? 0ul : 1ul));
		if(_mark_dlevels[itr->var()]==temp){
			continue;
		}
		else if(!strengthened && _mark_dlevels[itr->var()]==(temp^1ul)){
			literal=-(*itr);
			strengthened=true;
		}
		else{
			return None;
		}
	}

	return strengthened ? Strengthened : Subsumed;
}

//
// Return FALSE if a conflict occurs
//
bool Solver::strengthen(ClausePtr clause_ptr, Literal literal, bool update_occur)
{
	assert(_dlevel==TOP_DLEVEL);

	Clause& clause=ClausePool::get(clause_ptr);

	if(clause.size()==2){
		// The clause becomes unit after strengthening
		Literal implied_literal=(clause[0]==literal ? clause[1] : clause[0]);
		ClausePool::free(clause_ptr);
		if(is_assigned(implied_literal)){
			if(is_false(implied_literal)){
				// Unsatisfiable
				return false;
			}
		}
		else{
			set_var_value(implied_literal, TOP_DLEVEL);
		}
	}
	else{
		clause.strengthen(literal);

		if(update_occur){
			// Update occurrence
			vector<ClausePtr>& occurs=_occurrences[literal];
			for(vector<ClausePtr>::iterator itr=occurs.begin(); itr!=occurs.end(); itr++){
				if(*itr==clause_ptr){
					*itr=occurs.back();
					occurs.pop_back();
					break;
				}
			}
		}
	}

	return true;
}

void Solver::eliminate_clauses(Literal literal, set<Variable>& elim_candidates)
{
	vector<ClausePtr>& occurs=_occurrences[literal];
	for(vector<ClausePtr>::iterator itr=occurs.begin(); itr!=occurs.end(); itr++){
		Clause& clause=ClausePool::get(*itr);
		if(clause.is_deleted()){
			continue;
		}

		if(_config.drup_output.enabled){
			output_drup_clause(clause.begin(), clause.end(), true);
		}

		for(Clause::iterator sitr=clause.begin(); sitr!=clause.end(); sitr++){
			if(*sitr!=literal){
				// Update occurrence
				vector<ClausePtr>& occurs=_occurrences[*sitr];
				for(vector<ClausePtr>::iterator ssitr=occurs.begin(); ssitr!=occurs.end(); ssitr++){
					if(*ssitr==*itr){
						*ssitr=occurs.back();
						occurs.pop_back();
						break;
					}
				}

				assert(!_eliminated[sitr->var()]);

				elim_candidates.insert(sitr->var());
			}
		}

		ClausePool::free(*itr);
	}

	_occurrences.deallocate(literal);
	_binary_watchers.deallocate(literal);
	_watchers.deallocate(literal);
}

//
// Save and remove eliminated clauses
//
void Solver::save_eliminated_clauses(Variable var, set<Variable>& elim_candidates)
{
	Literal pos_lit(var, P_POSITIVE);
	Literal neg_lit(var, P_NEGATIVE);

	// Save an opportunity to be assigned opposite value
	_eliminated_clauses.push_back(Literal::UNDEF);
	if(_occurrences[pos_lit].size()<_occurrences[neg_lit].size()){
		_eliminated_clauses.push_back(neg_lit);
	}
	else{
		_eliminated_clauses.push_back(pos_lit);
	}

	vector<ClausePtr>& clauses=(_occurrences[pos_lit].size()<_occurrences[neg_lit].size() ? _occurrences[pos_lit] : _occurrences[neg_lit]);
	for(vector<ClausePtr>::iterator itr=clauses.begin(); itr!=clauses.end(); itr++){
		Clause& clause=ClausePool::get(*itr);
		if(clause.is_deleted()){
			continue;
		}

		// Place a delimiter (Literal::UNDEF) before a clause due to loading in reverse order later
		_eliminated_clauses.push_back(Literal::UNDEF);
		size_t first_index=_eliminated_clauses.size();
		size_t var_index=first_index;

		for(Clause::iterator itr=clause.begin(); itr!=clause.end(); itr++){
			assert(!_eliminated[itr->var()]);

			_eliminated_clauses.push_back(*itr);
			if(itr->var()==var){
				var_index=_eliminated_clauses.size()-1;
			}
		}

		// Place the eliminated variable at the first place
		if(var_index!=first_index){
			Literal temp=_eliminated_clauses[first_index];
			_eliminated_clauses[first_index]=_eliminated_clauses[var_index];
			_eliminated_clauses[var_index]=temp;
		}
	}
}

void Solver::load_eliminated_clauses()
{
	// Increase dlevel to store the assignments of eliminated variables
	increase_dlevel();

	// Load eliminated clauses in reverse order
	for(vector<Literal>::reverse_iterator itr=_eliminated_clauses.rbegin(); itr!=_eliminated_clauses.rend(); itr++){
		while(*itr!=Literal::UNDEF){
			if(is_false(*itr)){
				itr++;
			}
			else{
				if(!is_assigned(*itr)){
					set_var_value(*itr, _dlevel);
				}

				while(*(++itr)!=Literal::UNDEF);
			}
		}
	}

	_eliminated_clauses.clear();
}

void Solver::set_var_value(Literal lit, unsigned int dlevel, ClausePtr clause_ptr)
{
	Variable var=lit.var();

	assert(value(var)==V_UNASSIGNED);

	_assignment_stack[dlevel].push_back(lit);
	_assigned++;

	value(var)=lit.implied_value();
	// If the variable is assigned at the top level
	// Do no record its reason
	reason(var)={dlevel, (dlevel!=TOP_DLEVEL ? clause_ptr : ClausePool::CLS_NULL)};

	_implication_queue.push_back(lit);
}

void Solver::propagate(Literal lit)
{
	reason(lit).dlevel<_dlevel ? propagate_amending(lit) : propagate_regular(lit);
}

void Solver::propagate_regular(Literal lit)
{
	_stat.execution.propagate_regular++;

	assert(_conflict_clauses.empty());
	assert(reason(lit).dlevel==_dlevel);

	Literal false_lit=-lit;
	Literal blocker(Literal::UNDEF);

	// Take priority in checking binary clauses
	vector<Watcher>& binary_watchers=_binary_watchers[false_lit];

	for(vector<Watcher>::iterator itr=binary_watchers.begin(); itr!=binary_watchers.end(); itr++){
		blocker=itr->blocker;

		if (is_true(blocker)){
			continue;
		}
		else if(is_false(blocker)){
			_conflict_clauses.push(itr->clause_ptr);
			break;
		}
		else{
			set_var_value(blocker, _dlevel, itr->clause_ptr);
		}
	}

	if(!_conflict_clauses.empty()){
		return;
	}

	vector<Watcher>& watchers = _watchers[false_lit];
	size_t i=0, j=0;
	size_t size=watchers.size();
	bool is_conf_or_unit = true;

	for (i=j=0; i<size; i++){
		is_conf_or_unit = true;
		blocker=watchers[i].blocker;

		// if the blocker is true
		// the clause has already been satisfied
		if (is_true(blocker)){
			watchers[j++] = watchers[i];
			continue;
		}

		ClausePtr clause_ptr = watchers[i].clause_ptr;
		Clause& clause = ClausePool::get(clause_ptr);

		// ensure the current literal is at the second position
		// so that if the clause is implied
		// the implied literal is always at the first position
		if (clause[0] == false_lit){
			clause[0]=clause[1];
			clause[1]=false_lit;
		}

		if (clause[0]!=blocker && is_true(clause[0])){
			watchers[j++] = {clause_ptr, clause[0]};
			continue;
		}

		for (size_t k = 2; k < clause.size(); k++){
			if (!is_false(clause[k])){
				// Found non-false literal
				clause[1]=clause[k];
				clause[k]=false_lit;
				_watchers[clause[1]].push_back({clause_ptr, clause[0]});
				is_conf_or_unit = false;
				break;
			}
//			else if(reason(clause[k]).dlevel==TOP_DLEVEL){
//				clause[k]=clause[clause.size()-1];
//				clause.size()--;
//				k--;
//			}
		}

		if (is_conf_or_unit)
		{
//			watchers[j++] = watchers[i];
			watchers[j++] = {clause_ptr, clause[0]};
			if (is_false(clause[0])){
				// Conflict
				assert(reason(clause[0]).dlevel==_dlevel);
				_conflict_clauses.push(clause_ptr);

				while(++i<watchers.size()){
					watchers[j++] = watchers[i];
				}
				break;
			}
			else{
				// Unit clause
				set_var_value(clause[0], _dlevel, clause_ptr);

				if(clause.is_learnt() && clause.glue()>2){
					unsigned int glue=compute_glue(clause_ptr);
					if(glue<clause.glue()){
						clause.glue()=glue;
					}
				}
			}
		}
	}

	watchers.resize(j);
}

void Solver::propagate_amending(Literal lit)
{
	_stat.execution.propagate_amending++;

	assert(reason(lit).dlevel<_dlevel);

	Literal false_lit=-lit;
	size_t i, j;
	Literal blocker(Literal::UNDEF);

	// Take priority in checking binary clauses
	vector<Watcher>& binary_watchers=_binary_watchers[false_lit];

	for(i = 0; i < binary_watchers.size(); i++){
		blocker=binary_watchers[i].blocker;

		if (is_true(blocker)){
			if(reason(blocker).dlevel>reason(false_lit).dlevel){
				unsigned int back_dlevel=reason(blocker).dlevel-1;
				backtrack(back_dlevel);
				clean_invalid_implication();
				while(!_conflict_clauses.empty()){
					_conflict_clauses.pop();
				}
				set_var_value(blocker, reason(false_lit).dlevel, binary_watchers[i].clause_ptr);
			}
		}
		else if(is_false(blocker)){
			if(reason(blocker).dlevel==reason(false_lit).dlevel){
				unsigned int back_dlevel=reason(blocker).dlevel;
				if(back_dlevel<_dlevel){
					backtrack(back_dlevel);
					clean_invalid_implication();
					while(!_conflict_clauses.empty()){
						_conflict_clauses.pop();
					}
				}
				_conflict_clauses.push(binary_watchers[i].clause_ptr);

				// No need to continue propagating
				// No implication or conflict is possible at lower level
				return;
			}
			else{
				// Why reason(blocker).dlevel>reason(false_lit).dlevel ?
				// Assume reason(blocker).dlevel<reason(false_lit).dlevel
				// 1. If -blocker is in the implication queue, it should be propagated before lit
				// 2. If -blocker is not in the implication queue,
				//    -lit should have been implied at the time -blocker was being propagated

				assert(reason(blocker).dlevel>reason(false_lit).dlevel);

				unsigned int back_dlevel=reason(blocker).dlevel-1;
				backtrack(back_dlevel);
				clean_invalid_implication();
				while(!_conflict_clauses.empty()){
					_conflict_clauses.pop();
				}
				set_var_value(blocker, reason(false_lit).dlevel, binary_watchers[i].clause_ptr);
			}
		}
		else{
			set_var_value(blocker, reason(false_lit).dlevel, binary_watchers[i].clause_ptr);
		}
	}

	vector<Watcher>& watchers = _watchers[false_lit];
	bool is_conf_or_unit = true;

	for (i=0, j=0; i<watchers.size(); i++){
		is_conf_or_unit = true;

		ClausePtr clause_ptr = watchers[i].clause_ptr;
		Clause& clause = ClausePool::get(clause_ptr);

		// ensure the current literal is at the second position
		// so that if the clause is implied
		// the implied literal is always at the first position
		if (clause[0] == false_lit){
//			clause.swap_literal(0, 1);
			clause[0]=clause[1];
			clause[1]=false_lit;
		}

		int swap_lit_index = 1;

		for (size_t k = 2; k < clause.size(); k++){
			if (!is_false(clause[k])){
				// Found non-false literal
				swap_lit_index = k;
				is_conf_or_unit = false;
				break;
			}
			else if (reason(clause[k]).dlevel > reason(clause[swap_lit_index]).dlevel){
				// If all unwatched literals are false
				// Watch the literal with highest decision level
				swap_lit_index = k;
			}
		}

		if (swap_lit_index != 1){
			clause[1]=clause[swap_lit_index];
			clause[swap_lit_index]=false_lit;
			_watchers[clause[1]].push_back({clause_ptr, clause[0]});
		}
		else{
			watchers[j++] = watchers[i];
		}

		if(is_conf_or_unit){
			if (is_false(clause[0])){
				if(reason(clause[0]).dlevel<reason(clause[1]).dlevel){
					// Check if there is any unwatched false literal with higher level than the first literal
					swap_lit_index=0;

					for (size_t k = 2; k < clause.size(); k++){
						if (reason(clause[k]).dlevel > reason(clause[swap_lit_index]).dlevel){
							swap_lit_index = k;
						}
					}

					if(swap_lit_index!=0){
						Literal temp=clause[0];
						clause[0]=clause[swap_lit_index];
						clause[swap_lit_index]=temp;

						// Revise watcher list of both literals
						_watchers[clause[0]].push_back({clause_ptr, clause[1]});

						vector<Watcher>& temp_watchers=_watchers[clause[swap_lit_index]];
						for(size_t i=0; i<temp_watchers.size(); i++){
							if(temp_watchers[i].clause_ptr==clause_ptr){
								temp_watchers[i]=temp_watchers.back();
								temp_watchers.pop_back();
								break;
							}
						}
					}

					assert(reason(clause[0]).dlevel<=reason(clause[1]).dlevel);

					Literal temp=clause[0];
					clause[0]=clause[1];
					clause[1]=temp;
				}

				assert(reason(clause[0]).dlevel>=reason(clause[1]).dlevel);

				if(reason(clause[0]).dlevel==reason(clause[1]).dlevel){
					unsigned int back_dlevel=reason(clause[0]).dlevel;
					if(back_dlevel<_dlevel){
						backtrack(back_dlevel);
						clean_invalid_implication();
						// Clear _conflict_clauses once backtracking occurs
						while(!_conflict_clauses.empty()){
							_conflict_clauses.pop();
						}
					}
					_conflict_clauses.push(clause_ptr);

					assert(_dlevel>=reason(false_lit).dlevel);
					if(_dlevel==reason(false_lit).dlevel){
						// No implication or conflict is possible at lower level
						while(++i<watchers.size()){
							watchers[j++] = watchers[i];
						}
						break;
					}
				}
				else{
					unsigned int back_dlevel=reason(clause[0]).dlevel-1;
					backtrack(back_dlevel);
					clean_invalid_implication();
					// Clear _conflict_clauses once backtracking occurs
					while(!_conflict_clauses.empty()){
						_conflict_clauses.pop();
					}
					set_var_value(clause[0], reason(clause[1]).dlevel, clause_ptr);

					if(clause.is_learnt() && clause.glue()>2){
						unsigned int glue=compute_glue(clause_ptr);
						if(glue<clause.glue()){
							clause.glue()=glue;
						}
					}

					if(lit.var()==clause[0].var()){
						// Current assignment is invalid because the negation is implied
						while(++i<watchers.size()){
							watchers[j++] = watchers[i];
						}
						break;
					}
				}
			}
			else if (is_true(clause[0])){
				if(reason(clause[0]).dlevel>reason(clause[1]).dlevel){
					unsigned int back_dlevel=reason(clause[0]).dlevel-1;
					backtrack(back_dlevel);
					clean_invalid_implication();
					// Clear _conflict_clauses once backtracking occurs
					while(!_conflict_clauses.empty()){
						_conflict_clauses.pop();
					}
					set_var_value(clause[0], reason(clause[1]).dlevel, clause_ptr);

					if(clause.is_learnt() && clause.glue()>2){
						unsigned int glue=compute_glue(clause_ptr);
						if(glue<clause.glue()){
							clause.glue()=glue;
						}
					}
				}
			}
			else{
				set_var_value(clause[0], reason(clause[1]).dlevel, clause_ptr);

				if(clause.is_learnt() && clause.glue()>2){
					unsigned int glue=compute_glue(clause_ptr);
					if(glue<clause.glue()){
						clause.glue()=glue;
					}
				}
			}
		}
	}

	watchers.resize(j);

	// Always give priority to the implication at the lowest level
	std::partial_sort(_implication_queue.begin(), _implication_queue.begin()+1,  _implication_queue.end(), ImplicationLt(_reasons));
}

void Solver::increase_dlevel()
{
//	cout<<endl;
	_dlevel++;
	_assignment_stack.push_back(vector<Literal> ());

#ifdef TRACK
	vector<Literal>& assigns=_assignment_stack[_dlevel-1];
	track_out<<"Lv "<<_dlevel-1<<" ("<<assigns.size()<<"): ";
	if(!assigns.empty()){
		track_out<<assigns.front();
	}
	track_out<<endl;
#endif
}

// Implication is invalid iff its variable is unassigned
void Solver::clean_invalid_implication()
{
	int size=_implication_queue.size();
	for(int i=0; i<size; i++){
		Literal lit=_implication_queue.front();
		if(value(lit.var())!=V_UNASSIGNED){
			_implication_queue.push_back(lit);
		}
		_implication_queue.pop_front();
	}
}

void Solver::execute_periodic_task()
{
	check_restart();
	check_simplify();
	check_shrink();
 	check_garbage_collect();

	// Output status
	if(Solver::sig_output_status==1){
		output_status(cout);

		if(_output_count<_output_interval){
			_output_count++;
		}
		else{
			_output_count=1;
			_output_interval<<=1;
		}

		Solver::sig_output_status=0;
		signal(SIGALRM, Solver::signal_output_status_handler);
		alarm(_output_interval);
	}
}

void Solver::restart()
{
	_stat.execution.restart++;

#ifdef TRACK
//	track_out<<"Restart (Upper bound = "<<_restart_seq.current()<<")"<<endl;
#endif

	if(_assigned==_values.size()-1){
		// All variables have been assigned
		// The result is SAT
		// No need to restart
		return;
	}

	int restart_dlevel=TOP_DLEVEL;

	if(_config.restart.reuse_trail){
		assert(!_heap.empty());

		// Find the unassigned variable with the largest activity
		while(value(_heap.top())!=V_UNASSIGNED){
			_heap.pop();
		}

		double act=activity(_heap.top());

		for(size_t i=1; i<_assignment_stack.size(); i++){
			// Compare the activities of decision variables and unassigned variable
			if(activity(_assignment_stack[i][0].var())<act){
				restart_dlevel=i-1;
				break;
			}
		}
	}

	backtrack(restart_dlevel);

	_implication_queue.clear();
}

void Solver::shrink()
{
	_stat.execution.shrink++;

#ifdef TRACK
	track_out<<"Shrink clauses (Upper bound = "<<_stat.clause.learnt_upper_bound<<")"<<endl;
#endif

	// Place important clauses ahead of unimportant clauses
	std::sort(_learnt_clauses.begin(), _learnt_clauses.end(), ClauseOrderLt());

	size_t size=_learnt_clauses.size();
	size_t deleted = size * _config.clause_deletion.delete_factor;
	size_t i, j;

	// Keep binary clauses and 2-glue clauses
	for(i=deleted, j=deleted; i<size; i++){
		Clause& clause = ClausePool::get(_learnt_clauses[i]);
		if(clause.glue()==2 || clause.size()==2){
			_learnt_clauses[j++] = _learnt_clauses[i];
		}
		else{
			break;
		}
	}

	for(; i<size; i++){
		Clause& clause = ClausePool::get(_learnt_clauses[i]);
		if (!is_locked(clause, _learnt_clauses[i])){
			delete_clause(_learnt_clauses[i]);
		}
		else{
			_learnt_clauses[j++] = _learnt_clauses[i];
		}
	}

	_learnt_clauses.resize(j);
}

void Solver::simplify()
{
	_stat.execution.simplify++;

	assert(_dlevel==TOP_DLEVEL);
	assert(_assigned>_top_level_var_count);

	size_t i, j;

	for (i = j = 0; i < _clauses.size(); i++){
		if (is_satisfied(_clauses[i])){
			delete_clause(_clauses[i]);
		}
		else{
			_clauses[j++] = _clauses[i];
		}
	}
	_clauses.resize(j);

	for (i = j = 0; i < _learnt_clauses.size(); i++){
		if (is_satisfied(_learnt_clauses[i])){
			delete_clause(_learnt_clauses[i]);
		}
		else{
			_learnt_clauses[j++] = _learnt_clauses[i];
		}
	}
	_learnt_clauses.resize(j);

	vector<Literal>& assignments=_assignment_stack[TOP_DLEVEL];
	for(size_t i=_top_level_var_count; i<assignments.size(); i++){
		Literal true_lit(assignments[i]);
		_binary_watchers.deallocate(true_lit);
		_watchers.deallocate(true_lit);

		Literal false_lit(-true_lit);
		_binary_watchers.deallocate(false_lit);
		_watchers.deallocate(false_lit);
	}

	_top_level_var_count = _assigned;
}

void Solver::increase_variable_activity(Variable var)
{
	if ((activity(var) += _stat.activity.var_growth) > _config.var_activity.upper_bound){
		// Rescale
		for (Variable i=1; i<_values.size(); i++){
			activity(i) *= _config.var_activity.rescale_factor;
		}
		_stat.activity.var_growth *= _config.var_activity.rescale_factor;
	}

	_heap.increase(var);
}

void Solver::increase_clause_activity(ClausePtr clause_ptr)
{
	increase_clause_activity(ClausePool::get(clause_ptr));
}

void Solver::increase_clause_activity(Clause& clause)
{
	if (clause.is_learnt()){
		if ((clause.activity() += _stat.activity.clause_growth) > _config.clause_activity.upper_bound){
			// Rescale
			for (vector<ClausePtr>::iterator itr = _learnt_clauses.begin(); itr
					!= _learnt_clauses.end(); itr++){
				ClausePool::get(*itr).activity() *= _config.clause_activity.rescale_factor;
			}
			_stat.activity.clause_growth
					*= _config.clause_activity.rescale_factor;
		}
	}
}

void Solver::decay_var_activity()
{
	_stat.activity.var_growth /= _config.var_activity.decay_factor;
}

void Solver::decay_clause_activity()
{
	_stat.activity.clause_growth /= _config.clause_activity.decay_factor;
}

void Solver::garbage_collect()
{
	_stat.execution.garbage_collect++;

	assert(_dlevel==TOP_DLEVEL);

	ClausePool::reallocate(_clauses, _learnt_clauses);

	rebuild_watchers();
}

unsigned int Solver::compute_glue(ClausePtr clause_ptr)
{
	Clause& clause=ClausePool::get(clause_ptr);
	unsigned int glue=0;

	_mark++;
	for(Clause::iterator itr=clause.begin(); itr!=clause.end(); itr++){
		// Exclude the literals at top level
		if(reason(*itr).dlevel!=TOP_DLEVEL && _mark_dlevels[reason(*itr).dlevel]!=_mark){
			_mark_dlevels[reason(*itr).dlevel]=_mark;
			glue++;
		}
	}

	return glue;
}

void Solver::rebuild_occurrences()
{
	_occurrences.clear();

	for(vector<ClausePtr>::iterator itr=_clauses.begin(); itr!=_clauses.end(); itr++){
		Clause& clause=ClausePool::get(*itr);
		assert(!clause.is_deleted());
		for(Clause::iterator sitr=clause.begin(); sitr!=clause.end(); sitr++){
			_occurrences[*sitr].push_back(*itr);
		}
	}
}

void Solver::rebuild_watchers()
{
	_binary_watchers.clear();
	_watchers.clear();
	_stat.literal.learnt=0;

	for (vector<ClausePtr>::iterator itr = _clauses.begin(); itr
			!= _clauses.end(); itr++){
		attach_clause(*itr);
	}
	for (vector<ClausePtr>::iterator itr = _learnt_clauses.begin(); itr
			!= _learnt_clauses.end(); itr++){
		attach_clause(*itr);
	}
}

//
// Probe for failed literals
// Return FALSE if a conflict occurs, i.e., the formula is unsatisfiable
//
bool Solver::probe()
{
	assert(_dlevel==TOP_DLEVEL);

	if(_config.preprocessing.probing.timeout==0){
		return true;
	}

	Solver::sig_timeout=0;

	signal(SIGALRM, Solver::signal_timeout_handler);
	alarm(_config.preprocessing.probing.timeout);

	double start_time=System::get_cpu_time();

	check_simplify();

	unsigned int count=_top_level_var_count;
//	vector<Literal> probing[2];
	vector<Literal> learnt_clause;
	size_t var_size=_values.size()-1;
//	vector<bool> visited(2*(var_size+1), false);

	for(Variable var=1; var<=var_size && Solver::sig_timeout==0; var++){
		if(value(var)!=V_UNASSIGNED){
			continue;
		}

		Literal lits[2]={Literal(var, P_POSITIVE), Literal(var, P_NEGATIVE)};
		bool failed_lit=false;

		for(int i=0; i<2; i++){
//			if(visited[lits[i].toInt()]){
//				continue;
//			}

			increase_dlevel();
			set_var_value(lits[i], _dlevel, ClausePool::CLS_NULL);

			if(deduce()){
				// Include lits[i]
				vector<Literal>& assigns=_assignment_stack[_dlevel];

//				for(vector<Literal>::iterator itr=assigns.begin(); itr!=assigns.end(); itr++){
//					visited[itr->toInt()]=true;
//				}

//				probing[i].assign(assigns.begin(), assigns.end());

				backtrack(TOP_DLEVEL);
			}
			else{
				// Failed literal
//				analyze_conflict_firstUIP(_conflict_clauses.front(), learnt_clause);
//				analyze_conflict_first_dlevel(_conflict_clauses.front(), learnt_clause);
				_conflict_clauses.pop();

//				assert(learnt_clause.size()==1);
//				assert(learnt_clause.back()==-lits[i]);

				backtrack(TOP_DLEVEL);

				if(_config.drup_output.enabled){
					learnt_clause.push_back(-lits[i]);
					output_drup_clause(learnt_clause.begin(), learnt_clause.end(), false);
					learnt_clause.clear();
				}

//				for(vector<Literal>::iterator itr=learnt_clause.begin(); itr!=learnt_clause.end(); itr++){
//					set_var_value(*itr, TOP_DLEVEL, ClausePool::CLS_NULL);
//				}

//				set_var_value(learnt_clause[0], TOP_DLEVEL, ClausePool::CLS_NULL);
				set_var_value(-lits[i], TOP_DLEVEL, ClausePool::CLS_NULL);

				if(deduce()){
					failed_lit=true;
					break;
				}
				else{
					return false;
				}
			}
		}

		// Necessary assingment extraction is incompatible with DRAT-trim
		// Comment for further investigation
//		if(!failed_lit && probing[0].size()>1 && probing[1].size()>1){
//			// Extract necessary assignments
//			std::sort(probing[0].begin()+1, probing[0].end());
//			std::sort(probing[1].begin()+1, probing[1].end());
//
//			assert(probing[0][0]==lits[0]);
//			vector<Literal>::iterator pos_itr=probing[0].begin()+1;
//			vector<Literal>::iterator pos_end=probing[0].end();
//
//			assert(probing[1][0]==lits[1]);
//			vector<Literal>::iterator neg_itr=probing[1].begin()+1;
//			vector<Literal>::iterator neg_end=probing[1].end();
//
//			while(pos_itr!=pos_end && neg_itr!=neg_end){
//				if(*pos_itr==*neg_itr){
//					if(_config.drup_output.enabled){
//						output_drup_clause(pos_itr, pos_itr+1, false);
//					}
//
//					set_var_value(*pos_itr, TOP_DLEVEL, ClausePool::CLS_NULL);
//					pos_itr++;
//					neg_itr++;
//				}
//				else if(*pos_itr<*neg_itr){
//					pos_itr++;
//				}
//				else{
//					neg_itr++;
//				}
//			}
//
//			if(!deduce()){
//				return false;
//			}
//		}
//
//		probing[0].clear();
//		probing[1].clear();
	}

	if(Solver::sig_timeout==0){
		// Cancel the alarm
		alarm(0);
	}

	_stat.preprocessing.probing.assigned_variables=_assigned-count;

	double end_time=System::get_cpu_time();
	cout<<"c Probing Time: "<<end_time-start_time<<" s"<<(Solver::sig_timeout==1 ? " (Timeout)" : "")<<endl;

	if(_config.status_output.enabled){
		cout<<"c Assigned Variables: "<<_stat.preprocessing.probing.assigned_variables<<endl;
	}

	return true;
}

//
// Do not invoke propagation in the phase of elimination
// So do not update watchers
// Return FALSE if a conflict occurs, i.e., the formula is unsatisfiable
//
bool Solver::eliminate()
{
	assert(_dlevel==TOP_DLEVEL);

	if(_config.preprocessing.elimination.timeout==0){
		return true;
	}

	check_simplify();

	if(_clauses.size()>5000000){
		cout<<"c The number of clauses ("<<_clauses.size()<<") exceeds 5000000. Skip elimination"<<endl;
		return true;
	}

	Solver::sig_timeout=0;

	signal(SIGALRM, Solver::signal_timeout_handler);
	alarm(_config.preprocessing.elimination.timeout);

	double start_time=System::get_cpu_time();

	_occurrences.set_variable_size(_values.size()-1);
	rebuild_occurrences();

	set<Variable> elim_candidates;
	size_t var_size=_values.size()-1;
	for(Variable i=1; i<=var_size; i++){
		if(value(i)==V_UNASSIGNED){
			// Pure literal
			if(_occurrences[Literal(i, P_POSITIVE)].empty()){
				Literal implied_literal(i, P_NEGATIVE);
				set_var_value(implied_literal, TOP_DLEVEL);
				_occurrences.deallocate(implied_literal);
				_binary_watchers.deallocate(implied_literal);
				_watchers.deallocate(implied_literal);
			}
			else if(_occurrences[Literal(i, P_NEGATIVE)].empty()){
				Literal implied_literal(i, P_POSITIVE);
				set_var_value(implied_literal, TOP_DLEVEL);
				_occurrences.deallocate(implied_literal);
				_binary_watchers.deallocate(implied_literal);
				_watchers.deallocate(implied_literal);
			}
			else{
				elim_candidates.insert(i);
			}
		}
		else{
			// Remove false literal
			Literal false_literal(i, (value(i)==V_TRUE ? P_NEGATIVE : P_POSITIVE));
			vector<ClausePtr>& occurs=_occurrences[false_literal];
			for(vector<ClausePtr>::iterator itr=occurs.begin(); itr!=occurs.end(); itr++){
				Clause& clause=ClausePool::get(*itr);
				assert(clause.size()>2);

				if(_config.drup_output.enabled){
					vector<Literal> literals;
					for(Clause::iterator itr=clause.begin(); itr!=clause.end(); itr++){
						if(*itr!=false_literal){
							literals.push_back(*itr);
						}
					}

					output_drup_clause(literals.begin(), literals.end(), false);

					literals.push_back(false_literal);
					output_drup_clause(literals.begin(), literals.end(), true);
				}

				clause.strengthen(false_literal);
			}
			_occurrences.deallocate(false_literal);
			_binary_watchers.deallocate(false_literal);
			_watchers.deallocate(false_literal);
		}
	}

//	vector<ClausePtr> touched(_clauses);
	deque<ClausePtr> touched(_clauses.begin(), _clauses.end());

	ClauseDistributor distributor(_values.size()-1);

//	int count=0;

	while(Solver::sig_timeout==0 && (!touched.empty() || !elim_candidates.empty())){
//		cout<<"********************* Stage "<<count++<<" *********************"<<endl;
//		cout<<"Eliminated Candidates: "<<elim_candidates.size()<<endl;
//		cout<<"Strengthen Candidates: "<<touched.size()<<endl;

		// Backward subsumption
		while(Solver::sig_timeout==0 && !touched.empty()){
			ClausePtr clause_ptr=touched.front();
			touched.pop_front();
			if(!backward_subsumption(clause_ptr, touched)){
				// Unsatisfiable
				return false;
			}
		}

		set<Variable> temp;
		temp.swap(elim_candidates);

		// Variable elimination
		for(set<Variable>::iterator itr=temp.begin(); itr!=temp.end() && Solver::sig_timeout==0; itr++){
			Literal pos_lit(*itr, P_POSITIVE);
			Literal neg_lit(*itr, P_NEGATIVE);
			if(!_eliminated[*itr] && value(*itr)==V_UNASSIGNED
					&& distributor.resolve(*itr, _occurrences[pos_lit], _occurrences[neg_lit])){
				vector<Literal> literals;
				for(ClauseDistributor::iterator sitr=distributor.begin(), sub_end=distributor.end(); sitr!=sub_end; ++sitr){
					sitr.get(literals);
					if(prepare_clause(literals)){
						if(literals.empty()){
							// Unsatisfiable
							return false;
						}
						else if(literals.size()==1){
							set_var_value(literals[0], TOP_DLEVEL);
						}
						else{
							ClausePtr clause_ptr=ClausePool::create(literals, false);
							_clauses.push_back(clause_ptr);
							touched.push_back(clause_ptr);

							// Update occurrence
							for(vector<Literal>::iterator ssitr=literals.begin(); ssitr!=literals.end(); ssitr++){
								_occurrences[*ssitr].push_back(clause_ptr);
							}
						}

						if(_config.drup_output.enabled){
							output_drup_clause(literals.begin(), literals.end(), false);
						}
					}
				}

				save_eliminated_clauses(*itr, elim_candidates);
				eliminate_clauses(pos_lit, elim_candidates);
				eliminate_clauses(neg_lit, elim_candidates);

				_eliminated[*itr]=true;
				_stat.preprocessing.elimination.eliminated_variables++;
			}
		}

		clean_clauses();

		if (check_garbage_collect()){
			rebuild_occurrences();

			// Rebuild touched
			touched.clear();
			for(vector<ClausePtr>::iterator itr=_clauses.begin(); itr!=_clauses.end(); itr++){
				if(ClausePool::get(*itr).is_touched()){
					touched.push_back(*itr);
				}
			}
		}

//		cout<<"Top Level Assignment: "<<_assignment_stack[0].size()<<endl;
//		cout<<"Subsumed Clauses: "<<_stat.preprocessing.subsumed_clauses<<endl;
//		cout<<"Strengthened Clauses: "<<_stat.preprocessing.strengthened_clauses<<endl;
//		cout<<"Eliminated Variables: "<<_stat.preprocessing.eliminated_variables<<endl;
	}

	if(Solver::sig_timeout==0){
		// Cancel the alarm
		alarm(0);
	}

	double end_time=System::get_cpu_time();
	cout<<"c Elimination Time: "<<end_time-start_time<<" s"<<(Solver::sig_timeout==1 ? " (Timeout)" : "")<<endl;

	if(_config.status_output.enabled){
		cout<<"c Subsumed Clauses: "<<_stat.preprocessing.elimination.subsumed_clauses<<endl;
		cout<<"c Strengthened Clauses: "<<_stat.preprocessing.elimination.strengthened_clauses<<endl;
		cout<<"c Eliminated Variables: "<<_stat.preprocessing.elimination.eliminated_variables<<endl;
	}

	_occurrences.deallocate_all();

	rebuild_watchers();

	return deduce();
}

//
// Return FALSE if a conflict occurs, i.e., the formula is unsatisfiable
//
bool Solver::preprocess()
{
	assert(_dlevel==TOP_DLEVEL);

	if(!probe()){
		return false;
	}

	if(!eliminate()){
		return false;
	}

	if(_config.preprocessing.probing.timeout>0 || _config.preprocessing.elimination.timeout>0){
		output_problem_stat();
	}

	return true;
}

bool Solver::decide()
{
	_stat.execution.decide++;

	bool result = true;

	// VSIDS
	int var_id=0;
	do{
		if (_heap.empty()){
			result = false;
			break;
		}
		else{
			var_id = _heap.top();
			_heap.pop();
		}
	} while (_eliminated[var_id] || value(var_id)!=V_UNASSIGNED);

	if (result){
		set_var_value(Literal(var_id, prev_value(var_id)==V_TRUE ? P_POSITIVE : P_NEGATIVE), _dlevel);
	}

	return result;
}


//
// Return TRUE if there is no conflict
// Return FALSE if a conflict occurs
//
bool Solver::deduce()
{
	_stat.execution.deduce++;

	bool result = true;
	int cur_dlevel=_dlevel;
	bool amended=(!_implication_queue.empty() && reason(_implication_queue.front()).dlevel<_dlevel);

	while (!_implication_queue.empty()){
		// Must create a copy of the first assignment in the implication queue
		Literal lit = _implication_queue.front();
		_implication_queue.pop_front();

		assert(reason(lit).dlevel<=_dlevel);

		if(_conflict_clauses.empty() || reason(lit).dlevel<_dlevel){
			propagate(lit);
		}
	}

	_stat.backtrack_distance.actual_distance+=(cur_dlevel-_dlevel);

	if(!_conflict_clauses.empty()){
		result=false;
		if(amended){
			_stat.backtrack_distance.trigger_conflict++;
		}
	}

	return result;
}

//
// Return TRUE if the conflict has been resolved successfully
// Return FALSE if the conflict cannot be resolved, i.e., the formula is unsatisfiable
//
bool Solver::resolve_conflict()
{
	_stat.execution.resolve_conflict++;

#ifdef TRACK
	vector<Literal>& assigns=_assignment_stack.back();
	track_out<<"Conflict @ Lv "<<_dlevel<<" ("<<assigns.size()<<"): ";
	track_out<<assigns.front();
	track_out<<endl;
#endif

	assert(!_conflict_clauses.empty());

	bool result=true;

	if(_dlevel<=TOP_DLEVEL){
		if(_config.drup_output.enabled){
			output_drup_clause(&Literal::UNDEF, &Literal::UNDEF, false);
		}

		result=false;
	}
	else{
		vector<Literal> learnt_clause;
		ClausePtr conflict_clause_ptr=_conflict_clauses.front();
		_conflict_clauses.pop();

		while(!_conflict_clauses.empty()){
			_conflict_clauses.pop();
		}

		analyze_conflict_firstUIP(conflict_clause_ptr, learnt_clause);

		unsigned int assert_dlevel = TOP_DLEVEL;
		ClausePtr antecedent_clause_ptr = ClausePool::CLS_NULL;

		if (learnt_clause.size() >= 2){
			// Learnt clause has at least two literals
			int swap_lit_index = 1;

			for (size_t i = 2; i < learnt_clause.size(); i++){
				if (reason(learnt_clause[i]).dlevel > reason(learnt_clause[swap_lit_index]).dlevel){
					swap_lit_index = i;
				}
			}

			if(swap_lit_index!=1){
				Literal temp = learnt_clause[1];
				learnt_clause[1] = learnt_clause[swap_lit_index];
				learnt_clause[swap_lit_index] = temp;
			}

			assert_dlevel = reason(learnt_clause[1]).dlevel;

			antecedent_clause_ptr = ClausePool::create(learnt_clause, true);
			_learnt_clauses.push_back(antecedent_clause_ptr);
			attach_clause(antecedent_clause_ptr);
			increase_clause_activity(antecedent_clause_ptr);

			unsigned int glue=compute_glue(antecedent_clause_ptr);
			ClausePool::get(antecedent_clause_ptr).glue()=glue;
			_glue_queue.push(glue);
			_stat.glue.total+=glue;
		}
		else{
			assert(learnt_clause.size()==1);

			_glue_queue.push(1);
			_stat.glue.total+=1;
		}

#ifdef TRACK
		if(_config.partial_backtracking.enabled){
			track_out<<"Amended (Distance: "<<_dlevel-assert_dlevel<<")"<<endl;
		}
#endif

		if(_config.drup_output.enabled){
			output_drup_clause(learnt_clause.begin(), learnt_clause.end(), false);
		}

		if(_stat.execution.resolve_conflict>10000 && _glue_queue.is_full() && _assigned>1.4*_trail_queue.sum()/_trail_queue.size()){
			// Block one restart
			_stat.execution.blocked_restart++;
			_glue_queue.clear();
		}
		_trail_queue.push(_assigned);

		unsigned int back_dlevel=assert_dlevel;

		if(_config.partial_backtracking.enabled && _dlevel-assert_dlevel>_config.partial_backtracking.ignore_distance){
			back_dlevel=_dlevel-1;
			_stat.execution.partial_backtrack++;
		}

		_stat.backtrack_distance.max_distance+=(_dlevel-assert_dlevel);
		_stat.backtrack_distance.actual_distance+=(_dlevel-back_dlevel);

		backtrack(back_dlevel);

		set_var_value(learnt_clause[0], assert_dlevel, antecedent_clause_ptr);
	}

	return result;
}

//
// Terminate the resolution loop when the learnt clause contains exactly
// one literal assigned at the current decision level
//
void Solver::analyze_conflict_firstUIP(ClausePtr conflict_clause_ptr, vector<Literal>& learnt_clause)
{
	vector<Literal>& assigns = _assignment_stack[_dlevel];

	learnt_clause.clear();
	learnt_clause.push_back(Literal::UNDEF);

	int index = assigns.size() - 1;
	Variable var = 0;
	int counter = 0;
//	int depth=0;
	ClausePtr clause_ptr=conflict_clause_ptr;

	do{
		Clause& clause = ClausePool::get(clause_ptr);
		increase_clause_activity(clause);

		// The first literal in binary clause may not be the implied one
		if(var!=0 && clause.size()==2 && clause[0].var()!=var){
			assert(is_false(clause[0]));
			assert(is_true(clause[1]));

			Literal temp=clause[0];
			clause[0]=clause[1];
			clause[1]=temp;
		}

		for (size_t i=(var==0 ? 0 : 1); i < clause.size(); i++){
			if (!_seen[clause[i].var()] && reason(clause[i]).dlevel > TOP_DLEVEL){
				increase_variable_activity(clause[i].var());
				_seen[clause[i].var()] = true;
				if (reason(clause[i]).dlevel == _dlevel){
					counter++;
//					depth++;
				}
				else{
					learnt_clause.push_back(clause[i]);
				}
			}
		}

		do{
			assert(index>=0);
			var = assigns[index--].var();
		} while (!_seen[var]);

		counter--;
		_seen[var] = false;
		clause_ptr = reason(var).antecedent_clause_ptr;
	} while (counter > 0);

	_stat.minimization.max_literal+=learnt_clause.size();
	learnt_clause[0] = Literal(var, value(var) == V_TRUE ? P_NEGATIVE : P_POSITIVE);

	if(learnt_clause.size()>2){
		// Simplify learnt clause
		minimize_learnt_clause(learnt_clause);
	}
	binary_minimize_learnt_clause(learnt_clause);

	_stat.minimization.actual_literal+=learnt_clause.size();

	for (vector<Literal>::iterator itr = learnt_clause.begin() + 1; itr != learnt_clause.end(); itr++){
		_seen[itr->var()] = false;
	}

//	if(depth>2){
//		analyze_direct_conflict(conflict_clause_ptr);
//	}
//	else{
//		cout<<"Direct reason is the same as learnt"<<endl;
//	}
}

//
// For the conflicts occurring at Level 1
// Find all UIPs
// neg_uips stores the negation of UIPs
//
void Solver::analyze_conflict_first_dlevel(ClausePtr conflict_clause_ptr, vector<Literal>& neg_uips)
{
	assert(_dlevel==1);

	vector<Literal>& assigns=_assignment_stack[_dlevel];

	neg_uips.clear();

	int index = assigns.size() - 1;
	Variable var = 0;
	int counter = 0;
	ClausePtr clause_ptr=conflict_clause_ptr;

	do{
		Clause& clause = ClausePool::get(clause_ptr);

		// The first literal in binary clause may not be the implied one
		if(var!=0 && clause.size()==2 && clause[0].var()!=var){
			assert(is_false(clause[0]));
			assert(is_true(clause[1]));

			Literal temp=clause[0];
			clause[0]=clause[1];
			clause[1]=temp;
		}

		for (size_t i=(var==0 ? 0 : 1); i < clause.size(); i++){
			if (!_seen[clause[i].var()] && reason(clause[i]).dlevel > TOP_DLEVEL){
				increase_variable_activity(clause[i].var());
				_seen[clause[i].var()] = true;
				counter++;
			}
		}

		do{
			assert(index>=0);
			var = assigns[index--].var();
		} while (!_seen[var]);

		counter--;
		if(counter==0){
			neg_uips.push_back(-assigns[index+1]);
		}

		_seen[var] = false;
		clause_ptr = reason(var).antecedent_clause_ptr;
	} while (index!=-1);
}

void Solver::analyze_direct_conflict(ClausePtr conflict_clause_ptr)
{
	vector<Literal> learnt_clause;

	Clause& clause = ClausePool::get(conflict_clause_ptr);
	assert(reason(clause[1]).dlevel==_dlevel);
	for (size_t i=1; i < clause.size(); i++){
		_seen[clause[i].var()] = true;
		learnt_clause.push_back(clause[i]);
	}

	Clause& antecedent_clause=ClausePool::get(reason(clause[0]).antecedent_clause_ptr);
	for (size_t i=1; i < antecedent_clause.size(); i++){
		if (!_seen[antecedent_clause[i].var()]){
			_seen[antecedent_clause[i].var()] = true;
			learnt_clause.push_back(antecedent_clause[i]);
		}
	}

	assert(reason(learnt_clause[0]).dlevel==_dlevel);
	for (vector<Literal>::iterator itr = learnt_clause.begin()+1; itr != learnt_clause.end(); itr++){
		if(reason(*itr).dlevel==_dlevel){
			Literal temp=*itr;
			*itr=learnt_clause[1];
			learnt_clause[1]=temp;
		}
	}

	for (vector<Literal>::iterator itr = learnt_clause.begin(); itr != learnt_clause.end(); itr++){
		_seen[itr->var()] = false;
	}

//	minimize_learnt_clause(learnt_clause);

	ClausePtr clause_ptr = ClausePool::create(learnt_clause, true);
	_learnt_clauses.push_back(clause_ptr);
	attach_clause(clause_ptr);
	increase_clause_activity(clause_ptr);
}

//
// Pre-condition:
// For any literal l in learnt_clause(except the asserted literal), _seen[l.var()]=true
//
// Post-condition:
// For any removed literal l, _seen[l.var()]=false
//
void Solver::minimize_learnt_clause(vector<Literal>& learnt_clause)
{
	_mark+=2;
	// Mark the decision levels appearing in the learnt clause
	for (vector<Literal>::iterator itr = learnt_clause.begin() + 1; itr
			!= learnt_clause.end(); itr++){
		unsigned int dlevel=reason(*itr).dlevel;
		if(_mark_dlevels[dlevel]==_mark-1){
			// Mark the decision levels appearing more than once in the learnt clause
			// Only need to check the literals with these decision levels
			_mark_dlevels[dlevel]=_mark;
		}
		else if(_mark_dlevels[dlevel]!=_mark){
			_mark_dlevels[dlevel]=_mark-1;
		}
	}

	bool removed = true;
	size_t i = 1, j = 1;
	Variable var=0;

	for (i=j=1; i < learnt_clause.size(); i++){
		removed = true;
		int top=_minimize_clear_seen.size();

		if (reason(learnt_clause[i].var()).antecedent_clause_ptr == ClausePool::CLS_NULL
				|| _mark_dlevels[reason(learnt_clause[i]).dlevel]!=_mark){
			removed = false;
		}
		else{
			// Implied variables are candidates for removal
			_analyze_stack.clear();
			_analyze_stack.push_back(learnt_clause[i]);

			do{
				var=_analyze_stack.back().var();
				Clause& clause = ClausePool::get(reason(var).antecedent_clause_ptr);
				_analyze_stack.pop_back();

				// The first literal in binary clause may not be the implied one
				if(clause.size()==2 && clause[0].var()!=var){
					assert(is_false(clause[0]));
					assert(is_true(clause[1]));

					Literal temp=clause[0];
					clause[0]=clause[1];
					clause[1]=temp;
				}

				for (Clause::iterator itr = clause.begin()+1; itr
						!= clause.end(); itr++){
					Reason& rn=reason(*itr);
					if (!_seen[itr->var()] && rn.dlevel > TOP_DLEVEL){
						if (rn.antecedent_clause_ptr != ClausePool::CLS_NULL
								&& (_mark_dlevels[rn.dlevel]==_mark-1 || _mark_dlevels[rn.dlevel]==_mark)){
							_seen[itr->var()] = true;
							_minimize_clear_seen.push_back(itr->var());
							_analyze_stack.push_back(*itr);
						}
						else{
							for (size_t k=top; k< _minimize_clear_seen.size(); k++){
								_seen[_minimize_clear_seen[k]] = false;
							}
							_minimize_clear_seen.resize(top);
							removed = false;
							break;
						}
					}
				}
			} while (!_analyze_stack.empty() && removed);
		}

		if (!removed){
			learnt_clause[j++] = learnt_clause[i];
		}
		else{
			assert(_seen[learnt_clause[i].var()]);
			_seen[learnt_clause[i].var()] = false;
		}
	}

	for(vector<Variable>::iterator itr=_minimize_clear_seen.begin(); itr!=_minimize_clear_seen.end(); itr++){
		_seen[*itr]=false;
	}
	_minimize_clear_seen.clear();

	learnt_clause.resize(j);
}

//
// Self-subsumption with binary clauses.
//
// Pre-condition:
// For any literal l in learnt_clause (except the asserted literal), _seen[l.var()]=true
//
// Post-condition:
// For any removed literal l, _seen[l.var()]=false
//
void Solver::binary_minimize_learnt_clause(vector<Literal>& learnt_clause)
{
	if(learnt_clause.size()>30){
		return;
	}

	_mark++;
	bool removed=false;
	vector<Watcher>& watchers=_binary_watchers[learnt_clause[0]];
	for(vector<Watcher>::iterator itr=watchers.begin(); itr!=watchers.end(); itr++){
		Literal blocker=itr->blocker;
		if(_seen[blocker.var()] && is_true(blocker)){
			_mark_dlevels[blocker.var()]=_mark;
			removed=true;
		}
	}

	if(removed){
		size_t i, j;
		for(i=j=1; i<learnt_clause.size(); i++){
			if(_mark_dlevels[learnt_clause[i].var()]!=_mark){
				learnt_clause[j++]=learnt_clause[i];
			}
			else{
				assert(_seen[learnt_clause[i].var()]);
				_seen[learnt_clause[i].var()] = false;
			}
		}
		learnt_clause.resize(j);
	}
}

//
// Backtrack to given decision level
// The assignments at the given level are retained
//
void Solver::backtrack(int back_dlevel)
{
	_stat.execution.backtrack++;

#ifdef TRACK
	track_out<<"Backtrack to Lv "<<back_dlevel<<" (Distance: "<<_dlevel-back_dlevel<<")"<<endl;
#endif

	assert(back_dlevel<=_dlevel && back_dlevel>=TOP_DLEVEL);

	for (int i = _dlevel; i > back_dlevel; i--){
		vector<Literal>& assigns = _assignment_stack[i];
		for (vector<Literal>::reverse_iterator itr = assigns.rbegin(); itr
				!= assigns.rend(); itr++){
			Variable var=itr->var();
			prev_value(var)=value(var);
			value(var)=V_UNASSIGNED;
//			reason(var)={-1, ClauseFactory::CLS_NULL};

			_heap.push(var);
		}
		_assigned-=assigns.size();
	}

	_assignment_stack.resize(back_dlevel+1);
	_dlevel = back_dlevel;
}

Result Solver::solve()
{
	_stat.cpu_time.start_time = System::get_cpu_time();
	_stat.wall_time.start_time = System::get_wall_time();

	output_configuration();
	output_problem_stat();

	if(_executable){
		_executable = false;

		_stat.clause.learnt_upper_bound=_config.clause_deletion.first_learnt_upper_bound;

		_stat.status_output.conflict_upper_bound=_config.status_output.first_conflict_upper_bound;

#ifdef TRACK
	track_out.open("track", ios::out);
#endif

		if(!preprocess()){
			_result = UNSAT;
		}
		else{
			if(_config.status_output.enabled){
				output_status_header(cout);
				output_status(cout);

				Solver::sig_output_status=0;
				signal(SIGALRM, Solver::signal_output_status_handler);
				alarm(_output_interval);
			}

			while (true){
				if (!deduce()){
					if (!resolve_conflict()){
						_result = UNSAT;
						break;
					}

					decay_var_activity();
					decay_clause_activity();
				}
				else{
					execute_periodic_task();

					increase_dlevel();

					if (!decide()){
						_result = SAT;
						break;
					}
				}
			}
		}

		if(_result==SAT && !_eliminated_clauses.empty()){
			load_eliminated_clauses();
		}

//		if(_config.drup_output.enabled){
//			drup_out.close();
//		}

#ifdef TRACK
	track_out.close();
#endif
	}

	_stat.cpu_time.end_time = System::get_cpu_time();
	_stat.wall_time.end_time = System::get_wall_time();
	_stat.memory.max_memory_usage=System::get_max_memory_usage();

	output_stat();
	output_result();

	return _result;
}

bool Solver::verify()
{
	for (vector<ClausePtr>::iterator itr = _clauses.begin(); itr
			!= _clauses.end(); itr++){
		if(!is_satisfied(*itr)){
			return false;
		}
	}
	return true;
}

void Solver::output_drup_clause(ClausePtr clause_ptr, bool deleted)
{
	Clause& clause=ClausePool::get(clause_ptr);
	output_drup_clause(clause.begin(), clause.end(), deleted);
}

template<typename Iterator>
void Solver::output_drup_clause(Iterator begin, Iterator end, bool deleted)
{
	if(deleted){
//		drup_out<<"d ";
		cout<<"d ";
	}

	for(Iterator itr=begin; itr!=end; itr++){
//		drup_out<<*itr<<" ";
		cout<<*itr<<" ";
	}

//	drup_out<<"0\n";
	cout<<"0\n";
}

void Solver::output_configuration(ostream& out) const
{
	out<<"c ====================================== Configuration =============================================="<<endl;
	out<<"c Variable Activity Decay Factor: "<<_config.var_activity.decay_factor<<endl;
	out<<"c Clause Activity Decay Factor: "<<_config.clause_activity.decay_factor<<endl;
	out<<"c First Learnt Clause Upper Bound: "<<_config.clause_deletion.first_learnt_upper_bound<<endl;
	out<<"c Increment of Learnt Clause Upper Bound: "<<_config.clause_deletion.increment<<endl;
	out<<"c Clause Deletion Factor: "<<_config.clause_deletion.delete_factor<<endl;
	out<<"c Partial Backtracking: "<<(_config.partial_backtracking.enabled ? "Yes" : "No")<<endl;
}

void Solver::output_problem_stat(ostream& out) const
{
	out<<"c ==================================================================================================="<<endl;
	out<<"c "<<setw(12)<<"Variables:"<<setw(12)<<_values.size()-1-_stat.preprocessing.elimination.eliminated_variables-_assigned<<endl;
	out<<"c "<<setw(12)<<"Clauses:"<<setw(12)<<_clauses.size()<<endl;
	out<<"c ==================================================================================================="<<endl;
}

void Solver::output_status_header(ostream& out) const
{
	out<<"c ";
	out<<setw(11)<<"Decision";
	out<<setw(11)<<"Conflict";
	out<<setw(11)<<"Clause";
	out<<setw(11)<<"Learnt";
	out<<setw(11)<<"AvgLitQty";
	out<<setw(11)<<"AvgGlue";
	out<<setw(11)<<"Restart";
	out<<setw(11)<<"CPUTime";
	out<<setw(11)<<"Memory"<<endl;
}

void Solver::output_status(ostream& out) const
{
	out<<"c ";
	out<<setw(11)<<_stat.execution.decide;
	out<<setw(11)<<_stat.execution.resolve_conflict;
	out<<setw(11)<<_clauses.size();
	out<<setw(11)<<_learnt_clauses.size();
	out<<setw(11)<<(_learnt_clauses.empty() ? 0 : _stat.literal.learnt/_learnt_clauses.size());
	out<<setw(11)<<(_stat.execution.resolve_conflict==0 ? 0 : _stat.glue.total/_stat.execution.resolve_conflict);
	out<<setw(11)<<_stat.execution.restart;
	out<<setw(9)<<System::get_cpu_time()-_stat.cpu_time.start_time<<" s";
	out<<setw(8)<<System::get_memory_usage()<<" MB"<<endl;
}

void Solver::output_stat(ostream& out) const
{
	out << "c Decision: " << _stat.execution.decide << endl;
	out << "c Propagation (Regular): " << _stat.execution.propagate_regular << endl;

	if(_config.partial_backtracking.enabled){
		out << "c Propagation (Amending): " << _stat.execution.propagate_amending << " ("
			<< (_stat.backtrack_distance.max_distance==0 ? 0 : ((double)_stat.backtrack_distance.max_distance-_stat.backtrack_distance.actual_distance)/_stat.backtrack_distance.max_distance*100)
			<< " % Distance reduced, "<<_stat.backtrack_distance.trigger_conflict<<" Conflicts triggered)" << endl;
	}

	out << "c Conflict: " << _stat.execution.resolve_conflict << " ("
		<< (_stat.minimization.max_literal==0 ? 0 : ((double)_stat.minimization.max_literal-_stat.minimization.actual_literal)/_stat.minimization.max_literal*100)
		<< " % Literals deleted)"<<endl;
	out << "c Backtrack: " << _stat.execution.backtrack << endl;

	if(_config.partial_backtracking.enabled){
		out << "c Partial Backtrack: " <<_stat.execution.partial_backtrack << endl;
	}

	out << "c Restart: " << _stat.execution.restart << endl;
	out << "c Blocked Restart: " << _stat.execution.blocked_restart <<endl;
	out << "c Simplify: " << _stat.execution.simplify << endl;
	out << "c Shrink: " << _stat.execution.shrink << " ("
		<< (_stat.clause.deleted_learnt+_learnt_clauses.size()==0 ? 0 : (double)_stat.clause.deleted_learnt/(_stat.clause.deleted_learnt+_learnt_clauses.size())*100)
		<< " % Learnt Clauses deleted)"<<endl;
	out << "c GC: " << _stat.execution.garbage_collect << endl;
	out << "c CPU Time: " << _stat.cpu_time.end_time - _stat.cpu_time.start_time << " s" << endl;
	out << "c Wall Time: " << _stat.wall_time.end_time - _stat.wall_time.start_time << " s" << endl;
	out << "c Max Memory Usage: " << _stat.memory.max_memory_usage << " MB" << endl;
}

const vector<Value>& Solver::assignment() const
{
	return _values;
}

bool Solver::is_executable() const
{
	return _executable;
}

Result Solver::result() const
{
	return _result;
}

void Solver::output_result(ostream& out)
{
	if (_result == SAT){
		out << "s SATISFIABLE" << endl;
		if(verify()){
			if(_config.assignment_output.enabled){
				for(int i=1, size=_values.size(); i<size; i++){
					if(i%10==1){
						cout<<"v";
					}
					out<<" "<<(_values[i]==V_TRUE ? i : -i);
					if(i%10==0){
						cout<<endl;
					}
				}
				out<<(_values.size()%10==1 ? "v 0" : " 0")<<endl;
			}
		}
		else{
			out<<"c Verification failed! Wrong assignment!"<<endl;
		}
	}
	else if (_result == UNSAT){
		cout << "s UNSATISFIABLE" << endl;
	}
}
