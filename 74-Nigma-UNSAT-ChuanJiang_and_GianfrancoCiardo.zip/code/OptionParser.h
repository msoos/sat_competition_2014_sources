#ifndef _OPTIONPARSER_HEADER
#define _OPTIONPARSER_HEADER

#include <vector>
#include <cstdlib>
#include <iostream>

#include "Option.h"
#include "SolverConfig.h"

using namespace std;

class OptionParser
{
private:
	IntOption _opt_elimination_timeout;
	IntOption _opt_probing_timeout;
	SwitchOption _opt_partial_backtracking;
	SwitchOption _opt_reuse_trail;
	DoubleOption _opt_garbage_ratio;
	SwitchOption _opt_verbose;
	SwitchOption _opt_display_assignments_if_sat;
	SwitchOption _opt_output_drup_if_unsat;
	StringOption _opt_output_drup_dir;
	SwitchOption _opt_help;
	vector<Option*> _options;

	void output_usage_and_exit(ostream& out);
	void output_invalid_option_and_exit(ostream& out, const char* argv);
	void output_require_argument_and_exit(ostream& out, const char* argv);

public:
	OptionParser();
	int parse(int argc, char** argv);
	void configure(SolverConfig& config);
};

#endif
