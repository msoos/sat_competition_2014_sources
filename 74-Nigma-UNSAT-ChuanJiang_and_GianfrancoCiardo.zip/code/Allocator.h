#ifndef _ALLOCATOR_HEADER
#define _ALLOCATOR_HEADER

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cassert>

using namespace std;

class OutOfMemoryException : public exception
{
public:
    virtual const char* what() const throw()
    {
    	return "No more memory is available.";
    }
};

template<typename T>
class Allocator
{
private:
	static const size_t DEFAULT_CAPACITY=1024*1024;

	// _memory[0] is reserved for UnDef
	T* _memory;
	size_t _capacity;
	size_t _size;
	size_t _wasted;

public:
	static const size_t MEM_NULL=0;
	static const size_t MEM_BEGIN=1;

	Allocator(size_t capacity=DEFAULT_CAPACITY)
		: _memory(NULL), _capacity(0), _size(0), _wasted(0)
	{
		reserve(capacity);
	}

	~Allocator()
	{
		if(_memory!=NULL){
//			cout<<"Free memory used by Allocator"<<endl;
			::free(_memory);
		}
	}

	const T& operator[](size_t index) const
	{
		assert(index>=1 || index<=_size);
		return _memory[index];
	}

	T& operator[](size_t index)
	{
		assert(index>=1 || index<=_size);
		return _memory[index];
	}

	size_t capacity() const
	{
		return _capacity;
	}

	size_t size() const
	{
		return _size;
	}

	size_t wasted() const
	{
		return _wasted;
	}

	void reserve(size_t capacity)
	{
		_capacity=capacity;

		size_t size=sizeof(T)*(_capacity+1);
		void* temp=realloc(_memory, size);
		if(temp!=NULL){
			_memory=static_cast<T*>(temp);
		}
		else{
			throw OutOfMemoryException();
		}
	}

	size_t create(size_t size)
	{
		if(_size+size>_capacity){
			reserve((_size+size)*3/2);
		}

		size_t addr=_size+1;
		_size+=size;

		return addr;
	}

	size_t allocate(T* begin, size_t size)
	{
		size_t addr=create(size);
		for(size_t i=0; i<size; i++){
			_memory[addr+i]=*begin;
			begin++;
		}
		return addr;
	}

	void free(size_t begin, size_t free_size)
	{
		assert(begin>=1 && begin+free_size-1<=_size);
		_wasted+=free_size;
	}

	void move(Allocator<T>& to)
	{
		if(to._memory!=NULL){
			::free(to._memory);
		}

		to._memory=_memory;
		to._capacity=_capacity;
		to._size=_size;
		to._wasted=_wasted;

		_memory=NULL;
		_capacity=0;
		_size=0;
		_wasted=0;
	}

	void dump(std::ostream& out) const
	{
		out<<"Capacity: "<<_capacity<<endl;
		out<<"Size: "<<_size<<endl;
		out<<"Wasted: "<<_wasted<<endl;
		for(size_t i=1; i<=_size; i++){
			out<<_memory[i]<<" ";
		}
		out<<endl;
	}

	// Copy elements from one address to another address
	// Will not check if overwrite or overlap occurs
	void copy(size_t to, size_t from, size_t size)
	{
		memmove(&_memory[to], &_memory[from], size*sizeof(T));
	}

	void shrink(size_t size)
	{
		assert(size<=_size);
		_size=size;
		_wasted=0;
	}
};

#endif
