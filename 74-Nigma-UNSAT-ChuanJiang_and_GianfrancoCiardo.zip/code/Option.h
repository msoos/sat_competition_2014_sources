#ifndef _OPTION_HEADER
#define _OPTION_HEADER

#include <cstdlib>

class Option
{
protected:
	const char* _name;
	const char* _description;
	const char* _argument_name;
	bool _has_argument;

public:
	Option(const char* name, const char* description)
		: _name(name), _description(description), _argument_name(NULL), _has_argument(false)
	{
	}

	Option(const char* name, const char* description, const char* argument_name)
		: _name(name), _description(description), _argument_name(argument_name), _has_argument(true)
	{
	}

	virtual ~Option()
	{
	}

	const char* name()
	{
		return _name;
	}

	const char* description()
	{
		return _description;
	}

	const char* argument_name()
	{
		return _argument_name;
	}

	bool has_argument()
	{
		return _has_argument;
	}

	virtual void parse(const char* value)=0;
};

template<typename T>
class TypedOption : public Option
{
protected:
	T _value;
public:
	TypedOption<T>(const char* name, const char* description)
		: Option(name, description)
	{
	}

	TypedOption<T>(const char* name, const char* description, const char* argument_name, T default_value)
		: Option(name, description, argument_name), _value(default_value)
	{
	}

	T value()
	{
		return _value;
	}
};

class SwitchOption : public TypedOption<bool>
{
public:
	SwitchOption(const char* name, const char* description)
		: TypedOption<bool>(name, description)
	{
		_value=false;
	}

	virtual void parse(const char* argument)
	{
		_value=true;
	}
};

class IntOption : public TypedOption<int>
{
public:
	IntOption(const char* name, const char* description, const char* argument_name, int default_value)
		: TypedOption<int>(name, description, argument_name, default_value)
	{
	}

	virtual void parse(const char* value)
	{
		_value=atoi(value);
	}
};

class DoubleOption : public TypedOption<double>
{
public:
	DoubleOption(const char* name, const char* description, const char* argument_name, double default_value)
		: TypedOption<double>(name, description, argument_name, default_value)
	{
	}

	virtual void parse(const char* value)
	{
		_value=atof(value);
	}
};

class StringOption : public TypedOption<const char*>
{
public:
	StringOption(const char* name, const char* description, const char* argument_name, const char* default_value)
		: TypedOption<const char*>(name, description, argument_name, default_value)
	{
	}

	virtual void parse(const char* value)
	{
		_value=value;
	}
};

#endif
