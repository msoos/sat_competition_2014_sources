#ifndef _SOLVERSTAT_HEADER
#define _SOLVERSTAT_HEADER

#include <ctime>

struct SolverStat
{
	struct Execution
	{
		unsigned int decide;
		unsigned int resolve_conflict;
		unsigned int deduce;
		unsigned int backtrack;
		unsigned int partial_backtrack;
		unsigned int propagate_regular;
		unsigned int propagate_amending;
		unsigned int restart;
		unsigned int blocked_restart;
		unsigned int shrink;
		unsigned int simplify;
		unsigned int garbage_collect;
	} execution;

	struct Preprocessing
	{
		struct Elimination
		{
			unsigned int eliminated_variables;
			unsigned int subsumed_clauses;
			unsigned int strengthened_clauses;
		} elimination;

		struct Probing
		{
			unsigned int assigned_variables;
		} probing;
	} preprocessing;

	struct ClauseStat
	{
		unsigned long deleted_learnt;
		size_t learnt_upper_bound;
	} clause;

	struct GlueStat
	{
		unsigned long total;
	} glue;

	struct LiteralStat
	{
		unsigned long learnt;
		unsigned long deleted_learnt;
	} literal;

	struct Activity
	{
		double clause_growth;
		double var_growth;
	} activity;

	struct BacktrackDistanceStat
	{
		unsigned long max_distance;
		unsigned long actual_distance;
		unsigned long trigger_conflict;
	} backtrack_distance;

	struct MinimizationStat
	{
		unsigned long max_literal;
		unsigned long actual_literal;
	} minimization;

	struct StatusOutputStat
	{
		unsigned int conflict_upper_bound;
	} status_output;

	struct TimeStat
	{
		double start_time;    // second
		double end_time;    // second
	};

	struct TimeStat cpu_time;
	struct TimeStat wall_time;

	struct MemoryStat
	{
		double max_memory_usage;
	} memory;

	SolverStat()
	{
		execution.decide=0;
		execution.resolve_conflict=0;
		execution.deduce=0;
		execution.backtrack=0;
		execution.partial_backtrack=0;
		execution.propagate_regular=0;
		execution.propagate_amending=0;
		execution.restart=0;
		execution.blocked_restart=0;
		execution.shrink=0;
		execution.simplify=0;
		execution.garbage_collect=0;

		preprocessing.elimination.eliminated_variables=0;
		preprocessing.elimination.subsumed_clauses=0;
		preprocessing.elimination.strengthened_clauses=0;
		preprocessing.probing.assigned_variables=0;

		clause.deleted_learnt=0;

		glue.total=0;

		literal.learnt=0;
		literal.deleted_learnt=0;

		activity.var_growth=1;
		activity.clause_growth=1;

		backtrack_distance.max_distance=0;
		backtrack_distance.actual_distance=0;
		backtrack_distance.trigger_conflict=0;

		minimization.max_literal=0;
		minimization.actual_literal=0;

		status_output.conflict_upper_bound=0;

		cpu_time.start_time=0;
		cpu_time.end_time=0;

		wall_time.start_time=0;
		wall_time.end_time=0;

		memory.max_memory_usage=0;
	}
};

#endif
