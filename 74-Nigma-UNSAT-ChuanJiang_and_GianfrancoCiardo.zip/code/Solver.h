#ifndef _SOLVER_HEADER
#define _SOLVER_HEADER

#include <fstream>
#include <deque>
#include <queue>
#include <signal.h>

#include "SolverConfig.h"
#include "SolverStat.h"
#include "VariableHeap.h"
#include "LiteralVector.h"
//#include "RestartSequence.h"
#include "BoundedQueue.h"

typedef enum Result
{
	SAT=0,
	UNSAT=1,
	UNKNOWN=2
}Result;

class Solver
{
private:
	static volatile sig_atomic_t sig_timeout;
	static volatile sig_atomic_t sig_output_status;

	static const unsigned int TOP_DLEVEL=0;
	static const char* DRUP_FILE;

	typedef struct Reason
	{
		unsigned int dlevel;
		ClausePtr antecedent_clause_ptr;
	}Reason;

	typedef struct LiteralLt
	{
		bool operator() (int first, int second) const
		{
			if(abs(first)<abs(second)){
				return true;
			}
			else if(first>0 && first==-second){
				return true;
			}
			return false;
		}
	}LiteralLt;

	typedef struct ClauseOrderLt
	{
		bool operator() (ClausePtr left, ClausePtr right) const
		{
			Clause& left_clause=ClausePool::get(left);
			Clause& right_clause=ClausePool::get(right);

			if(right_clause.size()==2){
				return false;
			}

			assert(right_clause.size()>2);
			if(left_clause.size()==2){
				return true;
			}

			assert(left_clause.size()>2);
			if(left_clause.glue()>right_clause.glue()){
				return false;
			}

			if(left_clause.glue()<right_clause.glue()){
				return true;
			}

			assert(left_clause.glue()==right_clause.glue());
			return left_clause.activity()>right_clause.activity();
		}
	}ClauseOrderLt;

	typedef struct VariableOrderLt
	{
		const vector<double>& _activities;

		VariableOrderLt(const vector<double>& activities)
			: _activities(activities)
		{
		}

		bool operator () (int x, int y) const
		{
			return _activities[x] > _activities[y];
		}
	}VariableOrderLt;

	typedef struct ImplicationLt
	{
		const vector<Reason>& _reasons;

		ImplicationLt(const vector<Reason>& reasons)
			: _reasons(reasons)
		{
		}

		bool operator () (Literal x, Literal y)
		{
			return _reasons[x.var()].dlevel<_reasons[y.var()].dlevel;
		}
	} ImplicationLt;

	typedef struct Watcher
	{
		ClausePtr clause_ptr;
		Literal blocker;
	}Watcher;

	typedef enum Subsumption
	{
		None=0,
		Subsumed=1,
		Strengthened=2
	}Subsumption;

	const SolverConfig _config;    // Must be placed before RestartSequence
	SolverStat _stat;

	BoundedQueue<unsigned int> _glue_queue;
	BoundedQueue<size_t> _trail_queue;

	vector<Value> _values;
	vector<Reason> _reasons;
	vector<double> _activities;
	vector<Value> _prev_values;
	vector<unsigned long> _mark_dlevels;

	vector<ClausePtr> _clauses;
	vector<ClausePtr> _learnt_clauses;
	vector<Literal> _eliminated_clauses;

	vector<bool> _eliminated;
	vector<bool> _seen;

	LiteralVector<Watcher> _binary_watchers;
	LiteralVector<Watcher> _watchers;
	LiteralVector<ClausePtr> _occurrences;

	vector<vector<Literal> > _assignment_stack;
	deque<Literal> _implication_queue;
	queue<ClausePtr> _conflict_clauses;
	VariableHeap<VariableOrderLt> _heap;

	unsigned int _dlevel;    // decision level
	size_t _top_level_var_count;
	size_t _assigned;
	unsigned long _mark;

	Result _result;
	bool _executable;

	// Temporary variables
	vector<Literal> _analyze_stack;
	vector<Variable> _minimize_clear_seen;

	unsigned int _output_interval;
	unsigned int _output_count;

//	ofstream drup_out;

#ifdef TRACK
	ofstream track_out;
#endif

	static void signal_timeout_handler(int signum);
	static void signal_output_status_handler(int signum);

	// Variable Helper
	Value& value(Variable var);
	Value value(Variable var) const;
	Reason& reason(Variable var);
	double& activity(Variable var);
	Value& prev_value(Variable var);

	// Literal Helper
	bool is_true(Literal lit);
	bool is_false(Literal lit);
	bool is_assigned(Literal lit);
	Reason& reason(Literal lit);

	// Clause Helper
	bool is_locked(Clause& clause, ClausePtr clause_ptr);
	bool is_satisfied(ClausePtr clause_ptr);

	void propagate_regular(Literal lit);
	void propagate_amending(Literal lit);

	bool prepare_clause(vector<Literal>& literals);
	void attach_clause(ClausePtr clause_ptr);
	void detach_clause(ClausePtr clause_ptr);
	void delete_clause(ClausePtr clause_ptr);
	void clean_clauses();

	bool backward_subsumption(ClausePtr clause_ptr, deque<ClausePtr>& touched);
	Subsumption check_subsumption(Clause& left, Clause& right, Literal& literal);
	bool strengthen(ClausePtr clause_ptr, Literal literal, bool update_occur);

	void save_eliminated_clauses(Variable var, set<Variable>& elim_candidates);
	void eliminate_clauses(Literal literal, set<Variable>& elim_candidates);
	void load_eliminated_clauses();

	void increase_dlevel();
	void execute_periodic_task();
	void restart();
	void shrink();
	void simplify();
	void increase_variable_activity(Variable var);
	void increase_clause_activity(ClausePtr clause_ptr);
	void increase_clause_activity(Clause& clause_ptr);
	void decay_var_activity();
	void decay_clause_activity();
	void garbage_collect();

	// Return true if the corresponding procedure is invoked
	bool check_restart();
	bool check_simplify();
	bool check_shrink();
	bool check_garbage_collect();

	unsigned int compute_glue(ClausePtr clause_ptr);

	void rebuild_watchers();
	void rebuild_occurrences();

	bool preprocess();
	bool decide();
	bool deduce();
	void propagate(Literal lit);
	void set_var_value(Literal lit, unsigned int dlevel, ClausePtr clause_ptr=ClausePool::CLS_NULL);
	bool resolve_conflict();
	void backtrack(int back_dlevel);

	// Preprocessing
	bool probe();
	bool eliminate();

	// different conflict analysis strategies
	void analyze_conflict_firstUIP(ClausePtr conflict_clause_ptr, vector<Literal>& learnt_clause);
	void analyze_direct_conflict(ClausePtr conflict_clause_ptr);
	void analyze_conflict_first_dlevel(ClausePtr conflict_clause_ptr, vector<Literal>& neg_uips);

	void clean_invalid_implication();
	void minimize_learnt_clause(vector<Literal>& learnt_clause);
	void binary_minimize_learnt_clause(vector<Literal>& learnt_clause);

	void output_drup_clause(ClausePtr clause_ptr, bool deleted);

	template<typename Iterator>
	void output_drup_clause(Iterator begin, Iterator end, bool deleted);

public:
	Solver(const SolverConfig& config=SolverConfig());
	~Solver();

	void set_variable_size(int var_size);
	ClausePtr add_clause(vector<int>& literals);

	Result solve();
	bool verify();

	void output_configuration(ostream& out=cout) const;
	void output_problem_stat(ostream& out=cout) const;
	void output_status_header(ostream& out=cout) const;
	void output_status(ostream& out=cout) const;
	void output_stat(ostream& out=cout) const;
	void output_result(ostream& out=cout);

	const vector<Value>& assignment() const;

	bool is_executable() const;
	Result result() const;
};

inline Value& Solver::value(Variable var)
{
	return _values[var];
}

inline Value Solver::value(Variable var) const
{
	return _values[var];
}

inline Solver::Reason& Solver::reason(Variable var)
{
	return _reasons[var];
}

inline double& Solver::activity(Variable var)
{
	return _activities[var];
}

inline Value& Solver::prev_value(Variable var)
{
	return _prev_values[var];
}

inline bool Solver::is_true(Literal lit)
{
	return (lit.phase()^value(lit.var()))==V_TRUE;
}

inline bool Solver::is_false(Literal lit)
{
	return (lit.phase()^value(lit.var()))==V_FALSE;
}

inline bool Solver::is_assigned(Literal lit)
{
	return _values[lit.var()]!=V_UNASSIGNED;
}

inline Solver::Reason& Solver::reason(Literal lit)
{
	return reason(lit.var());
}

inline bool Solver::is_locked(Clause& clause, ClausePtr clause_ptr)
{
	// No problem if all binary clauses are retained
	assert(clause.size()>2);
	return is_true(clause[0]) && reason(clause[0].var()).antecedent_clause_ptr==clause_ptr;
}

inline bool Solver::is_satisfied(ClausePtr clause_ptr)
{
	Clause& clause=ClausePool::get(clause_ptr);
	for(Clause::iterator itr=clause.begin(); itr!=clause.end(); itr++){
		if(is_true(*itr)){
			return true;
		}
	}
	return false;
}

inline bool Solver::check_restart()
{
	if (_glue_queue.is_full() && 0.8*_glue_queue.sum()/_glue_queue.size() > (double)_stat.glue.total/_stat.execution.resolve_conflict){
		_glue_queue.clear();
		restart();
		return true;
	}
	return false;
}

inline bool Solver::check_simplify()
{
	if (_dlevel == TOP_DLEVEL && _assigned > _top_level_var_count){
		simplify();
		return true;
	}
	return false;
}

inline bool Solver::check_shrink()
{
 	if (_learnt_clauses.size()+_top_level_var_count > _stat.clause.learnt_upper_bound+_assigned){
		shrink();
		_stat.clause.learnt_upper_bound+=_config.clause_deletion.increment;
		return true;
	}
 	return false;
}

inline bool Solver::check_garbage_collect()
{
	if (_dlevel == TOP_DLEVEL && ClausePool::wasted_ratio() >= _config.garbage_collect.garbage_ratio){
		// Invoke GC at the top level to avoid updating the reasons of the existing implications
		garbage_collect();
		return true;
	}
	return false;
}

#endif
