Nigma 1.1
Chuan Jiang, Iowa State University, cjiang@iastate.edu
Gianfranco Ciardo, Iowa State University, ciardo@iastate.edu

For building:
./build.sh
The executable file will be in the directory /binary

For running:
nigma INSTANCE --verbose --display-assignments-if-sat --partial-backtracking --preprocessing-timeout TIMEOUT

For running and outputting an unsatisfiability proof:
nigma INSTANCE --verbose --display-assignments-if-sat --output-drup-if-unsat --output-drup-dir TEMPDIR --partial-backtracking --preprocessing-timeout TIMEOUT
