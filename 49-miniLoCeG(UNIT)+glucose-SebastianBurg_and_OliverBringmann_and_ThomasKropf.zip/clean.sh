#!/bin/bash
export MROOT=$PWD/code/loceg
#export FM=$PWD/code/glucose_2.1/sources/SatELite/ForMani

#rm -rf code/glucose_2.1/glucose_static 
#rm -rf code/glucose_2.1/SatELite_release

rm -r binary

#cd code/glucose_2.1/sources/SatELite/SatELite
#make clean

cd code/glucose_2.1/sources/glucose/core
make clean
 
cd $MROOT
cd loceg
make clean

