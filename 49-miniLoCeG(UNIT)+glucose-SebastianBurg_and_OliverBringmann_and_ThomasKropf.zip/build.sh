#!/bin/bash
export MROOT=$PWD/code/loceg
#export FM=$PWD/code/glucose_2.1/sources/SatELite/ForMani

mkdir binary


echo "#!/bin/bash" > binary/start.sh
echo "FILENAME=\$1" >> binary/start.sh
echo "TEMPDIR=\$2" >> binary/start.sh
echo "MODE=\$3" >> binary/start.sh
echo "./loceg_static -mode=\$MODE -iterations=20  -dimacs=out.cnf  \$FILENAME ">> binary/start.sh
echo "./glucose_static out.cnf" >> binary/start.sh



#cd code/glucose_2.1/sources/SatELite/SatELite
#make r
#cp SatELite_release ../../../../../binary

cd code/glucose_2.1/sources/glucose/core
make rs
cp glucose_static ../../../../../binary
 
cd $MROOT
cd loceg
make rs
cp loceg_static ../../../binary

