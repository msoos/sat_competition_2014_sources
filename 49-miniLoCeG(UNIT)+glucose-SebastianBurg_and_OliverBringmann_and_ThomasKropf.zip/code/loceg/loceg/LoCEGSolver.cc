/***********************************************************************************[SimpSolver.cc]
Copyright (c) 2006,      Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "mtl/Sort.h"
#include "loceg/LoCEGSolver.h"
#include "utils/System.h"

using namespace Minisat;

//=================================================================================================
// Options:


static const char* _cat = "LoCEG";


//=================================================================================================
// Constructor/Destructor:


LoCEGSolver::LoCEGSolver(): debugon(false), modus(ALL)
{

}


LoCEGSolver::~LoCEGSolver()
{
}


Var LoCEGSolver::newVar(bool sign, bool dvar) {
    Var v = Solver::newVar(sign, dvar);

    //analyseoccurs[v]=0;
    return v;
}



bool LoCEGSolver::addClause_(vec<Lit>& ps)
{



	CRef cr = ca.alloc(ps, false);

	clauses.push(cr);

	attachClause(cr);


    return true;
}

bool LoCEGSolver::analyse(std::vector<int> dirties)
{
	maxvar = 0;
	maxocc = 0;
	//analyseoccurs.clear(false);



	if(debugon) printf("[%s] Analyse START\n", _cat);
	if(debugon) fflush(stdout);
	for(int i = 0; i < nVars(); i++)
	{
		analyseoccurs[i]=0;
	}

	if(dirties.size()>=(size_t)nVars()) return false;
	for(int i = 0; i < Solver::clauses.size(); i++)
	{
		Clause& c = ca[clauses[i]];
		for (int i = 0; i < c.size(); i++){
			if(!vecHas(var(c[i]), dirties))
			{
				//printf("[%s] %i(%i) ", var(c[i]), analyseoccurs[var(c[i])].size());
				analyseoccurs[var(c[i])]++;

				if(analyseoccurs[var(c[i])] > maxocc)
				{
					maxvar = var(c[i]);
					maxocc = analyseoccurs[var(c[i])];
				}
			}
		}
		//printf("[%s] \n");
	}
	if(debugon) printf("[%s] Maxvar %i with %i occs\n", _cat, toInt(maxvar), maxocc);
	return true;
}

bool LoCEGSolver::containsClause(std::vector<CRef>& cl, CRef cr)
{
	//printf("[%s] cl %i\n", _cat,cl.size());
	/* for(int i = 0; i < cl.size(); i++)
	 {

		Clause& c = ca[cl[i]];
		for (int j = 0; j < c.size(); j++)
				printf("[%s] %i ", _cat, var(c[j]));

		printf("[%s] \n");

	 }*/
	//printf("[%s] cr\n");

	for(size_t i = 0; i < cl.size(); i++)
	{
		CRef c = cl[i];
		if(sameClause(cr, c))
		{
		//	printf("[%s] true");
			return true;
		}
	}

	//printf("[%s] false\n");
	return false;
}


bool LoCEGSolver::sameClause(CRef& c1, CRef& c2)
{
	Clause& cc1 = ca[c1];
	Clause& cc2 = ca[c2];
	if (cc1.size() != cc2.size())
	{
		//printf("[%s] not same size\n");
		return false;
	}


	const Lit* c   = (const Lit*)cc1;
	const Lit* d   = (const Lit*)cc2;

	bool found = false;
	for (int i = 0; i < cc1.size(); i++) {
		// search for c[i] or ~c[i]
		found = false;
		for (int j = 0; j < cc2.size(); j++)
			if (c[i] == d[j])
				found = true;
		if(!found) return false;
	}

	return found;
}


bool LoCEGSolver::clauseHasVar(CRef& c1, int maxvar)
{

	Clause& cc1 = ca[c1];

	for (int i = 0; i < cc1.size(); i++) {
		if (var(cc1[i]) == maxvar)
			return true;
	}

	return false;
}

int LoCEGSolver::getModus()
{
	if(modus==ALL)
		{
			return INT32_MAX;
		} else if(modus==UNIT )
		{
			return 1;
		} else if(modus==SAT2)
		{
			return 2;
		}
		else if(modus == SAT3)
		{
			return 3;
		} else
		{
			return 100;
		}
}

std::vector<CRef> LoCEGSolver::getSubinstance(int maxclauses)
{
	std::vector<CRef> subinst;
	//printf("[%s] Maxvar %i", _cat, maxvar);

	for(int i = 0; i < clauses.size(); i++)
	{
		if(clauseHasVar(clauses[i], maxvar) && !containsClause(subinst, clauses[i]))
		{
			subinst.push_back(clauses[i]);
			Clause& cc1 = ca[clauses[i]];
			if(debugon) {
				for(int j = 0; j < cc1.size(); j++)
				{
					printf("[%s]  %s%i", _cat, sign(cc1[j])?"-":"", var(cc1[j]));
				}
				printf("\n");
			}
		}

		if(subinst.size() > (size_t)maxclauses) break;
	}
	return subinst;
}

std::vector<std::vector<Lit> > LoCEGSolver::makeNeg(std::vector<CRef> subinst)
{
	std::vector<std::vector<Lit> > Lits;
	for(size_t i = 0; i < subinst.size(); i++)
	{
		std::vector<std::vector<Lit> > nl;
		if(i==0)
		{

			Clause& c = ca[subinst[i]];
			for(int j = 0; j < c.size(); j++)
			{
				Lit l = ~c[j];
				std::vector<Lit> nnl;
				nnl.push_back(l);
				nl.push_back(nnl);
			}
		} else {
			Clause& c = ca[subinst[i]];
			for(int j = 0; j < c.size(); j++)
			{
				Lit l = ~c[j];
				for(size_t k = 0; k < Lits.size(); k++)
				{
					std::vector<Lit> nnl;
					nnl = Lits[k];
					if(!vecHasNeg(l, nnl))
					{
						if(!vecHas(l, nnl))
						{
							nnl.push_back(l);
						}
						nl.push_back(nnl);
					}
				}

			}

		}
		Lits = nl;
	}
	return Lits;
}


std::vector<int> LoCEGSolver::getSubvariables(std::vector<std::vector< Lit > > Lits)
{
	std::vector<int> subvariables;
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	while(it != Lits.end())
	{
// 			vec<Lit> cl;
		int     varl;
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
// 				cl.push((*it2));
			varl = var((*it2));
			if(!vecHas(varl, subvariables))
			{
				subvariables.push_back(varl);
				subvariables.push_back(-varl);
			}
			it2++;

		}
// 			nS.addClause_(cl);
		it++;
	}
	return subvariables;
}

std::vector<std::vector<int> > LoCEGSolver::makePermutations(std::vector<int> subvariables, int maxsub)
{
	std::vector<std::vector<int> > permutationen;
	for(unsigned int j = 0; j < subvariables.size(); j++)
	{
		std::vector<int> p;
		p.push_back(subvariables[j]);
		permutationen.push_back(p);
		p.clear();
	}

	bool breaker = (maxsub==1);
	while(!breaker)
	{
		std::vector<std::vector<int> > np;
		np.clear();
		for(size_t i = 0; i < permutationen.size() ; i++)
		{
			for(size_t j = 0; j < subvariables.size(); j++)
			{
				std::vector<int> p;
				copyVec(permutationen[i], p);
				//Lit l = mkLit(subvariables[j], true);
				if(!vecHas(subvariables[j], p))
				{
					p.push_back(subvariables[j]);


				}
				np.push_back(p);
				if(p.size()>=subvariables.size() || p.size() >= (size_t)maxsub || i > 100) breaker = true;
				p.clear();
			}
		}

		permutationen.swap(np);
		
		np.clear();
	}

	return permutationen;
}

void LoCEGSolver::solverInit(Solver &nS, std::vector<std::vector<Lit> > Lits)
{
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	while(it != Lits.end())
	{
		vec<Lit> cl;
		int     varl;
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
			cl.push((*it2));
			varl = var((*it2));
		/*	if(!vecHas(varl, subvariables))
			{
				subvariables.push_back(varl);
			} */
			while (varl >= nS.nVars()) nS.newVar();
			it2++;

		}
		nS.addClause_(cl);
		it++;
	}
}

void LoCEGSolver::calcSolutions(std::vector<int>& subvariables, int maxsub, std::vector<std::vector<Lit> >& Lits, std::vector<std::vector<int> >& solutions)
{
	double starttime = cpuTime();
	std::vector<std::vector<int> > permutationen;

	for(size_t j = 0; j < subvariables.size(); j++)
	{
		std::vector<int> p;
		p.push_back(subvariables[j]);
		if(isSat(Lits, p))
		{
			solutions.push_back(p);
		}
		permutationen.push_back(p);
		p.clear();
	}

	bool breaker = (maxsub==1);
	while(!breaker)
	{
		std::vector<std::vector<int> > np;
		for(size_t i = 0; i < permutationen.size() ; i++)
		{
			//Solver nS;
			//nS.verbosity = verbosity;
			//solverInit(nS, Lits);
			for(size_t j = 0; j < subvariables.size(); j++)
			{
				std::vector<int> p;
				copyVec(permutationen[i], p);
				//Lit l = mkLit(subvariables[j], true);
				if(!vecHas(subvariables[j], p))
				{
					p.push_back(subvariables[j]);
					if(isSat(Lits, p))
					{
						solutions.push_back(p);
					} else {
						np.push_back(p);
					}

				}

				if(p.size()>=subvariables.size() || p.size() >= (size_t)maxsub)
				{
					breaker = true;
				}
				if(cpuTime() -starttime  > 5*60)
				{
					return;
				}
			}
			if(cpuTime() -starttime  > 5*60)
			{
				return;
			}
		}

		permutationen.swap(np);
		
	}
	if(debugon){
		printf("[%s] Solutions done\n", _cat);
		fflush(stdout);
	}
}

bool LoCEGSolver::isSat(std::vector<std::vector<Lit > >& Lits, std::vector<int> sets)
{
	std::vector<std::vector<Lit> >::iterator it = Lits.begin();
	outer: while(it!=Lits.end())
	{
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
			for(size_t i = 0; i < sets.size(); i++)
			{
				if(abs(sets[i])==var(*it2) && sign(*it2)==(sets[i] < 0))
				{
					it++;
					goto outer; // Klausel erfuellt
				}
			}
			it2++;
		}
		return false; // Klausel nicht erfuellt
	}
	return true; // wenn es keine Klausel gibt die nicht erf�llt war, ist alles SAT
}





void LoCEGSolver::startLearn(int maxiters)
{
	// LoCEG LOOP wie im Paper

	double starttime = cpuTime();
	int maxclauses = 5;
	int maxsub = getModus();

	std::vector<int> dirties;

	analyseoccurs = new int[nVars()];

	for (int iters = 0; iters < maxiters; iters++)
	{

		std::vector<CRef> subinst;

		if(!analyse(dirties))
		{
			return;
		}
		subinst = getSubinstance(maxclauses);


		dirties.push_back(maxvar);


		std::vector<std::vector<Lit> > Lits = makeNeg(subinst);


		std::vector<int> subvariables = getSubvariables(Lits);
		std::vector<std::vector<int> > solutions;
		calcSolutions(subvariables, maxsub, Lits, solutions);


		std::vector<vec<Lit> > added;
		for(size_t j=0; j < solutions.size(); j++)
		{

			vec<Lit> nlits;


			for (size_t i = 0; i < solutions[j].size(); i++)
			{
				Lit l = (solutions[j][i]>0) ? ~mkLit(solutions[j][i]) : mkLit(solutions[j][i]);
				if(debugon)
					printf("[%s] %s%i ", _cat, (solutions[j][i]>0)?"-":"", abs(solutions[j][i]));// NEGIERT

				nlits.push( l );
			}


			if(nlits.size()>0)
			{
				addClause_(nlits);
			}
		}

		if(debugon)printf("[%s] Out Iteration %i %i\n", _cat,iters, maxiters);
		if(debugon)fflush(stdout);

		if( cpuTime() -starttime  > 5*60)
		{
			break;
		}
	}

	if(debugon)printf("[%s] loceg done\n", _cat);
	if(debugon)fflush(stdout);
}

void LoCEGSolver::makeAssumption(std::vector<int> vars, vec<Lit> &ret)
{

	for(unsigned int i = 0; i < vars.size(); i++)
	{
		Lit l = mkLit(vars[i], true);//vars[i]<0);
		ret.push(l);
	}
}

void LoCEGSolver::copyVec(std::vector<int> &in, std::vector<int> &out)
{
	for(unsigned int i = 0 ; i < in.size(); i++)
	{
		out.push_back(in[i]);
	}
}

bool LoCEGSolver::vecHas(int needle, std::vector<std::vector<Lit> > haystack)
{
	std::vector<std::vector<Lit> >::iterator it = haystack.begin();

	while(it!=haystack.end())
	{
		std::vector<Lit>::iterator it2 = (*it).begin();
		while(it2!=(*it).end())
		{
			if(var((*it2))==needle)
			{
				return true;
			}
			it2++;
		}
		it++;
	}
	return false;
}

bool LoCEGSolver::sameVec(vec<Lit>& l1, vec<Lit>& l2)
{
	if(l1.size()!=l2.size()) return false;
	for(int i = 0; i < l1.size(); i++)
	{
		if(l1[i]!=l2[i]) return false;
	}
	return true;
}

bool LoCEGSolver::vecHas(std::vector<vec<Lit> >& haystack, vec<Lit>& needle)
{
	std::vector<vec<Lit> >::iterator it = haystack.begin();

	while(it!=haystack.end())
	{
		for(int i = 0; i < (*it).size(); i++)
		{
			if(sameVec(it[i], needle))
				return true;
		}
		it++;
	}
	return false;
}

bool LoCEGSolver::vecHasNeg(Lit needle, std::vector<Lit> haystack)
{
	std::vector<Lit>::iterator it = haystack.begin();
	while(it!=haystack.end())
	{
		if(var((*it))==var(needle) && sign(needle) != sign((*it)))
		{
			return true;
		}
		it++;
	}
	return false;
}
bool LoCEGSolver::vecHas(int needle, std::vector<int> haystack)
{
	for(size_t i = 0; i < haystack.size(); i++)
	{
		if(abs(needle) == abs(haystack[i])) return true;
	}
	return false;
}

bool LoCEGSolver::vecHas(Lit needle, vec<Lit>& haystack)
{
	for(int i = 0; i < haystack.size(); i++)
	{
		if(var(haystack[i])==var(needle)) return true;
	}
	return false;
}



bool LoCEGSolver::vecHas(Lit needle, std::vector<Lit> haystack)
{
	std::vector<Lit>::iterator it = haystack.begin();
	while(it!=haystack.end())
	{
		if(var((*it))==var(needle) && sign(needle) == sign((*it)))
		{
			return true;
		}
		it++;
	}
	return false;
}
