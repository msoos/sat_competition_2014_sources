#!/bin/bash

mkdir -p binary
cd code

export FM=$PWD/sources/SatELite/ForMani
export MROOT=$PWD/sources/rokk

cp rokk.sh ../binary/rokk.sh
cp rokk_sat.sh ../binary/rokk_sat.sh

# Compile SatELite
cd sources/SatELite/SatELite
make r
cp SatELite_release ../../../../binary

# Compile rokk_static
cd ../../rokk/core
make rs
cp rokk_static ../../../../binary

# Compile rokk_release
cd ../simp
make rs
cp rokk_static ../../../../binary/rokk_sat

