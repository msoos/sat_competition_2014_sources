#!/bin/bash

mkdir binary 2>/dev/null

echo 'buidling hyperplane...'
cd code/hyperplane/
make
cd ../../
mv code/hyperplane/best_hyperplane binary

echo 'buidling minisat...'
cd code/minisat/
./build.sh
cd ../../
mv code/minisat/minisat2.2-hyper binary

echo 'buidling satelite...'
cd code/satelite/
./build.sh
cd ../../
mv code/satelite/SatELite_release binary

cp code/MSP.sh binary
