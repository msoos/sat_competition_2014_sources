MiniSAT with Speculative Preprocessing
==========

Solver version: 1.0


Authors
=======

Wenxiang Chen, Adele Howe, Darrell Whitley 


Usage
=====

Buidling binary files
----
./build.sh
cd binary
./MSP.sh <instance> <TMPDIR>


Cleaning
---
./clean.sh

Contact
=======

To contact the authors, please send an email to: 
chenwx@cs.colostate.edu

