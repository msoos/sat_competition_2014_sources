export MROOT=$PWD
cd simp
make
mv minisat ../minisat2.2-hyper
