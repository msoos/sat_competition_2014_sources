export FM=$PWD/ForMani

cd SatELite
make realclean
make r
cp SatELite_release ..
cd ..

