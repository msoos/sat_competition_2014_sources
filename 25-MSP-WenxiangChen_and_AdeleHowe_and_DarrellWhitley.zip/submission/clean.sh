#!/bin/bash

cd code/hyperplane/
make clean

cd ../minisat
./clean.sh

cd ../satelite/
./clean.sh

cd ../../
rm -r binary 2>/dev/null
