#!/bin/bash
export FM=$PWD/sources/SatElite/ForMani
rm -rf rokk_static 
rm -rf SatELite_release

cd sources/SatElite/SatELite
make clean 

cd ../../rokk/core
make clean 

find . -name 'depend.mak' -delete 
