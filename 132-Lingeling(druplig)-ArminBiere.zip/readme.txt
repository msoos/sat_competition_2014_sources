Lingeling SAT Solver Version azd-0d99752-140506

./configure.sh && make

This software is copyright 2010-2014, Armin Biere, JKU, Linz.  

This is only a restricted release of this software.

See 'COPYING' for more details on the permission to use this software.

All rights are reserved.  No warranty is implied.

Armin Biere
