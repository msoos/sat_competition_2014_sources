#!/bin/sh
rm -rf binary
mkdir binary
cd code/druplig
./configure.sh || exit 1
make || exit 1
cd ../lingeling
./configure.sh -O || exit 1
make lingeling
install -m 755 -s lingeling ../../binary
