#!/bin/sh
# Norbert Manthey, 2014
#
# script to clean the SAT solver MinitSAT
#

# remove binary directory
rm -rf binary

# clean 
cd code;
make clean

# return to calling directory
cd ..
