#!/bin/sh
# Norbert Manthey, 2014
#
# script to build the SAT solver MinitSAT
#

# setup binary directory
rm -rf binary
mkdir -p binary

cd code;
# build the solver
make clean
make rs

cp MinitSAT ../binary

# return to calling directory
cd ..
