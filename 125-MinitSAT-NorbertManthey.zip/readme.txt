MinitSAT. Norbert Manthey. 2014

================================================================================

This software package contains the SAT solver MinitSAT, a small modification of 
Minisat, which initializes the variable activities and polarities of the solver.

=== BUILDING: ==================================================================

	To build MinitSAT
	make rs

=== COMMON USE CASES: ==========================================================

MinitSAT can be used as MiniSAT. The initialization for the variables is done
only at the first call to the solve method, so that the modified solver can be
used incrementally as the plain Minisat.
