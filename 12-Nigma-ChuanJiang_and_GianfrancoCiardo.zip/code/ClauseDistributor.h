#ifndef _CLAUSEDISTRIBUTOR_HEADER
#define _CLAUSEDISTRIBUTOR_HEADER

#include <vector>

#include "Base.h"

using namespace std;

class ClauseDistributor {
private:
	static const size_t OCCUR_UPPER=8;

	unsigned long _mark;
	vector<unsigned long> _marks;
	vector<Literal> _resolvents;
	vector<size_t> _delimiters;

public:
	ClauseDistributor(size_t var_size);
	~ClauseDistributor();

	bool resolve(Variable var, const vector<ClausePtr>& poss, const vector<ClausePtr>& negs);
	void clear();

	// Used to get the resolvents in the distributor iteratively
	class iterator{
		friend class ClauseDistributor;

		private:
		const ClauseDistributor& _distributor;
		size_t _index;

		iterator(const ClauseDistributor& distributor);

		public:
		void get(vector<Literal>& clause);

		iterator& operator++()
		{
			_index++;
			return *this;
		}

		const iterator operator++(int)
		{
			ClauseDistributor::iterator itr(*this);
			++(*this);
			return itr;
		}

		bool operator==(const iterator& right)
		{
			return (&_distributor==&(right._distributor)) && (_index==right._index);
		}

		bool operator!=(const iterator& right)
		{
			return (&_distributor!=&(right._distributor)) || (_index!=right._index);
		}
	};

	friend class ClauseDistributor::iterator;

	iterator begin()
	{
		return ClauseDistributor::iterator(*this);
	}

	iterator end()
	{
		ClauseDistributor::iterator end(*this);
		end._index=_delimiters.size();
		return end;
	}
};

#endif
