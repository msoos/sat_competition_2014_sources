#ifndef _LITERALHEAP_HEADER
#define _LITERALHEAP_HEADER

#include <vector>

#include "Base.h"

using namespace std;

template <typename Comp>
class VariableHeap
{
private:
	static const int NOT_IN_HEAP=-1;

	static inline size_t left(size_t i)
	{
		return i*2+1;
	}

	static inline size_t right(size_t i)
	{
		return i*2+2;
	}

	static inline size_t parent(size_t i)
	{
		return (i-1)/2;
	}

	vector<int> _heap;
	vector<int> _indices;
	Comp lt;

	bool inline has_left(size_t index)
	{
		return left(index)<_heap.size();
	}

	bool inline has_right(size_t index)
	{
		return right(index)<_heap.size();
	}

	void percolate_down(int var_id)
	{
		int i=_indices[var_id];
		while (has_left(i)){
			int min_index = left(i);
			if (has_right(i)){  
				if (lt(_heap[right(i)], _heap[min_index])) {
					min_index = right(i);
				}  
			}  
			if (lt(_heap[min_index], var_id)) {
				_indices[_heap[min_index]]=i;
				_heap[i]=_heap[min_index];
				i=min_index;
			}
			else{
				break;
			}  
		}
		_indices[var_id]=i;
		_heap[i]=var_id;
	}

	void percolate_up(int var_id)
	{
		int i=_indices[var_id];
		int p=parent(i);
		while (i>0 && lt(var_id, _heap[p])){
			_indices[_heap[p]]=i;
			_heap[i]=_heap[p];
			i=p;
			p=parent(i);
		}
		_indices[var_id]=i;
		_heap[i]=var_id;
	}

public:
	VariableHeap(const Comp& c)
		: lt(c)
	{
	}

	~VariableHeap()
	{
	}

	void set_variable_size(int var_size)
	{
		_indices.assign(var_size+1, NOT_IN_HEAP);

		_heap.clear();
		_heap.reserve(var_size);

		for(int i=1; i<=var_size; i++){
			push(i);
		}
	}

	void push(int var_id)
	{
		if(!is_in_heap(var_id)){
			_indices[var_id]=_heap.size();
			_heap.push_back(var_id);
			percolate_up(var_id);
		}
	}

	void pop()
	{
		_indices[_heap[0]]=NOT_IN_HEAP;
		_heap[0]=_heap[_heap.size()-1];
		_indices[_heap[0]]=0;
		_heap.pop_back();
		percolate_down(_heap[0]);
	}

	void decrease(int var_id)
	{
		if(is_in_heap(var_id)){
			percolate_down(var_id);
		}
	}

	void increase(int var_id)
	{
		if(is_in_heap(var_id)){
			percolate_up(var_id);
		}
	}

	int top()
	{
		return _heap[0];
	}

	bool is_in_heap(int var_id) const
	{
		return _indices[var_id]!=NOT_IN_HEAP;
	}

	bool empty() const
	{
		return _heap.empty();
	}

	void dump(ostream& out) const
	{
		for(vector<int>::const_iterator itr=_heap.begin(); itr!=_heap.end(); itr++){
			out<<*itr<<"  ";
		}
		out<<endl;
	}
};

#endif
