#include <iostream>
#include <cassert>
#include <algorithm>

#include "Base.h"

using namespace std;

const Literal Literal::UNDEF;

ofstream& operator<<(ofstream& out, const Literal& literal)
{
	out<<(literal.phase()==P_POSITIVE ? "" : "-")<<literal.var();
	return out;
}

Allocator<ClausePool::UnitType> ClausePool::_allocator;

ClausePool::ClausePool()
{
}

ClausePtr ClausePool::create(const vector<Literal>& literals, bool is_learnt)
{
	ClausePtr ptr=static_cast<ClausePtr>(_allocator.create(calculate_clause_size(literals.size())));
	new (&_allocator[ptr]) Clause(literals, is_learnt);
	return ptr;
}

void ClausePool::free(ClausePtr ptr)
{
	Clause& clause=get(ptr);
	if(!clause.is_deleted()){
		clause.set_deleted();
		_allocator.free(ptr, calculate_clause_size(clause.size()));
	}
}

void ClausePool::reallocate(vector<ClausePtr>& clauses, vector<ClausePtr>& learnt_clauses)
{
	// Must guarantee that the clauses in vector are orderd by address ascending
	std::sort(learnt_clauses.begin(), learnt_clauses.end());

	ClausePtr clause_ptr=Allocator<UnitType>::MEM_BEGIN;

	for(vector<ClausePtr>::iterator itr=clauses.begin(); itr!=clauses.end(); itr++){
		Clause& clause=get(*itr);
		size_t size=calculate_clause_size(clause.size());
		if(clause_ptr!=*itr){
			assert(clause_ptr<*itr);
			_allocator.copy(clause_ptr, *itr, size);
			*itr=clause_ptr;
		}
		clause_ptr+=size;
	}

	for(vector<ClausePtr>::iterator itr=learnt_clauses.begin(); itr!=learnt_clauses.end(); itr++){
		Clause& clause=get(*itr);
		size_t size=calculate_clause_size(clause.size());
		if(clause_ptr!=*itr){
			assert(clause_ptr<*itr);
			_allocator.copy(clause_ptr, *itr, size);
			*itr=clause_ptr;
		}
		clause_ptr+=size;
	}

	_allocator.shrink(clause_ptr-Allocator<UnitType>::MEM_BEGIN);
}

double ClausePool::wasted_ratio()
{
	return (double)_allocator.wasted()/_allocator.size();
}

size_t ClausePool::memory_usage()
{
	return _allocator.capacity()*sizeof(UnitType);
}

void ClausePool::dump(ostream& out)
{
	_allocator.dump(out);
}
